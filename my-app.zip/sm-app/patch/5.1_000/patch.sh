#!/bin/sh

################
# Delete existing bucket
################

# exit script as soon as any command fails:
set -e

thisPatch="Patch Sprint 5.1"
echo "==========================="
echo "Running ${thisPatch}"
echo "==========================="

# Check environment variables
if [ -z "$STAGE" ]
then
    echo you must define STAGE environment variable
    exit 1
fi

if [ -z "$ASPIRE" ]
then
    echo you must define ASPIRE environment variable
    exit 1
fi

if [ -z "$AWS_REGION" ]
then
    echo you must define AWS_REGION environment variable
    exit 1
fi

aws s3api head-bucket --bucket s3-app-${ASPIRE}-${STAGE}-public-${AWS_REGION} || notfound=true
echo "bucket not found: $notfound"
if [ "$notfound" != "true" ]
then  
  echo 'delete bucket : ' s3-app-${ASPIRE}-${STAGE}-public-${AWS_REGION}
  aws s3 rb s3://s3-app-${ASPIRE}-${STAGE}-public-${AWS_REGION} --force
else
  echo "no bucket to delete"
fi

echo "successfull end of ${thisPatch}"