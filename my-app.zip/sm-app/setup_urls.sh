#!/bin/sh

set -e

if [ $# -ne 2 ]; then
    echo "Wrong parameter number."
    echo "Usage: $0 dev root_path"
    echo "Dev is the stage's name"
    echo "root_path is the root path of project"
    echo "Stop building project process."
    exit 1
fi

STAGE=$1 
ROOT=$2
# Copy url conf file to urls.json based on the stage where we'll deploy to
# Each stage (env) has the different url from another so check all urls out before deploying the project.
echo '===== Setup urls for side band'

file_path="$ROOT/conf/urls/${STAGE}.json"
if [ ! -f "$file_path" ]; 
then
    echo "File $file_path not found!"
    exit 1
fi

echo "Copy conf/urls/${STAGE}.json to client/dist/conf/urls"
mkdir -p ./client/dist/conf/urls
cp -f "$file_path"  client/dist/conf/urls/urls.json