#!/bin/bash

JIRA_LOGIN=$1
JIRA_PASSWORD=$2
JIRA_URL='https://jiralab.fr.capgemini.com'
EXPORT_OPTS=$3

rm -rf tmp
mkdir tmp

# AUTHENT
JSESSIONID=$(curl -k -i $JIRA_URL/login.jsp | grep 'JSESSIONID' | awk -F '=' '{print  $2}' | awk -F ';' '{print  $1}')
[ -z "$JSESSIONID" ] && echo 'Error Accessing JIRA' && exit 1
echo $JSESSIONID

curl -i -k $JIRA_URL'/rest/gadget/1.0/login' -H "Cookie: JSESSIONID=$JSESSIONID" --data 'os_username='$JIRA_LOGIN'&os_password='$JIRA_PASSWORD --compressed > auth_response.log

JSESSIONID=$(cat auth_response.log | grep 'JSESSIONID=' | awk -F '=' '{print  $2}' | awk -F ';' '{print  $1}')
[ -z "$JSESSIONID" ] && echo 'Error authenticating' && exit 1
echo $JSESSIONID

# EXPORT
curl -i -k -H "Cookie: JSESSIONID=$JSESSIONID" $JIRA_URL'/rest/raven/1.0/export/test?'$EXPORT_OPTS -o tmp/features.zip

cd tmp
unzip features.zip

# Translate french words to english ones
sed -i 's/#language: fr//g' *.feature
sed -i 's/Fonctionnalité/Feature/g' *.feature
sed -i 's/Contexte:/Background:/g' *.feature
sed -i 's/Scénario:/Scenario:/g' *.feature
cat *.feature

# TESTS
# npm run e2e

# PUSH REPORT
#curl -H "Content-Type: application/json" -X POST -H "Cookie: JSESSIONID=$JSESSIONID" --data @reports/cucumber.json $JIRA_URL/rest/raven/1.0/import/execution/cucumber
