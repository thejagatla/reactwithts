module.exports.mainJsPath = () => {
  // Code that generates dynamic data to force the custom resource update
  var fs = require('fs');
  var assets = JSON.parse(fs.readFileSync('client/dist/asset-manifest.json', 'utf8'));
  return assets['main.js'];
}
