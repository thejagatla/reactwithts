#!/bin/bash

# Configure aws credentials from CodeBuild environment and provided role to assume as argument of the script
# References :
# https://aws.amazon.com/fr/blogs/security/a-new-and-standardized-way-to-manage-credentials-in-the-aws-sdks/
# http://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_temp_use-resources.html#using-temp-creds-sdk-cli

if [ $# != 2 ]
then
  echo "Error : this script requires 2 arguments."
  echo "Usage: "$(basename $0)" <profile name> <role arn>"
  echo ""
  exit 1
fi

# retrieve current codebuild credentials
curl 169.254.170.2$AWS_CONTAINER_CREDENTIALS_RELATIVE_URI > tmp_credentials.json
ACCESS_KEY_ID=$(cat tmp_credentials.json | awk -F '"' '{print $8}')
SECRET_ACCESS_KEY=$(cat tmp_credentials.json | awk -F '"' '{print $12}')
TOKEN=$(cat tmp_credentials.json | awk -F '"' '{print $16}')
rm -f tmp_credentials.json

# build an .aws/credentials file
mkdir -p ~/.aws
echo "[default]" > ~/.aws/credentials
echo "aws_access_key_id = $ACCESS_KEY_ID" >> ~/.aws/credentials
echo "aws_secret_access_key = $SECRET_ACCESS_KEY" >> ~/.aws/credentials
echo "aws_session_token = $TOKEN" >> ~/.aws/credentials
echo "region = $AWS_REGION" >> ~/.aws/credentials
echo '' >> ~/.aws/credentials
echo '' >> ~/.aws/credentials

# then add the role to assume
# first arg is the name of the profile
# second arg is the role arn to be used for the profile
echo "[$1]" >> ~/.aws/credentials
echo "role_arn = $2" >> ~/.aws/credentials
echo 'source_profile = default' >> ~/.aws/credentials
echo '' >> ~/.aws/credentials

cat ~/.aws/credentials | sed -e 's/aws_secret_access_key = .*/aws_secret_access_key
= xxxxx/g'
export AWS_CONTAINER_CREDENTIALS_RELATIVE_URI=
export AWS_PROFILE=$1
