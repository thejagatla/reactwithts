//============================================================
// Script to execute from  the pipeline or the local console
// IMPORTANT: var AWS = require('aws-sdk'); is not used because aws-sdk is not available in the pipeline exec context
//            So, we use AWS CLI from node instead
//
// Arguments:
//    --stage <stage> the name of the stage
//=============================================================
const { exec } = require('child_process');

// Log a exec command error
function displayError(err, stdout, stderr) {
    console.log('Error code ' + err);
    console.log('stdout:\n' + stdout);
    console.log('stderr:\n' + stderr);
    process.exit(1);
}

// Return the cognito configuration as a typescript / javascript piece of code
function getConfigAsTsxSourceCode(config, minified) {
    var margin = '  ';
    var eol = "\n";
    var sp = ' ';
    if (minified) {
        margin = '';
        eol = '';
        sp = '';
    }
    return `cognitoConfig${sp}=${sp}{${eol}` +
        `${margin}clientId:${sp}'${config.clientId}',${eol}` +
        `${margin}identityPool:${sp}'${config.identityPool}',${eol}` +
        `${margin}region:${sp}'${config.region}',${eol}` +
        `${margin}userPool:${sp}'${config.userPool}'${eol}` +
        `};${eol}`;
}

// Patch the Cognito configuration in the distribution artifact
function patchCognitoConfig(config) {
    var fs = require('fs')
    var directoryPath = /*require('path').normalize(*/process.cwd() + '/client/dist/static/js'/*)*/;
    var files = fs.readdirSync(directoryPath);
    for (var i = 0, len = files.length; i < len; i++) {
        if (/^main\.[a-z0-9]+\.js$/.test(files[i])) {
            var filePath = process.cwd() + `/client/dist/static/js/${files[i]}`;
            fs.readFile(filePath, 'utf8', function (err,data) {
                if (err) {
                    return console.log(err);
                }
                else {
                    var re = new RegExp('\.cognitoConfig={[^{}]*}', 'g');
                    var replacement = '.' + getConfigAsTsxSourceCode(config, true);
                    var result = data.replace(re, replacement);
                    fs.writeFile(filePath, result, 'utf8', function (err) {
                        if (err) return console.log(err);
                    });
                    console.log(`The Cognito configuration is patched in ${filePath}`);
                }
            });
        }
    }
}

// Generate the cognito configuration
function generateCognitoConfig(config) {
    // Generate the src/config/cognitoConfig.tsx exporting the Cognito Config
    var fs = require('fs');
    var filePath = process.cwd() + '/src/config/cognitoConfig.tsx';
    if (fs.existsSync(filePath)) {
      var stream = fs.createWriteStream(filePath);
      var replacement = getConfigAsTsxSourceCode(config, false);
      stream.once('open', function(fd) {
          stream.write(`export const ${replacement}`);
          stream.end();
      });
      console.log('The Cognito configuration is updated in ' + filePath);
    } else {
      console.log('Warning: File ' + filePath + ' does not exist, so it is not patched');
    }

}

// Get details on the retrieved identity pool
function processCognitoPool(idPool) {
    exec('aws cognito-identity describe-identity-pool --identity-pool-id "' + idPool + '"', {env: process.env}, (err, stdout, stderr) => {
        var cognitoConfig = {
            clientId: 'undefined',
            identityPool: 'undefined',
            region: 'undefined',
            userPool: 'undefined'
        };
        if (err) displayError(err, stdout, stderr)
        else {
            var data = JSON.parse(stdout);
            // set the identityPool value
            cognitoConfig.identityPool = data.IdentityPoolId;
            // set the clientId value
            if (data.CognitoIdentityProviders.length == 1) {
                // get the first in the list
                var idp = data.CognitoIdentityProviders[0];
                cognitoConfig.clientId = idp.ClientId;
                cognitoConfig.region = 'eu-west-1';
                cognitoConfig.userPool = idp.ProviderName.split('/')[1];
            }
        }
        console.log('The Cognito configuration for update is:');
        console.dir(cognitoConfig);

        // Update the Cognito configuration in the source code (Not done by the pipeline)
        generateCognitoConfig(cognitoConfig);

        // Patch the Cognito configuration in the distribution artifact
        patchCognitoConfig(cognitoConfig);
    });
}

// Read the list of Identity User Pools in the AWS account
function setAppCognitoConfiguration(stage) {
    exec('aws cognito-identity list-identity-pools --max-results 60', {env: process.env}, (err, stdout, stderr) => {
        if (err) displayError(err, stdout, stderr)
        else {
            var data = JSON.parse(stdout);
            var re = new RegExp('^.*' + stage + '$');
            for (var i = 0, len = data.IdentityPools.length; i < len; i++) {
                var identityPool = data.IdentityPools[i];
                if (re.test(identityPool.IdentityPoolName)) {
                    processCognitoPool(identityPool.IdentityPoolId);
                    break;
                }
            }
        }
    });
}

//==============================================
// Main
//==============================================

// Arguments checkup

// TODO check null
var stage =  process.argv[2] || 'dev';
console.log("Using stage " + stage);
/*
var args = require('minimist')(process.argv);
if (args.stage == null) {
    console.log(args._[1] + ': --stage parameter not found or empty, ' + stage + ' is used');
}
else {
    stage = args.stage
}
*/

// Main launching the configuration update
setAppCognitoConfiguration(stage);
