module.exports.deploymentTimestamp = () => {
   // Code that generates dynamic data
   return Date.now();
}
