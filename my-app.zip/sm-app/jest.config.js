module.exports = {
  globals: {
    'ts-jest': {
      skipBabel: true
    }
  },
  mapCoverage: true,
  // collectCoverage commented to avoid coverage collect when developing
  // collectCoverage: true,
  // sonarqube-scanner throws LCOV report errors
  // when activating coverage on all files with collectCoverageFrom
  // (to cover the not tested ones too)
  // collectCoverageFrom: [
  //  "src/**/*.ts?(x)"
  // ],
  moduleFileExtensions: ['js', 'ts', 'tsx'],
  moduleNameMapper: {
    "\\.(jpg|jpeg|png|svg|css|scss)$": "<rootDir>/__tests__/stubs/fileStub.js",
    "\\c3(.*)$": "<rootDir>/__tests__/stubs/c3Stub.js"
  },
  setupFiles: [ "<rootDir>/__tests__/setupTests.ts" ],
  transform: {
    '^.+\\.(ts|tsx)?$': '<rootDir>/node_modules/ts-jest/preprocessor.js'
  },
  testMatch: ['**/__tests__/**/*.(spec|test).ts?(x)', '**/?(*.)(spec|test).ts?(x)']  
};
