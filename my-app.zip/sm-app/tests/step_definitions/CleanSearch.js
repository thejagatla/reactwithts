const { client } = require('nightwatch-cucumber');
const { defineSupportCode } = require('cucumber');

defineSupportCode(({ Given, Then, When }) => {
    
    const eventsBoard = client.page.eventsBoard();

    Then(/^I expect the clean search button is active$/, () => {
        return eventsBoard.assert.elementPresent('@clearSearchButtonActive');
    });

    Then(/^I expect the clean search button is not active$/, () => {
        return eventsBoard.assert.elementNotPresent('@clearSearchButtonActive');
    });

    Then(/^I expect the search button is active$/, () => {
        return eventsBoard.assert.elementPresent('@searchButtonActive');
    });

    Then(/^I expect the search button is not active$/, () => {
        return eventsBoard.assert.elementNotPresent('@searchButtonActive');
    });

});