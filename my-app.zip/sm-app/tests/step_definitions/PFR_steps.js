const { client } = require('nightwatch-cucumber');
const { defineSupportCode } = require('cucumber');
const { generateMessage,generateCFRMessage,generateEmptyCFRMessage, generateMessageDuplicateFM, generateEmptyMessage, injectMessage, injectMessageAfterCannibal, normalize, attribute, time } = require('../support/messages');
// const { getLatestLogStreamName, isLogMessageExists } = require('../support/cloudWatchLogs');
const { expectedOH } = require('../support/normalization');
const TIME_WAIT_INJECTION = 1000;

defineSupportCode(({ Given, Then, When }) => {
  const eventsBoard = client.page.eventsBoard();
  const eventsSHM = eventsBoard.section.eventsSHM;
  //GIVENS
  Given(/^a new PFR message containing a (.*) with the following characteristics :*$/, (name, dataTable) => {
    this.message = generateMessage(dataTable.rowsHash(), name);
  });

  Given(/^a new PFR message containing three fault messages.*$/, dataTable => {
    this.message = generateMessageDuplicateFM(dataTable.rowsHash());
  });

  Given(/^a second PFR message containing a (.*) with same acid :.*$/, (name, dataTable) => {
    this.message = generateMessage(dataTable.rowsHash(), name);
  });

  Given(/^a new empty PFR message.*$/, (dataTable) => {
    this.message = generateEmptyMessage(dataTable.rowsHash());
  });

  Given(/^a second empty PFR message.*$/, dataTable => {
    this.message = generateEmptyMessage(dataTable.rowsHash());
  });

  Given(/^a new CFRmessage with the following characteristics :*$/, (dataTable) => {
    this.message = generateCFRMessage(dataTable.rowsHash());
  });

  Given(/^an already injected PFR message containing a (.*) with following characteristics:*$/, (name, dataTable) => {
    console.log("name =" + name);
    this.message = generateMessage(dataTable.rowsHash(), name);
    return injectMessage(this.message),
      client.pause(TIME_WAIT_INJECTION);
  });

  Given(/^an already injected CFR message containing a (.*) with following characteristics:*$/, (name, dataTable) => {
    console.log("name =" + name);
    this.message = generateCFRMessage(dataTable.rowsHash());
    console.log(this.message);
    return injectMessage(this.message),
      client.pause(TIME_WAIT_INJECTION);
  });

  Given(/^an already injected PFR message send after Cannibal with a (.*) with following characteristics:*$/, (name, dataTable) => {
    console.log("name =" + name);
    this.message = generateMessage(dataTable.rowsHash(), name);
    return injectMessageAfterCannibal(this.message),
      client.pause(TIME_WAIT_INJECTION);
  });

  Given(/^an already injected new empty PFR message.*$/, dataTable => {
    this.message = generateEmptyMessage(dataTable.rowsHash());
    return injectMessage(this.message),
      client.pause(TIME_WAIT_INJECTION);
  });

  Given(/^a less of (.*) hours oldest PFR message containing a (.*) with the following datas.*$/, (period, name, dataTable) => {
    this.message = generateMessage(dataTable.rowsHash(), name);
    //date modification
    var date = new Date();
    date.setHours(date.getHours() - (period - 4));
    this.message.transmissionDate = date.toISOString().split('.')[0] + 'Z';
    this.message.warnings[0].transmissionDate = date.toISOString().split('.')[0] + 'Z';

    return injectMessage(this.message),
      client.pause(TIME_WAIT_INJECTION);
  });

  Given('{int} already injected new empty PFR message :', (number, dataTable, callback) => {
    var result = [];
    var i = 1;
    var interval = setInterval(function () {
      console.log('Injection empty message number ==> ' + i);
      this.message = generateEmptyMessage(dataTable.rowsHash());
      result.push(injectMessage(this.message));
      if (i === number) {
        clearInterval(interval);
        setTimeout(function () {
          callback();
        }, 1200);
      }
      i++;
    }, 2000);
    return result;
    setTimeout(callback, 3);
  });

  Given('{int} already injected new CFR message :', (number, dataTable, callback) => {
    var result = [];
    var i = 1;
    var interval = setInterval(function () {
      console.log('Injection new CFR message number ==> ' + i);
      this.message = generateCFRMessage(dataTable.rowsHash());
      result.push(injectMessage(this.message));
      if (i === number) {
        clearInterval(interval);
        setTimeout(function () {
          callback();
        }, 1200);
      }
      i++;
    }, 2000);
    console.log(this.message);
    return result;
    setTimeout(callback, 3);
  });

  Given('{int} already injected new empty PFR message send after Cannibal:', (number, dataTable, callback) => {
    var result = [];
    var i = 1;
    var interval = setInterval(function () {
      console.log('Injection empty message number ==> ' + i);
      this.message = generateEmptyMessage(dataTable.rowsHash(), 'CMSempty');
      result.push(injectMessageAfterCannibal(this.message));
      if (i === number) {
        clearInterval(interval);
        setTimeout(function () {
          callback();
        }, 1100);
      }
      i++;
    }, 2000);
    return result;
    setTimeout(callback, 3);
  });

  //WHENS
  When('this message is injected into Skywise HM', () => {
    return injectMessage(this.message);
  });

  When(/^I search the message with the search bar$/, () => {
    return eventsBoard.searchFor(this.message.acid);
  });

  When(/^I search the text of message with the search bar$/, () => {
    return eventsBoard.searchFor(this.message.text);
  });

  When('this CFRmessage is injected into Skywise HM', () => {
    return injectMessage(this.message);
  });

  //THENS
  Then(/^I expect to see this message in the list of events$/, () => {
    client.pause(2000);
    return eventsSHM.assert.containsText('@eventFTail', this.message.acid);
  });

  Then(/^I expect to find the message displaying with the (.*) on the board$/, elementToSee => {
    client.pause(1000);
    const normalized = normalize(elementToSee);
    const attributed = attribute(elementToSee).toString();

    return eventsSHM.assert.containsText('@' + normalized, this.message.faultMesages[0][attributed])
  });

  Then(/^I expect to find the message displaying with the status (.*)$/, statusDisplayed => {
    return eventsSHM.assert.containsText('@eventStatus', statusDisplayed)
  });

  Then(/^I expect to find a comment area$/, () => {
    client.pause(1000);
    return eventsSHM.expect.element('@eventComment').to.be.present;
  });

  Then(/^The OH is (.*)$/, stringOH => {
    const tabOH = expectedOH(stringOH);
    return eventsBoard.checkOH(tabOH);
  });

  // //THENS
  // Then(/^I expect to find messageId in my logs$/, () => {
  //   var messageId = this.message.messageId;
  //   return getLatestLogStreamName(messageId).then(// On affiche un message avec la valeur
  //     (result) => {
  //       //var messageId = "414d51205346502e4d422e514d312020518c8a5a026c0020";
  //       var message1 = "s3 object has been created";
  //       var logStreamTest = "i-009fca95585f524bd-cannibal";
  //       return isLogMessageExists(result.logStreamName, result.messageId).then(
  //         (isExists) => {
  //           return isExists;
  //         }).catch(
  //         // Promesse rejetée
  //         () => { 
  //           console.log("promesse isLogMessageExists rompue");
  //         });
  //     }).catch(
  //       // Promesse rejetée
  //       function(err) { 
  //         console.log(err, err.stack);
  //         console.log("promesse getLatestLogStreamName rompue");
  //       }).then( (isExists) => {
  //         if(!isExists) {
  //           throw new Error('The message with ' + this.message.messageId + ' and aircraft familly ' + this.message.aircraftType + ' not found in logs');
  //         }
  //     });
  // });

  /**
 
   Then(/^I expect to find the message displaying with date$/, elementToSee => {
     client.pause(1000);
     const date = time(this.message.faultMesages[0].transmissionDate).date;
     return  eventsSHM.assert.containsText('@eventDate', date)
   });
 
   Then(/^I expect to find the message displaying with time$/, elementToSee => {
     client.pause(1000);
     const time = time(this.message.faultMesages[0].transmissionDate).time;
     return  eventsSHM.assert.containsText('@eventTime', time)
   });
 
   */
});
