const { client } = require('nightwatch-cucumber');
const { defineSupportCode } = require('cucumber');
const config = require('../support/config');

/*GET authorized aircraft 4 current user */
let promiseEndPoint = require('../support/aircraftsListPerUser').promiseEndPoint;


/*Load and configure log4js */
const log4js = require('log4js');
log4js.configure({
  appenders: {
    out: { type: 'stdout' },
    app: { type: 'file', filename: '../../application.log' }
  },
  categories: {
    default: { appenders: [ 'out', 'app' ], level: 'info' }
  }
})
const logger = log4js.getLogger();

// intersect(tailNumbersFromDashboard, tailNumbersFromSaZ);
/*Return elements who are present in both array  */
function intersect(arrayLeft, arrayRight) {
    var d1 = {};
    var d2 = {};
    var results = [];
    console.log("Array from dashboard : ", arrayLeft);
    console.log("Array from api saz : ", arrayRight);
    if( (arrayLeft.length !== 0)  && (arrayRight.length !== 0)){
        for (var i = 0; i < arrayLeft.length; i++) {
            d1[arrayLeft[i]] = true;
        }
        for (var j = 0; j < arrayRight.length; j++) {
            d2[arrayRight[j]] = true;
        }
        for (var k in d1) {
            if (d2[k]) 
                results.push(k);
        }
    }else{   
        throw new Error ("We should have some values in both array from apiSAZ and dashboard" );
    }

    return results;
}

 /*Verify than valueNotExpected ot in dashoard */
function isAcidInArraySaz(valueExpected,arrayToCheck){
    var result = arrayToCheck.indexOf(valueExpected);
    if(result === -1 ){
        console.log("Error on this current value {", valueExpected ,"}");
         throw new Error ("Value should not be present in dashboard" );
    }else{
        console.log("Find acid in result of api saz array {"+ valueExpected + "} ");
    }
}

let valueNotExpectedInDashboard = "F-TEST";


//uid
var REPLACE_BY = "" ;
var PATTERN = "@airbus.com" ;
var uid =  config.users['SPM-EZY-USER-01_TEST'].login ;
uid = uid.replace(PATTERN,REPLACE_BY);

var applications="SHM";
var aircrafts="ALL";

const EXPECTED_7_ITEMS = "7";
const EXPECTED_0_ITEM = "0";

defineSupportCode(({ Given, Then, When }) => { 
        const oneloginPage = client.page.oneLoginPage();
        const eventsBoard = client.page.eventsBoard();


        Given(/^I enter the url of Skywise Health Monitoring$/,() => {
            // navigate to oneLoginPage
            // logger.info("Navigate to one login page -> " + oneloginPage.url);
            console.log("Navigate to one login page -> " + oneloginPage.url);

            
            return oneloginPage.navigate();  
        });

        Given(/^I redirect to onelogin page "(.*)"$/, (urlLoginPage)  => {
            client.pause(2000);
            // logger.info("Compare this url --> " ,urlLoginPage);
            console.log("Compare this url --> " ,urlLoginPage);
  
            return client.url((result) => {
                //Check is onelogin page
                // logger.info("With ->" , result.value);
                console.log("With ->" , result.value);
                client.assert.equal(result.value, urlLoginPage, 'Url must be the same');
            });
        });

        When(/^I fill the form on login page with my login details for user SPM_EZY_USER_TEST$/, () =>  {
        // enter credentials and click
            return oneloginPage.waitForElementVisible('@logoAirbus', 5000).then(() => {
                client.pause(2000);
                return oneloginPage.login('SPM-EZY-USER-01_TEST').then(() => {
                    client.pause(2000);
                })
            });
            
        });
            
        Then(/^I redirect and now logged on the Skywise Health Monitoring Board of events$/, () =>  {
            return eventsBoard.waitForElementVisible('@dashboard', 5000).then(() => {
                client.pause(6000);
            });
        
        });          

        Then(/^the SPM_EZY_USER_TEST user name is well displayed$/, () => {
            var userNameParam =  config.users['SPM-EZY-USER-01_TEST'].login ;
            return eventsBoard.assert.containsText('@userName', userNameParam.toLowerCase() );        
        });
        
        Then(/^I disable filters$/,  () =>  {
            return eventsBoard.xfiltersActivation('true');
        });

        Then(/^I can see the aircrafts for the user SPM_EZY_USER_TEST "(.*)"$/, (acid)  => {
            
        return eventsBoard.waitForElementVisible('@eventsCounter', 5000).then(() => { 
                    // logger.info("ACID TO FIND ",acid);
                    console.log("Parameter acid to find in dashboard {",acid,"}");
                    var tailNumbersFromDashboard = [];
                    let object = {} ;
                    let objectIntern = {} ;
                    let tailNumberArray = [] ;
                    let tailNumbersFromSaZ = [];

                    //Fisrt get all acid number from dashboard
                    //Call api usersAircrafts
                    // wait 4 loading events
                    client.pause(6000);

                    //search G-EZUD
                    eventsBoard.searchFor(acid);
                    client.pause(2000);
                    eventsBoard.assert
                        .visible('@eventsCounter')
                        .assert.containsText('@eventsCounter', EXPECTED_7_ITEMS );  

                    // F-TEST   should not be find in dashborad     
                    eventsBoard.searchFor(valueNotExpectedInDashboard);           
                    client.pause(2000);
                    eventsBoard.assert
                            .visible('@eventsCounter')
                            .assert.containsText('@eventsCounter', EXPECTED_0_ITEM );  

                    client.pause(4000);

                    // uid, applications, aircrafts --> "SPM-EZY-USER-01.test","SHM","ALL"
                    promiseEndPoint(uid,applications,aircrafts).then(
                                result => { 
                                    objectIntern.status = result.status ;
                                    objectIntern.response = result.body ; 
                                },
                                reject => {  logger.info("REJECT ", error); }
                            ).then(
                                () => { 
                                    console.log("Then result -->>", objectIntern ) ;
                            
                                    obj = JSON.parse(objectIntern.response);
                                    // logger.info("application " , obj.fineAuthorizations[0].application);
                                    // logger.info("aircrafts " , obj.fineAuthorizations[0].aircrafts);

                                    console.log("application " , obj.fineAuthorizations[0].application);
                                    console.log("aircrafts " , obj.fineAuthorizations[0].aircrafts);
                        
                                    //TODO BEFORE: check if aircrafts != 0
                                    obj.fineAuthorizations[0].aircrafts.forEach(function(element) {
                                        tailNumberArray.push(element.tailNumber);
                                    });
                            
                                    tailNumberArray.forEach(function(element) {
                                        // logger.info("TAIL_NUMBER = " , element); 
                                        console.log("TAIL_NUMBER = " , element);
                                        tailNumbersFromSaZ.push(element);
                                    });

                                    //Compare than this value not in dashboard
                                    isAcidInArraySaz(acid,tailNumbersFromSaZ);
                                } 
                            );//end then of promise


        });

            






        });

});    