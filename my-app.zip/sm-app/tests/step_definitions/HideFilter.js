const { client } = require('nightwatch-cucumber');
const { defineSupportCode } = require('cucumber');
const { normalize } = require('../support/normalization');

defineSupportCode(({ Given, Then, When }) => {
  const eventsBoard = client.page.eventsBoard();
  const eventsSHM = eventsBoard.section.eventsSHM;

  // to test that the filter are present in the dashbord
  Then(/^I expect to see all filter in the DashBoard$/, () => {
    return eventsBoard.expect.element('@filter').to.be.visible;
  });
  // to test that the HideButton is present in the dashbord
  Then(/^I expect that there is a hideButton in the DashBoard$/, () => {
    return eventsBoard.expect.element('@hideToggele').to.be.visible;
  });
  // to test that the filter are NOT present in the dashboard, I check the presence of one classe !!!
  Then(/^I expect that there all filter are not present in the dashboard$/, () => {
    return eventsBoard.expect.element('@hidenFilter').to.be.present;
  });
  // to test that the hideButton is up in the dashbord
  Then(/^I expect to see the hideButton is UP in the Dahsboard$/, () => {
    return eventsBoard.assert.elementPresent('@ToggeleUp');
  });
  // to test that the hideButton is Down in the dashbord
  Then(/^I expect to see the hideButton DOWN in the dashboard$/, () => {
    return eventsBoard.assert.elementPresent('@ToggeleDown');
  });
  When(/^I click in the hideButton$/, () => {
    return eventsBoard.click('@hideToggele');
  });

});