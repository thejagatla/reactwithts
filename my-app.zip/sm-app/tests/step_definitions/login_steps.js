const { client } = require('nightwatch-cucumber');
const { defineSupportCode } = require('cucumber');
const config = require('../support/config');

defineSupportCode(({ Given, Then, When }) => {
  const loginPage = client.page.loginPage();
  const eventsBoard = client.page.eventsBoard();
  const eventPage = client.page.spmEventDetails();

  // GIVENS
  Given(
    /^I am a user on the Skywise Health Monitoring Board of events$/,
    () => {
      return loginPage.navigate().waitForElementVisible('@login', 5000).then(function () {
        client.pause(2000);
        return loginPage.login('tester').then(function () {
          return eventsBoard.waitForElementVisible('@dashboard', 5000);
        })
      });
    }
  );

  Given(
    /^I am on the Skywise Health Monitoring Login page$/,
    () => {
      return loginPage.navigate().waitForElementVisible('@login', 5000);
    }
  );

  Given(
    /^I am a user on the Skywise Predictive Maintenance event page$/,
    () => {
      return loginPage.navigate().waitForElementVisible('@login', 5000).then(function () {
        return loginPage.login('tester').pause(2000).then(function () {
          return eventPage.navigate().waitForElementVisible('#eventDetailsPage', 5000);
        })
      });
    }
  );

  Given(
    /^I am a now logged on the Skywise Health Monitoring Board of events$/,
    () => {
      return eventsBoard.navigate().waitForElementVisible('@dashboard', 5000);
    }
  );

  // WHENS
  When(/^I fill the form with my login details for user '(.*)'$/, username => {
    return loginPage.login(username);
  });

  When(/^I click on the logout button of the dashboard$/, () => {
    return eventsBoard.click('@dropdownUserMenu')
      .click('@logout');
  });

  //THENS
  Then(/^the '(.*)' user name is well displayed$/, username => {
    return eventsBoard.assert.containsText('@userName', config.users[username].login);
  });
});
