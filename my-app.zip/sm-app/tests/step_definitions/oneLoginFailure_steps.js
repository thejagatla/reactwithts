const { client } = require('nightwatch-cucumber');
const { defineSupportCode } = require('cucumber');
const config = require('../support/config');

/*GET authorized aircraft 4 current user */
let promiseEndPoint = require('../support/aircraftsListPerUser').promiseEndPoint;


/*Load and configure log4js */
const log4js = require('log4js');
log4js.configure({
  appenders: {
    out: { type: 'stdout' },
    app: { type: 'file', filename: '../../application.log' }
  },
  categories: {
    default: { appenders: [ 'out', 'app' ], level: 'info' }
  }
})
const logger = log4js.getLogger();


defineSupportCode(({ Given, Then, When }) => { 
        const oneloginPage = client.page.oneLoginPage();
        const eventsBoard = client.page.eventsBoard();


        When(/^I entering wrong identifiers in the form$/, () =>  {
        // enter credentials and click
        return oneloginPage.navigate().waitForElementVisible('@logoAirbus', 5000).then(() => {
            client.pause(2000);
            return oneloginPage.fakeLogin('FAKE_CREDENTIALS').then(() => {
                 client.pause(2000);
            })
          });
            
        });

        Then(/^I have an error message "(.*)"$/, (errorMessage) => {
            return  eventsBoard.assert.containsText('@ErrorMessageOneLogin', errorMessage);
        // //*[@id="errors"]/div/text()
        // text()
        /*    return  client.useXpath()
            .getText("//*[@id='errors']/div", (result) => {
                console.log("Invalid text " , result );
            }).then(() => {
                //  Invalid username or password
                // #errors .error-message
            }) ;
        */
        });



});    