const { client } = require('nightwatch-cucumber');
const { defineSupportCode } = require('cucumber');

defineSupportCode(({ Given, Then, When }) => {
    const fleetsweepFBoard = client.page.fleetsweepFBoard();

    When(/^I click on the (.*) tab of the Other Filter panel$/, filterId => {
        return fleetsweepFBoard.click('@PERIOD');
    });

    Then(/^I select (.*) hours$/, hours => {
        return fleetsweepFBoard.click('@PERIOD_' + hours);
    });

    Then(/^I apply this filter$/, () => {
        return fleetsweepFBoard.click('.ds-filter-choices--inner .ds-form-group-submit .ds-button--primary-1');
    });  
});