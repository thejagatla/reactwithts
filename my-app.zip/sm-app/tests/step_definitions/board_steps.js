const { client } = require('nightwatch-cucumber');
const { defineSupportCode } = require('cucumber');
const { normalize } = require('../support/normalization');

defineSupportCode(({ Given, Then, When }) => {
  const eventsBoard = client.page.eventsBoard();
  const eventsSHM = eventsBoard.section.eventsSHM;

  // GIVENS
  Given(/^filters are disable$/, () => {
    return eventsBoard.filtersActivation('true');
  });

  Given(/^filters are activated$/, () => {
    return eventsBoard.filtersActivation('false');
  });

  // WHENS
  When('I wait for {int} seconds', timeInSeconds => {
    return client.pause(timeInSeconds * 1000);
  });

  When(/^I sort the list of events by (.*)$/, column => {
    return 'pending';
  });

  When(/^I search for the terms "([^"]*)"$/, searchTerms => {
    return eventsBoard.searchFor(searchTerms);
  });

  When(/^I search for the exact terms "([^"]*)"$/, searchTerms => {
    return eventsBoard.searchFor('"' + searchTerms + '"');
  });

  When(/^I fill the search terms "([^"]*)"$/, searchTerms => {
    return eventsBoard.fillSearchField(searchTerms);
  });

  When(/^I click on the clear search button$/, () => {
    return eventsBoard.click('@clearSearchButton');
  });
   // To test when I click on 1 suggesion of the dropdownlist
   When(/^I click on the term in the list of suggestions "([^"]*)"$/, text => {
    return eventsBoard.click('@' + text);
  });
  // To test If the date is displayed well in the dashBord
  When(/^I expected to see the date of the event$/, () => {
    return eventsBoard.expect.element('@eventDate').to.be.visible;
  });

  // THEN (expectations)
  Then(/^the list of events is sorted by (.*)$/, column => {
    return 'pending';
  });

  Then(/^the titlebar is "([^"]*)"$/, title => {
    return client.assert.title(title);
  });

  Then(/^I expect to see the (.*) on the board$/, elementToSee => {
    const normalized = normalize(elementToSee);
    client.pause(1000);
    return eventsBoard.expect.element('@' + normalized).to.be.visible;
  });

  Then(/^I expect to see "(.*)" in the list of events$/, whatToSee => {
    return 'pending';
    // return eventsBoard.expect.element('@eventsList').text.to.contain(whatToSee);
  });

  Then(/^I expect to see "(.*)" in the cell "(.*)" of the first event$/, (whatToSee, column) => {
    return eventsSHM.assert.containsText('@' + column, whatToSee);
  });

  Then(/^I expect the counter of events to show (.*)$/, whatIsShown => {
    return eventsBoard.assert
      .visible('@eventsCounter')
      .assert.containsText('@eventsCounter', whatIsShown);
  });

  Then(/^there is no comment$/, () => {
    return eventsSHM.assert.elementNotPresent('@eventComment');
  });

  Then(/^I expect to see this message "([^"]*)"$/, text => {
    client.pause(2000);
    return eventsSHM.assert.containsText('@eventText', text);
  });
  // To test dropDown List is visible
  Then(/^I expect that there is a dropdown list with search suggestions$/, () => {
    return eventsBoard.expect.element('@searchSuggestion').to.be.visible;
  });
  // To test dropDown List is not present in the DOM
  Then(/^I expect not to see the dropdown list with search suggestions$/, () => {
    return eventsBoard.expect.element('@searchSuggestion').to.not.be.present;
  });
  // to test if the search Term is in the dropDonwList
  Then(/^I expect to see the term "([^"]*)" in the search bar$/, text => {
    return eventsBoard.assert.value('@searchInput', text);
  });
  
  /*
  Then(/^my input search form exists$/, () => {
    var inputSearch = input.elements.searchInput;
    return client.assert.visible(inputSearch);
  });

  Then(/^I write in my input "([^"]*)"$/, text => {
    return client.setValue('input[name="textFilter"]', text).pause(4000);
  });

  Then(/^I see the table$/, () => {
    return client.waitForElementVisible('.react-grid-table', 5000);
  });

  Then(/^I click on the row (\d+)$/, rowNumber => {
    return client
      .click('.react-grid-table-container tr:nth-child(' + rowNumber + ')')
      .assert.visible(
        '.react-grid-table-container tr:nth-child(' +
          rowNumber +
          ').react-grid-active'
      )
      .pause(2000);
  });

  Then(/^I sort my table by the Aircraft column$/, () => {
    return client
      .click('.react-grid-header th:nth-child(2)')
      .assert.visible(
        '.react-grid-header th:nth-child(2).react-grid-sort-handle-visible'
      )
      .pause(4000);
  });*/
});
