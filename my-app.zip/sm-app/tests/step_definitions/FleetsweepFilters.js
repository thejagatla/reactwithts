const { client } = require('nightwatch-cucumber');
const { defineSupportCode } = require('cucumber');
const { constTabs, constTabsDetails, constPriorityFilters } = require('../support/constants');

defineSupportCode(({ Given, Then, When }) => {
    const fleetsweepFBoard = client.page.fleetsweepFBoard();
    const tabs = fleetsweepFBoard.section.tabs;
    const filterChoices = fleetsweepFBoard.section.filterChoices;

    //WHENS
    When(/^I click on the (.*) tab of the Fleet Sweep Filter panel$/, FsfTabName => {
        FsfTabName = constTabs[FsfTabName];
        return tabs.click('@' + FsfTabName),
            client.pause(2000);
    });

    When(/^I click on (.*) button of the Fleet Sweep Filter panel$/, FsfTabButton => {
        FsfTabButton = constTabsDetails[FsfTabButton];
        return fleetsweepFBoard.click('@' + FsfTabButton),
            client.pause(2000);
    });

    When(/^I click on clear filters in the Fleet Sweep Filter choices$/, () => {
        return filterChoices.click('@clearFilters'),
            client.pause(2000);
    });

    When(/^I click on apply in the Fleet Sweep Filter choices$/, () => {
        return filterChoices.click('@applyButton').api.pause(1000);
    });

    When(/^I select the following choices in the Fleet Sweep Filter: (.*)$/, choices => {
        var resultat;
        var splitChoices = choices.split(' ');
        filterChoices.click('@clearFilters');
        console.log(splitChoices);
        splitChoices.forEach(element => {
            element = constPriorityFilters[element];
            resultat = client.click('.ds-filter-choices--form label[for=' + element + ']');
        });
        return resultat;
    });

    //THENS
    Then(/^tab Customize is not visible$/, () => {
        return tabs.assert.elementNotPresent('@CUSTOM');
    });

    Then(/^tab Customize is visible$/, () => {
        return tabs.assert.elementPresent('@CUSTOM');
    });

    Then(/^tab Customize is selected$/, () => {
        return tabs.assert.cssClassPresent('@CUSTOM', 'ds-active');
    });

    Then(/^nothing is checked in the Fleet Sweep Filter choices$/, () => {
        var result
        return client.elements('css selector', '.ds-checkbox', (res) => {
            var i = 1;
            res.value.forEach(() => {
                result = client.assert.attributeEquals('.ds-filter-choices--form div:nth-child(' + i + ') input', 'aria-checked', 'false');
                i++;
            });
        });
        return result;
    });



    // const eventsBoard = client.page.eventsBoard();
    // eventsBoard.getAttribute('@buttonEnableFilters', 'data-checked', (result) => {
    //   if (result.value == want) {
    //     return eventsBoard.click('@buttonEnableFilters');
    //   }
    // });
});