const { client } = require('nightwatch-cucumber');
const TIME_WAIT_SEARCH = 4000;
const config = require('../support/config');

const fleetsweepFBoard = {
}

const tabsButtons = {
    URGENT_3: '[id="0"]',
    URGENT_2: '[id="1"]',
    URGENT_1: '[id="2"]',
    PLANNED: '[id="3"]',
    TO_BE_MONITORED: '[id="4"]',
    CUSTOM: '[id="5"]'
}


const filterChoicesDetails = {
    clearFilters: '.ds-filter--reset',
    applyButton: '.ds-filter-choices--form .ds-form-group-submit .ds-button--primary-1'
}

module.exports = {
    url: config.url,
    commands: [fleetsweepFBoard],
    sections: {
        tabs: {
            selector: '.l-filters .ds-tabs',
            elements: [tabsButtons]
        },
        filterChoices: {
            selector: '.ds-filter-choices ',
            elements: [filterChoicesDetails]
        }
    },
    elements: {
        PERIOD: '#period',
        PERIOD_12: 'label[for=HALF_DAY]',
        PERIOD_24: 'label[for=DAY]',
        PERIOD_48: 'label[for=TWO_DAYS]',
        PERIOD_72: 'label[for=THREE_DAYS]',
        PERIOD_168: 'label[for=WEEK]',    
        WORK_STATUS: '#work-status',
        EVENT_RANK: '#event-rank',
        PRIORITY: '#priority',
        OCCURRENCE: '#occurence'
    }
};
