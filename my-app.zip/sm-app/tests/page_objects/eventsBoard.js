const { client } = require('nightwatch-cucumber');
const TIME_WAIT_SEARCH = 4000;
const config = require('../support/config');

const boardCommands = {
  searchFor: searchTerms => {
    // redeclare eventsBoard because "this" is undefined
    // view issue on github :
    // https://github.com/mucsi96/nightwatch-cucumber/issues/315
    const eventsBoard = client.page.eventsBoard();
    return eventsBoard.setValue('@searchInput', searchTerms).click('@searchButton').api.pause(TIME_WAIT_SEARCH);
  },
  checkOH: tabOH => {
    var result;
    for (var i = 0; i < 15; i++) {
      const j = i + 1;
      switch (tabOH[i]) {
        case 'o':
          result = client.expect.element('#c-events .occ-history li:nth-child(' + j + ')').to.have.attribute('class')
            .which.equals('occ-history__empty-flight');
          break;
        case 'n':
          result = client.expect.element('#c-events .occ-history li:nth-child(' + j + ')').to.have.attribute('class')
            .which.equals('occ-history__no-flight');
          break;
        case 'x':
          result = client.expect.element('#c-events .occ-history li:nth-child(' + j + ')').to.have.attribute('class')
            .which.equals('occ-history__spm');
          break;
        default:
          result = client.assert.containsText('#c-events .occ-history li:nth-child(' + j + ')', tabOH[i]);
      }
    }
    return result;
  },
  checkUrlNewTab: (url, message) => {
    var finalResult;
    client.window_handles(function (result) {
      var handle = result.value[1];
      client.switchWindow(handle);
    });
    finalResult = client.assert.urlEquals(url, message);
    client.window_handles(function (result) {
      if (result.value[1] != undefined) {
        client.closeWindow();
      }
      handle = result.value[0];
      client.switchWindow(handle);
      client.pause(2000);
    });
    return finalResult;
  },
  filtersActivation: want => {
    const eventsBoard = client.page.eventsBoard();
    eventsBoard.getAttribute('@buttonEnableFilters', 'data-checked', (result) => {
      if (result.value == want) {
        return eventsBoard.click('@buttonEnableFilters');
      }
    });
  },
  xfiltersActivation: want => {
    const eventsBoard = client.page.eventsBoard();
    eventsBoard.getAttribute('@buttonEnableFilters', 'data-checked', (result) => {
      if (result.value == want) {
        return client.useXpath().click('//div[@id="filters-enabled"]/label');
      }
    });    
  }, 
  fillSearchField: searchTerms => {
    const eventsBoard = client.page.eventsBoard();
    return eventsBoard.setValue('@searchInput', searchTerms);
  },
  scroolInElement: function (selector, time, nbScrool) {
    if (typeof nbScrool !== 'number') {
      return false;
    }
    const eventsBoard = client.page.eventsBoard();
    eventsBoard.waitForElementVisible(selector, time, false)
      .click(selector);

    for (var i = 0; i < nbScrool; i++) {
      client.keys(client.Keys.DOWN_ARROW);
    }
  },
  isPresent: function (selector, callback) {
    return client.elements('css selector', selector, results => {
      if (results.status !== 0) {
        console.log('>>>>>>>>>>>< Can\'t find ' + selector + ' selector.');
      }
      callback(results.value.length > 0);
    })
  },
};

const sharedCellsDetails = {
  eventPriority: '.event-priority',
  eventFTail: '.event-flight__tail',
  eventFFlight: '.event-flight__flight',
  eventDateTime: '.event-datetime',
  eventTime: '.event-datetime__time',
  eventDate: '.event-datetime__date',
  eventAta: '.event-shortinfo__ata',
  eventSource: '.event-shortinfo__source',
  eventClass: '.event-shortinfo__class',
  eventText: '.event-shortinfo__title',
  eventHistory: '.occ-history',
  eventHistorySHM: '.occ-history__shm',
  eventHistorySPM: '.occ-history__spm',
  eventHistoryNoEvent: '.occ-history__no-flight',
  eventStatus: '.dropdown-button',
  eventWSLaunchAction: '.dropdown-menu .launch_action',
  eventWSPlanned: '.dropdown-menu .planned',
  eventWSIgnore: '.dropdown-menu .ignore',
  eventComment: '.event-comments'
}

module.exports = {
  url: config.url,
  commands: [boardCommands],
  sections: {
    eventsSPM: {
      selector: '#c-events .spm-row',
      elements: [sharedCellsDetails]
    },
    eventsSHM: {
      selector: '.shm-row',
      elements: [sharedCellsDetails]
    }
  },
  elements: {
    dashboard:'#main',
    searchButton: '#f-search .search-form__launch',
    searchButtonActive: '#f-search .search-form__input.active',
    clearSearchButton: '#f-search .search-form__remove',
    clearSearchButtonActive: '#f-search .search-form__remove--active',
    searchInput: '#f-search .search-form__input ',
    // to identify the list of suggestion 
    searchSuggestion: '#searchDropdownMenu',
    eventsCounter: '#d-events-number .search-title__number',
    eventsList: '#c-events .ReactVirtualized__Grid__innerScrollContainer .event-row',
    idEvents: '#c-events',
    rowSPM: '#c-events .spm-row',
    rowSHM: '#c-events .shm-row',
    buttonEnableFilters: '#filters-enabled-input',
    userName: '#user-menu .username',
    dropdownUserMenu: '#user-menu .fa-chevron-down',
    logout: '#user-menu .dropdown-menu .logout',
    // to identify the list of suggestion that we are testing
    flightNumber: '#flightNumberLabel',
    ata6: '#ata6Label',
    acMatricule: '#acMatriculeLabel',
    aircraftType: '#aircraftTypeLabel',
    eventType: '#eventTypeLabel',
    priority: '#priorityLabel',
    eventDate: '#eventDateLabel',
    titleFromAircraft: '#titleFromAircraftLabel',
    viewMelLinks: '#viewMelLinksLabel',
    smUiEventDate: '#smUiEventDateLabel',
    uiWorkOrderStatus: '#uiWorkOrderStatusLabel',
    hideToggele: '#toggle-filters',
    ToggeleUp: '.fa-chevron-up',
    ToggeleDown: '.fa-chevron-down',
    filter: '.filters-container',
    hidenFilter:'.hidden.l-filters',
    Square: '.square',
    HidenSquare: '.hidden.square',
    eventboard: '.l-spaced-horizontal events-container',
    ButtonTop: '#scroll-to-top',
    ErrorMessageOneLogin: '#errors .error-message',
    eventDate : '.event-flight-border'
  }
};
