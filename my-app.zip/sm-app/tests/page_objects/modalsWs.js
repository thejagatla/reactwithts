const { client } = require('nightwatch-cucumber');
const TIME_TO_REFRESH = 4000;
const config = require('../support/config');

const modalCommands = {
    submitMyForm: modalApply => {
        const modalsWs = client.page.modalsWs();
        return modalsWs.submitForm(modalApply).api.pause(TIME_TO_REFRESH);
    },
    launchAction: () => {
        const eventsBoard = client.page.eventsBoard();
        const eventsSHM = eventsBoard.section.eventsSHM;
        eventsSHM.click('@eventStatus', () => {
            eventsSHM.click('@eventWSLaunchAction');
        });
    }
};

module.exports = {
    commands: [modalCommands],
    elements: {
        modalWorkStatus: '.workflow-modal',
        modalWsWRef: 'input[name=workOrderReference]',
        modalWsDate: '.DayPickerInput input',
        modalWsPickerDate: ".DayPickerInput-OverlayWrapper .DayPicker-Day--today",
        modalWsComment: 'textarea[name=workOrderComment]',
        modalWsApply: 'button[type=submit]',
        modalWsActiveIcon: '.ds-step--current',
        modalWsHeader: '#event-informations',
        modalIGNSpurious: '.ds-radio label[for=IgnoredWorkStatusReasonEnumSPURIOUS]',
        modalIGNNoAction: '.ds-radio label[for=IgnoredWorkStatusReasonEnumNO_ACTION]',
        modalIGNOtherReason: '.ds-radio label[for=IgnoredWorkStatusReasonEnumOTHER_REASON]',
        modalIGNComment: 'textarea[name=workOrderComment]',
        modalIGNApply: 'button[type=submit]',
        modalBtnDisabled: 'button[disabled]',
        modalIGNCancel: 'button[type=button]'
    }
};