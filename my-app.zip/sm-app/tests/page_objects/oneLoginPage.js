const { client } = require('nightwatch-cucumber');
const TIME_WAIT_LOGIN = 1000;
const config = require('../support/config');

const loginCommands = {
  login: (username) => {
    const oneloginPage = client.page.oneLoginPage();
    return oneloginPage.setValue('@usernameInput', config.users[username].login)
    .setValue('@passwordInput', config.users[username].password)
    .click('@submitInput').api.pause(TIME_WAIT_LOGIN);
  },
  fakeLogin: (username) => {
    const oneloginPage = client.page.oneLoginPage();
    return oneloginPage.setValue('@usernameInput', config.users[username].login)
    .setValue('@passwordInput', config.users[username].password)
    .click('@submitInput').api.pause(TIME_WAIT_LOGIN);
  }
};

module.exports = {
  url: config.oneLoginUrl,
  commands: [loginCommands],
  elements: {
    usernameInput: '#user_email',
    passwordInput: '#user_password',
    submitInput:   '#user_submit',
    logoAirbus: '#login-logo'
  }
};


//-->  <input autocapitalize="off" autofocus="true" id="user_email" maxlength="255" name="email" placeholder="Email/Username" title="Email/Username" type="text">
//-->  <input autocomplete="off" id="user_password" name="password" placeholder="Password" title="Password" type="password">
//--> <input autocomplete="off" class="suppress create" id="user_submit" name="commit" type="submit" value="Log in">
 