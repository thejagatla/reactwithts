const { client } = require('nightwatch-cucumber');
const TIME_WAIT_SEARCH = 4000;
const config = require('../support/config');

module.exports = {
  url: config.url + '/event/AZ123%5E123%5E123',
  elements: {
    eventHeaderSection: '#eventDetailsHeader',
    eventChart: '#containerChartEvents .c3',
    eventChartThresholdToggle: '#threshold-toggle',
    eventChartRescaleButton: '#rescale-button',
    tooltip: '#spm-c3-tooltip-charts',
    eventChartTooltipLoader: '#spm-c3-tooltip-charts #tooltip-loader',
    eventChartTooltipData: '#spm-c3-tooltip-charts #tooltip-data',
    threshold: '.c3-chart-line.c3-target-threshold0',
    eventChartLastPoint: '#containerChartEvents .c3-event-rects .c3-event-rect:last-child'
  }
};
