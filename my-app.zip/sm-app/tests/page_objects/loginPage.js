const { client } = require('nightwatch-cucumber');
const TIME_WAIT_LOGIN = 2000;
const config = require('../support/config');

const loginCommands = {
  login: (username) => {
    const loginPage = client.page.loginPage();
    return loginPage.setValue('@usernameInput', config.users[username].login)
      .setValue('@passwordInput', config.users[username].password)
      .click('@submitInput')
      .api.pause(TIME_WAIT_LOGIN);
  }
};

module.exports = {
  url: config.url,
  commands: [loginCommands],
  elements: {
    login: '.login-form',
    usernameInput: '.login-form input[name=username]',
    passwordInput: '.login-form input[name=password]',
    submitInput: '.login-form button',
  }
};
