'use strict';

const config = {
  users: {
    'VIP': {
      login: 'john@doe.com',
      password: 'super_password',
    },
    'tester': {
      login: 'shm',
      password: 'Skywise1!',
    }
  },
  stage: 'search',
  // TODO : retrieve url dynamically or use dns alias
  // without dns alias
  // => use the cloudformation export : 'website-' + config.stage
  url: 'https://d3ap1fo0tlr1zm.cloudfront.net/'
};

module.exports = config;
