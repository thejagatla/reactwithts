'use strict';

const config = {
  users: {
    'VIP': {
      login: 'john@doe.com',
      password: 'super_password',
    },
    'tester': {
      login: 'tester',
      password: 'Skywise2018!',
    }
  },
  stage: 'at',
  // TODO : retrieve url dynamically or use dns alias
  url: 'http://localhost:3000'
};

module.exports = config;
