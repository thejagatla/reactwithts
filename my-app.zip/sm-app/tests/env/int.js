'use strict';

const config = {
  users: {
    'VIP': {
      login: 'john@doe.com',
      password: 'super_password',
    }
  },
  stage: 'int',
  // TODO : retrieve url dynamically or use dns alias
  url: 'https://d14jgwpupatji1.cloudfront.net/'
};

module.exports = config;
