'use strict';

const config = {
  users: {
    'VIP': {
      login: 'john@doe.com',
      password: 'super_password',
    },
    'SPM-EZY-USER-01_TEST': {
      login: 'SPM-EZY-USER-01.test@airbus.com',
      password: 'Abcd1234!',
    },
    'FAKE_CREDENTIALS': {
      login: 'fake_user',
      password: 'fake_password',
    },
    'tester': {
      login: 'shm',
      password: 'Skywise1!',
    }
  },
  stage: 'test',
  // TODO : retrieve url dynamically or use dns alias
  url: 'https://d2pblgs177i45w.cloudfront.net/',
  oneLoginUrl: 'https://d2c09zyntajyxc.cloudfront.net'
};

module.exports = config;
