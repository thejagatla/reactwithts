'use strict';

const config = {
  users: {
    'VIP': {
      login: 'john@doe.com',
      password: 'super_password',
    },
    'tester': {
      login: 'shm',
      password: 'Skywise1!',
    }
  },
  stage: 'at',
  // TODO : retrieve url dynamically or use dns alias
  // without dns alias
  // => use the cloudformation export : 'website-' + config.stage
  url: 'https://d5tji1om32mj7.cloudfront.net/login'
};

module.exports = config;
