module.exports = function (grunt) {

  grunt.initConfig({

    pkg: grunt.file.readJSON('package.json'),

    // postcss: {
    //   options: {
    //       map: true,
    //       processors: [
    //           require('autoprefixer')
    //       ]
    //   },
    //   dist: {
    //     files: [
    //         {
    //             'tmp/sm-app.css': 'src/sass/main.scss'
    //         }
    //     ]
    //   }
    // },

    sassLoader: {
      includePaths: [
        'node_modules'
      ]
    },

    sass: {
      options: {
        sourceMap: true,
        includePaths: ['node_modules']
      },
      dist: {
        files: [
          {
            'tmp/sm-app.css': 'src/style/sass/main.scss'
          }
        ]
      }
    },

    cssmin: {
      dist: {
        files: [
          {
            'src/style/css/style.min.css': 'src/style/css/style.css'
          }
        ]
      }
    },

    concat: {
      dist: {
        src: [
          'tmp/*.css',
        ],
        dest: 'src/style/css/style.css',
      }
    },

    watch: {
      sass: {
        files: [
          'src/style/sass/**/*.scss'
        ],
        tasks: ['sass']
      },
      cssmin: {
        files: ['src/style/css/style.css'],
        tasks: ['cssmin']
      },
      concat: {
        files: ['tmp/*.css'],
        tasks: ['concat']
      }
    },

    exec: {
      build: {
        command: 'yarn build'
      }
    },

    concurrent: {
      options: {
        logConcurrentOutput: true
      },
      dev: {
        tasks: ['watch:sass', 'watch:cssmin', 'watch:concat']
      }
    }
  });

  grunt.loadNpmTasks('grunt-sass');
  grunt.loadNpmTasks('grunt-contrib-cssmin');
  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-contrib-concat');
  grunt.loadNpmTasks('grunt-concurrent');
  grunt.loadNpmTasks('grunt-exec');
  grunt.loadNpmTasks('grunt-postcss');

  grunt.task.registerTask('dev', ['sass', 'concat', 'cssmin', 'concurrent:dev']);
  grunt.task.registerTask('build', ['sass', 'concat', 'cssmin', 'exec:build']);
  grunt.registerTask('default', ['dev']);
};
