#!/bin/sh
# deploy script called by pipeline

echo "============= starting $0 on $STAGE"
# exit script as soon as any command fails:
set -e

if [ -z "$AWS_REGION" ]; then
    # curious behavior on some pipeline stages
    # the AWS_REGION variable is not available where it is in other stages
    # INT/PRE have the variable, but no production
    # that may lead to issues when deploying ES schemas below
    AWS_REGION='eu-west-1'
    echo "setting AWS_REGION to $AWS_REGION"
fi

#remove client dir if needed
if [ -d client ]
then
  echo "Removing client dir"
  rm -rf client
fi

if [ "$FROM_LOCAL" = 'true' ]
then
  # Local deploy
  echo "Local deploy"
  ROOT=$(pwd)
  mkdir -p client
  cp -R build client/dist
else
  # Pipeline deploy
  cd $(dirname $0)
  ROOT=$(pwd)
  WORKDIR=/tmp/work/deploy-$(date '+%Y%m%d%H%M%S')

  if [ ! -z "$VERSION" ]
  then
    echo "Download version from artifact manager"
    mkdir -p $WORKDIR
    cd $WORKDIR
    PKG_URL=$M2_REPOSITORY_HOST/nexus/repository/sm-m2-releases/com/airbus/sm/app/sm-app/$VERSION/sm-app-$VERSION-package.zip
    curl -X GET -O -L $PKG_URL
    if [ "$?" != "0" ]
    then
      echo "Error downloading archive $PKG_URL"
      exit 1
    fi
    unzip sm-app-$VERSION-package.zip
    if [ "$?" != "0" ]
    then
      echo "Error unzipping downloaded archive"
      exit 1
    fi
    cd sm-app-$VERSION
    ls -al
  else
    echo "Using local artifacts"
    mkdir -p client
    cp -R build client/dist
  fi
fi

# test if PM backend stacks are present
stackName="stack-${ASPIRE}-${STAGE}-services-pm-event-${STAGE}"
echo "============= testing existance of SPM stacks ${stackName}"
# authorize errors because it is the only way to test existence of 1 stack
set +e
aws cloudformation describe-stacks --region "${AWS_REGION}" --stack-name "${stackName}" --query "Stacks[0].StackId"
if [ "$?" != "0" ]
then
  echo "WARNING: Considering that SPM API are not deployed on stage $STAGE"
  export SPM_IS_NOT_DEPLOYED=true
fi
set -e
echo "SPM_IS_NOT_DEPLOYED=$SPM_IS_NOT_DEPLOYED"

# test if SHM API is deployed on stage
shmApiStackName="stack-${ASPIRE}-${STAGE}-frontend-${STAGE}"
echo "============= testing existance of ${shmApiStackName}"
# authorize errors because it is the only way to test existence of 1 stack
set +e
aws cloudformation describe-stacks --region "${AWS_REGION}" --stack-name "${shmApiStackName}" --query "Stacks[0].StackId"
if [ "$?" != "0" ]
then
  echo "WARNING: Considering that SHM API is not deployed on stage $STAGE"
  export SHM_API_IS_NOT_DEPLOYED=true
fi
set -e
echo "SHM_API_IS_NOT_DEPLOYED=$SHM_API_IS_NOT_DEPLOYED"

echo "============= deploying stack"

sls deploy --force --stage=$STAGE

echo "============= copying url conf to dist folder"
"$ROOT"/setup_urls.sh $STAGE "$ROOT"

echo "============= copying static files to s3-app-${ASPIRE}-${STAGE}-public-v2-${AWS_REGION} bucket"
aws s3 sync client/dist s3://s3-app-${ASPIRE}-${STAGE}-public-v2-${AWS_REGION}/ --delete --exclude 'api/*'

# Remove work dir if not local and version set
if [ "$FROM_LOCAL" != 'true' ]
then
  if [ ! -z "$VERSION" ]
  then
    echo "Cleaning workdir"
    cd $ROOT
    rm -rf $WORKDIR
  fi
fi

echo "============= try to delete old bucket"
./patch/5.1_000/patch.sh

echo "============= successful end $0 on $STAGE"
