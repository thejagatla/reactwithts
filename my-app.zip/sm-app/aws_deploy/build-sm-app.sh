#!/bin/bash

. ./common_create.sh

STAGE=$1
[ -z $STAGE ] && echo_syntax 1
[ $( echo "$STAGE" | grep -Eq '^\-\-help|^help$|^\-h$' ; echo $? ) -eq 0 ] && echo_syntax 0
[ $( echo "$STAGE" | grep -Eq '^(at|int|test|prod|pprod|val|dev)$' ; echo $? ) -eq 0 ] && echo "Error: the stage must not be equal to at|int|test|prod|pprod|val|dev" && exit 1
[ $( echo "$STAGE" | grep -Eq '^[a-z0-9]{2,5}$' ; echo $? ) -eq 1 ] && echo "Error: the stage must match [a-z0-9]{2,5}" && exit 1
region=$(aws configure get region 2>/dev/null) ; [ $? -ne 0 ] && echo "Error: the AWS CLI tool seems to not be available" && exit 1
[ "$region" != 'eu-west-1' ] && echo "Error: your default AWS region used by AWS CLI is not eu-west-1" && exit 1


ROOT="$( cd "$(dirname "$0")/../.." ; pwd -P )"
SMHP_CONFIG=~/.smhp
STEP=DEFAULT
STAGE_STEPS=$SMHP_CONFIG/$STAGE
PULL=0
MARK_DONE=0
DEPLOY=1
BAR=`for ((i=1; i<=148; i++)); do printf '\x1b(0\x71\x1b(B'; done`

#===============================================================
# Step management
#===============================================================

#--------------------------------------------
# Parameters handling
#--------------------------------------------

shift
while [ "${1+defined}" ]; do
  if [ $( echo "$1" | grep -Eq '^\-\-pull$' ; echo $? ) -eq 0 ]; then
    PULL=1
  elif [ $( echo "$1" | grep -Eq '^(\-\-mark\-all\-done)$' ; echo $? ) -eq 0 ]; then
    MARK_DONE=1
  elif [ $( echo "$1" | grep -Eq '^(\-\-no\-deploy)$' ; echo $? ) -eq 0 ]; then
    DEPLOY=0
  elif [ $( echo "$1" | grep -Eq '^(\-\-help|help|\-h)$' ; echo $? ) -eq 0 ]; then
    echo_syntax 0
  else
    STEP_ID=`realpath $1 --relative-to $STAGE_STEPS`
    if [ `echo $STEP_ID | grep -c '\.\.\/'` -eq 0 ]; then
      [ ! -e $1 ] && echo "$1 is not a file or folder" && exit 1
      rm -R $1
      echo `realpath $1 --relative-to $STAGE_STEPS` step must be performed
    else
      echo `realpath $1 --relative-to $STAGE_STEPS` is not a valid step
    fi
  fi
  shift
done

#
# sm-app
#
# first start by building the artifacts
_phase sm-app
_cd sm-app
_pull
# yarn.lock is managed in repo and must not be deleted before the build.
_do rm -rf node_modules/ client/dist/ \; yarn
_do node_modules/.bin/grunt build

echo end of build

# then deploy
# (SPM API gateway ids of AT)
#export SPM_API_EVENTS_ID=$(aws apigateway get-rest-apis | sed ':a;N;$!ba;s/\n//g' | sed -e 's/.*\({[^{]*[\"]name[\"]: [\"]'$STAGE'-sm-pm-services-pm-event[\"][^}]*}\).*/\1/' | sed -e 's/.*[\"]id[\"]: [\"]\([^\"]\+\)[\"].*/\1/')
#export SPM_API_EVENT_ITEMS_ID=$(aws apigateway get-rest-apis | sed ':a;N;$!ba;s/\n//g' | sed -e 's/.*\({[^{]*[\"]name[\"]: [\"]'$STAGE'-sm-pm-services-pm-event-item[\"][^}]*}\).*/\1/' | sed -e 's/.*[\"]id[\"]: [\"]\([^\"]\+\)[\"].*/\1/')
#export SPM_APIS_ORIGIN_PATH=$STAGE
#[ ! -d client ] && mkdir client
#[ -d build ] && mv build client/dist
#_do node scripts/update_cognito_config.js $STAGE
#_do yarn add serverless-finch@1.4.0
#_do _sls client deploy --stage $STAGE
#_do _sls deploy --force --stage $STAGE
