#!/bin/bash

function echo_syntax() {
  echo "Syntax:"
  echo ""
  echo "$0 stage param1 param2 ..."
  echo ""
  echo "Parameters:"
  echo "   stage             : the stage name. Always mandatory if not equal to --help|-h|help"
  echo "   --help|-h|help    : Display the help"
  echo "   --mark-all-done   : set all steps to done without doing sls deploy and compilation"
  echo "                     :   use this option before to perform a limited deployment on a existing stage"
  echo "   --no-deploy       : does not deploy on AWS. Serverless calls are not performed"
  echo "   --pull            : do a git pull on each visited git folder before to do steps"
  echo "   stepFileOrFolder  : param you can repeat as a step file or folder (in ~/.smhp/\$stage/ folder tree). Enforce the related step to be done"
  echo ""
  echo "Example to execute all remaining steps and to do again the Smoke Test step:"
  echo ""
  echo "$0 stg1 ~/.smhp/stg1/Smoke_Test"
  echo ""
  exit $1
}

#--------------------------------------------
# Functions
#--------------------------------------------

function _phase() {
  STEP=$1
  echo ""
  l=${#STEP}
  left_margin=`for ((i=1; i<=$((74 - $l / 2)); i++)); do echo -n ' '; done`
  right_margin=`for ((i=1; i<=$((74 - $l / 2 - $l % 2)); i++)); do echo -n ' '; done`
  printf "\x1b(0\x6c\x1b(B${BAR}\x1b(0\x6b\x1b(B\n"
  printf "\x1b(0\x78\x1b(B${left_margin}${STEP}${right_margin}\x1b(0\x78\x1b(B\n"
  printf "\x1b(0\x6d\x1b(B${BAR}\x1b(0\x6a\x1b(B\n"
}

function _cd() {
  if [ ! -d $ROOT/$1 ]
  then
    echo "Missing folder $ROOT/$1"
    exit 1
  fi
  cd $ROOT/$1
  echo "--------------------> from $(pwd)"
}

function _do() {
  RELROOTPATH=`realpath --relative-to="$ROOT" "."`
  COMMAND_STR=`echo $* | sed -e 's/[^a-zA-Z0-9\-]/_/g'`
  STEP_DIR=$STAGE_STEPS/$STEP/$RELROOTPATH
  NEXT_SUBSTEP_FILE=$STEP_DIR/$COMMAND_STR
  [ ! -d $STEP_DIR ] && mkdir -p "$STEP_DIR"
  [ -f $NEXT_SUBSTEP_FILE.failed ] && rm $NEXT_SUBSTEP_FILE.failed
  if [ ! -f $NEXT_SUBSTEP_FILE.done ]
  then
    if [ $MARK_DONE -eq 0 ]
    then
      echo "====================> $*"
      eval "$*"
    else
      echo "-----[MARK DONE]----> $*"
    fi
    STEP_EXIT_CODE=$?
    if [ $STEP_EXIT_CODE -eq 0 ]
    then
      echo "$*\ndone" > $NEXT_SUBSTEP_FILE.done
      echo "--------------------> $NEXT_SUBSTEP_FILE done"
    elif [ $STEP_EXIT_CODE -ne 125 ]; then
      echo "######################"
      echo "${pwd}/$* failed with error code $STEP_EXIT_CODE"
      echo "######################"
      echo "${pwd}/$*\nfailed with exit code $STEP_EXIT_CODE" > $NEXT_SUBSTEP_FILE.failed
      exit $STEP_EXIT_CODE
    fi
  else
    echo "Already done ........ $*"
  fi
  return 0
}

function _sls() {
  if [ $DEPLOY -eq 0 ]
  then
    echo "---[NOT PERFORMED]---"
    (exit 125)
  else
    eval "sls $*"
  fi
}

function _pull() {
  if [ $PULL -ne 0 ]
  then
    echo "====================> git pull"
    git pull
    STEP_EXIT_CODE=$?
    if [ $STEP_EXIT_CODE -ne 0 ]
    then
      echo "######################"
      echo "git pull failed with error code $STEP_EXIT_CODE"
      echo "######################"
    fi
  fi
}

function smoke_test() {
  aws lambda invoke --function-name lambda-smhp-$STAGE-smoketest-novpc --payload '{"actions":[{"actionName":"DoSmokeTest"}]}' $STAGE_STEPS/outputsmoke.json
  # check that output file contains success keyword
  cat $STAGE_STEPS/outputsmoke.json | grep SmokeTestIsOk
  GREP_EXIT_CODE=$?
  if [ $GREP_EXIT_CODE -ne 0 ]
  then
    echo "######################"
    echo "SmokeTest failed due to its output not equal to SmokeTestIsOk:"
    cat $STAGE_STEPS/outputsmoke.json
    echo "######################"
    return 1
  fi
  return 0
}

function create_cognito_user() {
  aws cognito-idp list-users --user-pool-id $1 --filter 'username = "'$2'"' | grep '"Users": \[\]'
  EXIT_CODE=$?
  if [ $EXIT_CODE -ne 1 ]
  then
    aws cognito-idp admin-create-user --user-pool-id $1 --username $2 --temporary-password 'Skywise1!' --user-attributes Name=email_verified,Value=true Name=email,Value=$2@airbus.cloud
    EXIT_CODE=$?
    if [ $EXIT_CODE -ne 0 ]
    then
      echo "######################"
      echo "Unable to create the user $2 in the user pool $1"
      echo "######################"
      return 1
    else
      echo "######################"
      echo "The user $2 has been created in the user pool $1"
      echo "######################"
    fi
  else
      echo "######################"
      echo "The user $2 is already created in the user pool $1"
      echo "######################"
  fi
  return 0
}