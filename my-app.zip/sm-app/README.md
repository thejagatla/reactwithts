# Skywise App

This is the App web UI for Skywise clients. It is designed to display views for HM (Health Monitoring) or PM (Predictive Maintenance).

Touch 2 time to force sls deploy in the pipeline.


