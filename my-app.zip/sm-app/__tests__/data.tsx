export const dataTest = [{
    acEventId: 12121213,
    acMatricule: "XX-XXX",
    aircraftType: "A320",
    ata6 : "240000",
    eventClass: "P",
    eventDate: "2018-01-17T10:10",
    indexedDate: "2017-11-22T10:25:31.229",
    latest: true,
    msn: 0,
    occurrenceHistory: "....XWXX.XD....",
    origin: "SPM",
    priority: "high",
    smEventDate: "2018-01-17T10:23",
    titleFromAircraft: "IDG1 Low Frequency Excursion",
    type: "smEventOccurrence",
    workOrderStatus: "TO_BE_REVIEWED"
}];
