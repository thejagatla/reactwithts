import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import * as actions from '../../../src/store/actions/spm/SpmEventActions';
import * as types from '../../../src/store/actions/spm/SpmActionsTypes';
import * as data from '../../stubs/SpmDataStub';

const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);

const mockResponse = (status, statusText, response) => {
  return new window.Response(response, {
    status,
    statusText,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

describe('Spm event actions', () => {

  it ('checks spm event actions', () => {
    // To define a solution for react-cognito
  });

  // it('creates a LOADEVENTSUCCESS when fetching event has been done', () => {
  //   window.fetch = jest.fn().mockImplementation(() =>
  //     Promise.resolve(mockResponse(200, null, '{"event": "event"}')));

  //   const expectedAction = [
  //     { type: types.LOADEVENTSUCCESS, event: { event: 'event' } }
  //   ];

  //   const store = mockStore({ event: {} });

  //   return store.dispatch(actions.loadEvent('id')).then(() => {
  //     expect(store.getActions()).toEqual(expectedAction);
  //   });
  // });

  // it('creates a LOADEVENTERROR when fetching event throws an error', () => {
  //   window.fetch = jest.fn().mockImplementation(() =>
  //     Promise.resolve(mockResponse(500, null, '')));

  //   const expectedAction = [
  //     { type: types.LOADEVENTERROR }
  //   ];

  //   const store = mockStore({ event: {} });

  //   return store.dispatch(actions.loadEvent('id')).then(() => {
  //     expect(store.getActions()).toEqual(expectedAction);
  //   });
  // });

  // it('creates a LOADEVENTSUCCESS action', () => {
  //   const event = data.spmEvent1;
  //   const expectedAction = {
  //     event,
  //     type: types.LOADEVENTSUCCESS
  //   };
  //   expect(actions.loadEventSuccess(event)).toEqual(expectedAction);
  // });

  // it('creates a LOADEVENTERROR action', () => {
  //   const expectedAction = {
  //     type: types.LOADEVENTERROR
  //   };
  //   expect(actions.loadEventError()).toEqual(expectedAction);
  // });

  // it('creates a LOADCHARTSUCCESS when fetching chart has been done', () => {
  //   window.fetch = jest.fn().mockImplementation(() =>
  //     Promise.resolve(mockResponse(200, null, '{"chart": "chart"}')));

  //   const expectedAction = [
  //     { type: types.LOADCHARTSUCCESS, chart: { chart: 'chart' } }
  //   ];

  //   const store = mockStore({ chart: {} });

  //   return store.dispatch(actions.loadChart('id')).then(() => {
  //     expect(store.getActions()).toEqual(expectedAction);
  //   });
  // });

  // it('creates a LOADCHARTERROR when fetching chart throws an error', () => {
  //   window.fetch = jest.fn().mockImplementation(() =>
  //     Promise.resolve(mockResponse(500, null, '')));

  //   const expectedAction = [
  //     { type: types.LOADCHARTERROR }
  //   ];

  //   const store = mockStore({ chart: {} });

  //   return store.dispatch(actions.loadChart('id')).then(() => {
  //     expect(store.getActions()).toEqual(expectedAction);
  //   });
  // });

  // it('creates a LOADEVENTITEMSUCCESS when fetching event item has been done', () => {
  //   window.fetch = jest.fn().mockImplementation(() =>
  //     Promise.resolve(mockResponse(200, null, '{"eventItem": "eventItem"}')));

  //   const expectedAction = [
  //     { type: types.LOADEVENTITEMSUCCESS, eventItem: { eventItem: 'eventItem' } }
  //   ];

  //   const store = mockStore({ eventItem: {} });

  //   return store.dispatch(actions.loadEventItemById('id', 'date')).then(() => {
  //     expect(store.getActions()).toEqual(expectedAction);
  //   });
  // });

  // it('creates a LOADCHARTSUCCESS action', () => {
  //   const expectedAction = {
  //     chart: data.spmChart1,
  //     type: types.LOADCHARTSUCCESS
  //   };
  //   expect(actions.loadChartSuccess(data.spmChart1)).toEqual(expectedAction);
  // });

  // it('creates a LOADCHARTERROR action', () => {
  //   const expectedAction = {
  //     type: types.LOADCHARTERROR
  //   };
  //   expect(actions.loadChartError()).toEqual(expectedAction);
  // });

  // it('creates a SELECTCHARTPOINT action', () => {
  //   const selectedPoint = {
  //     selectedPoint: 'selectedPoint'
  //   };
  //   const expectedAction = {
  //     selectedPoint,
  //     type: types.SELECTCHARTPOINT
  //   };
  //   expect(actions.selectChartPoint(selectedPoint)).toEqual(expectedAction);
  // });

  // it('creates a SETTOOLTIP action', () => {
  //   const tooltipSettings = {
  //     tooltipSettings: 'tooltipSettings'
  //   };
  //   const expectedAction = {
  //     tooltipSettings,
  //     type: types.SETTOOLTIP
  //   };
  //   expect(actions.setTooltip(tooltipSettings)).toEqual(expectedAction);
  // });

  // it('creates a LOADEVENTITEMSUCCESS action', () => {
  //   const eventItem = {
  //     eventItem: 'eventItem'
  //   };
  //   const expectedAction = {
  //     eventItem,
  //     type: types.LOADEVENTITEMSUCCESS
  //   };
  //   expect(actions.loadEventItemSuccess(eventItem)).toEqual(expectedAction);
  // });

  // it('creates a LOADEVENTITEMERROR action', () => {
  //   const expectedAction = {
  //     type: types.LOADEVENTITEMERROR
  //   };
  //   expect(actions.loadEventItemError()).toEqual(expectedAction);
  // });

  // it('creates a INITTOOLTIP action', () => {
  //   const expectedAction = {
  //     type: types.INITTOOLTIP
  //   };
  //   expect(actions.initTooltip()).toEqual(expectedAction);
  // });

  // it('creates a INITTOOLTIPSUCCESS action', () => {
  //   const expectedAction = {
  //     type: types.INITTOOLTIPSUCCESS
  //   };
  //   expect(actions.initTooltipSuccess()).toEqual(expectedAction);
  // });

  // it('creates a TOGGLETHRESHOLDDISPLAY action', () => {
  //   const thresholdDisplay = true;
  //   const expectedAction = {
  //     thresholdDisplay,
  //     type: types.TOGGLETHRESHOLDDISPLAY
  //   };
  //   expect(actions.toggleThresholdDisplay(thresholdDisplay)).toEqual(expectedAction);
  // });

  // it('creates a YAXISRESCALE action', () => {
  //   const expectedAction = {
  //     type: types.YAXISRESCALE
  //   };
  //   expect(actions.yAxisRescale()).toEqual(expectedAction);
  // });

  // it('creates a YAXISRESCALESUCCESS action', () => {
  //   const expectedAction = {
  //     type: types.YAXISRESCALESUCCESS
  //   };
  //   expect(actions.yAxisRescaleSuccess()).toEqual(expectedAction);
  // });

  // it('creates a YAXISRESCALEPOSSIBLE action', () => {
  //   const possible = true;
  //   const expectedAction = {
  //     possible,
  //     type: types.YAXISRESCALEPOSSIBLE
  //   };
  //   expect(actions.yAxisRescalePossible(possible)).toEqual(expectedAction);
  // });
});