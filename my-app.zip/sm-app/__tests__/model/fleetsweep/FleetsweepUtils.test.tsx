/**
 * FleetsweepUtils test component
 */
import * as enzyme from 'enzyme';
import * as React from 'react';

import { WorkOrderStatus, WorkOrderStatusEnum } from '../../../src/model/EventsConstantes';
import {
    FleetsweepEventRank,
    FleetsweepEventRankEnum,
    FleetsweepFilterTypeEnum,
    FleetsweepPriority,
    FleetsweepPriorityEnum
} from '../../../src/model/fleetsweep/FleetsweepConstantes';
import * as FleetsweepUtils from '../../../src/utils/FleetsweepUtils';

describe('FleetsweepUtils component', () => {

    /**
     * Check getFullFleetsweepValueFromEnum method with TO_BE_REVIEWED work status
     */
    it('tests getFullFleetsweepValueFromEnum TO_BE_REVIEWED work status function', () => {
        const lReturn = FleetsweepUtils.getFullFleetsweepValueFromEnum(
            FleetsweepFilterTypeEnum.WORK_STATUS,
            WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]);

        expect(lReturn).toEqual(WorkOrderStatus.TO_BE_REVIEWED);
    });

    /**
     * Check getFullFleetsweepValueFromEnum method with OPENED work status
     */
    it('tests getFullFleetsweepValueFromEnum OPENED work status function', () => {
        const lReturn = FleetsweepUtils.getFullFleetsweepValueFromEnum(
            FleetsweepFilterTypeEnum.WORK_STATUS,
            WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED]);

        expect(lReturn).toEqual(WorkOrderStatus.OPENED);
    });

    /**
     * Check getFullFleetsweepValueFromEnum method with PLANNED work status
     */
    it('tests getFullFleetsweepValueFromEnum PLANNED work status function', () => {
        const lReturn = FleetsweepUtils.getFullFleetsweepValueFromEnum(
            FleetsweepFilterTypeEnum.WORK_STATUS,
            WorkOrderStatusEnum[WorkOrderStatusEnum.PLANNED]);

        expect(lReturn).toEqual(WorkOrderStatus.PLANNED);
    });

    /**
     * Check getFullFleetsweepValueFromEnum method with TO_BE_MONITORED work status
     */
    it('tests getFullFleetsweepValueFromEnum TO_BE_MONITORED work status function', () => {
        const lReturn = FleetsweepUtils.getFullFleetsweepValueFromEnum(
            FleetsweepFilterTypeEnum.WORK_STATUS,
            WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_MONITORED]);

        expect(lReturn).toEqual(WorkOrderStatus.TO_BE_MONITORED);
    });

    /**
     * Check getFullFleetsweepValueFromEnum method with CLOSED work status
     */
    it('tests getFullFleetsweepValueFromEnum CLOSED work status function', () => {
        const lReturn = FleetsweepUtils.getFullFleetsweepValueFromEnum(
            FleetsweepFilterTypeEnum.WORK_STATUS,
            WorkOrderStatusEnum[WorkOrderStatusEnum.CLOSED]);

        expect(lReturn).toEqual(WorkOrderStatus.CLOSED);
    });

    /**
     * Check getFullFleetsweepValueFromEnum method with IGNORED work status
     */
    it('tests getFullFleetsweepValueFromEnum IGNORED work status function', () => {
        const lReturn = FleetsweepUtils.getFullFleetsweepValueFromEnum(
            FleetsweepFilterTypeEnum.WORK_STATUS,
            WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED]);

        expect(lReturn).toEqual(WorkOrderStatus.IGNORED);
    });

    /**
     * Check getFullFleetsweepValueFromEnum method with Warning event rank
     */
    it('tests getFullFleetsweepValueFromEnum Warning event rank function', () => {
        const lReturn = FleetsweepUtils.getFullFleetsweepValueFromEnum(
            FleetsweepFilterTypeEnum.EVENT_RANK,
            FleetsweepEventRank[FleetsweepEventRank.W]);

        expect(lReturn).toEqual(FleetsweepEventRankEnum.W);
    });

    /**
     * Check getFullFleetsweepValueFromEnum method with Class1 event rank
     */
    it('tests getFullFleetsweepValueFromEnum 1&2 event rank function', () => {
        const lReturn = FleetsweepUtils.getFullFleetsweepValueFromEnum(
            FleetsweepFilterTypeEnum.EVENT_RANK,
            FleetsweepEventRank[FleetsweepEventRank.C1]);

        expect(lReturn).toEqual(FleetsweepEventRankEnum.C1);
    });

  /**
   * Check getFullFleetsweepValueFromEnum method with Class2 event rank
   */
  it('tests getFullFleetsweepValueFromEnum 1&2 event rank function', () => {
    const lReturn = FleetsweepUtils.getFullFleetsweepValueFromEnum(
      FleetsweepFilterTypeEnum.EVENT_RANK,
      FleetsweepEventRank[FleetsweepEventRank.C2]);

    expect(lReturn).toEqual(FleetsweepEventRankEnum.C2);
  });

    /**
     * Check getFullFleetsweepValueFromEnum method with Predictive event rank
     */
    it('tests getFullFleetsweepValueFromEnum Predictive event rank function', () => {
        const lReturn = FleetsweepUtils.getFullFleetsweepValueFromEnum(
            FleetsweepFilterTypeEnum.EVENT_RANK,
            FleetsweepEventRank[FleetsweepEventRank.P]);

        expect(lReturn).toEqual(FleetsweepEventRankEnum.P);
    });

    /**
     * Check getFullFleetsweepValueFromEnum method with High priority
     */
    it('tests getFullFleetsweepValueFromEnum High priority function', () => {
        const lReturn = FleetsweepUtils.getFullFleetsweepValueFromEnum(
            FleetsweepFilterTypeEnum.PRIORITY,
            FleetsweepPriority[FleetsweepPriority.HIGH]);

        expect(lReturn).toEqual(FleetsweepPriorityEnum.HIGH);
    });

    /**
     * Check getFullFleetsweepValueFromEnum method with Medium priority
     */
    it('tests getFullFleetsweepValueFromEnum Medium priority function', () => {
        const lReturn = FleetsweepUtils.getFullFleetsweepValueFromEnum(
            FleetsweepFilterTypeEnum.PRIORITY,
            FleetsweepPriority[FleetsweepPriority.MEDIUM]);

        expect(lReturn).toEqual(FleetsweepPriorityEnum.MEDIUM);
    });

    /**
     * Check getFullFleetsweepValueFromEnum method with Low priority
     */
    it('tests getFullFleetsweepValueFromEnum Low priority function', () => {
        const lReturn = FleetsweepUtils.getFullFleetsweepValueFromEnum(
            FleetsweepFilterTypeEnum.PRIORITY,
            FleetsweepPriority[FleetsweepPriority.LOW]);

        expect(lReturn).toEqual(FleetsweepPriorityEnum.LOW);
    });

    /**
     * Check getFullFleetsweepValueFromEnum method with None priority
     */
    it('tests getFullFleetsweepValueFromEnum None priority function', () => {
        const lReturn = FleetsweepUtils.getFullFleetsweepValueFromEnum(
            FleetsweepFilterTypeEnum.PRIORITY,
            FleetsweepPriority[FleetsweepPriority.NONE]);

        expect(lReturn).toEqual(FleetsweepPriorityEnum.NONE);
    });

    /**
     * Check getFullFleetsweepValueFromEnum method with Spurious priority
     */
    it('tests getFullFleetsweepValueFromEnum Spurious priority function', () => {
        const lReturn = FleetsweepUtils.getFullFleetsweepValueFromEnum(
            FleetsweepFilterTypeEnum.PRIORITY,
            FleetsweepPriority[FleetsweepPriority.SPURIOUS]);

        expect(lReturn).toEqual(FleetsweepPriorityEnum.SPURIOUS);
    });

    /**
     * Check getShortFleetsweepValueFromEnum method with High priority
     */
    it('tests getShortFleetsweepValueFromEnum High priority function', () => {
        const lReturn = FleetsweepUtils.getShortFleetsweepValueFromEnum(
            FleetsweepFilterTypeEnum.PRIORITY,
            FleetsweepPriority[FleetsweepPriority.HIGH]);

        expect(lReturn).toEqual('H');
    });

    /**
     * Check getShortFleetsweepValueFromEnum method with Warning event rank
     */
    it('tests getShortFleetsweepValueFromEnum High priority function', () => {
        const lReturn = FleetsweepUtils.getShortFleetsweepValueFromEnum(
            FleetsweepFilterTypeEnum.EVENT_RANK,
            FleetsweepEventRank[FleetsweepEventRank.W]);

        expect(lReturn).toEqual('W');
    });

    /**
     * Check getIconFromWorkStatusEnum method with To be reviewed work status
     */
    it('tests getIconFromWorkStatusEnum To be reviewed function', () => {
        const lReturn = FleetsweepUtils.getIconFromWorkStatusEnum(
            WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]);

        expect(lReturn).toEqual('location');
    });

    /**
     * Check getIconFromWorkStatusEnum method with Opened work status
     */
    it('tests getIconFromWorkStatusEnum Opened function', () => {
        const lReturn = FleetsweepUtils.getIconFromWorkStatusEnum(
            WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED]);

        expect(lReturn).toEqual('eye');
    });

    /**
     * Check getIconFromWorkStatusEnum method with Planned work status
     */
    it('tests getIconFromWorkStatusEnum Opened function', () => {
        const lReturn = FleetsweepUtils.getIconFromWorkStatusEnum(
            WorkOrderStatusEnum[WorkOrderStatusEnum.PLANNED]);

        expect(lReturn).toEqual('date_range');
    });

    /**
     * Check getIconFromWorkStatusEnum method with To be monitored work status
     */
    it('tests getIconFromWorkStatusEnum Opened function', () => {
        const lReturn = FleetsweepUtils.getIconFromWorkStatusEnum(
            WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_MONITORED]);

        expect(lReturn).toEqual('build');
    });

    /**
     * Check getIconFromWorkStatusEnum method with Closed work status
     */
    it('tests getIconFromWorkStatusEnum Closed function', () => {
        const lReturn = FleetsweepUtils.getIconFromWorkStatusEnum(
            WorkOrderStatusEnum[WorkOrderStatusEnum.CLOSED]);

        expect(lReturn).toEqual('check_checkbox');
    });

    /**
     * Check getIconFromWorkStatusEnum method with Ignored work status
     */
    it('tests getIconFromWorkStatusEnum Ignored function', () => {
        const lReturn = FleetsweepUtils.getIconFromWorkStatusEnum(
            WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED]);

        expect(lReturn).toEqual('cancel');
    });
});
