export const SpmComment1 = {
  eventId: 'AZ130^130^130',
  dateTime: '2017-11-26T19:10:00.000Z',
  author: 'shm',
  text: 'A comment'
};

export const SpmComment2 = {
  eventId: 'AZ130^130^130',
  dateTime: '2017-11-25T19:10:00.000Z',
  author: 'shm',
  text: 'A comment 2'
};

export const SpmCommentHistory1 = [
  SpmComment1,
  SpmComment2
];
