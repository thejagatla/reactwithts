import * as React from 'react';

/**
 * Chart with thresholds
 */
export const spmChart1 = {
  eventItems: [
    {
      eventId: 'L00737^ATA24_IDG_FREQUENCY_EXCURSION_M2:A330_#0_FREQUENCY^HIGH_FREQ_RISK_IDG1',
      eventItemId: '8c78760f-fcf7-5873-860a-d0ffecda18d3',
      isAlert: false,
      modelRef: 'ATA24_IDG_FREQUENCY_EXCURSION_M2:A330_#0_FREQUENCY',
      values: null,
      threshold: null,
      parameters: null,
      isMissingItem: false,
      flightUid: 1644677915,
      tailNumber: 'A6EYJ',
      xmsn: 'L00737',
      operator: 'EZY',
      family: 'A330',
      flightNb: 'ETD472',
      from: 'OMAA',
      fromDate: '2018-06-13T06:58:16.000Z',
      to: 'WIII',
      toDate: '2018-06-13T16:06:44.000Z',
      isMissingFlight: false,
      acIdSfp: '4626',
      dataSource: 'R38',
      maturity: 3,
      graphData: {
        RISK_THRESHOLD: 1,
        value1: 3
      },
      eventType: 'ATA24_IDG_FREQUENCY_EXCURSION_M2:A330_#0_FREQUENCY^HIGH_FREQ_RISK_IDG1'
    },
  ],
  displayProperties: {
    charts: [
      { 
        type: 'regular',
        id: '1',
        title: 'IDG1 High Frequency Excursion Risk',
        display: 'mandatory',
        'x-axis': [
          {
            name: 'x0',
            legend: 'Flights'
          }
        ],
        'y-axis': [
          {
            name: 'y0',
            legend: 'Risk',
            groups: [
              {
                type: 'line',
                'x-axis': 'x0',
                series: [
                  'value1'
                ]
              },
              {
                type: 'line',
                'x-axis': 'x0',
                series: [
                  'RISK_THRESHOLD'
                ]
              }
            ]
          }
        ]
      }
    ],
    series: [
      {
        name: 'value1',
        type: 'value',
        title: 'High Frequency Excursion Risk',
        unit: ''
      },
      {
        name: 'RISK_THRESHOLD',
        type: 'threshold',
        subtype: 'level1',
        title: 'Risk threshold',
        unit: ''
      }
    ],
    alerts: {
      title: 'High Frequency Excursion detected on IDG 1',
      ata4d: '2421',
      linkedAlerts: [
        {
          modelinstanceid: 'ATA24_IDG_FREQUENCY_EXCURSION_M2:A330_#0_FREQUENCY',
          alertid: 'HIGH_FREQ_RISK_IDG2'
        },
        {
          modelinstanceid: 'ATA24_IDG_FREQUENCY_EXCURSION_M2:A330_#0_FREQUENCY',
          alertid: 'LOW_FREQ_RISK_IDG1'
        },
        {
          modelinstanceid: 'ATA24_IDG_FREQUENCY_EXCURSION_M2:A330_#0_FREQUENCY',
          alertid: 'LOW_FREQ_RISK_IDG2'
        }
      ]
    }
  }
 
  /*displayProperties: {
    charts: [],
    series: [{
      name: "value1",
      title: "Oil delta temperature mean trend",
      type: "value",
      unit: "degC"
    }
    ],
  },
  eventItems: [
    {
      eventId: 'AZ123^123^123',
      toDate: '2015-04-03T04:08:00+0000',
      tailNumber: 'F-GLZK',
      eventItemId: '1',
      graphData: {
        SLOPE_THRESHOLD: 2,
        value1: 2,
      },
      isAlert: false,
      flightNb: 'AF6259',
      modelRef: '1',
      parameters: null,
      isMissingFlight: false,
      flightHash: '-982554000000',
      xmsn: 'AZ123',
      eventType: '123^123'
    },
    {
      eventId: 'AZ123^123^123',
      toDate: '2015-04-03T16:51:00+0000',
      tailNumber: 'F-GLZK',
      eventItemId: '2',
      graphData: {
        SLOPE_THRESHOLD: 2,
        value1: 2,
      },
      isAlert: false,
      flightNb: 'AF6259',
      modelRef: '1',
      parameters: null,
      isMissingFlight: true,
      flightHash: '1025690000000',
      xmsn: 'AZ123',
      eventType: '123^123'
    },
    {
      eventId: 'AZ123^123^123',
      toDate: '2015-04-04T03:56:00+0000',
      tailNumber: 'F-GLZK',
      eventItemId: '3',
      graphData: {
        SLOPE_THRESHOLD: 2,
        value1: 3,
      },
      isAlert: true,
      flightNb: 'AF6259',
      modelRef: '1',
      parameters: null,
      isMissingFlight: false,
      flightHash: '816773976',
      xmsn: 'AZ123',
      eventType: '123^123'
    },
    {
      eventId: 'AZ123^123^123',
      toDate: '2015-04-04T17:05:00+0000',
      tailNumber: 'F-GLZK',
      eventItemId: '4',
      graphData: {
        SLOPE_THRESHOLD: 2,
        value1: 4,
      },
      isAlert: true,
      flightNb: 'AF54216',
      modelRef: '1',
      parameters: null,
      isMissingFlight: false,
      flightHash: '-257423904',
      xmsn: 'AZ123',
      eventType: '123^123'
    },
    {
      eventId: 'AZ123^123^123',
      toDate: '2015-04-05T03:32:00+0000',
      tailNumber: 'F-GLZK',
      eventItemId: '5',
      graphData: {
        SLOPE_THRESHOLD: 2,
        value1: 5,
      },
      isAlert: true,
      flightNb: 'AF4060',
      modelRef: '1',
      parameters: null,
      isMissingFlight: false,
      flightHash: '1385269076',
      xmsn: 'AZ123',
      eventType: '123^123'
    }
  ]*/
};

export const spmChartDataColumnsExpected1 = [
  ['data0', 2, null, 3, 0, 3],
  ['threshold0', 2, 2, 2, 2, 2],
  ['threshold1', 2, 3, 4, 2, 3],
  ['x', '0', '1', '2', '3', '4']
];

export const spmChartDataColorsExpected1 = {
  data0: '#00AEC7',
  threshold0: '#DA188499',
  threshold1: '#DA188499'
};

export const spmChartDataTypesExpected1 = {
  data0: 'line',
  threshold0: 'step',
  threshold1: 'step'
};

/**
 * Chart without thresholds
 */
export const spmChart2 = {
  eventItems: [
    {
      eventId: 'AZ123^123^123',
      toDate: '2015-04-03T04:08:00+0000',
      tailNumber: 'F-GLZK',
      eventItemId: '1',
      values: [
        2,
        38
      ],
      threshold: [],
      isAlert: false,
      flightNb: 'AF6259',
      modelRef: '1',
      parameters: null,
      isMissingFlight: false,
      flightHash: '-982554000000',
      xmsn: 'AZ123',
      eventType: '123^123'
    },
    {
      eventId: 'AZ123^123^123',
      toDate: '2015-04-03T16:51:00+0000',
      tailNumber: 'F-GLZK',
      eventItemId: '2',
      values: [
        3,
        3
      ],
      threshold: [],
      isAlert: false,
      flightNb: 'AF6259',
      modelRef: '1',
      parameters: null,
      isMissingFlight: false,
      flightHash: '1025690000000',
      xmsn: 'AZ123',
      eventType: '123^123'
    },
    {
      eventId: 'AZ123^123^123',
      toDate: '2015-04-04T03:56:00+0000',
      tailNumber: 'F-GLZK',
      eventItemId: '3',
      values: [
        3,
        1
      ],
      threshold: [],
      isAlert: true,
      flightNb: 'AF6259',
      modelRef: '1',
      parameters: null,
      isMissingFlight: false,
      flightHash: '816773976',
      xmsn: 'AZ123',
      eventType: '123^123'
    },
    {
      eventId: 'AZ123^123^123',
      toDate: '2015-04-04T17:05:00+0000',
      tailNumber: 'F-GLZK',
      eventItemId: '4',
      values: [
        0,
        0
      ],
      threshold: [],
      isAlert: true,
      flightNb: 'AF54216',
      modelRef: '1',
      parameters: null,
      isMissingFlight: false,
      flightHash: '-257423904',
      xmsn: 'AZ123',
      eventType: '123^123'
    },
    {
      eventId: 'AZ123^123^123',
      toDate: '2015-04-05T03:32:00+0000',
      tailNumber: 'F-GLZK',
      eventItemId: '5',
      values: [
        3,
        1
      ],
      threshold: [],
      isAlert: true,
      flightNb: 'AF4060',
      modelRef: '1',
      parameters: null,
      isMissingFlight: false,
      flightHash: '1385269076',
      xmsn: 'AZ123',
      eventType: '123^123'
    },
    {
      eventId: 'AZ123^123^123',
      toDate: '2015-04-05T03:32:00+0000',
      tailNumber: 'F-GLZK',
      eventItemId: '6',
      values: [
        3,
        2
      ],
      threshold: [],
      isAlert: true,
      flightNb: 'AF4060',
      modelRef: '1',
      parameters: null,
      isMissingFlight: false,
      flightHash: '1385269076',
      xmsn: 'AZ123',
      eventType: '123^123'
    }
  ]
};

/*export const spmChartDataColumnsExpected2 = [
  ['data0', 2, 3, 3, 0, 3, 3],
  ['data1', 38, 3, 1, 0, 1, 2],
  ['x', '0', '1', '2', '3', '4', '5']
];

export const spmChartDataColorsExpected2 = {
  data0: '#00AEC7',
  data1: '#005587'
};

export const spmChartDataTypesExpected2 = {
  data0: 'line',
  data1: 'line'
};*/

/**
 * Regular event item
 */
export const spmEventItem1 = {
  eventId: 'AZ123^123^123',
  eventItemId: '1',
  family: '',
  flightNb: 'AF6259',
  flightUuid: 982554000000,
  from: 'EDDB',
  fromDate: '2015-04-03T02:08:00+0000',
  isAlert: false,
  isMissingFlight: false,
  isMissingItem: false,
  modelRef: '1',
  parameters: null,
  tailNumber: 'F-GLZK',
  threshold: [
    2,
    2
  ],
  to: 'LEBL',
  toDate: '2015-04-03T04:08:00+0000',
  values: [
    2
  ],
  xmsn: 'AZ123',
};

export const spmSelectedPoint1 = {
  chartData: [
    {
      id: 'data0',
      index: 0,
      name: 'data0',
      value: 1,
      x: 0,
    }
  ],
  eventData: {
    eventId: 'AZ123^123^123',
    eventItemId: '1',
    family: '',
    flightNb: 'AF6259',
    flightUuid: 982554000000,
    from: 'EDDB',
    fromDate: '2015-04-03T02:08:00+0000',
    isAlert: false,
    isMissingFlight: false,
    isMissingItem: false,
    modelRef: '1',
    parameters: null,
    tailNumber: 'F-GLZK',
    threshold: [
      2,
      2
    ],
    to: 'LEBL',
    toDate: '2015-04-03T04:08:00+0000',
    values: [
      2
    ],
    xmsn: 'AZ123',
  }
};

/**
 * Event item without flight data
 */
export const spmEventItem2 = {
  eventId: 'AZ123^123^123',
  toDate: '2015-04-03T04:08:00+0000',
  tailNumber: 'F-GLZK',
  eventItemId: '2',
  values: [
    2
  ],
  threshold: [
    2,
    2
  ],
  isAlert: false,
  flightNb: 'AF6259',
  modelRef: '1',
  parameters: null,
  isMissingFlight: false,
  flightHash: '-982554000000',
  xmsn: 'AZ123',
  eventType: '123^123'
};

export const spmSelectedPoint2 = {
  chartData: [
    {
      id: 'data0',
      index: 1,
      name: 'data0',
      value: 2,
      x: 1,
    }
  ],
  eventData: {
    eventId: 'AZ123^123^123',
    toDate: '2015-04-03T04:08:00+0000',
    tailNumber: 'F-GLZK',
    eventItemId: '2',
    values: [
      2
    ],
    threshold: [
      2,
      2
    ],
    isAlert: false,
    flightNb: 'AF6259',
    modelRef: '1',
    parameters: null,
    isMissingFlight: false,
    flightHash: '-982554000000',
    xmsn: 'AZ123',
    eventType: '123^123'
  }
};

/**
 * Regular event item
 */
export const spmEventItem3 = {
  eventId: 'AZ123^123^123',
  eventItemId: '3',
  family: 'A320',
  flightNb: 'AF6259',
  flightUuid: 816773976,
  from: 'EDDB',
  fromDate: '2015-04-04T01:56:00+0000',
  isAlert: true,
  isMissingFlight: false,
  isMissingItem: false,
  modelRef: '1',
  parameters: null,
  tailNumber: 'F-GLZK',
  threshold: [
    2,
    4
  ],
  to: 'LEBL',
  toDate: '2015-04-04T03:56:00+0000',
  values: [
    3
  ],
  xmsn: 'AZ123',
};

export const spmSelectedPoint3 = {
  chartData: [
    {
      id: 'data0',
      index: 2,
      name: 'data0',
      value: 1,
      x: 2,
    }
  ],
  eventData: {
    eventId: 'AZ123^123^123',
    eventItemId: '3',
    family: 'A320',
    flightNb: 'AF6259',
    flightUuid: 816773976,
    from: 'EDDB',
    fromDate: '2015-04-04T01:56:00+0000',
    isAlert: true,
    isMissingFlight: false,
    isMissingItem: false,
    modelRef: '1',
    parameters: null,
    tailNumber: 'F-GLZK',
    threshold: [
      2,
      4
    ],
    to: 'LEBL',
    toDate: '2015-04-04T03:56:00+0000',
    values: [
      3
    ],
    xmsn: 'AZ123',
  }
};

/**
 * Event item with empty flight values and isMissingFlight
 */
export const spmEventItem4 = {
  eventId: 'AZ123^123^123',
  toDate: '',
  tailNumber: '',
  eventItemId: '4',
  values: [],
  threshold: [],
  isAlert: true,
  flightNb: '',
  modelRef: '',
  parameters: null,
  isMissingFlight: true,
  flightHash: '',
  xmsn: 'AZ123',
  eventType: '123^123'
};

export const spmSelectedPoint4 = {
  chartData: [
    {
      id: 'data0',
      index: 3,
      name: 'data0',
      value: 1,
      x: 3,
    }
  ],
  eventData: {
    eventId: 'AZ123^123^123',
    toDate: '2015-04-04T17:05:00+0000',
    tailNumber: 'F-GLZK',
    eventItemId: '4',
    values: [],
    threshold: [
      2,
      2
    ],
    isAlert: true,
    flightNb: 'AF54216',
    modelRef: '1',
    parameters: null,
    isMissingFlight: false,
    flightHash: '-257423904',
    xmsn: 'AZ123',
    eventType: '123^123'
  }
};

/**
 * Regular event item with 2 values
 */
export const spmEventItem5 = {
  eventId: 'AZ123^123^123',
  toDate: '2015-04-05T03:32:00+0000',
  tailNumber: 'F-GLZK',
  eventItemId: '5',
  values: [
    3,
    4
  ],
  threshold: [
    2,
    3
  ],
  isAlert: true,
  flightNb: 'AF4060',
  modelRef: '1',
  parameters: null,
  isMissingFlight: false,
  flightHash: '1385269076',
  xmsn: 'AZ123',
  eventType: '123^123'
};

export const spmSelectedPoint5 = {
  chartData: [
    {
      id: 'data0',
      index: 4,
      name: 'data0',
      value: 1,
      x: 4,
    }
  ],
  eventData: {
    eventId: 'AZ123^123^123',
    toDate: '2015-04-05T03:32:00+0000',
    tailNumber: 'F-GLZK',
    eventItemId: '5',
    values: [
      3,
      4
    ],
    threshold: [
      2,
      3
    ],
    isAlert: true,
    flightNb: 'AF4060',
    modelRef: '1',
    parameters: null,
    isMissingFlight: false,
    flightHash: '1385269076',
    xmsn: 'AZ123',
    eventType: '123^123'
  }
};

/**
 * Chart without data
 */
export const spmChart3 = {

  displayProperties: {
    alerts: {
    },
    charts: [
    ],
    series: [
    ],
  },
  eventItems: [],
};
