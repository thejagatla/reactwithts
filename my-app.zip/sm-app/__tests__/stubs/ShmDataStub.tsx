import * as React from 'react';

export const lExpectedResult1 = (
    <ul className="occ-history">
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__no-flight">&nbsp;</li>
        <li className="occ-history__no-flight">&nbsp;</li>
        <li className="occ-history__no-flight">&nbsp;</li>
        <li className="occ-history__shm">3</li>
    </ul>
);

export const lEvent1 = {
    hashKey: 'LA-AC1^W1^240000',
    acEventId: 24723,
    ata6: '240000',
    messageID: 'ID:414d51205346502e4d422e514d202020bb86675908b03921',
    acMatricule: 'LA-AC1',
    aircraftType: 'A320',
    eventDate: '2017-11-23T04:13:00',
    smEventDate: '2017-12-12T04:31:00',
    eventType: 'FAULT_MESSAGE',
    fcid: '24723',
    flightNumber: 'NW675',
    msn: 1249,
    operatorId: 61,
    flightPhase: 'PHASE_3',
    titleFromAircraft: 'W1',
    statusInfoItem: {},
    occurrenceHistory: [
        {
            d: '2017-12-12T04:31:00',
            p: 'PHASE_3'
        }
    ],
    workOrderStatus: 'TO_BE_REVIEWED',
    uiWorkOrderStatus: 'To be reviewed',
    isWorkOrderStatusHighlighted: 'To be',
    origin: 'SHM',
    latest: true,
    smUiEventDate: '12 dec 2017 04:31',
    type: 'smEventOccurrence',
    flightOccurrence: [
        '2017-11-23T04:31:00',
        '2017-11-24T04:31:00',
        '2017-11-25T04:31:00',
        '2017-12-12T04:31:00'
    ]
};

export const lExpectedResult2 = (
    <ul className="occ-history">
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__shm">2</li>
        <li className="occ-history__shm">3</li>
    </ul>
);

export const lExpectedResult3 = (
    <ul className="occ-history">
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__shm">2</li>
        <li className="occ-history__shm">3</li>
        <li className="occ-history__no-flight">&nbsp;</li>
    </ul>
);

export const lExpectedResult4 = (
    <ul className="occ-history">
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__shm">2</li>
        <li className="occ-history__shm">3</li>
        <li className="occ-history__no-flight">&nbsp;</li>
        <li className="occ-history__shm">12</li>
    </ul>
);

export const lExpectedResult5 = (
    <div className="status-infos--work-reference">
        <label>Work Ref: </label>
        testSHM
    </div>
);

export const lEvent2 = {
    latest: true,
    occurrenceHistory: [
        {
            d: '2017-11-05T05:41:57.185',
            p: 'PHASE_2'
        },
        {
            d: '2017-11-06T05:41:57.185',
            p: 'PHASE_3'
        }
    ],
    flightOccurrence: [
        '2017-11-05T05:41:57.185',
        '2017-11-06T05:41:57.185'
    ],
    origin: 'SHM',
    workOrderReference: 'testSHM',
    workOrderStatus: 'OPENED',
    uiWorkOrderStatus: 'Opened',
    workOrderComment: 'A comment',
    flightNumber: '1234',
    acMatricule: 'ABC-XNG',
    eventClass: '1',
    eventAta: 'Ata',
    eventType: 'WARNING',
    titleFromAircraft: 'A title',
    smEventDate: '2017-11-23T21:07:57.185'
};

export const lEvent3 = {
    acMatricule: 'ABC-XNG',
    eventAta: 'Ata',
    eventClass: '1',
    latest: true,
    occurrenceHistory: [
        {
            d: '2017-11-05T05:41:57.185',
            p: 'PHASE_2'
        },
        {
            d: '2017-11-06T05:41:57.185',
            p: 'PHASE_3'
        }
    ],
    flightOccurrence: [
        '2017-11-05T05:41:57.185',
        '2017-11-06T05:41:57.185',
        '2017-11-07T05:41:57.185'
    ],
    flightNumber: '1234',
    origin: 'SHM',
    smEventDate: '2017-11-23T21:07:57.185',
    titleFromAircraft: 'A title',
    workOrderStatus: 'PLANNED',
    uiWorkOrderStatus: 'Planned',
    workOrderComment: 'A comment',
    workOrderPlannedDate: '2017-11-06T05:41:57.185'  
};

export const lEvent4 = {
    latest: true,
    occurrenceHistory: [
        {
            d: '2017-11-05T05:41:57.185',
            p: 'PHASE_2'
        },
        {
            d: '2017-11-06T05:41:57.185',
            p: 'PHASE_3'
        },
        {
            d: '2017-11-08T05:41:57.185',
            p: 'PHASE_12'
        }
    ],
    flightOccurrence: [
        '2017-11-05T05:41:57.185',
        '2017-11-06T05:41:57.185',
        '2017-11-07T05:41:57.185',
        '2017-11-08T05:41:57.185'
    ],
    origin: 'SHM',
    workOrderStatus: 'TO_BE_MONITORED',
    uiWorkOrderStatus: 'To be monitored',    
    workOrderComment: 'A comment',
    flightNumber: '1234',
    acMatricule: 'ABC-XNG',
    eventClass: '1',
    eventAta: 'Ata',
    titleFromAircraft: 'A title',
    smEventDate: '2017-11-23T21:07:57.185'
};

export const lEvent5 = {
    latest: true,
    occurrenceHistory: [
        {
            d: '2017-11-05T05:41:57.185',
            p: 'PHASE_2'
        },
        {
            d: '2017-11-06T05:41:57.185',
            p: 'PHASE_3'
        },
        {
            d: '2017-11-08T05:41:57.185',
            p: 'PHASE_12'
        }
    ],
    flightOccurrence: [
        '2017-11-05T05:41:57.185',
        '2017-11-06T05:41:57.185',
        '2017-11-07T05:41:57.185',
        '2017-11-08T05:41:57.185'
    ],
    origin: 'SHM',
    workOrderStatus: 'CLOSED',
    uiWorkOrderStatus: 'Closed',    
    workOrderComment: 'A comment',
    flightNumber: '1234',
    acMatricule: 'ABC-XNG',
    eventClass: '1',
    eventAta: 'Ata',
    titleFromAircraft: 'A title',
    smEventDate: '2017-11-23T21:07:57.185'
};

export const lEvent6 = {
    latest: true,
    occurrenceHistory: [
        {
            d: '2017-11-05T05:41:57.185',
            p: 'PHASE_2'
        },
        {
            d: '2017-11-06T05:41:57.185',
            p: 'PHASE_3'
        },
        {
            d: '2017-11-08T05:41:57.185',
            p: 'PHASE_12'
        }
    ],
    flightOccurrence: [
        '2017-11-05T05:41:57.185',
        '2017-11-06T05:41:57.185',
        '2017-11-07T05:41:57.185',
        '2017-11-08T05:41:57.185'
    ],
    origin: 'SHM',
    workOrderStatus: 'IGNORED',
    uiWorkOrderStatus: 'Ignored',
    workOrderComment: 'A comment',
    flightNumber: '1234',
    acMatricule: 'ABC-XNG',
    eventClass: '1',
    eventAta: 'Ata',
    titleFromAircraft: 'A title',
    smEventDate: '2017-11-23T21:07:57.185'
};
