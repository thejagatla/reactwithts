
export const workStatusFilters = [
    {
        active: true,
        id: 'TO_BE_REVIEWED',
        label: 'To be reviewed'
    },
    {
        active: true,
        id: 'OPENED',
        label: 'Opened'
    },
    {
        active: false,
        id: 'PLANNED',
        label: 'planned'
    },
    {
        active: false,
        id: 'TO_BE_MONITORED',
        label: 'to be monitored'
    },
    {
        active: false,
        id: 'CLOSED',
        label: 'Closed'
    },
    {
        active: false,
        id: 'IGNORED',
        label: 'Ignored'
    }
];
