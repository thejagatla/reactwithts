import * as React from 'react';

export const lExpectedResult1 = (
    <ul className="occ-history">
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__spm">&nbsp;</li>
    </ul>
);

export const lEvent1 = {
    latest: true,
    occurrenceHistory: [
        {
            d: '2017-11-05T05:41:57.185'
        }
    ],
    flightOccurrence: [
        '2017-11-05T05:41:57.185'
    ],
    statusInfoItem: {
        status: 'TO_BE_REVIEWED'
    }
    ata6: 11200,
    origin: 'SPM',
    workOrderStatus: 'TO_BE_REVIEWED',
    uiWorkOrderStatus: 'To be reviewed',
    workOrderComment: 'A comment',
    flightNumber: '1234',
    acMatricule: 'ABC-XNG',
    eventClass: '1',
    eventAta: 'Ata',
    titleFromAircraft: 'A title',
    smEventDate: '2017-11-23T21:07:57.185'
};

export const lExpectedResult2 = (
    <ul className="occ-history">
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__spm">&nbsp;</li>
        <li className="occ-history__spm">&nbsp;</li>
    </ul>
);

export const lExpectedResult3 = (
    <ul className="occ-history">
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__spm">&nbsp;</li>
        <li className="occ-history__spm">&nbsp;</li>
        <li className="occ-history__no-flight">&nbsp;</li>
    </ul>
);

export const lExpectedResult4 = (
    <ul className="occ-history">
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__empty-flight">&nbsp;</li>
        <li className="occ-history__spm">&nbsp;</li>
        <li className="occ-history__spm">&nbsp;</li>
        <li className="occ-history__no-flight">&nbsp;</li>
        <li className="occ-history__spm">&nbsp;</li>
    </ul>
);

export const lEvent2 = {
    latest: true,
    occurrenceHistory: [
        {
            d: '2017-11-05T05:41:57.185'
        },
        {
            d: '2017-11-06T05:41:57.185'
        }
    ],
    flightOccurrence: [
        '2017-11-05T05:41:57.185',
        '2017-11-06T05:41:57.185'
    ],
    origin: 'SPM',
    workOrderStatus: 'OPENED',
    uiWorkOrderStatus: 'Opened',
    workOrderComment: 'A comment',
    flightNumber: '1234',
    acMatricule: 'ABC-XNG',
    eventClass: '1',
    eventAta: 'Ata',
    statusInfoItem: {
        status: 'OPENED'
    },
    titleFromAircraft: 'A title',
    smEventDate: '2017-11-23T21:07:57.185'
};

export const lEvent3 = {
    latest: true,
    occurrenceHistory: [
        {
            d: '2017-11-05T05:41:57.185'
        },
        {
            d: '2017-11-06T05:41:57.185'
        }
    ],
    flightOccurrence: [
        '2017-11-05T05:41:57.185',
        '2017-11-06T05:41:57.185',
        '2017-11-07T05:41:57.185'
    ],
    origin: 'SPM',
    workOrderStatus: 'PLANNED',
    uiWorkOrderStatus: 'Planned',
    workOrderComment: 'A comment',
    flightNumber: '1234',
    acMatricule: 'ABC-XNG',
    statusInfoItem: {
        status: 'PLANNED'
    },
    eventClass: '1',
    eventAta: 'Ata',
    titleFromAircraft: 'A title',
    smEventDate: '2017-11-23T21:07:57.185'
};

export const lEvent4 = {
    latest: true,
    occurrenceHistory: [
        {
            d: '2017-11-05T05:41:57.185'
        },
        {
            d: '2017-11-06T05:41:57.185'
        },
        {
            d: '2017-11-08T05:41:57.185'
        }
    ],
    flightOccurrence: [
        '2017-11-05T05:41:57.185',
        '2017-11-06T05:41:57.185',
        '2017-11-07T05:41:57.185',
        '2017-11-08T05:41:57.185'
    ],
    origin: 'SPM',
    workOrderStatus: 'TO_BE_MONITORED',
    uiWorkOrderStatus: 'To be monitored',
    workOrderComment: 'A comment',
    flightNumber: '1234',
    acMatricule: 'ABC-XNG',
    statusInfoItem: {
        status: 'TO_BE_MONITORED'
    },
    eventClass: '1',
    eventAta: 'Ata',
    titleFromAircraft: 'A title',
    smEventDate: '2017-11-23T21:07:57.185'
};

export const lEvent5 = {
    latest: true,
    occurrenceHistory: [
        {
            d: '2017-11-05T05:41:57.185'
        },
        {
            d: '2017-11-06T05:41:57.185'
        },
        {
            d: '2017-11-08T05:41:57.185'
        }
    ],
    flightOccurrence: [
        '2017-11-05T05:41:57.185',
        '2017-11-06T05:41:57.185',
        '2017-11-07T05:41:57.185',
        '2017-11-08T05:41:57.185'
    ],
    origin: 'SPM',
    workOrderStatus: 'CLOSED',
    uiWorkOrderStatus: 'Closed',
    workOrderComment: 'A comment',
    flightNumber: '1234',
    acMatricule: 'ABC-XNG',
    eventClass: '1',
    statusInfoItem: {
        status: 'CLOSED'
    },
    eventAta: 'Ata',
    titleFromAircraft: 'A title',
    smEventDate: '2017-11-23T21:07:57.185'
};

export const lEvent6 = {
    latest: true,
    occurrenceHistory: [
        {
            d: '2017-11-05T05:41:57.185'
        },
        {
            d: '2017-11-06T05:41:57.185'
        },
        {
            d: '2017-11-08T05:41:57.185'
        }
    ],
    flightOccurrence: [
        '2017-11-05T05:41:57.185',
        '2017-11-06T05:41:57.185',
        '2017-11-07T05:41:57.185',
        '2017-11-08T05:41:57.185'
    ],
    origin: 'SPM',
    workOrderStatus: 'IGNORED',
    uiWorkOrderStatus: 'Ignored',
    workOrderComment: 'A comment',
    flightNumber: '1234',
    acMatricule: 'ABC-XNG',
    statusInfoItem: {
        status: 'IGNORED'
    },
    eventClass: '1',
    eventAta: 'Ata',
    titleFromAircraft: 'A title',
    smEventDate: '2017-11-23T21:07:57.185'
};

/**
 * Event
 * Priority LOW
 * Status TO_BE_REVIEWED
 */
export const spmEvent1 = {
    eventId: 'AZ123^123^123',
    tailNumber: 'F-GLZK',
    family: 'A320',
    eventCreationTimestamp: '2017-06-02T06:47:43+0000',
    eventClosureTimestamp: null,
    ataChapter: 'ATA46',
    riskName: 'Low_pressure_risk',
    riskPriority: 'LOW',
    occurenceCount: 1,
    flightCount: 101,
    statusInfoItem: {
        airport: "TLS",
        attachments: [],
        author: 'author',
        comment: 'comment',
        dateTime: '2017-11-20T10:23:00+0000',
        deleted: false,
        eventId: 'N00001^O2_LEAK^LEAK',
        fltBefore: '000123A',
        possibleCause: 'possibleCause',
        status: 'TO_BE_REVIEWED',
        workDatetime: '2017-11-20T10:23:00+0000',
        workReference: 'workReference'
    },
    ohFlights: null,
    ohOccurrences: null,
    ohOpenDate: '',
    ohPlannedDate: '',
    ohToBeMonitoredDate: '',
    xmsn: 'AZ123',
    eventType: '123^123'
};

/**
 * Event
 * Priority LOW
 * Status OPENED
 */
export const spmEvent2 = {
    eventId: 'AZ123^123^123',
    tailNumber: 'F-GLZK',
    family: 'A320',
    eventCreationTimestamp: '2017-06-02T06:47:43+0000',
    eventClosureTimestamp: null,
    ataChapter: 'ATA46',
    riskName: 'Low_pressure_risk',
    riskPriority: 'LOW',
    occurenceCount: 1,
    flightCount: 101,
    statusInfoItem: {
        airport: "TLS",
        attachments: [],
        author: 'author',
        comment: 'comment',
        dateTime: '2017-11-20T10:23:00+0000',
        deleted: false,
        eventId: 'N00001^O2_LEAK^LEAK',
        fltBefore: '000123A',
        possibleCause: 'possibleCause',
        status: 'OPENED',
        workDatetime: '2017-11-20T10:23:00+0000',
        workReference: 'workReference'
    },
    ohFlights: null,
    ohOccurrences: null,
    ohOpenDate: '',
    ohPlannedDate: '',
    ohToBeMonitoredDate: '',
    xmsn: 'AZ123',
    eventType: '123^123'
};

/**
 * Event
 * Priority MEDIUM
 * Status PLANNED
 */
export const spmEvent3 = {
    eventId: 'AZ123^123^123',
    tailNumber: 'F-GLZK',
    family: 'A320',
    eventCreationTimestamp: '2017-06-02T06:47:43+0000',
    eventClosureTimestamp: null,
    ataChapter: 'ATA46',
    riskName: 'Low_pressure_risk',
    riskPriority: 'MEDIUM',
    occurenceCount: 1,
    flightCount: 101,
    statusInfoItem: {
        airport: "TLS",
        attachments: [],
        author: 'author',
        comment: 'comment',
        dateTime: '2017-11-20T10:23:00+0000',
        deleted: false,
        eventId: 'N00001^O2_LEAK^LEAK',
        fltBefore: '000123A',
        possibleCause: 'possibleCause',
        status: 'PLANNED',
        workDatetime: '2017-11-20T10:23:00+0000',
        workReference: 'workReference'
    },
    ohFlights: null,
    ohOccurrences: null,
    ohOpenDate: '',
    ohPlannedDate: '',
    ohToBeMonitoredDate: '',
    xmsn: 'AZ123',
    eventType: '123^123'
};

/**
 * Event
 * Priority MEDIUM
 * Status TO_BE_MONITORED
 */
export const spmEvent4 = {
    eventId: 'AZ123^123^123',
    tailNumber: 'F-GLZK',
    family: 'A320',
    eventCreationTimestamp: '2017-06-02T06:47:43+0000',
    eventClosureTimestamp: null,
    ataChapter: 'ATA46',
    riskName: 'Low_pressure_risk',
    riskPriority: 'MEDIUM',
    occurenceCount: 1,
    flightCount: 101,
    statusInfoItem: {
        airport: "TLS",
        attachments: [],
        author: 'author',
        comment: 'comment',
        dateTime: '2017-11-20T10:23:00+0000',
        deleted: false,
        eventId: 'N00001^O2_LEAK^LEAK',
        fltBefore: '000123A',
        possibleCause: 'possibleCause',
        status: 'TO_BE_MONITORED',
        workDatetime: '2017-11-20T10:23:00+0000',
        workReference: 'workReference'
    },
    ohFlights: null,
    ohOccurrences: null,
    ohOpenDate: '',
    ohPlannedDate: '',
    ohToBeMonitoredDate: '',
    xmsn: 'AZ123',
    eventType: '123^123'
};

/**
 * Event
 * Priority HIGH
 * Status IGNORED
 */
export const spmEvent5 = {
    eventId: 'AZ123^123^123',
    tailNumber: 'F-GLZK',
    family: 'A320',
    eventCreationTimestamp: '2017-06-02T06:47:43+0000',
    eventClosureTimestamp: null,
    ataChapter: 'ATA46',
    riskName: 'Low_pressure_risk',
    riskPriority: 'HIGH',
    occurenceCount: 1,
    flightCount: 101,
    statusInfoItem: {
        airport: "TLS",
        attachments: [],
        author: 'author',
        comment: 'comment',
        dateTime: '2017-11-20T10:23:00+0000',
        deleted: false,
        eventId: 'N00001^O2_LEAK^LEAK',
        fltBefore: '000123A',
        possibleCause: 'possibleCause',
        status: 'IGNORED',
        workDatetime: '2017-11-20T10:23:00+0000',
        workReference: 'workReference'
    },
    ohFlights: null,
    ohOccurrences: null,
    ohOpenDate: '',
    ohPlannedDate: '',
    ohToBeMonitoredDate: '',
    xmsn: 'AZ123',
    eventType: '123^123'
};

/**
 * Event
 * Priority HIGH
 * Status CLOSED
 */
export const spmEvent6 = {
    eventId: 'AZ123^123^123',
    tailNumber: 'F-GLZK',
    family: 'A320',
    eventCreationTimestamp: '2017-06-02T06:47:43+0000',
    eventClosureTimestamp: null,
    ataChapter: 'ATA46',
    riskName: 'Low_pressure_risk',
    riskPriority: 'HIGH',
    occurenceCount: 1,
    flightCount: 101,
    statusInfoItem: {
        airport: "TLS",
        attachments: [],
        author: 'author',
        comment: 'comment',
        dateTime: '2017-11-20T10:23:00+0000',
        deleted: false,
        eventId: 'N00001^O2_LEAK^LEAK',
        fltBefore: '000123A',
        possibleCause: 'possibleCause',
        status: 'CLOSED',
        workDatetime: '2017-11-20T10:23:00+0000',
        workReference: 'workReference'
    },
    ohFlights: null,
    ohOccurrences: null,
    ohOpenDate: '',
    ohPlannedDate: '',
    ohToBeMonitoredDate: '',
    xmsn: 'AZ123',
    eventType: '123^123'
};

/**
 * Event
 * Priority LOW
 * Status TO_BE_REVIEWED
 */
export const spmEvent7 = {
    eventId: 'AZ123^123^123',
    tailNumber: 'F-GLZK',
    family: 'A320',
    eventCreationTimestamp: '2017-06-02T06:47:43+0000',
    eventClosureTimestamp: null,
    ataChapter: 'ATA46',
    riskName: 'Low_pressure_risk',
    riskPriority: 'LOW',
    origin: 'SPM',
    occurenceCount: 1,
    flightCount: 101,
    statusInfoItem: {
        airport: "TLS",
        attachments: [],
        dateTime: '2017-11-20T10:23:00+0000',
        deleted: false,
        eventId: 'N00001^O2_LEAK^LEAK',
        fltBefore: '000123A',
        possibleCause: 'possibleCause',
        status: 'TO_BE_REVIEWED',
        workDatetime: '2017-11-20T10:23:00+0000',
    },
    ohFlights: null,
    ohOccurrences: null,
    ohOpenDate: '',
    ohPlannedDate: '',
    ohToBeMonitoredDate: '',
    xmsn: 'AZ123',
    eventType: '123^123'
};