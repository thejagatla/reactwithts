export const models1 = [
  {
    modelId: 'modelId',
    modelName: 'modelName',
  },
  {
    modelId: 'modelId2',
    modelName: 'modelName2',
  }
];

export const loadModelsException = {
  message: 'testMessage',
  smTraceId: 'testSmTraceId',
  support: {
    contactChinese: 'testContactChinese',
    contactEnglish: 'testContactEnglish',
    techRequestUrl: 'testTechRequestUrl'
  },
};

export const modelConf = {
  modelConfigurations: [
    {
      effectivity: {
        aircraftType: 'A319',
        engineType: 'CFM56-5B5/3'
      },
      parameters: [
        {
          name: 'DURATION_THRESHOLD',
          value: null
        },
        {
          name: 'MATURITY',
          value: null
        },
        {
          name: 'MAX_DURATION_SEC',
          value: null
        },
        {
          name: 'POURCENTAGE_FLIGHT_THRESHOLD',
          value: null
        }
      ]
    },
    {
      effectivity: {
        aircraftType: 'A320',
        engineType: 'CFM56 - 5B4/3'
      },
      parameters: [
        {
          name: 'DURATION_THRESHOLD',
          value: null
        },
        {
          name: 'MATURITY',
          value: null
        },
        {
          name: 'MAX_DURATION_SEC',
          value: null
        },
        {
          name: 'POURCENTAGE_FLIGHT_THRESHOLD',
          value: null
        }
      ]
    },
    {
      effectivity: {
        aircraftType: 'A319',
        engineType: 'CFM56 - 5B5/P'
      },
      parameters: [
        {
          name: 'DURATION_THRESHOL',
          value: null
        },
        {
          name: 'MATURITY',
          value: null
        },
        {
          name: 'MAX_DURATION_SEC',
          value: null
        },
        {
          name: 'POURCENTAGE_FLIGHT_THRESHOLD',
          value: null
        }
      ]
    }
  ]
};

export const modelDef = {
  modelDefinition: {
    parameters: [
      {
        name: 'DURATION_THRESHOLD',
        dtype: 'integer',
        type: 'threshold',
        description: null,
        defaultMin: null,
        defaultMax: null,
        unit: null,
        defaultValue: null
      },
      {
        name: 'MATURITY',
        dtype: 'integer',
        type: 'parameter',
        description: null,
        defaultMin: 0,
        defaultMax: 3,
        unit: null,
        defaultValue: null
      },
      {
        name: 'MAX_DURATION_SE',
        dtype: 'integer',
        type: 'parameter',
        description: null,
        defaultMin: null,
        defaultMax: null,
        unit: null,
        defaultValue: null
      },
      {
        name: 'POURCENTAGE_FLIGHT_THRESHOLD',
        dtype: 'integer',
        type: 'threshold',
        description: null,
        defaultMin: null,
        defaultMax: null,
        unit: null,
        defaultValue: null
      }
    ]
  }
};

export const selectedModel = {
  id: 'ATA28_SMA_TIME_CLOSE_OPEN_M1:A320_#0_RIGHT_FWD_ITCV^ACTUATOR_FAILURE',
  atas: [
    28
  ],
  title: 'Right Fwd Inter-Cell Transfer Valve SMA slow to close or to open.',
  effectivities: [
    {
      aircraftType: 'A319',
      engineType: 'CFM56-5B5/3'
    },
    {
      aircraftType: 'A320',
      engineType: 'CFM56-5B4/3'
    },
    {
      aircraftType: 'A319',
      engineType: 'CFM56-5B5/P'
    }
  ],
  automaticWorkflowDefinition: {
    enabled: false,
    flightsBeforeMonitorToClosed: {
      defaultValue: 10,
      max: 999,
      min: 1,
    },
    flightsBeforeOpenedToIgnored: {
      defaultValue: 10,
      max: 999,
      min: 1,
    },
    flightsBeforeReviewToIgnored: {
      defaultValue: 10,
      max: 999,
      min: 1,
    },
  },
  automaticWorkflowConfiguration: {
    enabled: true,
    flightsBeforeReviewToIgnored: {
      value: 30
    },
    flightsBeforeOpenedToIgnored: {
      value: 30
    },
    flightsBeforeMonitorToClosed: {
      value: 30
    }
  },
  mayurity: 1,
  modelAccessLevel: 3,
  modelDefinition: {
    parameters: [
      {
        name: 'DURATION_THRESHOLD',
        dtype: 'integer',
        type: 'threshold',
        description: null,
        defaultMin: null,
        defaultMax: null,
        unit: null,
        defaultValue: null
      },
      {
        name: 'MATURITY',
        dtype: 'integer',
        type: 'parameter',
        description: null,
        defaultMin: 0,
        defaultMax: 3,
        unit: null,
        defaultValue: null
      },
      {
        name: 'MAX_DURATION_SE',
        dtype: 'integer',
        type: 'parameter',
        description: null,
        defaultMin: null,
        defaultMax: null,
        unit: null,
        defaultValue: null
      },
      {
        name: 'POURCENTAGE_FLIGHT_THRESHOLD',
        dtype: 'integer',
        type: 'threshold',
        description: null,
        defaultMin: null,
        defaultMax: null,
        unit: null,
        defaultValue: null
      }
    ]
  },
  modelConfigurations: [
    {
      effectivity: {
        aircraftType: 'A319',
        engineType: 'CFM56-5B5/3'
      },
      parameters: [
        {
          name: 'DURATION_THRESHOLD',
          value: null
        },
        {
          name: 'MATURITY',
          value: null
        },
        {
          name: 'MAX_DURATION_SEC',
          value: null
        },
        {
          name: 'POURCENTAGE_FLIGHT_THRESHOLD',
          value: null
        }
      ]
    },
    {
      effectivity: {
        aircraftType: 'A320',
        engineType: 'CFM56 - 5B4/3'
      },
      parameters: [
        {
          name: 'DURATION_THRESHOLD',
          value: null
        },
        {
          name: 'MATURITY',
          value: null
        },
        {
          name: 'MAX_DURATION_SEC',
          value: null
        },
        {
          name: 'POURCENTAGE_FLIGHT_THRESHOLD',
          value: null
        }
      ]
    },
    {
      effectivity: {
        aircraftType: 'A319',
        engineType: 'CFM56 - 5B5/P'
      },
      parameters: [
        {
          name: 'DURATION_THRESHOL',
          value: null
        },
        {
          name: 'MATURITY',
          value: null
        },
        {
          name: 'MAX_DURATION_SEC',
          value: null
        },
        {
          name: 'POURCENTAGE_FLIGHT_THRESHOLD',
          value: null
        }
      ]
    }
  ]
};
