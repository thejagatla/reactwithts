export const SpmStatus1 = {
    eventId: 'AZ130^130^130',
    dateTime: '2017-11-26T19:10:00.000Z',
    status: 'OPENED',
    comment: 'This is my comment',
    author: 'system',
    deleted: false,
    workReference: '',
    workDatetime: '',
    possibleCause: 'Low oil pressure',
    fltBefore: '',
    airport: '',
    attachments: []
};

export const SpmStatus2 = {
    eventId: 'AZ130^130^130',
    dateTime: '2017-11-25T19:10:00.000Z',
    status: 'TO_BE_REVIEWED',
    comment: 'This is my comment',
    author: 'John Smith',
    deleted: false,
    workReference: '',
    workDatetime: '',
    possibleCause: 'Low oil pressure',
    fltBefore: '',
    airport: '',
    attachments: []
};

export const SpmStatusHistory1 = [
    SpmStatus1,
    SpmStatus2
];
