// raf polyfill must be loaded befor enzyme
import 'raf/polyfill';
// tslint:disable-next-line:ordered-imports
import * as enzyme from 'enzyme';
import * as Adapter from 'enzyme-adapter-react-16';

// tslint:disable-next-line:no-any
(enzyme as any).configure({ adapter: new Adapter() });

// Mock browser function for c3 component test
// tslint:disable-next-line:no-any
global.SVGPathElement = () => {};

const localStorageMock = (() => {
  let store = {};

  return {
    clear: () => {
      store = {};
    },
    getItem: (key) => {
      return store[key] || null;
    },
    setItem: (key, value) => {
      store[key] = value.toString();
    },
  };
})();

Object.defineProperty(window, 'localStorage', {
  value: localStorageMock
});

/*
// Fail tests on any warning
console.error = (message) => {
  throw new Error(message);
};
*/