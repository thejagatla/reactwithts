import {} from '@types/jest';
import * as enzyme from 'enzyme';
import * as React from 'react';
import { OccurrenceHelpView } from '../../../src/components/common/help/OccurrenceHelpView';
import { SearchHelpView } from '../../../src/components/common/help/SearchHelpView';

describe('Help test', () => {
  it('Check Occurrence history help', () => {
    const lWrapper: enzyme.ReactWrapper = enzyme.mount(
      <OccurrenceHelpView />
    );
    expect(lWrapper.childAt(0).childAt(0).text())
      .toEqual('Occurrence history represents the history of occurrences of a given event in the last 15 flights');
  });

  it('Check Search help', () => {
    const lWrapper: enzyme.ReactWrapper = enzyme.mount(
      <SearchHelpView />
    );
    expect(lWrapper.childAt(0).childAt(0).text())
      .toEqual('The search function makes it possible to search all the event data of the Event Cockpit');
  });

});
