import {} from '@types/jest';
import * as enzyme from 'enzyme';
import * as React from 'react';
import { SearchAutocomplete } from '../../../../src/components/common/search/SearchAutocomplete';
import { ErrorModalView } from '../../../../src/components/utils/errorModal/ErrorModalView';
import { dataTest } from '../../../data';

const suggestions = [
  { label: 'ata' },
  { label: 'registrationNumber' },
  { label: 'aircraftType' },
  { label: 'eventType' },
  { label: 'flightNumber' },
  { label: 'priority' },
  { label: 'eventDate' },
  { label: 'eventTitle' },
  { label: 'viewMEL' },
  { label: 'source' },
  { label: 'workflowStatus' },
  { label: 'workRef' },
  { label: 'workComment' },
  { label: 'workAuthor' },
  { label: 'nickName' },
  { label: 'displayed' }
];

let goodSuggestions = suggestions;

function setSuggestions(value: any) {
  goodSuggestions = value;
}

describe('Events Search tests', () => {
  it('Check Autocomplete suggestions', () => {
    const lWrapper: enzyme.ReactWrapper = enzyme.mount(
      <SearchAutocomplete
        activeClass="active"
        filterText={function(){}}
        onKeyPress={function(){}}
        menuStyle={{}}
        value=""
        suggestions={goodSuggestions}
        setText={function(){}}
        setSuggestions={setSuggestions}
      />
    );

    const inputField = lWrapper.find('input');
    lWrapper.setProps({
      value: 'event'
    });

    inputField.simulate('focus');

    lWrapper.setProps({
      suggestions: goodSuggestions,
    });

    inputField.simulate('focus');
    expect(lWrapper.find('.react-autosuggest__suggestions-list').children().length).toEqual(3);
  });

  it('renders ErrorModalView', () => {
    const pTechRequestUrl = 'test';
    const pTraceId = '32';
    const lWrapper: enzyme.ReactWrapper = enzyme.mount(
      <ErrorModalView
        languageInfo={['test', 'test2']}
        techRequestUrl={pTechRequestUrl}
        traceId={pTraceId}
      />
    );
  });
});
