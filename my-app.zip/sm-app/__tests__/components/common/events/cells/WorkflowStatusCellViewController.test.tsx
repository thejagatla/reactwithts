/**
 * WorkflowStatusCellView test class
 */
import * as enzyme from 'enzyme';
import * as React from 'react';
import { dataTest } from '../../../../data';

import {
  WorkflowStatusCellViewController
} from '../../../../../src/components/common/events/cells/workflow/WorkflowStatusCellViewController';

describe('WorkflowStatusCellViewController component', () => {
  /**
   * Render method test
   */
  it('Render method test', () => {
    const lActions: string[] = ['EDIT', 'IGNORE'];
    const lWrapper = enzyme.shallow(
      <WorkflowStatusCellViewController
          workOrderStatus="TO_BE_REVIEWED"
          lWorkOrderStatus="TO_BE_REVIEWED"
          isWorkOrderStatusHighlighted={true}
          origin="SHM"
          event={dataTest}
      />
    );

    // Check dropdown contants
    expect(lWrapper.prop('actions')).toEqual(lActions);
    
    // Check dropdown not displayed
    expect(lWrapper.prop('displayedDropdown')).toEqual(false);
  });
});
