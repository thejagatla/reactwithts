/**
 * WorkflowStatusCellView test class
 */
import * as enzyme from 'enzyme';
import * as React from 'react';
import { lEvent1 as lEventSHM } from '../../../../stubs/ShmDataStub';
import { spmEvent7 as lEventSPM } from '../../../../stubs/SpmDataStub';

import {
  CommentViewController
} from '../../../../../src/components/common/events/cells/comment/CommentViewController';

let localEvent = {};

function addLocalEvent(event: any) {
  localEvent = event;
}

function startTimeout() {
  return '';
}

function openErrorModal() {
  return '';
}

function removeLocalEvent() {
  return '';
}

const expectedComment = <span className="comment--text">Test</span>;

describe('WorkflowStatusCellViewController component', () => { 
  /**
   * Test comment submit SHM event
   */
  it('Test comment submission on SHM event', () => {
    const lWrapper: enzyme.ReactWrapper = enzyme.mount(
      <CommentViewController
        addLocalEvent={addLocalEvent}
        startTimeout={startTimeout}
        event={lEventSHM}
        openErrorModal={openErrorModal}
        removeLocalEvent={removeLocalEvent}
      />
    );
    lWrapper.find('a[role="button"]').simulate('click');
    lWrapper.setState({ newComment: 'Test comment SHM' });
    const input = lWrapper.find('textarea');
    input.simulate('keyDown', { keyCode: 13 });

    lWrapper.setProps({
      event: localEvent
    });

    expect(lWrapper.find('.comment').childAt(0).text()).toEqual('Test comment SHM');
  });

  /**
   * Test comment submit SPM event
   */
  it('Test comment submission on SPM event', () => {
    const lWrapper: enzyme.ReactWrapper = enzyme.mount(
      <CommentViewController
        addLocalEvent={addLocalEvent}
        startTimeout={startTimeout}
        event={lEventSPM}
        openErrorModal={openErrorModal}
        removeLocalEvent={removeLocalEvent}
      />
    );
    lWrapper.find('a[role="button"]').simulate('click');
    lWrapper.setState({ newComment: 'Test comment SPM' });
    const input = lWrapper.find('textarea');
    input.simulate('keyDown', { keyCode: 13 });

    lWrapper.setProps({
      event: localEvent
    });

    expect(lWrapper.find('.comment').childAt(0).text()).toEqual('Test comment SPM');
  });
});
