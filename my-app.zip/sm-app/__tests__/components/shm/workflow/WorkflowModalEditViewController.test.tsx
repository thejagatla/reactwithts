/**
 * WorkflowModalEditViewController test class
 */
import { DSStep, DSSteppers } from '@sm/skywise-react-library';
import * as enzyme from 'enzyme';
import * as React from 'react';
// import { Checkbox } from '../../../src/components/storybook/controls/Checkbox';
import {
  WorkflowModalEditViewController
} from '../../../../src/components/shm/workflow/WorkflowModalEditViewController';
import { WorkflowModalHeaderView } from '../../../../src/components/shm/workflow/WorkflowModalHeaderView';
// import { WorkflowModalIgnoreActionView } from '../../../src/components/shm/workflow/WorkflowModalIgnoreActionView';
import { WorkflowModalLaunchActionView } from '../../../../src/components/shm/workflow/WorkflowModalLaunchActionView';
import { WorkOrderStatusEnum } from '../../../../src/model/EventsConstantes';
import { lEvent1, lEvent2, lEvent3, lEvent4, lEvent5, lEvent6 } from '../../../stubs/ShmDataStub';
// import * as SpmDataStub from '../../stubs/SpmDataStub';

describe('WorkflowModalEditViewController component', () => {
  
  /**
   * Render method test for EDIT action
   */
  it('Check render method test for EDIT action', () => {
    const lWrapper = enzyme.mount(
      <WorkflowModalEditViewController
        event={lEvent3}
        setWorkOrderStatus={jest.fn()}
        closeModal={jest.fn()}
      />
    );

    // Check workflow popin content
    expect(lWrapper.containsAllMatchingElements([
      WorkflowModalHeaderView,
      DSSteppers,
      DSStep,
      WorkflowModalLaunchActionView
    ])).toBe(true);

    // Unmount
    lWrapper.unmount();
  });

  /**
   * Check handleWorkReferenceChange method
   */
  it('Check handleWorkReferenceChange method', () => {
    const lWrapper = enzyme.mount(
      <WorkflowModalEditViewController
        event={lEvent1}
        setWorkOrderStatus={jest.fn()}
        closeModal={jest.fn()}
      />
    );
        
    const lWorkflowModaLaunchActionViewWrapper =
      lWrapper.find(WorkflowModalLaunchActionView);
    const workOrderReferenceTextArea =
      lWorkflowModaLaunchActionViewWrapper.find({ name: 'workOrderReference' }).at(1);

    // Check the setOpened method
    workOrderReferenceTextArea.instance().value = 'Test';
    workOrderReferenceTextArea.simulate('change');
    expect(lWrapper.state('dateDisabled')).toBe(false);
    expect(lWrapper.state('workOrderStatus')).toBe(WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED]);

    // Check return to TO_BE_REVIEWED state if workOrderReference removed
    workOrderReferenceTextArea.instance().value = '';
    workOrderReferenceTextArea.simulate('change');
    expect(lWrapper.state('dateDisabled')).toBe(true);
    expect(lWrapper.state('workOrderStatus')).toBe(WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]);

    // Unmount
    lWrapper.unmount();
  });
});
