/**
 * ShmWorkflowModalViewController test class
 */
import { DSStep, DSSteppers } from '@sm/skywise-react-library';
import * as enzyme from 'enzyme';
import * as React from 'react';
// import { Checkbox } from '../../../src/components/storybook/controls/Checkbox';
import { WorkflowModalHeaderView } from '../../../../src/components/shm/workflow/WorkflowModalHeaderView';
import { WorkflowModalIgnoreActionView } from '../../../../src/components/shm/workflow/WorkflowModalIgnoreActionView';
import { WorkflowModalIgnoredEditViewController 
} from '../../../../src/components/shm/workflow/WorkflowModalIgnoredEditViewController';
// import { WorkflowModalLaunchActionView } from '../../../src/components/workflow/WorkflowModalLaunchActionView';
// import { IgnoredWorkStatusReason, WorkflowPageOrigin, WorkOrderStatusEnum } from '../../../src/model/EventsConstantes';
import { lEvent1, lEvent2, lEvent3, lEvent4, lEvent5, lEvent6 } from '../../../stubs/ShmDataStub';
// import * as SpmDataStub from '../../stubs/SpmDataStub';

describe('WorkflowModalViewController component', () => {

  let lWrapper;
  
  beforeEach(() => {
    lWrapper = enzyme.mount(
            <WorkflowModalIgnoredEditViewController
                event={lEvent3}
                closeModal={jest.fn()}
                setWorkOrderStatus={jest.fn()}
            />
        );
  });

    /**
     * Render method test for IGNORE action
     */
  it('Check render method test for IGNORE action', () => {
        // Check WorkflowModalView component presence
    expect(lWrapper.containsAllMatchingElements([
      WorkflowModalHeaderView,
      DSSteppers,
      DSStep,
      WorkflowModalIgnoreActionView
    ])).toBe(true);

        // Unmount
    lWrapper.unmount();
  });

    /**
     * Check handleSubmit method
     */
  it('Check handleSubmit method', () => {
        // Check handleSubmit method
    lWrapper.find('form').simulate('submit');

        // Unmount
    lWrapper.unmount();
  });

    /**
     * Check handleIgnoredReasonChange method with SPURIOUS
     */
  it('Check handleIgnoredReasonChange method with SPURIOUS', () => {

        // Select SPURIOUS ignore reason and check handleIgnoredReasonChange method       
    lWrapper.find('#IgnoredWorkStatusReasonEnumSPURIOUS').first().simulate('change');

        // Unmount
    lWrapper.unmount();
  });

  /**
   * Check handleIgnoredReasonChange method with NO_ACTION
   */
  it('Check handleIgnoredReasonChange method with NO ACTION', () => {
    
            // Select SPURIOUS ignore reason and check handleIgnoredReasonChange method       
    lWrapper.find('#IgnoredWorkStatusReasonEnumNO_ACTION').first().simulate('change');
    
            // Unmount
    lWrapper.unmount();
  });

    /**
     * Check handleIgnoredReasonChange method with OTHER_REASON
     */
  it('Check handleIgnoredReasonChange method with OTHER_REASON', () => {
        // Erase comment
    lWrapper.setState({ workOrderComment: '' });

        // Select OTHER_REASON ignore reason and check handleIgnoredReasonChange method
    lWrapper.find('#IgnoredWorkStatusReasonEnumOTHER_REASON').first().simulate('change');

        // Unmount
    lWrapper.unmount();
  });

    // /**
    //  * Check handleInputChange method
    //  */
    // it('Check handleInputChange method', () => {
    //     const lWrapper = enzyme.mount(
    //         <WorkflowModalViewController
    //             title="A title"
    //             event={lEvent1}
    //             action="LAUNCH_ACTION"
    //             setWorkOrderStatus={jest.fn()}
    //             modalOrigin={WorkflowPageOrigin.SHM}
    //         />
    //     );
    //     const lWorkflowModaLaunchActionViewWrapper =
    //         lWrapper.find(WorkflowModalView).find(WorkflowModalLaunchActionView);
    //     const workOrderReferenceTextArea =
    //         lWorkflowModaLaunchActionViewWrapper.find({ name: 'workOrderReference' }).at(1);

    //     // Check the setOpened method
    //     workOrderReferenceTextArea.simulate('change', { target: { name: 'workOrderReference', value: 'Test' } });
    //     expect(lWrapper.state('dateDisabled')).toBe(false);
    //     expect(lWrapper.state('workOrderStatus')).toBe(WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED]);

    //     // Check return to TO_BE_REVIEWED state if workOrderReference removed
    //     workOrderReferenceTextArea.simulate('change', { target: { name: 'workOrderReference', value: '' } });
    //     expect(lWrapper.state('dateDisabled')).toBe(true);
    //     expect(lWrapper.state('workOrderStatus')).toBe(WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]);

    //     // Unmount
    //     lWrapper.unmount();
    // });

    // /**
    //  * Check workOrderStatus changes if ignore reason is SPURIOUS or NO_ACTION
    //  * and comment is filled
    //  */
    // it('Check handleCommentChange method', () => {
    //     const lWrapper = enzyme.mount(
    //         <WorkflowModalViewController
    //             title="A title"
    //             event={lEvent3}
    //             action="IGNORE"
    //             setWorkOrderStatus={jest.fn()}
    //             modalOrigin={WorkflowPageOrigin.SHM}
    //         />
    //     );

    //     const lWorkflowModalIgnoreActionViewWrapper =
    //         lWrapper.find(WorkflowModalView).find(WorkflowModalIgnoreActionView);

    //     // Check OTHER_REASON with no comment
    //     lWrapper.setState({ workOrderIgnoredReason: IgnoredWorkStatusReason[IgnoredWorkStatusReason.OTHER_REASON] });

    //     // Select comment field
    //     lWorkflowModalIgnoreActionViewWrapper.find('textarea').simulate('change', { target: { value: '' } });

    //     expect(lWrapper.state('workOrderStatus')).toBe(WorkOrderStatusEnum[WorkOrderStatusEnum.PLANNED]);

    //     // Check OTHER_REASON with comment
    //     lWrapper.setState({ workOrderIgnoredReason: IgnoredWorkStatusReason[IgnoredWorkStatusReason.OTHER_REASON] });

    //     // Select comment field
    //     lWorkflowModalIgnoreActionViewWrapper.find('textarea').simulate('change', { target: { value: 'Text' } });

    //     expect(lWrapper.state('workOrderStatus')).toBe(WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED]);

    //     // Check NO_ACTION
    //     lWrapper.setState({ workOrderIgnoredReason: IgnoredWorkStatusReason[IgnoredWorkStatusReason.NO_ACTION] });

    //     // Select comment field
    //     lWorkflowModalIgnoreActionViewWrapper.find('textarea').simulate('change', { target: { value: 'Text' } });

    //     expect(lWrapper.state('workOrderStatus')).toBe(WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED]);

    //     // Check SPURIOUS
    //     lWrapper.setState({ workOrderIgnoredReason: IgnoredWorkStatusReason[IgnoredWorkStatusReason.SPURIOUS] });

    //     // Select comment field
    //     lWorkflowModalIgnoreActionViewWrapper.find('textarea').simulate('change', { target: { value: 'Text' } });

    //     expect(lWrapper.state('workOrderStatus')).toBe(WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED]);

    //     // Check unknown ignore reason
    //     lWrapper.setState({ workOrderIgnoredReason: 'TOTO' });

    //     lWorkflowModalIgnoreActionViewWrapper.find('textarea').simulate('change', { target: { value: 'Text' } });

    //     expect(lWrapper.state('workOrderStatus')).toBe(WorkOrderStatusEnum[WorkOrderStatusEnum.PLANNED]);

    //     // Unmount
    //     lWrapper.unmount();
    // });

});
