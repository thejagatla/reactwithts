import { DSBar, DSIcon, DSStepIcon } from '@sm/skywise-react-library';
import * as enzyme from 'enzyme';
import * as React from 'react';
import { MemoryRouter } from 'react-router-dom';
import { CommentViewController } from '../../../src/components/common/events/cells/comment/CommentViewController';
import { WorkflowStatusCellViewController } from '../../../src/components/common/events/cells/workflow/WorkflowStatusCellViewController';
import { WorkReferenceView } from '../../../src/components/common/events/cells/WorkReferenceView';
import { EventLine } from '../../../src/components/common/events/eventLine/EventLine';
import { EventTitle } from '../../../src/components/common/events/EventTitle';
import { DSDropdown } from '../../../src/components/storybook/DSDropdown/DSDropdown';

// tslint:disable-next-line:max-line-length
import {
  EventType,
  WorkflowActionEnum,
  WorkOrderStatus
} from '../../../src/model/EventsConstantes';
import {
  lEvent1,
  lEvent2,
  lEvent3,
  lEvent4,
  lEvent5,
  lEvent6,
  lExpectedResult1,
  lExpectedResult2,
  lExpectedResult3,
  lExpectedResult4,
  lExpectedResult5
} from '../../stubs/ShmDataStub';

describe('ShmEventRowRenderer component', () => {
  const lWrapper: enzyme.ReactWrapper = enzyme.mount(
    <MemoryRouter>
      <EventLine event={lEvent1} key={0} pageOrigin="SHM" />
    </MemoryRouter>
  );

  const lWrapper2: enzyme.ReactWrapper = enzyme.mount(
    <MemoryRouter>
      <EventLine event={lEvent2} key={1} pageOrigin="SHM" />
    </MemoryRouter>
  );

  const lWrapper3: enzyme.ReactWrapper = enzyme.mount(
    <MemoryRouter>
      <EventLine event={lEvent3} key={2} pageOrigin="SHM" />
    </MemoryRouter>
  );

  const lWrapper4: enzyme.ReactWrapper = enzyme.mount(
    <MemoryRouter>
      <EventLine event={lEvent4} key={3} pageOrigin="SHM" />
    </MemoryRouter>
  );

  const lWrapper5: enzyme.ReactWrapper = enzyme.mount(
    <MemoryRouter>
      <EventLine event={lEvent5} key={4} pageOrigin="SHM" />
    </MemoryRouter>
  );

  const lWrapper6: enzyme.ReactWrapper = enzyme.mount(
    <MemoryRouter>
      <EventLine event={lEvent6} key={5} pageOrigin="SHM" />
    </MemoryRouter>
  );

  /**
   * Priority render
   */
  it('Test priority renderer of a SHM event', () => {
    const wrapper: enzyme.ReactWrapper = lWrapper
      .find('.pass-event__section')
      .first()
      .childAt(0);
    expect(wrapper.hasClass('priority-column')).toEqual(true);
    expect(wrapper.hasClass('no-priority')).toEqual(true);
  });

  /**
   * Render aircraft
   */
  it('Test aircraft renderer of a SHM event', () => {
    const wrapper: enzyme.ReactWrapper = lWrapper.find(
      '.list.list--horizontal.pass-event--aircraft__details'
    );
    expect(wrapper.find('.list__header span').text()).toEqual(
      lEvent1.acMatricule
    );
    expect(
      wrapper
        .find('span')
        .last()
        .text()
    ).toEqual(lEvent1.flightNumber);
  });

  /**
   * Render comment
   */
  it('Test comment renderer of a Fault Message event comment', () => {
    const wrapper: enzyme.ReactWrapper = lWrapper
      .find(CommentViewController)
      .childAt(0);
    expect(wrapper.hasClass('pass-event--comment')).toEqual(true);
  });

  /**
   * Render workReference
   */
  it('Test render reference of an avent', () => {
    const wrapper: enzyme.ReactWrapper = lWrapper2
      .find(WorkReferenceView)
      .childAt(0);
    expect(wrapper.hasClass('pass-event--work-reference')).toEqual(true);
    expect(wrapper.find('span').text()).toEqual(lEvent2.workOrderReference);
  });

  /**
   * Render work order status
   */
  it('Test To be reviewed work order status renderer of a SHM event', () => {
    const lActions: string[] = ['EDIT', 'IGNORE'];
    const wrapper: enzyme.ReactWrapper = lWrapper.find(
      WorkflowStatusCellViewController
    );
    // Is class name correct ?
    expect(
      wrapper
        .find(DSStepIcon)
        .childAt(0)
        .hasClass('ds-step-ico tbr')
    ).toEqual(true);

    // Is WorkflowStatusCellView react component present ?
    expect(wrapper.childAt(0).containsMatchingElement(<DSDropdown />)).toEqual(
      true
    );

    // Is WorkflowStatusCellView contains class name
    expect(wrapper.childAt(0).prop('workOrderStatus')).toEqual(
      lEvent1.workOrderStatus
    );
    expect(
      wrapper
        .find(DSIcon)
        .first()
        .prop('type')
    ).toEqual('location');
  });

  /**
   * Render work order status
   */
  it('Test Opened work order status renderer of a SHM event', () => {
    const lActions: string[] = ['EDIT', 'IGNORE'];

    const wrapper: enzyme.ReactWrapper = lWrapper2.find(
      WorkflowStatusCellViewController
    );
    // Is class name correct ?
    expect(
      wrapper
        .find(DSStepIcon)
        .childAt(0)
        .hasClass('ds-step-ico opened')
    ).toEqual(true);

    // Is WorkflowStatusCellView react component present ?
    expect(wrapper.childAt(0).containsMatchingElement(<DSDropdown />)).toEqual(
      true
    );

    // Is WorkflowStatusCellView contains class name
    expect(wrapper.childAt(0).prop('workOrderStatus')).toEqual(
      lEvent2.workOrderStatus
    );
    expect(
      wrapper
        .find(DSIcon)
        .first()
        .prop('type')
    ).toEqual('eye');
  });

  /**
   * Render work order status
   */
  it('Test Planned work order status renderer of a SHM event', () => {
    const lActions: string[] = ['EDIT', 'IGNORE'];

    const wrapper: enzyme.ReactWrapper = lWrapper3.find(
      WorkflowStatusCellViewController
    );
    // Is class name correct ?
    expect(
      wrapper
        .find(DSStepIcon)
        .childAt(0)
        .hasClass('ds-step-ico planned')
    ).toEqual(true);

    // Is WorkflowStatusCellView react component present ?
    expect(wrapper.childAt(0).containsMatchingElement(<DSDropdown />)).toEqual(
      true
    );

    // Is WorkflowStatusCellView contains class name
    expect(wrapper.childAt(0).prop('workOrderStatus')).toEqual(
      lEvent3.workOrderStatus
    );
    expect(
      wrapper
        .find(DSIcon)
        .first()
        .prop('type')
    ).toEqual('date_range');
  });

  /**
   * Render work order status
   */
  it('Test To be monitored work order status renderer of a SHM event', () => {
    const lActions: string[] = ['EDIT', 'IGNORE'];

    const wrapper: enzyme.ReactWrapper = lWrapper4.find(
      WorkflowStatusCellViewController
    );
    // Is class name correct ?
    expect(
      wrapper
        .find(DSStepIcon)
        .childAt(0)
        .hasClass('ds-step-ico tbm')
    ).toEqual(true);

    // Is WorkflowStatusCellView react component present ?
    expect(wrapper.childAt(0).containsMatchingElement(<DSDropdown />)).toEqual(
      true
    );

    // Is WorkflowStatusCellView contains class name
    expect(wrapper.childAt(0).prop('workOrderStatus')).toEqual(
      lEvent4.workOrderStatus
    );
    expect(
      wrapper
        .find(DSIcon)
        .first()
        .prop('type')
    ).toEqual('build');
  });

  /**
   * Render work order status
   */
  it('Test Closed work order status renderer of a SHM event', () => {
    const wrapper: enzyme.ReactWrapper = lWrapper5.find(
      WorkflowStatusCellViewController
    );
    // Is class name correct ?
    expect(
      wrapper
        .find(DSStepIcon)
        .childAt(0)
        .hasClass('ds-step-ico closed')
    ).toEqual(true);

    // Is WorkflowStatusCellView react component present ?
    expect(wrapper.childAt(0).containsMatchingElement(<DSDropdown />)).toEqual(
      true
    );

    // Is WorkflowStatusCellView contains class name
    expect(wrapper.childAt(0).prop('workOrderStatus')).toEqual(
      lEvent5.workOrderStatus
    );
    expect(
      wrapper
        .find(DSIcon)
        .first()
        .prop('type')
    ).toEqual('check_checkbox');
  });

  /**
   * Render work order status
   */
  it('Test Ignored work order status renderer of a SHM event', () => {
    const wrapper: enzyme.ReactWrapper = lWrapper6.find(
      WorkflowStatusCellViewController
    );
    // Is class name correct ?
    expect(
      wrapper
        .find(DSStepIcon)
        .childAt(0)
        .hasClass('ds-step-ico ignored')
    ).toEqual(true);

    // Is WorkflowStatusCellView react component present ?
    expect(wrapper.childAt(0).containsMatchingElement(<DSDropdown />)).toEqual(
      true
    );

    // Is WorkflowStatusCellView contains class name
    expect(wrapper.childAt(0).prop('workOrderStatus')).toEqual(
      lEvent6.workOrderStatus
    );
    expect(
      wrapper
        .find(DSIcon)
        .first()
        .prop('type')
    ).toEqual('cancel');
  });

  /**
   * Render title
   */
  it('Test title renderer of a Fault Message event', () => {
    const wrapper: enzyme.ReactWrapper = lWrapper.find(
      '.event-aircraft__title'
    );
    expect(wrapper.text()).toEqual(lEvent1.titleFromAircraft);
  });

  /**
   * Occurrence history render
   */
  it('Test occurrence history renderer with one fault message occurred during phase 2', () => {
    /*const lWrapper: enzyme.ShallowWrapper = enzyme.shallow(
      <ShmEventRowRenderer
        event={lEvent1}
        key={0}
      />
    );
    const wrapper = lWrapper.find('.event-row').childAt(6).shallow().childAt(0);
    expect(wrapper.equals(lExpectedResult1)).toEqual(true);*/
  });

  /*it('Test occurrence history renderer with one fault message occurred during phase 3', () => {
    const lWrapper: enzyme.ShallowWrapper = enzyme.shallow(
      <ShmEventRowRenderer
        event={lEvent2}
        key={0}
      />
    );
    const wrapper = lWrapper.find('.event-row').childAt(6).shallow().childAt(0);
    expect(wrapper.equals(lExpectedResult1)).toEqual(true);
  });

  it('Test occurrence history renderer with no fault message on last flight', () => {
    const lWrapper: enzyme.ShallowWrapper = enzyme.shallow(
      <ShmEventRowRenderer
        event={lEvent3}
        key={0}
      />
    );
    const wrapper = lWrapper.find('.event-row').childAt(6).shallow().childAt(0);
    expect(wrapper.equals(lExpectedResult1)).toEqual(true);
  });

  it('Test occurrence history renderer with one fault message on phase 12 last flight', () => {
    const lWrapper: enzyme.ShallowWrapper = enzyme.shallow(
      <ShmEventRowRenderer
        event={lEvent4}
        key={0}
      />
    );
    const wrapper = lWrapper.find('.event-row').childAt(6).shallow().childAt(0);
    expect(wrapper.equals(lExpectedResult1)).toEqual(true);
  });*/
});
