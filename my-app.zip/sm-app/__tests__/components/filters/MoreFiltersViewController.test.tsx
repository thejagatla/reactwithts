/**
 * MoreFiltersViewController test class
 */
import * as enzyme from 'enzyme';
import * as React from 'react';
import { DSButton } from '../../../node_modules/@sm/skywise-react-library';
import MoreFiltersViewController from '../../../src/components/common/filters/otherFilters/MoreFiltersViewController';
import { Filter } from '../../../src/components/storybook/filter/Filter';
import { FilterButton } from '../../../src/components/storybook/filter/FilterButton';
import { FleetsweepFilter } from '../../../src/model/fleetsweep/FleetsweepInterfaces';

describe('MoreFiltersViewController component', () => {

  const lMoreFiltersMock: FleetsweepFilter[] = [
    {
      title: 'A/C Type',
      type: 'AIRCRAFT_TYPE',
      values: [
        {
          active: false,
          value: 'A318'
        },
        {
          active: false,
          value: 'A319'
        },
        {
          active: false,
          value: 'A320'
        },
        {
          active: false,
          value: 'A321'
        },
        {
          active: false,
          value: 'A330'
        },
        {
          active: false,
          value: 'A340'
        },
      ]
    }
  ];

  /**
   * Check content of the more filters view controller
   */
  it('Check content of the more filters view controller', () => {
    const lWrapper = enzyme.shallow(
        <MoreFiltersViewController
          filters={lMoreFiltersMock}
          setMoreFilters={jest.fn()}
          startTimeout={jest.fn()}
        />
    );

    // Check that view controller contains only one Filter component
    expect(lWrapper.find(Filter)).toHaveLength(1);
  });

  /**
   * Check title of the button when no checkbox has been selected
   */
  it('Check title of the button when no checkbox has been selected', () => {
    const lWrapper = enzyme.mount(
        <MoreFiltersViewController
          filters={lMoreFiltersMock}
          setMoreFilters={jest.fn()}
          startTimeout={jest.fn()}
        />
    );

    // Get the button component
    const lButton: enzyme.ReactWrapper = lWrapper.find(Filter);

    // Check title of the button component
    expect(lButton.find(FilterButton)).toHaveLength(1);
    expect(lButton.find(FilterButton).prop('textList')).toEqual(['A/C Type']);

    lWrapper.unmount();
  });

  /**
   * Check class of the button when no checkbox has been selected
   */
  it('Check class of the button when no checkbox has been selected', () => {
    const lWrapper = enzyme.mount(
        <MoreFiltersViewController
          filters={lMoreFiltersMock}
          setMoreFilters={jest.fn()}
          startTimeout={jest.fn()}
        />
    );

    // Get the button component wrapper
    const lFilterButtonWrapper: enzyme.ReactWrapper = lWrapper.find(Filter).find(FilterButton);

    expect(lFilterButtonWrapper.find(DSButton)).toHaveLength(1);

    // Get DSButton component wrapper
    const lDSButtonWrapper: enzyme.ReactWrapper = lFilterButtonWrapper.find(DSButton);

    // Check class of the button component
    expect(lDSButtonWrapper.hasClass('ds-button ds-button--gray ds-button--negative ds-button--small'))
        .toBe(true);

    lWrapper.unmount();
  });
});
