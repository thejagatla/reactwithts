/**
 * FleetsweepPanelViewController test class
 */
import { DSButton, DSTab, DSTabPanel, DSTabs } from '@sm/skywise-react-library';
import * as enzyme from 'enzyme';
import * as React from 'react';
import * as fleetsweepFilters from '../../../src/resources/fleetsweepFilters.json';
import * as moreFilters from '../../../src/resources/moreFilters.json';

import {
    FiltersPanelViewController
} from '../../../src/components/common/filters/FiltersPanelViewController';
import { Filter } from '../../../src/components/storybook/filter/Filter';
import { FilterButton } from '../../../src/components/storybook/filter/FilterButton';
import {
    FleetsweepEventRank,
    FleetsweepEventRankEnum,
    FleetsweepFilterTypeEnum,
    FleetsweepPriority,
    FleetsweepPriorityEnum,
} from '../../../src/model/fleetsweep/FleetsweepConstantes';

describe('FleetsweepPanelViewController component', () => {
  /**
   * Check content of the header
   */
  it('Check content of the fleetsweep panel header', () => {

    const lMockSetFilters = (() => {
        // DO nothing
    });

    const lMockStartInterval = ((value) => {
        // DO nothing
    });

    const lWrapper: enzyme.ReactWrapper = enzyme.mount(
      <FiltersPanelViewController
          setFilters={lMockSetFilters}
          state={{ 
            filters: fleetsweepFilters.tabs[0].filters,
            moreFilters: moreFilters.filters,
            selectedTabId: 0,
            tabs: fleetsweepFilters.tabs 
          }}
          startTimeout={lMockStartInterval}
      />
    );

    console.log(lWrapper);

    // Panel must have 5 tabs
    const lTabHeader: enzyme.ReactWrapper = lWrapper.find(DSTabs).find(DSTab);
    expect(lTabHeader).toHaveLength(6);

    // Check tabs titles
    expect(lTabHeader.at(0).prop('title')).toEqual(fleetsweepFilters.tabs[0].title);
    expect(lTabHeader.at(1).prop('title')).toEqual(fleetsweepFilters.tabs[1].title);
    expect(lTabHeader.at(2).prop('title')).toEqual(fleetsweepFilters.tabs[2].title);
    expect(lTabHeader.at(3).prop('title')).toEqual(fleetsweepFilters.tabs[3].title);
    expect(lTabHeader.at(4).prop('title')).toEqual(fleetsweepFilters.tabs[4].title);
    expect(lTabHeader.at(5).prop('title')).toEqual(fleetsweepFilters.tabs[5].title);

    // Check that the first tab is the active tab
    expect(lTabHeader.at(0).prop('selected')).toEqual(true);
    expect(lTabHeader.at(1).prop('selected')).toEqual(false);
    expect(lTabHeader.at(2).prop('selected')).toEqual(false);
    expect(lTabHeader.at(3).prop('selected')).toEqual(false);
    expect(lTabHeader.at(4).prop('selected')).toEqual(false);
    expect(lTabHeader.at(5).prop('selected')).toEqual(false);
  });

  /**
   * Check content of a tab
   */
  it('Check content of the tab method test', () => {

    const lMockSetFilters = (() => {
        // DO nothing
    });

    const lMockStartInterval = ((value) => {
        // DO nothing
    });

    const lWrapper = enzyme.mount(
        <FiltersPanelViewController
            setFilters={lMockSetFilters}
            state={{ 
              filters: fleetsweepFilters.tabs[0].filters,
              moreFilters: moreFilters.filters,
              selectedTabId: 0,
              tabs: fleetsweepFilters.tabs
            }}
            startTimeout={lMockStartInterval}
        />
    );

    // Get tab content
    const lTabContent = lWrapper.find(DSTabPanel);
    expect(lTabContent).toHaveLength(1);

    // Get filters list
    const lFilters = lTabContent.find(Filter);
    expect(lFilters).toHaveLength(4);

    // Check Filter buttons
    expect(lFilters.at(0).find(FilterButton).prop('label')).toEqual(fleetsweepFilters.tabs[0].filters[0].title);
    expect(lFilters.at(0).find(FilterButton).prop('textList')).toEqual([]);

    expect(lFilters.at(1).find(FilterButton).prop('label')).toEqual(fleetsweepFilters.tabs[0].filters[1].title);
    expect(lFilters.at(1).find(FilterButton).prop('textList')).toEqual([]);

    expect(lFilters.at(2).find(FilterButton).prop('label')).toEqual(fleetsweepFilters.tabs[0].filters[2].title);
    expect(lFilters.at(2).find(FilterButton).prop('textList')).toEqual([]);

    expect(lFilters.at(3).find(FilterButton).prop('label')).toEqual(fleetsweepFilters.tabs[0].filters[3].title);
    expect(lFilters.at(3).find(FilterButton).prop('textList')).toEqual([]);

    lWrapper.unmount();
  });
});
