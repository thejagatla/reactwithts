import { mount } from 'enzyme';
import * as React from 'react';

import {
  EventWorkStatusViewController
} from '../../../../src/components/spm/eventWorkStatus/EventWorkStatusViewController';
import { WorkOrderStatus, WorkOrderStatusEnum } from '../../../../src/model/EventsConstantes';
import * as eventData from '../../../stubs/SpmDataStub';

function setupComponent(options: any = {}) {
  const props = setupProps(options);

  const wrapper = mount(<EventWorkStatusViewController {...props} />);

  return {
    props,
    wrapper
  };
}

function setupProps(options: any = {}) {
  const props = {
    openModal: jest.fn(),
    status: WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED],
  };

  for (const option in options) {
    if (option in props) {
      props[option] = options[option];
    }
  }

  return props;
}

it('renders a "TO_BE_REVIEWED" event work status item', () => {
  const { wrapper, props } = setupComponent();
  const workStatus = WorkOrderStatus[WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]];
  expect(wrapper.contains(workStatus)).toEqual(true);
});

it('renders a "OPENED" event work status item', () => {
  const { wrapper, props } = setupComponent({ status: WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED] });
  const workStatus = WorkOrderStatus[WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED]];
  expect(wrapper.contains(workStatus)).toEqual(true);
});

it('renders a "PLANNED" event work status item', () => {
  const { wrapper, props } = setupComponent({ status: WorkOrderStatusEnum[WorkOrderStatusEnum.PLANNED] });
  const workStatus = WorkOrderStatus[WorkOrderStatusEnum[WorkOrderStatusEnum.PLANNED]];
  expect(wrapper.contains(workStatus)).toEqual(true);
});

it('renders a "TO_BE_MONITORED" event work status item', () => {
  const { wrapper, props } = setupComponent({ status: WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_MONITORED] });
  const workStatus = WorkOrderStatus[WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_MONITORED]];
  expect(wrapper.contains(workStatus)).toEqual(true);
});

it('renders a "CLOSED" event work status item', () => {
  const { wrapper, props } = setupComponent({ status: WorkOrderStatusEnum[WorkOrderStatusEnum.CLOSED] });
  const workStatus = WorkOrderStatus[WorkOrderStatusEnum[WorkOrderStatusEnum.CLOSED]];
  expect(wrapper.contains(workStatus)).toEqual(true);
});

it('renders a "IGNORED" event work status item', () => {
  const { wrapper, props } = setupComponent({ status: WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED] });
  const workStatus = WorkOrderStatus[WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED]];
  expect(wrapper.contains(workStatus)).toEqual(true);
});

it('checks the case of no status', () => {
  const { wrapper, props } = setupComponent({ status: '' });
  expect(wrapper.contains('---')).toEqual(true);
});

it('checks the case of work status update', () => {
  const { wrapper, props } = setupComponent({ status: WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED] });
  const workStatus1 = WorkOrderStatus[WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]];
  expect(wrapper.contains(workStatus1)).toEqual(true);

  wrapper.setProps({status: WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED]});
  const workStatus2 = WorkOrderStatus[WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED]];
  expect(wrapper.contains(workStatus2)).toEqual(true);
});
