import { mount, shallow } from 'enzyme';
import * as React from 'react';

import { DSLoader } from '@sm/skywise-react-library';
import { EventChartSectionView } from '../../../../src/components/spm/eventChartSection/EventChartSectionView';
import {
  EventChartSectionViewController
} from '../../../../src/components/spm/eventChartSection/EventChartSectionViewController';
import * as chartData from '../../../stubs/SpmChartDataStub';
import * as eventData from '../../../stubs/SpmDataStub';

function setupComponent(propsOptions: any = {}, stateOptions: any = {}) {
  const props = setupProps(propsOptions, stateOptions);

  const wrapper = shallow(<EventChartSectionViewController {...props} />);

  return {
    props,
    wrapper
  };
}

function setupProps(propsOptions: any = {}, stateOptions: any = {}) {
  const props = {
    chart: chartData.spmChart1,
    chartLoaded: true,
    chartLoadingError: false,
    chartSelector: 'containerChartEvents',
    event: eventData.spmEvent1,
    eventDetailsDisplay: [],
    eventId: 'EVENTID',
    eventItems: [],
    eventLoaded: true,
    eventLoadingError: false,
    lastEventItemLoadingError: false,
    statusHistory: [],
    user: {},
  };

  for (const option in propsOptions) {
    if (option in props) {
      props[option] = propsOptions[option];
    }
  }

  return props;
}

function setGraphicsDetails(wrapper: any, chartsOptions: any = {}) {

  const chartDetails = {

    chartTitle: 'ChartTitle',
    series: ['value1'],
    threshold: true,
    yAxisLabel: 'LabelTest'
  };

  for (const option in chartsOptions) {
    if (option in chartDetails) {
      chartDetails[option] = chartsOptions[option];
    }
  }

  wrapper.setState({
    graphicsDetails: [chartDetails]
  });
}

describe('EventChartSection component', () => {
  it('renders an EventChartSectionViewController component which contains EventChartSectionView', () => {
    const { wrapper } = setupComponent();
    setGraphicsDetails(wrapper);
    expect(wrapper.find(EventChartSectionView).length).toEqual(1);
  });

  it('renders an EventChartSectionViewController component which contains loader', () => {
    const { wrapper } = setupComponent({ chartLoaded: false }, {});
    expect(wrapper.find(DSLoader).length).toEqual(1);
  });

  it('renders an EventChartSectionViewController component which contains error message', () => {
    const { wrapper } = setupComponent({ chartLoadingError: true }, {});
    expect(wrapper.find('#error-message').length).toBeGreaterThan(0);
  });

  it('checks the case of no event data', () => {
    const { wrapper } = setupComponent({ event: [] });
  });

  it('checks the case of no chart data', () => {
    const { wrapper } = setupComponent({ chart: chartData.spmChart3 });
  });
});
