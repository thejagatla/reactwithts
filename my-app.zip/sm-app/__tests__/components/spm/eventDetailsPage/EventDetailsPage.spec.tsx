import { mount, shallow } from 'enzyme';
import * as React from 'react';

import { EventDetailsPageView } from '../../../../src/components/spm/eventDetailsPage/EventDetailsPageView';
import {
  EventDetailsPageViewController
} from '../../../../src/components/spm/eventDetailsPage/EventDetailsPageViewController';
import * as chartData from '../../../stubs/SpmChartDataStub';
import * as eventData from '../../../stubs/SpmDataStub';
import * as statusData from '../../../stubs/SpmStatusHistoryStub';

function setupComponent(options: any = {}) {
  const props = setupProps(options);

  const wrapper = shallow(<EventDetailsPageViewController {...props} />);

  return {
    props,
    wrapper
  };
}

function setupProps(options: any = {}) {
  const props = {
    handlePanelState: jest.fn(),
    loadChart: jest.fn(),
    loadEvent: jest.fn(),
    loadEventIgnoreError: jest.fn(),
    loadEventItem: jest.fn(),
    loadEventItems: jest.fn(),
    state: {
      aircraftId: 1,
      chart: chartData.spmChart1,
      chartLoaded: true,
      chartLoadingError: false,
      commentsHistory: [],
      event: eventData.spmEvent1,
      eventDetailsDisplay: [],
      eventId: 1,
      eventItems: [],
      eventLoaded: true,
      eventLoadingError: false,
      historyPanelElements: [],
      intervalId: 0,
      maintenanceAdvices: [],
      priorityClassName: '',
      statusHistory: [],
      userNotAuthorized: false,
      workflowPanelVisible: false,
    },
  };

  for (const option in options) {
    if (option in props.state) {
      props.state[option] = options[option];
    }
  }

  return props;
}

describe('EventDetailsPage component', () => {
  it('renders an EventDetailsPageViewController component', () => {
    const { wrapper } = setupComponent();

    expect(wrapper.find(EventDetailsPageView).length).toEqual(1);
  });

  it('checks the priorityToClassName method for LOW priority', () => {
    const { wrapper, props } = setupComponent({ event: {}, eventLoaded: false });

    expect(wrapper.state('priorityClassName')).toEqual('');

    wrapper.setProps(
      {
        state: {
          chart: chartData.spmChart1,
          commentsHistory: [],
          event: eventData.spmEvent1,
          eventDetailsDisplay: [],
          eventLoaded: true,
          maintenanceAdvices: [],
          statusHistory: [eventData.spmEvent1.statusInfoItem],
        }
      }
    );
    expect(wrapper.state('priorityClassName')).toEqual('low');
  });

  it('checks the priorityToClassName method for MEDIUM priority', () => {
    const { wrapper, props } = setupComponent({ event: {}, eventLoaded: false });

    expect(wrapper.state('priorityClassName')).toEqual('');

    wrapper.setProps(
      {
        state: {
          chart: chartData.spmChart1,
          commentsHistory: [],
          event: eventData.spmEvent3,
          eventDetailsDisplay: [],
          eventLoaded: true,
          maintenanceAdvices: [],
          statusHistory: [eventData.spmEvent3.statusInfoItem]
        }
      }
    );
    expect(wrapper.state('priorityClassName')).toEqual('medium');
  });

  it('checks the priorityToClassName method for HIGH priority', () => {
    const { wrapper, props } = setupComponent({ event: {}, eventLoaded: false });

    expect(wrapper.state('priorityClassName')).toEqual('');

    wrapper.setProps(
      {
        state: {
          chart: chartData.spmChart1,
          commentsHistory: [],
          event: eventData.spmEvent5,
          eventDetailsDisplay: [],
          eventLoaded: true,
          maintenanceAdvices: [],
          statusHistory: [eventData.spmEvent5.statusInfoItem]
        }
      }
    );
    expect(wrapper.state('priorityClassName')).toEqual('high');
  });

  it('checks the WF history is not visible by default', () => {
    const { wrapper } = setupComponent();
    expect(wrapper.state('workflowPanelVisible')).toBe(false);
  });

  it('checks the startInterval method', () => {
    const { wrapper, props } = setupComponent();

    expect(props.loadEvent.mock.calls.length).toBeGreaterThan(0);
  });
});
