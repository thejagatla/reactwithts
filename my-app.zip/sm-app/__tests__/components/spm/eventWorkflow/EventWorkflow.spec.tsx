/**
 * ShmWorkflowModalViewController test class
 */
import { mount } from 'enzyme';
import * as React from 'react';
import DayPickerInput from 'react-day-picker/DayPickerInput';

import {
  WorkflowModalHeaderView
} from '../../../../src/components/spm/eventWorkflow/WorkflowModalHeaderView';
import {
  WorkflowModalIgnoreActionView
} from '../../../../src/components/spm/eventWorkflow/WorkflowModalIgnoreActionView';
import {
  WorkflowModalPlanActionView
} from '../../../../src/components/spm/eventWorkflow/WorkflowModalPlanActionView';
import {
  WorkflowModalRejectActionView
} from '../../../../src/components/spm/eventWorkflow/WorkflowModalRejectActionView';
import {
  WorkflowModalValidateActionView
} from '../../../../src/components/spm/eventWorkflow/WorkflowModalValidateActionView';
import { WorkflowModalView } from '../../../../src/components/spm/eventWorkflow/WorkflowModalView';
import { WorkflowModalViewController } from '../../../../src/components/spm/eventWorkflow/WorkflowModalViewController';
import {
  WorkflowModalWatchActionView
} from '../../../../src/components/spm/eventWorkflow/WorkflowModalWatchActionView';
import { Checkbox } from '../../../../src/components/storybook/controls/Checkbox';
import { DSSteppers, Step } from '../../../../src/components/storybook/DSSteppers';
import { WorkflowAction, WorkflowPageOrigin, WorkOrderStatusEnum } from '../../../../src/model/EventsConstantes';
import * as SpmDataStub from '../../../stubs/SpmDataStub';

function setupComponent(options: any = {}) {
  const props = setupProps(options);

  const wrapper = mount(<WorkflowModalViewController {...props} />);

  return {
    props,
    wrapper
  };
}

function setupProps(options: any = {}) {
  const props = {
    action: WorkflowAction[WorkflowAction.SPM_IGNORE],
    event: SpmDataStub.spmEvent1,
    modalOrigin: WorkflowPageOrigin.SPM,
    setWorkOrderStatus: jest.fn(),
    title: 'A title',
    user: {
      signInUserSession : {
        idToken: ''
      }
    },
  };

  for (const option in options) {
    if (option in props) {
      props[option] = options[option];
    }
  }

  return props;
}

describe('WorkflowModalViewController component', () => {

  /**
   * Render method test for IGNORE SPM action
   */
  it('Check render method test for IGNORE SPM action', () => {
    const { wrapper } = setupComponent();

    // Check WorkflowModalView component presence
    expect(wrapper.find(WorkflowModalIgnoreActionView).length).toEqual(1);

    // Unmount
    wrapper.unmount();
  });

  /**
   * Render method test for Reject action
   */
  it('Check render method test for Reject SPM action', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_REJECT],
      event: SpmDataStub.spmEvent4,
    });

    // Check WorkflowModalView component presence
    expect(wrapper.find(WorkflowModalRejectActionView).length).toEqual(1);

    // Unmount
    wrapper.unmount();
  });

  /**
   * Render method test for Validate action
   */
  it('Check render method test for Validate SPM action', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_VALIDATE],
      event: SpmDataStub.spmEvent4,
    });

    // Check WorkflowModalView component presence
    expect(wrapper.find(WorkflowModalValidateActionView).length).toEqual(1);

    // Unmount
    wrapper.unmount();
  });

  /**
   * Render method test for Plan Action action
   */
  it('Check render method test for "Plan Action" SPM action', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_PLAN_ACTION],
      event: SpmDataStub.spmEvent2,
    });

    // Check WorkflowModalView component presence
    expect(wrapper.find(WorkflowModalPlanActionView).length).toEqual(1);

    // Unmount
    wrapper.unmount();
  });

  /**
   * Render method test for Watch action
   */
  it('Check render method test for Watch SPM action', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_WATCH],
      event: SpmDataStub.spmEvent1,
    });

    // Check WorkflowModalView component presence
    expect(wrapper.find(WorkflowModalWatchActionView).length).toEqual(1);

    // Unmount
    wrapper.unmount();
  });

  it('checks workflow scheme with TO_BE_REVIEWED as current status and SPM_WATCH action', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_WATCH],
      event: SpmDataStub.spmEvent1,
    });

    expect(wrapper.find('#workflow-step-tbr.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-opened.ds-step--reachable').length).toBeGreaterThan(0);
  });

  it('checks workflow scheme with TO_BE_REVIEWED as current status and SPM_PLAN_ACTION action', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_PLAN_ACTION],
      event: SpmDataStub.spmEvent1,
    });

    expect(wrapper.find('#workflow-step-tbr.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-planned.ds-step--reachable').length).toBeGreaterThan(0);
  });

  it('checks workflow scheme with OPENED as current status and SPM_PLAN_ACTION action', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_PLAN_ACTION],
      event: SpmDataStub.spmEvent2,
    });

    expect(wrapper.find('#workflow-step-opened.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-planned.ds-step--reachable').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-tbr.ds-step--done').length).toBeGreaterThan(0);

  });

  it('checks workflow scheme with PLANNED as current status and SPM_REGISTER_ACTION action', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_REGISTER_ACTION],
      event: SpmDataStub.spmEvent3,

    });

    expect(wrapper.find('#workflow-step-planned.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-tbm.ds-step--reachable').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-tbr.ds-step--done').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-opened.ds-step--done').length).toBeGreaterThan(0);
  });

  it('checks workflow scheme with TO_BE_MONITORED as current status and SPM_VALIDATE action', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_VALIDATE],
      event: SpmDataStub.spmEvent4,
    });

    expect(wrapper.find('#workflow-step-tbm.ds-step--current').length).toEqual(1);
    expect(wrapper.find('#workflow-step-closed.ds-step--reachable').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-tbr.ds-step--done').length).toEqual(1);
    expect(wrapper.find('#workflow-step-opened.ds-step--done').length).toEqual(1);
    expect(wrapper.find('#workflow-step-planned.ds-step--done').length).toEqual(1);
  });

  it('checks workflow scheme with TO_BE_MONITORED as current status and SPM_REJECT action', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_REJECT],
      event: SpmDataStub.spmEvent4,
    });

    expect(wrapper.find('#workflow-step-tbm.ds-step--current').length).toEqual(1);
    expect(wrapper.find('#workflow-step-opened.ds-step--reachable').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-tbr.ds-step--done').length).toEqual(1);
    expect(wrapper.find('#workflow-step-opened.ds-step--done').length).toEqual(1);
    expect(wrapper.find('#workflow-step-planned.ds-step--done').length).toEqual(1);
  });

  it('checks workflow scheme with CLOSED as current status', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_IGNORE],
      event: SpmDataStub.spmEvent6,
    });

    expect(wrapper.find('#workflow-step-closed.ds-step--current').length).toEqual(1);
    expect(wrapper.find('#workflow-step-tbr.ds-step--done').length).toEqual(1);
    expect(wrapper.find('#workflow-step-opened.ds-step--done').length).toEqual(1);
    expect(wrapper.find('#workflow-step-planned.ds-step--done').length).toEqual(1);
    expect(wrapper.find('#workflow-step-tbm.ds-step--done').length).toEqual(1);
  });

  it('checks workflow scheme with IGNORED as current status', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_IGNORE],
      event: SpmDataStub.spmEvent5,
    });

    expect(wrapper.find('#workflow-step-ignored.ds-step--current').length).toEqual(1);
  });

  it('checks the handleNoCommentCheck method', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_WATCH],
      event: SpmDataStub.spmEvent1,
    });

    expect(wrapper.state('noCommentChecked')).toBe(false);
    wrapper.find('input#no-comment').instance().checked = true;
    wrapper.find('input#no-comment').simulate('change');
    expect(wrapper.state('noCommentChecked')).toBe(true);
  });

  it('checks the transition between TO_BE_REVIEWED and OPENED', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_WATCH],
      event: SpmDataStub.spmEvent1,
    });

    expect(wrapper.find('#workflow-step-tbr.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-opened.ds-step--reachable').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(true);

    wrapper.find('#spm-workflow-modal textarea[name="workOrderComment"]')
      .simulate('change', { target: { value: 'Test' } });
    expect(wrapper.find('#workflow-step-tbr.ds-step--done').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-opened.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(false);

    wrapper.find('#spm-workflow-modal textarea[name="workOrderComment"]')
      .simulate('change', { target: { value: '' } });
    expect(wrapper.find('#workflow-step-tbr.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-opened.ds-step--reachable').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(true);

    wrapper.find('#spm-workflow-modal input#no-comment').instance().checked = true;
    wrapper.find('#spm-workflow-modal input#no-comment').simulate('change');
    expect(wrapper.find('#workflow-step-tbr.ds-step--done').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-opened.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(false);
  });

  it('checks the transition between TO_BE_REVIEWED and PLANNED', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_PLAN_ACTION],
      event: SpmDataStub.spmEvent1,
    });

    expect(wrapper.find('#workflow-step-tbr.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-planned.ds-step--reachable').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(true);

    wrapper.find('DayPickerInput').find('input').instance().value = '2018-2-20';
    wrapper.find('DayPickerInput').find('input').simulate('change');
    expect(wrapper.find('#workflow-step-tbr.ds-step--done').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-planned.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(false);

    wrapper.find('DayPickerInput').find('input').instance().value = '';
    wrapper.find('DayPickerInput').find('input').simulate('change');
    expect(wrapper.find('#workflow-step-tbr.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-planned.ds-step--reachable').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(true);
  });

  it('checks the transition between OPENED and PLANNED', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_PLAN_ACTION],
      event: SpmDataStub.spmEvent2,
    });

    expect(wrapper.find('#workflow-step-opened.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-planned.ds-step--reachable').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(true);

    wrapper.find('DayPickerInput').find('input').instance().value = '2018-2-20';
    wrapper.find('DayPickerInput').find('input').simulate('change');
    expect(wrapper.find('#workflow-step-opened.ds-step--done').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-planned.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(false);

    wrapper.find('DayPickerInput').find('input').instance().value = '';
    wrapper.find('DayPickerInput').find('input').simulate('change');
    expect(wrapper.find('#workflow-step-opened.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-planned.ds-step--reachable').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(true);
  });

  it('checks the transition between TO_BE_MONITORED and CLOSED', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_VALIDATE],
      event: SpmDataStub.spmEvent4,
    });

    expect(wrapper.find('#workflow-step-tbm.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-closed.ds-step--reachable').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(true);

    wrapper.find('#spm-workflow-modal textarea[name="workOrderComment"]')
      .simulate('change', { target: { value: 'Test' } });
    expect(wrapper.find('#workflow-step-tbm.ds-step--done').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-closed.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(false);

    wrapper.find('#spm-workflow-modal textarea[name="workOrderComment"]')
      .simulate('change', { target: { value: '' } });
    expect(wrapper.find('#workflow-step-tbm.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-closed.ds-step--reachable').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(true);

    wrapper.find('#spm-workflow-modal input#no-comment').instance().checked = true;
    wrapper.find('#spm-workflow-modal input#no-comment').simulate('change');
    expect(wrapper.find('#workflow-step-tbm.ds-step--done').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-closed.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(false);
  });

  it('checks the transition between TO_BE_MONITORED and OPENED', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_REJECT],
      event: SpmDataStub.spmEvent4,
    });

    expect(wrapper.find('#workflow-step-tbm.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-opened.ds-step--reachable').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(true);

    wrapper.find('#spm-workflow-modal textarea[name="workOrderComment"]')
      .simulate('change', { target: { value: 'Test' } });
    expect(wrapper.find('#workflow-step-opened.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(false);

    wrapper.find('#spm-workflow-modal textarea[name="workOrderComment"]')
      .simulate('change', { target: { value: '' } });
    expect(wrapper.find('#workflow-step-tbm.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-opened.ds-step--reachable').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(true);

    wrapper.find('#spm-workflow-modal input#no-comment').instance().checked = true;
    wrapper.find('#spm-workflow-modal input#no-comment').simulate('change');
    expect(wrapper.find('#workflow-step-opened.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(false);
  });

  it('checks the transition between IGNORED and others', () => {
    const { wrapper } = setupComponent({
      action: WorkflowAction[WorkflowAction.SPM_IGNORE],
      event: SpmDataStub.spmEvent4,
    });

    expect(wrapper.find('#workflow-step-tbm.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-ignored.ds-step--reachable').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(true);

    wrapper.find('#spm-workflow-modal textarea[name="workOrderComment"]')
      .simulate('change', { target: { value: 'Test' } });
    expect(wrapper.find('#workflow-step-ignored.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(false);

    wrapper.find('#spm-workflow-modal textarea[name="workOrderComment"]')
      .simulate('change', { target: { value: '' } });
    expect(wrapper.find('#workflow-step-tbm.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.find('#workflow-step-ignored.ds-step--reachable').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(true);

    wrapper.find('#spm-workflow-modal input#no-comment').instance().checked = true;
    wrapper.find('#spm-workflow-modal input#no-comment').simulate('change');
    expect(wrapper.find('#workflow-step-ignored.ds-step--current').length).toBeGreaterThan(0);
    expect(wrapper.state('submitDisabled')).toBe(false);
  });

});
