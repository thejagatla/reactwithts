import { mount } from 'enzyme';
import * as React from 'react';
import { MemoryRouter } from 'react-router-dom';
import { DSLoader } from '@sm/skywise-react-library';
import { EventDetailsPageHeaderView } from '../../../../src/components/spm/eventDetailsPageHeader/EventDetailsPageHeaderView';
import { EventDetailsPageHeaderViewController } from '../../../../src/components/spm/eventDetailsPageHeader/EventDetailsPageHeaderViewController';
import { EventWorkStatusViewController } from '../../../../src/components/spm/eventWorkStatus/EventWorkStatusViewController';
import * as data from '../../../stubs/SpmDataStub';

function setupComponent(options: any = {}) {
  const props = setupProps(options);

  const wrapper = mount(
    <MemoryRouter>
      <EventDetailsPageHeaderViewController {...props} />
    </MemoryRouter>
  );

  return {
    props,
    wrapper
  };
}

function setupProps(options: any = {}) {
  const props = {
    event: data.spmEvent1,
    eventLoaded: true,
    eventLoadingError: false,
    priorityToClassName: jest.fn()
  };

  for (const option in options) {
    if (option in props) {
      props[option] = options[option];
    }
  }

  return props;
}

describe('EventDetailsPageHeader component', () => {
  it('renders an EventDetailsPageHeaderViewController component with data loaded', () => {
    const { wrapper } = setupComponent();

    expect(wrapper.find(EventDetailsPageHeaderView).length).toEqual(1);
    expect(wrapper.find(EventDetailsPageHeaderView).hasClass('pass-event'));
  });

  it('renders an EventDetailsPageHeaderViewController component with data loading', () => {
    const { wrapper } = setupComponent({ eventLoaded: false });

    expect(wrapper.find(EventDetailsPageHeaderView).length).toEqual(0);
    expect(wrapper.find(DSLoader).length).toEqual(1);
  });

  it('renders an EventDetailsPageHeaderViewController component with data loading error', () => {
    const { wrapper } = setupComponent({ eventLoadingError: true });

    expect(wrapper.find(EventDetailsPageHeaderView).length).toEqual(0);
    expect(wrapper.find('#error-message').length).toBeGreaterThan(1);
  });

  it('checks the data displayed on this component', () => {
    const { wrapper } = setupComponent();

    expect(
      wrapper
        .find(
          '.list.list--horizontal.pass-event--aircraft__details .list__header span'
        )
        .text()
    ).toEqual(data.spmEvent1.tailNumber);
    expect(wrapper.find('.event-aircraft__title').text()).toEqual(
      data.spmEvent1.riskName
    );
  });

  it('checks openWorkflowModal method', () => {
    const { wrapper } = setupComponent();

    wrapper
      .find('.ds-menu-expand--list a')
      .first()
      .simulate('click');
  });
});
