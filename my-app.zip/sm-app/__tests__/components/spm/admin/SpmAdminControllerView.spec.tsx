import { DSLoader } from '@sm/skywise-react-library';
import { mount, shallow } from 'enzyme';
import * as React from 'react';
import AdminFiltersViews from '../../../../src/components/spm/admin/adminFilters/AdminFiltersViews';
import ModelAccessLevelController from '../../../../src/components/spm/admin/modelAccessLevel/ModelAccessLevelController';
import ModelParametersController from '../../../../src/components/spm/admin/modelParameters/ModelParametersController';
import { SpmAdminControllerView } from '../../../../src/components/spm/admin/SpmAdminControllerView';
import { AutomaticWorkflowController } from '../../../../src/components/spm/admin/workflow/AutomaticWorkflowController';
import { Message } from '../../../../src/components/storybook/Message';
import { ErrorModalView } from '../../../../src/components/utils/errorModal/ErrorModalView';
import * as SpmAdminStub from '../../../stubs/SpmAdminStub';

function setupComponent(options: any = {}) {
  const props = setupProps(options);

  const wrapper = mount(<SpmAdminControllerView {...props} />);

  return {
    props,
    wrapper
  };
}

function setupProps(options: any = {}) {
  const props = {
    ataForSelectedAirline: [],
    exception: null,
    getAirlines: jest.fn(),
    getModels: jest.fn(),
    icaos: [],
    icaosLoaded: false,
    loadingModelsException: null,
    modelsForSelectedAirline: [],
    modelsLoading: false,
  };

  for (const option in options) {
    if (option in props) {
      props[option] = options[option];
    }
  }

  return props;
}

describe('SpmAdminControllerView component', () => {

  it('renders <DSLoader /> when icaos are not Loaded', () => {
    const { wrapper } = setupComponent();
    expect(wrapper.find(DSLoader).length).toEqual(1);
    expect(wrapper.find(DSLoader).is('#modelsLoader')).toEqual(true);
  });

  it('renders <ErrorModalView /> when there is an exception', () => {
    const { wrapper } = setupComponent({
      exception: {
        message: 'Access Not authorized'
      },
      icaosLoaded: true
    });
    expect(wrapper.find(ErrorModalView).length).toEqual(1);
  });

  // it('render an error modal when there is an exception when loading models ', () => {
  //   const blob = new Blob([JSON.stringify(SpmAdminStub.loadModelsException)], { type : 'application/json' });
  //   const myResponse = new Response(blob, { 'status' : 200 });
  //   const { wrapper } = setupComponent({ 
  //     icaosLoaded: true,
  //     loadingModelsException: myResponse,
  //   });
  //   expect(wrapper.find(ErrorModalView).length).toEqual(1);
  // });

  it('render <AdminFiltersViews /> when icaos are loaded and There is no exception', () => {
    const { wrapper } = setupComponent({ 
      icaosLoaded: true,
    });
    expect(wrapper.find(AdminFiltersViews).length).toEqual(1);
  });

  it('render information message when no model is selected', () => {
    const { wrapper } = setupComponent({ 
      icaosLoaded: true,
    });
    expect(wrapper.find(Message).length).toEqual(1);
  });

  it('render modification cards when a model is selected', () => {
    const { wrapper } = setupComponent({ 
      icaosLoaded: true,
    });
    wrapper.setState({
      selectedModel: SpmAdminStub.selectedModel.id,
      workflow: {
        automaticWorkflowConfigurationByUser: SpmAdminStub.selectedModel.automaticWorkflowConfiguration,
        automaticWorkflowDefinition: SpmAdminStub.selectedModel.automaticWorkflowDefinition,
      }
    });
    // Model access level component is present
    expect(wrapper.find(ModelAccessLevelController).length).toEqual(1);
    // Automatic workflow component is present
    expect(wrapper.find(AutomaticWorkflowController).length).toEqual(1);
    // Model config component is present
    expect(wrapper.find(ModelParametersController).length).toEqual(1);
  });
});
