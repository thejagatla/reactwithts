import { DSBanner, DSButton, DSLoader } from '@sm/skywise-react-library';
import { mount, shallow } from 'enzyme';
import * as React from 'react';
import ModelAccessLevelController from '../../../../src/components/spm/admin/modelAccessLevel/ModelAccessLevelController';
import ModelAccessLevelView from '../../../../src/components/spm/admin/modelAccessLevel/ModelAccessLevelView';
import * as SpmAdminStub from '../../../stubs/SpmAdminStub';

function setupComponent(options: any = {}) {
  const props = setupProps(options);

  const wrapper = mount(<ModelAccessLevelController {...props} />);

  return {
    props,
    wrapper
  };
}

function setupProps(options: any = {}) {
  const props = {
    fillErrorModalWithData: jest.fn(),
    maturity: SpmAdminStub.selectedModel.mayurity,
    modelAccessLevel: SpmAdminStub.selectedModel.modelAccessLevel,
    selectedIcao: 'EZY',
    selectedModel: SpmAdminStub.selectedModel.id,
    showModelLoading: false,
  };

  for (const option in options) {
    if (option in props) {
      props[option] = options[option];
    }
  }

  return props;
}

describe('Testing Admin ModelAccessLevel components', () => {

  it('<ModelAccessLevelController /> must render <ModelAccessLevelView /> in normal case', () => {
    const { wrapper } = setupComponent();
    expect(wrapper.find(ModelAccessLevelView).length).toEqual(1);
  });

  it('<ModelAccessLevelView /> must render <DSLoader /> when model is loading', () => {
    const { wrapper } = setupComponent({
      showModelLoading: true
    });
    expect(wrapper.find(DSLoader).length).toEqual(1);
  });

  it('alert Banner is shown and submit button is disactivated when there is an alert', () => {
    const { wrapper } = setupComponent();
    wrapper.setState({
      alertMessages: {
        showModelALWarningBanner: true
      },
      applyButtonDisabledByDefaultForAL: true
    });
    // Alert banner is shown
    expect(wrapper.find(DSBanner).length).toEqual(1);
    expect(wrapper.find(DSBanner).at(0).is('#warning-model-access-level')).toEqual(true);

    // The apply button is not disabled
    expect(wrapper.find(DSButton).at(0).props().disabled).toEqual(false);
  });
  
  it('Test hiding banner on <ModelAccessLevelView />', () => {
    const { wrapper } = setupComponent();
    wrapper.setState({
      alertMessages: {
        showModelALWarningBanner: true
      }
    });
    // must shown banner
    expect(wrapper.find(DSBanner).length).toEqual(1);
    // Try to close alert banner
    wrapper.find('#warning-model-access-level').find('button').simulate('click');
    // O banner is shown
    expect(wrapper.find(DSBanner).length).toEqual(0);
  });
});
