import { DSBanner, DSButton, DSLoader } from '@sm/skywise-react-library';
import { mount, shallow } from 'enzyme';
import * as React from 'react';
import { AutomaticWorkflowController } from '../../../../src/components/spm/admin/workflow/AutomaticWorkflowController';
import AutomaticWorkflowView from '../../../../src/components/spm/admin/workflow/AutomaticWorkflowView';
import * as SpmAdminStub from '../../../stubs/SpmAdminStub';

function setupComponent(options: any = {}) {
  const props = setupProps(options);

  const wrapper = mount(<AutomaticWorkflowController {...props} />);

  return {
    props,
    wrapper
  };
}
  
function setupProps(options: any = {}) {
  const props = {
    fillErrorModalWithData: jest.fn(),
    selectedIcao: 'EZY',
    selectedModel: SpmAdminStub.selectedModel.id,
    showModelLoading: false,
    workflow: {
      automaticWorkflowConfiguration: SpmAdminStub.selectedModel.automaticWorkflowConfiguration,
      automaticWorkflowConfigurationByUser: SpmAdminStub.selectedModel.automaticWorkflowConfiguration,
      automaticWorkflowDefinition: SpmAdminStub.selectedModel.automaticWorkflowDefinition,
      newWorkflowIsLoading: false
    }
  };

  for (const option in options) {
    if (option in props) {
      props[option] = options[option];
    }
  }

  return props;
}

describe('Testing Admin AutomaticWorkflow', () => {

  it('<AutomaticWorkflowController /> must render <AutomaticWorkflowView /> in normal case', () => {
    const { wrapper } = setupComponent();
    expect(wrapper.find(AutomaticWorkflowView).length).toEqual(1);
  });

  it('<AutomaticWorkflowView /> must render <DSLoader /> when model is loading', () => {
    const { wrapper } = setupComponent({
      showModelLoading: true
    });
    expect(wrapper.find(DSLoader).length).toEqual(1);
  });

  it('<AutomaticWorkflowView /> must render DSBanners when there is a warning alert or a success alert ', () => {
    const { wrapper } = setupComponent();
    wrapper.setState({
      alertMessages: {
        workflowSuccessBaner: true,
        workflowWarningBaner: true
      }
    });
    expect(wrapper.find(DSBanner).length).toEqual(2);
    // The success banner is present
    expect(wrapper.find(DSBanner).at(0).is('#workflowSuccessBaner')).toEqual(true);
    // The Warning banner is present
    expect(wrapper.find(DSBanner).at(1).is('#workflowWarningBaner')).toEqual(true);
  });

  it('Test hiding banners on <AutomaticWorkflowView />', () => {
    const { wrapper } = setupComponent();
    wrapper.setState({
      alertMessages: {
        workflowSuccessBaner: true,
        workflowWarningBaner: true
      }
    });
    // must have 2 banners
    expect(wrapper.find(DSBanner).length).toEqual(2);
    // Try to close success banner
    wrapper.find('#workflowSuccessBaner').find('button').simulate('click');
    expect(wrapper.find('#workflowSuccessBaner').length).toEqual(0);
    // Try to close warning banner
    wrapper.find('#workflowWarningBaner').find('button').simulate('click');
    expect(wrapper.find('#workflowWarningBaner').length).toEqual(0);
    // The 2 banners are closed
    expect(wrapper.find(DSBanner).length).toEqual(0);
  });

  it('Check the status of submit button', () => {
    const { wrapper } = setupComponent();
    wrapper.setState({
      applyButtonDisabledByDefaultForWF: false
    });

    // The apply button is not disabled
    expect(wrapper.find(DSButton).at(0).props().disabled).toEqual(false);
  });

});
