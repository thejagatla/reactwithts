import { DSLoader } from '@sm/skywise-react-library';
import { mount, shallow } from 'enzyme';
import * as React from 'react';
import ModelParametersController from '../../../../src/components/spm/admin/modelParameters/ModelParametersController';
import ModelParametersView from '../../../../src/components/spm/admin/modelParameters/ModelParametersView';
import * as SpmAdminStub from '../../../stubs/SpmAdminStub';

function setupComponent(options: any = {}) {
  const props = setupProps(options);

  const wrapper = mount(<ModelParametersController {...props} />);

  return {
    props,
    wrapper
  };
}
  
function setupProps(options: any = {}) {
  const props = {
    fillErrorModalWithData: jest.fn(),
    modelConfiguration: SpmAdminStub.selectedModel.modelConfigurations,
    modelDefinition: SpmAdminStub.selectedModel.modelDefinition,
    naturalCompare: jest.fn(),
    selectedIcao: 'EZY',
    selectedModel: SpmAdminStub.selectedModel.id,
    showModelLoading: false,
  };

  for (const option in options) {
    if (option in props) {
      props[option] = options[option];
    }
  }

  return props;
}

describe('Testing Admin ModelParameterController', () => {

  it('<ModelParametersController /> must render <ModelParametersView /> in normal case', () => {
    const props = setupProps();
    const wrapper = shallow(<ModelParametersController {...props} />);
    expect(wrapper.find(ModelParametersView).length).toEqual(1);
  });

  it('<ModelParametersController /> must render <DSLoader /> when model is loading', () => {
    const { wrapper } = setupComponent({
      showModelLoading: true
    });
    expect(wrapper.find(DSLoader).length).toEqual(1);
  });
});
