import {
  DSBar,
  DSDropdown,
  DSIcon,
  DSStepIcon
} from '@sm/skywise-react-library';
import {} from '@types/jest';
import * as enzyme from 'enzyme';
import * as React from 'react';
import { MemoryRouter } from 'react-router-dom';
import reduxMockStore from 'redux-mock-store';
import { CommentView } from '../../../src/components/common/events/cells/comment/CommentView';
import { CommentViewController } from '../../../src/components/common/events/cells/comment/CommentViewController';
import { WorkflowStatusCellView } from '../../../src/components/common/events/cells/workflow/WorkflowStatusCellView';
import { WorkflowStatusCellViewController } from '../../../src/components/common/events/cells/workflow/WorkflowStatusCellViewController';
import { EventLine } from '../../../src/components/common/events/eventLine/EventLine';
// tslint:disable-next-line:max-line-length
import {
  lEvent1,
  lEvent2,
  lEvent3,
  lEvent4,
  lEvent5,
  lEvent6,
  lExpectedResult1,
  lExpectedResult2,
  lExpectedResult3,
  lExpectedResult4
} from '../../stubs/SpmDataStub';

describe('SpmEventRowRenderer component', () => {
  // create any initial state needed
  const initialState = {};
  // here it is possible to pass in any middleware if needed into //configureStore
  const mockStore = reduxMockStore();
  let store;

  let lWrapper;

  beforeEach(() => {
    // creates the store with any initial state or middleware needed
    store = mockStore(initialState);
    lWrapper = enzyme.mount(
      <MemoryRouter>
        <EventLine event={lEvent1} key={0} pageOrigin="SHM" />
      </MemoryRouter>
    );
  });

  /**
   * Priority render
   */
  it('Test priority renderer of a SPM event', () => {
    const wrapper: enzyme.ReactWrapper = lWrapper
      .find('.pass-event__section')
      .first()
      .childAt(0);

    expect(wrapper.hasClass('priority-column')).toEqual(true);
    expect(wrapper.hasClass('no-priority')).toEqual(true);
  });

  /**
   * Render title
   */
  it('Test title renderer of a SPM event', () => {
    const wrapper: enzyme.ReactWrapper = lWrapper.find(
      '.event-aircraft__title'
    );
    expect(wrapper.text()).toEqual(lEvent1.titleFromAircraft);
  });

  /**
   * Render aircraft
   */
  it('Test aircraft renderer of a SPM event', () => {
    const wrapper: enzyme.ReactWrapper = lWrapper.find(
      '.list.list--horizontal.pass-event--aircraft__details'
    );
    expect(wrapper.find('.list__header span').text()).toEqual(
      lEvent1.acMatricule
    );
    expect(
      wrapper
        .find('span')
        .last()
        .text()
    ).toEqual(lEvent1.flightNumber);
  });

  /**
   * Render comment
   */
  it('Test comment renderer of a SPM event', () => {
    const wrapper: enzyme.ReactWrapper = lWrapper
      .find(CommentViewController)
      .childAt(0);
    expect(wrapper.hasClass('pass-event--comment')).toEqual(true);
  });

  /**
   * Render work order status
   */
  it('Test To be reviewed work order status renderer of a SPM event', () => {
    const wrapper: enzyme.ReactWrapper = lWrapper.find(
      WorkflowStatusCellViewController
    );
    // Is class name correct ?
    expect(
      wrapper
        .find(DSStepIcon)
        .childAt(0)
        .hasClass('ds-step-ico tbr')
    ).toEqual(true);
  });

  /**
   * Render work order status
   */
  it('Test Opened work order status renderer of a SPM event', () => {
    const lWrapper2 = enzyme.mount(
      <MemoryRouter>
        <EventLine event={lEvent2} key={2} store={store} />
      </MemoryRouter>
    );

    const wrapper: enzyme.ReactWrapper = lWrapper2.find(
      WorkflowStatusCellViewController
    );
    // Is class name correct ?
    expect(
      wrapper
        .find(DSStepIcon)
        .childAt(0)
        .hasClass('ds-step-ico opened')
    ).toEqual(true);
  });

  /**
   * Render work order status
   */
  it('Test Planned work order status renderer of a SPM event', () => {
    const lWrapper3 = enzyme.mount(
      <MemoryRouter>
        <EventLine event={lEvent3} key={3} store={store} />
      </MemoryRouter>
    );

    const wrapper: enzyme.ReactWrapper = lWrapper3.find(
      WorkflowStatusCellViewController
    );
    // Is class name correct ?
    expect(
      wrapper
        .find(DSStepIcon)
        .childAt(0)
        .hasClass('ds-step-ico planned')
    ).toEqual(true);
  });

  /**
   * Render work order status
   */
  it('Test To be monitored work order status renderer of a SPM event', () => {
    const lWrapper4 = enzyme.mount(
      <MemoryRouter>
        <EventLine event={lEvent4} key={4} store={store} />
      </MemoryRouter>
    );

    const wrapper: enzyme.ReactWrapper = lWrapper4.find(
      WorkflowStatusCellViewController
    );
    // Is class name correct ?
    expect(
      wrapper
        .find(DSStepIcon)
        .childAt(0)
        .hasClass('ds-step-ico tbm')
    ).toEqual(true);
  });

  /**
   * Render work order status
   */
  it('Test Closed work order status renderer of a SPM event', () => {
    const lWrapper5 = enzyme.mount(
      <MemoryRouter>
        <EventLine event={lEvent5} key={5} store={store} />
      </MemoryRouter>
    );

    const wrapper: enzyme.ReactWrapper = lWrapper5.find(
      WorkflowStatusCellViewController
    );
    // Is class name correct ?
    expect(
      wrapper
        .find(DSStepIcon)
        .childAt(0)
        .hasClass('ds-step-ico closed')
    ).toEqual(true);
  });

  /**
   * Render work order status
   */
  it('Test Ignored work order status renderer of a SPM event', () => {
    const lWrapper6 = enzyme.mount(
      <MemoryRouter>
        <EventLine event={lEvent6} key={5} store={store} />
      </MemoryRouter>
    );

    const wrapper: enzyme.ReactWrapper = lWrapper6.find(
      WorkflowStatusCellViewController
    );
    // Is class name correct ?
    expect(
      wrapper
        .find(DSStepIcon)
        .childAt(0)
        .hasClass('ds-step-ico ignored')
    ).toEqual(true);
  });

  /**
   * Occurrence history render
   */
  /* it('Test occurrence history renderer with one fault message occurred during phase 2', () => {
 
     const lSpmEventRowRenderer = new SpmEventRowRenderer(null, EventType.SPM);
     const lRender = lSpmEventRowRenderer.renderRow(lEvent1);
     const wrapper = enzyme.shallow(lRender).find('.event-row').find('.event-occ-history').childAt(0);
 
     expect(wrapper.equals(lExpectedResult1)).toEqual(true);
   });
 
   it('Test occurrence history renderer with one fault message occurred during phase 3', () => {
 
     const lSpmEventRowRenderer = new SpmEventRowRenderer(null, EventType.SPM);
     const lRender = lSpmEventRowRenderer.renderRow(lEvent2);
     const wrapper = enzyme.shallow(lRender).find('.event-row').find('.event-occ-history').childAt(0);
 
     expect(wrapper.equals(lExpectedResult2)).toEqual(true);
   });
 
   it('Test occurrence history renderer with no fault message on last flight', () => {
 
     const lSpmEventRowRenderer = new SpmEventRowRenderer(null, EventType.SPM);
     const lRender = lSpmEventRowRenderer.renderRow(lEvent3);
     const wrapper = enzyme.shallow(lRender).find('.event-row').find('.event-occ-history').childAt(0);
 
     expect(wrapper.equals(lExpectedResult3)).toEqual(true);
   });
 
   it('Test occurrence history renderer with one fault message on phase 12 last flight', () => {
 
     const lSpmEventRowRenderer = new SpmEventRowRenderer(null, EventType.SPM);
     const lRender = lSpmEventRowRenderer.renderRow(lEvent4);
     const wrapper = enzyme.shallow(lRender).find('.event-row').find('.event-occ-history').childAt(0);
 
     expect(wrapper.equals(lExpectedResult4)).toEqual(true);
   });*/
});
