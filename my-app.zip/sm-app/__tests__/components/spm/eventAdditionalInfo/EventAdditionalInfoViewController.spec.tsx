import { mount } from 'enzyme';
import * as React from 'react';

import { DSBanner, DSLoader, DSTable } from '@sm/skywise-react-library';
import {
    EventAdditionalInfoView
} from '../../../../src/components/spm/eventAdditionalInfo/EventAdditionalInfoView';

function setupComponent(options: any = {}) {
  const props = setupProps(options);
  
  const wrapper = mount(<EventAdditionalInfoView {...props} />);
  
  return {
    props,
    wrapper
  };
}

function setupProps(options: any = {}) {
  const props = {
    eventLoaded: true,
    eventLoadingError: false,
    loadingLabel: 'loadingLabelTest',
  };

  for (const option in options) {
    if (option in props) {
      props[option] = options[option];
    }
  }

  return props;
}

describe('EventAdditionalInfoViewControlle component', () => {
  it('should render <DSLoader /> component when eventLoaded is false', () => {
    const { wrapper } = setupComponent({ eventLoaded: false });
    expect(wrapper.find(DSLoader).length).toEqual(1);
  });

  it('should render <DSBanner /> component when eventLoadingError is true', () => {
    const { wrapper } = setupComponent({ eventLoaded: true, eventLoadingError: true });
    expect(wrapper.find(DSBanner).length).toEqual(1);
  });

  it('should render children when eventLoaded is true and there is no error', () => {
    const wrapper = mount((
    <EventAdditionalInfoView eventLoaded={true} eventLoadingError={false} > 
        <DSTable />
    </EventAdditionalInfoView>));
    expect(wrapper.find(DSTable).length).toEqual(1);
  });

});
