/**
 * DSButton test component
 */
import { DSButton } from '@sm/skywise-react-library';
import * as enzyme from 'enzyme';
import * as React from 'react';

describe('Button component', () => {

    /**
     * Render an primary active Button
     */
    it('Render an primary active Button', () => {
        const lButton = enzyme.shallow(
            <DSButton
                content="my button"
                type="primary"
                handleClick={() => {}}
            />
        );
        expect(lButton.hasClass('ds-button')).toEqual(true);
        expect(lButton.hasClass('ds-button--primary-1')).toEqual(true);
        expect(lButton.hasClass('ds-button--negative')).toEqual(false);
        expect(lButton.hasClass('ds-button--white')).toEqual(false);
        expect(lButton.hasClass('ds-button--small')).toEqual(false);
        expect(lButton.hasClass('ds-button--compact')).toEqual(false);
        expect(lButton.prop('children')).toEqual([undefined, 'my button']);
    });
    /**
     * Render an primary unactive Button
     */
    it('Render an primary unactive Button', () => {
        const lButton = enzyme.shallow(
            <DSButton
                content="my button"
                type="primary"
                isDisabled={true}
                handleClick={() => {}}
            />
        );

        expect(lButton.hasClass('ds-button')).toEqual(true);
        expect(lButton.hasClass('ds-button--primary-1')).toEqual(true);
        expect(lButton.hasClass('ds-button--negative')).toEqual(false);
        expect(lButton.hasClass('ds-button--white')).toEqual(false);
        expect(lButton.hasClass('ds-button--small')).toEqual(false);
        expect(lButton.hasClass('ds-button--compact')).toEqual(false);
    });
    /**
     * Render an regular active Button
     */
    it('Render an regular active Button', () => {
        const lButton = enzyme.shallow(
            <DSButton
                content="my button"
                type="regular"
                handleClick={() => {}}
            />
        );

        expect(lButton.hasClass('ds-button')).toEqual(true);
        expect(lButton.hasClass('ds-button--primary-1')).toEqual(false);
        expect(lButton.hasClass('ds-button--negative')).toEqual(false);
        expect(lButton.hasClass('ds-button--white')).toEqual(false);
        expect(lButton.hasClass('ds-button--small')).toEqual(false);
        expect(lButton.hasClass('ds-button--compact')).toEqual(false);
    });
    /**
     * Render an regular unactive Button
     */
    it('Render an regular unactive Button', () => {
        const lButton = enzyme.shallow(
            <DSButton
                content="my button"
                type="regular"
                isDisabled={true}
                handleClick={() => {}}
            />
        );

        expect(lButton.hasClass('ds-button')).toEqual(true);
        expect(lButton.hasClass('ds-button--primary-1')).toEqual(false);
        expect(lButton.hasClass('ds-button--negative')).toEqual(false);
        expect(lButton.hasClass('ds-button--white')).toEqual(false);
        expect(lButton.hasClass('ds-button--small')).toEqual(false);
        expect(lButton.hasClass('ds-button--compact')).toEqual(false);
    });
    /**
     * Render an negative active Button
     */
    it('Render an negative active Button', () => {
        const lButton = enzyme.shallow(
            <DSButton
                content="my button"
                type="negative"
                handleClick={() => {}}
            />
        );

        expect(lButton.hasClass('ds-button')).toEqual(true);
        expect(lButton.hasClass('ds-button--primary-1')).toEqual(false);
        expect(lButton.hasClass('ds-button--negative')).toEqual(true);
        expect(lButton.hasClass('ds-button--white')).toEqual(false);
        expect(lButton.hasClass('ds-button--small')).toEqual(false);
        expect(lButton.hasClass('ds-button--compact')).toEqual(false);
    });
    /**
     * Render an negative unactive Button
     */
    it('Render an negative unactive Button', () => {
        const lButton = enzyme.shallow(
            <DSButton
                content="my button"
                type="negative"
                isDisabled={true}
                handleClick={() => {}}
            />
        );

        expect(lButton.hasClass('ds-button')).toEqual(true);
        expect(lButton.hasClass('ds-button--primary-1')).toEqual(false);
        expect(lButton.hasClass('ds-button--negative')).toEqual(true);
        expect(lButton.hasClass('ds-button--white')).toEqual(false);
        expect(lButton.hasClass('ds-button--small')).toEqual(false);
        expect(lButton.hasClass('ds-button--compact')).toEqual(false);
    });
    /**
     * Render an white active Button
     */
    it('Render an white active Button', () => {
        const lButton = enzyme.shallow(
            <DSButton
                content="my button"
                type="white"
                handleClick={() => {}}
            />
        );

        expect(lButton.hasClass('ds-button')).toEqual(true);
        expect(lButton.hasClass('ds-button--primary-1')).toEqual(false);
        expect(lButton.hasClass('ds-button--negative')).toEqual(false);
        expect(lButton.hasClass('ds-button--white')).toEqual(true);
        expect(lButton.hasClass('ds-button--small')).toEqual(false);
        expect(lButton.hasClass('ds-button--compact')).toEqual(false);
    });
    /**
     * Render an white unactive Button
     */
    it('Render an white unactive Button', () => {
        const lButton = enzyme.shallow(
            <DSButton
                content="my button"
                type="white"
                isDisabled={true}
                handleClick={() => {}}
            />
        );

        expect(lButton.hasClass('ds-button')).toEqual(true);
        expect(lButton.hasClass('ds-button--primary-1')).toEqual(false);
        expect(lButton.hasClass('ds-button--negative')).toEqual(false);
        expect(lButton.hasClass('ds-button--white')).toEqual(true);
        expect(lButton.hasClass('ds-button--small')).toEqual(false);
        expect(lButton.hasClass('ds-button--compact')).toEqual(false);
    });
    /**
     * Render an small active Button
     */
    it('Render an small active Button', () => {
        const lButton = enzyme.shallow(
            <DSButton
                content="my button"
                size="small"
                handleClick={() => {}}
            />
        );

        expect(lButton.hasClass('ds-button')).toEqual(true);
        expect(lButton.hasClass('ds-button--primary-1')).toEqual(false);
        expect(lButton.hasClass('ds-button--negative')).toEqual(false);
        expect(lButton.hasClass('ds-button--white')).toEqual(false);
        expect(lButton.hasClass('ds-button--small')).toEqual(true);
        expect(lButton.hasClass('ds-button--compact')).toEqual(false);
    });
    /**
     * Render an compact active Button
     */
    it('Render an compact active Button', () => {
        const lButton = enzyme.shallow(
            <DSButton
                content="my button"
                size="compact"
                handleClick={() => {}}
            />
        );

        expect(lButton.hasClass('ds-button')).toEqual(true);
        expect(lButton.hasClass('ds-button--primary-1')).toEqual(false);
        expect(lButton.hasClass('ds-button--negative')).toEqual(false);
        expect(lButton.hasClass('ds-button--white')).toEqual(false);
        expect(lButton.hasClass('ds-button--small')).toEqual(false);
        expect(lButton.hasClass('ds-button--compact')).toEqual(true);
    });
    /**
     * Test custom class
     */
    it('Test custom class', () => {
        const lButton = enzyme.shallow(
            <DSButton
                content="my button"
                className="my-class"
                handleClick={() => {}}
            />
        );

        expect(lButton.hasClass('my-class')).toEqual(true);
    });

    it('Test id of button', () => {
        const lButton = enzyme.shallow(
            <DSButton
                content="my button"
                id="01102"
                handleClick={() => {}}
            />
        );

        expect(lButton.prop('id')).toEqual('01102');
    });
});