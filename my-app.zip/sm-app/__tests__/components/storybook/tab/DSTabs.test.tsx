/**
 * DSTabs test component
 */
import { DSTab, DSTabs } from '@sm/skywise-react-library';
import * as enzyme from 'enzyme';
import * as React from 'react';

describe('DSTabs component', () => {

    // Tabs list
    const lTabs: any[] = [
        {
            id: '0',
            selected: true,
            title: 'Urgent +++',
        },
        {
            id: '1',
            selected: false,
            title: 'Urgent ++',
        },
        {
            id: '2',
            selected: false,
            title: 'Urgent +',
        },
        {
            id: '3',
            selected: false,
            title: 'Planned',
        },
        {
            id: '4',
            selected: false,
            title: 'To be monitored',
        }
    ];

    /**
     * Tests the header tab
     */
    it('Tests the header tab', () => {
        // DSTabs wrapper
        const lWrapper: enzyme.ShallowWrapper = enzyme.shallow(<DSTabs tabs={lTabs} selectedIndex={0}/>);

        // Check class
        expect(lWrapper.hasClass('ds-tabs')).toBe(true);

        // Check number of tabs
        expect(lWrapper.find(DSTab)).toHaveLength(5);

        // Check that the first tab is active
        expect(lWrapper.find(DSTab).at(0).prop('selected')).toBe(true);
        expect(lWrapper.find(DSTab).at(1).prop('selected')).toBe(false);
        expect(lWrapper.find(DSTab).at(2).prop('selected')).toBe(false);
        expect(lWrapper.find(DSTab).at(3).prop('selected')).toBe(false);
        expect(lWrapper.find(DSTab).at(4).prop('selected')).toBe(false);
    });
});
