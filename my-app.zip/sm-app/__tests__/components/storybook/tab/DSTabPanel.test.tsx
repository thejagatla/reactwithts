/**
 * DSTabPanel test component
 */
import { DSTabPanel } from '@sm/skywise-react-library';
import * as enzyme from 'enzyme';
import * as React from 'react';

describe('DSTabPanel component', () => {

    /**
     * Tests the DSTabPanel class
     */
    it('Tests DSTabPanel class', () => {
        const lWrapper: enzyme.ShallowWrapper = enzyme.shallow(<DSTabPanel />);
        expect(lWrapper.hasClass('ds-tabs--panel')).toBe(true);
    });
});
