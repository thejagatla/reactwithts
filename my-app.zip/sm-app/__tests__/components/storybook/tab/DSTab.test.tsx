/**
 * DSTab test component
 */
import { DSTab } from '@sm/skywise-react-library';
import * as enzyme from 'enzyme';
import * as React from 'react';

describe('DSTab component', () => {

    /**
     * Tests the class of an active tab
     */
    it('Tests the class of an active tab', () => {
        // DSTab wrapper
        const lWrapper: enzyme.ShallowWrapper = enzyme.shallow(<DSTab title="Urgent +++" selected={true} />);
        expect(lWrapper.find('li').hasClass('ds-active')).toBe(true);
    });

    /**
     * Tests the class of a non-active tab
     */
    it('Tests the class of a non-active tab', () => {
        // DSTab wrapper
        const lWrapper: enzyme.ShallowWrapper = enzyme.shallow(<DSTab title="Urgent +++" selected={false} />);
        expect(lWrapper.find('li').hasClass('ds-tabs--item')).toBe(true);
    });

});
