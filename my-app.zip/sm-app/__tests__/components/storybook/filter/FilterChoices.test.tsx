/**
 * FilterChoices test component
 */
import * as enzyme from 'enzyme';
import * as React from 'react';
import { Button } from '../../../../src/components/storybook/controls/Button';
import { FilterChoices } from '../../../../src/components/storybook/filter/FilterChoices';
import { workStatusFilters } from '../../../stubs/FleetsweepFilterDataStub';

describe('FilterChoices component', () => {
    const lMockStartInterval = ((value) => {
        // DO nothing
        console.log('click');
    });

    const lFilterChoices = enzyme.shallow(
        <FilterChoices
            values={workStatusFilters}
            handleApplyClick={() => { }}
            handleCancelClick={() => { }}
            handleCheckboxChange={() => { }}
            handleClearFilterClick={lMockStartInterval}
        />
    );

    /**
     * Tests render of reset filter button
     */
    it('Tests render of reset filter button', () => {
        const lResetButton = lFilterChoices.find('button').at(0);
        expect(lResetButton.hasClass('ds-picklist--reset')).toBe(true);
    });
    /**
     * Tests render of reset cancel button
     */
    it('Tests render of reset cancel button', () => {
        const lCancelButton = lFilterChoices.find('.ds-form-group-submit').find('DSButton').at(0);
        expect(lCancelButton).toHaveLength(1);
        expect(lCancelButton.prop('content')).toEqual('Cancel');
        expect(lCancelButton.prop('size')).toEqual('small');
    });
    /**
     * Tests render of reset submit button
     */
    it('Tests render of reset submit button', () => {
        const lSubmitButton = lFilterChoices.find('.ds-form-group-submit').find('DSButton').at(1);
        expect(lSubmitButton).toHaveLength(1);
        expect(lSubmitButton.prop('content')).toEqual('Apply');
        expect(lSubmitButton.prop('size')).toEqual('small');
        expect(lSubmitButton.prop('type')).toEqual('primary');
    });

});
