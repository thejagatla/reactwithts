/**
 * FilterButton test component
 */
import { DSIcon } from '@sm/skywise-react-library';
import { DSTextIcon } from '@sm/skywise-react-library';
import { SkywiseICONS } from '@sm/skywise-react-library/dist/SkywiseInterface';
import * as enzyme from 'enzyme';
import * as React from 'react';
import { FilterButton } from '../../../../src/components/storybook/filter/FilterButton';
import { IconStatusProps } from '../../../../src/model/CommonInterfaces';

describe('FilterButton component', () => {

    const lIconsList: SkywiseICONS[] = ['calendar'];
    const lTextList: string[] = ['My Text'];

    it('Render an empty FilterButton', () => {
        const lFilterButton = enzyme.shallow(
            <FilterButton
                label="My Label"
                handleButtonClick={() => {}}
                isEmpty={true}
            />
        );
        expect(lFilterButton.find('DSButton').prop('content')).toEqual('My Label');
        
    });

    it('Render an no empty FilterButton but without text', () => {
        const lFilterButton = enzyme.shallow(
            <FilterButton
                label="My Label"
                handleButtonClick={() => {}}
                isEmpty={false}
            />
        );
        expect(lFilterButton.find('.ds-fake-label')).toHaveLength(1);
        expect(lFilterButton.find('.ds-fake-label').prop('children')).toEqual('My Label');
        expect(lFilterButton.find('DSButton')).toHaveLength(1);
        expect(lFilterButton.find('DSButton').prop('text')).toEqual(undefined);
    });

    it('Render a FilterButton with icon and text', () => {
        const lFilterButton = enzyme.shallow(
            <FilterButton
                label="My Label"
                handleButtonClick={() => {}}
                isEmpty={false}
                iconsList={lIconsList}
                textList={lTextList}
            />
        );
        expect(lFilterButton.find('.ds-fake-label')).toHaveLength(1);
        expect(lFilterButton.find('.ds-fake-label').prop('children')).toEqual('My Label');

        const lTextIcon = <DSTextIcon iconType={lIconsList[0]} text={lTextList[0  ]} key="My Text0" className="ds-filter-button__elem"/>;
        expect(lFilterButton.find('DSButton').prop('content')).toEqual([lTextIcon]);
    });

    it('Render a FilterButton with icon but no text', () => {
        const lFilterButton = enzyme.shallow(
            <FilterButton
                label="My Label"
                handleButtonClick={() => {}}
                isEmpty={false}
                iconsList={lIconsList}
            />
        );
        expect(lFilterButton.find('.ds-fake-label')).toHaveLength(1);
        expect(lFilterButton.find('.ds-fake-label').prop('children')).toEqual('My Label');
    });
    
    it('Render a FilterButton with text but no icon', () => {
        const lFilterButton = enzyme.shallow(
            <FilterButton
                label="My Label"
                handleButtonClick={() => {}}
                isEmpty={false}
                textList={lTextList}
            />
        );
        expect(lFilterButton.find('.ds-fake-label')).toHaveLength(1);
        expect(lFilterButton.find('.ds-fake-label').prop('children')).toEqual('My Label');

        const lContent = 
            <span className="ds-filter-button__elem" key="My Text0">{lTextList[0]}</span>;
        expect(lFilterButton.find('DSButton').prop('content'))
        .toEqual([lContent]);
    });
});
