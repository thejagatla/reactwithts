/**
 * Checkbox test component
 */
import * as enzyme from 'enzyme';
import * as React from 'react';
import { Checkbox } from '../../../../src/components/storybook/controls/Checkbox';

describe('Checkbox component', () => {

    /**
     * Render an checked active Checkbox
     */
    it('Render an checked active Checkbox', () => {
        const lCheckbox = enzyme.shallow(
            <Checkbox
                id="myCheckbox" 
                label="Checkbox" 
                isChecked={true}
                handleCheckboxChange={() => {}}
            />
        );

        const lInput = lCheckbox.find({ type: 'checkbox' });
        expect(lInput.prop('id')).toEqual('myCheckbox');
        expect(lInput.props().checked).toEqual(true);
        expect(lInput.prop('aria-checked')).toEqual(true);
        expect(lInput.props().disabled).toEqual(false);
    });

    /**
     * Render an checked unactive Checkbox
     */
    it('Render an checked unactive Checkbox', () => {
        const lCheckbox = enzyme.shallow(
            <Checkbox
                id="myCheckbox" 
                label="Checkbox" 
                isChecked={true}
                isDisabled={true}
                handleCheckboxChange={() => {}}
            />
        );

        const lInput = lCheckbox.find({ type: 'checkbox' });
        expect(lInput.prop('id')).toEqual('myCheckbox');
        expect(lInput.props().checked).toEqual(true);
        expect(lInput.prop('aria-checked')).toEqual(true);
        expect(lInput.props().disabled).toEqual(true);
    });

    /**
     * Render an unchecked active Checkbox
     */
    it('Render an unchecked active Checkbox', () => {
        const lCheckbox = enzyme.shallow(
            <Checkbox
                id="myCheckbox" 
                label="Checkbox" 
                isChecked={false}
                handleCheckboxChange={() => {}}
            />
        );
        
        const lInput = lCheckbox.find({ type: 'checkbox' });
        expect(lInput.prop('id')).toEqual('myCheckbox');
        expect(lInput.props().checked).toEqual(false);
        expect(lInput.prop('aria-checked')).toEqual(false);
        expect(lInput.props().disabled).toEqual(false);
    });

    /**
     * Render an unchecked unactive Checkbox
     */
    it('Render an unchecked active Checkbox', () => {
        const lCheckbox = enzyme.shallow(
            <Checkbox
                id="myCheckbox" 
                label="Checkbox" 
                isChecked={false}
                isDisabled={true}
                handleCheckboxChange={() => {}}
            />
        );
        
        const lInput = lCheckbox.find({ type: 'checkbox' });
        expect(lInput.prop('id')).toEqual('myCheckbox');
        expect(lInput.props().checked).toEqual(false);
        expect(lInput.prop('aria-checked')).toEqual(false);
        expect(lInput.props().disabled).toEqual(true);
    });
});