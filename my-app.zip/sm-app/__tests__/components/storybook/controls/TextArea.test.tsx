/**
 * TestArea test component
 */
import * as enzyme from 'enzyme';
import * as React from 'react';
import { Textarea } from '../../../../src/components/storybook/text/Textarea';

describe('Textarea component', () => {

    /**
     * Render a default Textarea component
     */
    it('Render a Textarea component', () => {
        const ltextarea = enzyme.shallow(
            <Textarea
                label="myTextarea" 
                id="Textarea"
                handleChange={() => {}}
            />
        );

        const lInput = ltextarea.find({ id: 'Textarea' });
        expect(lInput.prop('disabled')).toEqual(false);
        expect(lInput.prop('cols')).toEqual(20);
        expect(lInput.prop('rows')).toEqual(4);
    });
});