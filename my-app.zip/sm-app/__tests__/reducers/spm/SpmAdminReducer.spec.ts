import * as types from '../../../src/store/actions/spm/SpmActionsTypes';
import SpmAdminReducer from '../../../src/store/reducers/spm/SpmAdminReducer';
import * as modelsStub from '../../stubs/SpmAdminStub';

function setupState(options: any = {}) {
  const defaultState = {
    exception: null,
    icaos: [],
    icaosLoaded: false
  };

  for (const option in options) {
    if (option in defaultState) {
      defaultState[option] = options[option];
    }
  }

  return defaultState;
}

describe('Spm admin reducer', () => {
  it('should return the initial state', () => {
    expect(SpmAdminReducer(undefined, {})).toEqual(setupState());
  });

  it('should handle LOADAIRLINESSUCCESS', () => {
    expect(
      SpmAdminReducer(setupState(), {
        icaos: modelsStub.models1,
        type: types.LOADAIRLINESSUCCESS
      })
    ).toEqual(
      setupState({
        icaos: modelsStub.models1,
        icaosLoaded: true,
        type: types.LOADAIRLINESSUCCESS
      })
    );
  });

  it('should handle LOADAIRLINESERROR', () => {
    expect(
      SpmAdminReducer(setupState(), {
        exception: {
          exception: 'exception'
        },
        type: types.LOADAIRLINESERROR
      })
    ).toEqual(
      setupState({
        exception: {
          exception: 'exception'
        },
        icaosLoaded: true,
        type: types.LOADAIRLINESSUCCESS
      })
    );
  });
});
