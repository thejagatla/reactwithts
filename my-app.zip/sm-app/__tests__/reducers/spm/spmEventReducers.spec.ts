import * as types from '../../../src/store/actions/spm/SpmActionsTypes';
import SpmEventReducers from '../../../src/store/reducers/spm/SpmEventReducers';
import * as chartData from '../../stubs/SpmChartDataStub';
import * as commentStub from '../../stubs/SpmCommentStub';
import * as eventStub from '../../stubs/SpmDataStub';
import * as historyStub from '../../stubs/SpmStatusHistoryStub';

function setupState(options: any = {}) {
  const defaultState = {
    chart: [],
    chartLoaded: false,
    chartLoadingError: false,
    chartLoadingErrorCode: null,
    commentsHistory: [],
    description: null,
    event: {},
    eventDetailsDisplay: {},
    eventId: null,
    eventItems: [],
    eventLoaded: false,
    eventLoadingError: false,
    eventLoadingErrorCode: null,
    lastEventItemLoadingError: false,
    loadChartException: {},
    loadEventException: {},
    maintenanceAdvices: null,
    statusHistory: []
  };

  for (const option in options) {
    if (option in defaultState) {
      defaultState[option] = options[option];
    }
  }

  return defaultState;
}

describe('event reducers', () => {
  it('should return the initial state', () => {
    expect(SpmEventReducers(undefined, {})).toEqual(setupState());
  });

  it('should handle LOADEVENTSUCCESS', () => {
    expect(
      SpmEventReducers(
        setupState(),
        {
          event: {
            commentsHistory: commentStub.SpmCommentHistory1,
            description: null,
            event: eventStub.spmEvent1,
            eventDetailsDisplay: {},
            maintenanceAdvices: null,
            statusHistory: historyStub.SpmStatusHistory1,
          },
          type: types.LOADEVENTSUCCESS,
        })
    ).toEqual(
      setupState({
        commentsHistory: commentStub.SpmCommentHistory1,
        event: eventStub.spmEvent1,
        eventDetailsDisplay: {},
        eventLoaded: true,
        statusHistory: historyStub.SpmStatusHistory1
      })
      );
  });

  it('should handle LOADEVENTERROR', () => {
    expect(
      SpmEventReducers(
        setupState(),
        {
          code: 123,
          exception: {
            exception : {}
          },
          type: types.LOADEVENTERROR,
        })
    ).toEqual(
      setupState({
        eventLoaded: true,
        eventLoadingError: true,
        eventLoadingErrorCode: 123,
      })
      );
  });

  it('should handle LOADCHARTSUCCESS', () => {
    expect(
      SpmEventReducers(
        setupState(),
        {
          chart: chartData.spmChart1,
          type: types.LOADCHARTSUCCESS,
        })
    ).toEqual(
      setupState(
        {
          chart: chartData.spmChart1,
          chartLoaded: true
        }
      )
      );
  });

  it('should handle LOADCHARTERROR', () => {
    expect(
      SpmEventReducers(
        setupState(),
        {
          code: 123,
          exception: {
            exception : {}
          },
          type: types.LOADCHARTERROR,
        })
    ).toEqual(
      setupState(
        {
          chartLoaded: true,
          chartLoadingError: true,
          chartLoadingErrorCode: 123
        }
      )
      );
  });

  it('should handle LOADEVENTITEMSUCCESS', () => {
    expect(
      SpmEventReducers(
        setupState(),
        {
          eventItem: { eventItem: 'eventItem' },
          type: types.LOADEVENTITEMSUCCESS,
        })
    ).toEqual(
      setupState({
        eventItems: [
          { eventItem: 'eventItem' }
        ]
      })
      );
  });

  it('should handle LOADEVENTITEMSUCCESS and add item on list', () => {
    expect(
      SpmEventReducers(
        setupState({
          eventItems: [
            { eventItem: 'eventItem' }
          ]
        }),
        {
          eventItem: { eventItem2: 'eventItem2' },
          type: types.LOADEVENTITEMSUCCESS,
        })
    ).toEqual(
      setupState({
        eventItems: [
          { eventItem: 'eventItem' },
          { eventItem2: 'eventItem2' }
        ]
      })
      );
  });
});
