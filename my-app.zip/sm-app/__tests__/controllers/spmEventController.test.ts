/**
 * spmEventsController test class
 */
import * as enzyme from 'enzyme';
import * as React from 'react';

import { SpmEventController } from '../../src/controllers/SpmEventController';

const mockResponse = (status, statusText, response) => {
  return new window.Response(response, {
    status,
    statusText,
    headers: {
      'Content-type': 'application/json'
    }
  });
};

describe('spmEventController component', () => {
  it('Test getEventById with success response', () => {
    window.fetch = jest.fn().mockImplementation(() =>
      Promise.resolve(mockResponse(200, null, '{"event": "event"}')));
    
    expect(SpmEventController.getEventById('id', 'token'))
      .toEqual(Promise.resolve(mockResponse(200, null, '{"event": "event"}')));
  });

  it('Test getEventById with error response', () => {
    window.fetch = jest.fn().mockImplementation(() =>
      Promise.reject(mockResponse(500, null, '')));
    
    expect(SpmEventController.getEventById('id', 'token'))
      .toEqual(Promise.resolve(mockResponse(500, null, '')));
  });

  it('Test getEventItemByEventId with success response', () => {
    window.fetch = jest.fn().mockImplementation(() =>
      Promise.resolve(mockResponse(200, null, '{"eventItem": "eventItem"}')));
    
    expect(
      SpmEventController.getEventItemByEventId('AF23ZZ', 'date', 'token'))
        .toEqual(Promise.resolve(mockResponse(200, null, '{"eventItem": "eventItem"}'))
    );
  });

  it('Test getEventItemByEventId with error response', () => {
    window.fetch = jest.fn().mockImplementation(() =>
      Promise.reject(mockResponse(500, null, '')));
    
    expect(
      SpmEventController.getEventItemByEventId('AF23ZZ', 'date', 'token'))
        .toEqual(Promise.resolve(mockResponse(500, null, ''))
    );
  });

  it('Test getChartByEventId with success response', () => {
    window.fetch = jest.fn().mockImplementation(() =>
      Promise.resolve(mockResponse(200, null, '{"chart": "chart"}')));
    
    expect(
      SpmEventController.getChartByEventId('id', 'token'))
        .toEqual(Promise.resolve(mockResponse(200, null, '{"chart": "chart"}'))
    );
  });

  it('Test getChartByEventId with error response', () => {
    window.fetch = jest.fn().mockImplementation(() =>
      Promise.reject(mockResponse(500, null, '')));
    
    expect(
      SpmEventController.getChartByEventId('id', 'token'))
        .toEqual(Promise.resolve(mockResponse(500, null, ''))
    );
  });
});
