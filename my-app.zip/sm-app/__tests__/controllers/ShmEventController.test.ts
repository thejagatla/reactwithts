/**
 * EventsController test class
 */
import * as enzyme from 'enzyme';
import * as React from 'react';
import { fetch } from 'whatwg-fetch';

import { ShmEventController } from '../../src/controllers/ShmEventController';

describe('ShmEventController component', () => {
  /**
   * Test getCorrelatedEventsHashKeys method
   */
  it('Test getCorrelatedEventsHashKeys', () => {
    expect(
      ShmEventController.getCorrelatedEventsHashKeys('token', '', '')
    ).toEqual(Promise.resolve('{}'));
  });
});
