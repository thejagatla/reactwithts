/**
 * EventsController test class
 */
import * as enzyme from 'enzyme';
import * as React from 'react';
import { fetch } from 'whatwg-fetch';
import * as fleetsweepfilters from '../../src/resources/fleetsweepFilters.json';

import { EventsController } from '../../src/controllers/EventsController';

const filters = fleetsweepfilters.tabs[0].filters;
 
describe('EventsController component', () => {
/**
 * Test fetchEvents method
 */
  it('Test fetchEvents', () => {
    expect(EventsController.fetchEvents('token', 0, 60, '', filters, -1, 'DATE_TIME'))
      .toEqual(Promise.resolve('{}'));
  });
});
