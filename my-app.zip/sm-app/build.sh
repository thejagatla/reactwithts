#!/bin/sh
# build script called by pipeline

echo ============= starting $0
# exit script as soon as any command fails:
set -e

 # cleanup previous builds
rm -rf build target

if [ "$FROM_LOCAL" = 'true' ]
then
	echo 'Local build'
	time yarn
	node_modules/.bin/grunt build
	time yarn verify || echo "WARNING on SonarQube analysis. The verification phase is disabled as the current version that doesn't pass verification"
	time mvn -B -e clean package
else
	# switch to work directory (avoid jenkins home to accelerate builds)
	SRC=$(pwd)
	mkdir -p $WORK_PATH
	cp -R * $WORK_PATH
	cd $WORK_PATH

	# prepare npm configuration for publishing
	echo '@sm:registry=http://'$NPM_REGISTRY'/nexus/repository/sm-npm-registry/' > ~/.npmrc
	echo '//'$NPM_REGISTRY'/nexus/repository/sm-npm-registry/:_authToken='$NPM_TOKEN >> ~/.npmrc
	time yarn version --new-version $NPM_VERSION --no-git-tag-version
	time yarn
	node_modules/.bin/grunt build
	time yarn verify || echo "WARNING on SonarQube analysis. The verification phase is disabled as the current version that doesn't pass verification"
	time yarn publish --verbose --no-git-tag-version --new-version $NPM_VERSION
	time mvn versions:set -DnewVersion=$VERSION
	time mvn -B -e clean deploy

	# go back to original source folder (needed as long as deployment are based on source directories)
	mv build $SRC
	cd $SRC
fi
