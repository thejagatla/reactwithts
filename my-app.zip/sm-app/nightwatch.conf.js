const debug = require('debug')('tests:config');
const npmConfig = require('./package.json');

const cucumberArgs = [
  '--require',
  'tests/support/hooks.js',
  '--require',
  'tests/step_definitions',
  //'--format', 'progress',
  '--format',
  'json:reports/cucumber.json',
  'tests/features'
];

let tags = '';
// use Cucumber tags notation : https://docs.cucumber.io/tag-expressions/
if (process.env.TAGS) {
  tags =
    '(' +
    process.env.TAGS
      .split(',')
      .join(' or ')
      .replace('~', 'not ') +
    ') and ';
}
// @WIP tags
if (!tags.includes('@WIP') && !tags.includes('@NOREG')) tags += ' not @WIP and not @NOREG and ';
// @Ignore tags
tags += ' not @Ignore';

// apply tags arguments
cucumberArgs.splice(cucumberArgs.length - 1, 0, '--tags');
cucumberArgs.splice(cucumberArgs.length - 1, 0, tags);
console.log('Executed Tags : ' + tags);

debug(cucumberArgs);
require('nightwatch-cucumber')({ cucumberArgs });

let nightwatchConf = {
  // do not define those with nightwatch-cucumber
  //src_folders : ['tests/scenarios'],
  output_folder: 'reports',
  custom_commands_path: 'tests/commands',
  custom_assertions_path: 'tests/assertions',
  page_objects_path: 'tests/page_objects',
  use_xpath: false,

  selenium: {
    start_process: false,
    server_path:
      'node_modules/selenium-server/lib/runner/selenium-server-standalone-' +
      npmConfig.devDependencies['selenium-server'].replace('^', '') +
      '.jar',
    log_path: '.',
    selenium_host: 'localhost',
    port: 4444,
    cli_args: {
      'webdriver.gecko.driver': './node_modules/.bin/geckodriver.cmd',
      'webdriver.chrome.driver': './node_modules/.bin/chromedriver.cmd'
    }
  },
  test_workers: {
    enabled: process.env.PARALLEL_NB_UNITS ? true : false,
    workers: process.env.PARALLEL_NB_UNITS || 2
  },
  test_settings: {
    default: {
      launch_url: 'about:blank',
      silent: true,
      end_session_on_fail: true,
      skip_testcases_on_fail: true,
      request_timeout_options: (process.env.DEFAULT_TIMEOUT || 20) * 1000,
      desiredCapabilities: {
        browserName: 'firefox',
        javascriptEnabled: true,
        acceptSslCerts: true,
        marionette: true
      },
      screenshots: {
        enabled: true,
        on_error: true,
        on_failure: true,
        path: './screenshots'
      },
      globals: {
        launchChrome: false
      }
    },
    chrome: {
      disable_colors: true,
      desiredCapabilities: {
        browserName: 'chrome',
        javascriptEnabled: true,
        acceptSslCerts: true
      }
    },
    localchrome: {
      desiredCapabilities: {
        browserName: 'chrome'
      },
      // standalone chromedriver
      selenium_port: 9515,
      selenium_host: 'localhost',
      default_path_prefix: '',
      globals: {
        launchChrome: true
      }
    },
    firefox: {
      desiredCapabilities: {
        browserName: 'firefox'
      }
    },
    localfirefox: {
      desiredCapabilities: {
        browserName: 'firefox'
      }
    }
  }
};

let env = 'default';
for (let i = 0; i < process.argv.length; i++) {
  if (process.argv[i] == '--env') {
    env = process.argv[i + 1];
  }
}
if (env == 'localfirefox') {
  nightwatchConf.selenium.start_process = true;
} else if (env == 'localchrome') {
  nightwatchConf.globals_path = 'tests/globals/chromedriver.js';
} else if (env != 'default') {
  // remote selenium server
  nightwatchConf.test_settings.default.selenium_host =
    process.env.SELENIUM_HOST || 'your_remote_selenium_server';
  nightwatchConf.test_settings.default.selenium_port =
    process.env.SELENIUM_PORT || 4444;
}

debug(nightwatchConf);

module.exports = nightwatchConf;
