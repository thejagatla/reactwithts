/**
 * Class description: App entry point
 * @author Capgemini
 * @version 1.0
 */
import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import { PersistGate } from 'redux-persist/integration/react';
import { persistor, store } from './store/configureStore';
import AppContainer from './store/containers/AppContainer';
import './style/css/style.min.css';

ReactDOM.render(
  <Provider store={store}>
    <PersistGate loading={null} persistor={persistor}>
      <BrowserRouter>
        <AppContainer />
      </BrowserRouter>
    </PersistGate>
  </Provider>,
  document.getElementById('root') as HTMLElement
);
