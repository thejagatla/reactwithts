/**
 * File description: Declaration of constants related to the app.
 * @author Capgemini
 * @version 1.0
 */
export const POLLING_DELAY = 30000;
