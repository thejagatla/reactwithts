/**
 * File description: Declaration of interfaces related to the fleet sweep filters.
 * @author Capgemini
 * @version 1.0
 */
export interface FleetsweepFilterValue {
  value: string;
  active: boolean;
}

export interface FleetsweepFilter {
  title: string;
  type: string;
  values: FleetsweepFilterValue[];
}

export interface FleetsweepTab {
  title: string;
  filters: FleetsweepFilter[];
}
