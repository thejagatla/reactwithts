/**
 * File description: Declaration of constants related to the fleet sweep filters.
 * @author Capgemini
 * @version 1.0
 */
export const FLEETSWEEP_TAB_PREFIX: string = 'tab-';

export enum FleetsweepTabsEnum {
    URGENT_3,
    URGENT_2,
    URGENT_1,
    PLANNED,
    TO_BE_MONITORED
}

export enum FleetsweepFilterTypeEnum {
    WORK_STATUS,
    EVENT_RANK,
    PRIORITY,
    OCCURRENCE,
    AIRCRAFT_TYPE
}

export enum FleetsweepFilterTypeESEnum {
    WORK_STATUS = 'workOrderStatus',
    EVENT_RANK = 'eventType',
    PRIORITY = 'priority',
    OCCURRENCE = 'occurrence',
    AIRCRAFT_TYPE = 'aircraftType'
}

export enum FleetsweepPriority {
    HIGH,
    MEDIUM,
    LOW,
    NONE,
    SPURIOUS
}

export enum FleetsweepPriorityEnum {
    HIGH = 'High',
    MEDIUM = 'Medium',
    LOW = 'Low',
    NONE = 'None',
    SPURIOUS = 'Spurious'
}

export enum FleetsweepEventRank {
    W,
    C1,
    C2,
    P,
    OR,
    SE,
    MTBUR,
    Lb
}

export enum FleetsweepEventRankEnum {
    W = 'Warning',
    C1 = 'Class 1 Fault Message',
    C2 = 'Class 2 Fault Message',
    P = 'Predictive',
    OR = 'Reliability OR',
    SE = 'Reliability SE',
    MTBUR = 'Reliability MTBUR',
    Lb = 'Reliability Logbook'
}
