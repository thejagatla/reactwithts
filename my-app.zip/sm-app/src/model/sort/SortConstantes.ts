/**
 * File description: Declaration of constants related to the sort event.
 * @author Capgemini
 * @version 1.0
 */

export enum SortValuesEnum {
  AC,
  ATA,
  DATE_TIME,
  PRIORITY
}
  
export enum SortValues {
  AC = 'A/C',
  ATA = 'ATA',
  DATE_TIME = 'Date & Time',
  PRIORITY = 'Priority'
}
