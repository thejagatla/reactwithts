export enum RoutesToPagename {
    '' = 'Cockpit',
    'login' = 'Login',
    'reset' = 'Reset password',
    'change_password' = 'Change password',
    'shm-event' = 'SHM Event details',
    'spm-event' = 'Predictive Event details',
    'admin' = 'SPM Admin',
    'trends' = 'SPM Trends'
}

export enum RoutesToMenuItem {
    '' = 'Alerting',
}

export const RoutesMenu = [
    { title: 'Alerting' }
];
