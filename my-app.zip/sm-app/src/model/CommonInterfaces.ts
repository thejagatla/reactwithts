/**
 * File description: Declaration of common interfaces
 * @author Capgemini
 * @version 1.0
 */

import { SkywiseICONS } from '../components/storybook';

export interface IconStatusProps {
  iconName: SkywiseICONS;
  className?: string;
}
