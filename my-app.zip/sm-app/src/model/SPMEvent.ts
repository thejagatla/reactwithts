import { WorkOrderStatus, WorkOrderStatusEnum } from './EventsConstantes';
import { OccurenceHistory } from './OccurenceHistory';

export interface SPMEvent {
  acMatricule: string;
  aircraftType: string;
  ata6: string;
  createdBy: string;
  eventClass: string;
  eventDate: string;
  flightCount: number;
  flightOccurrence: string[];
  hashKey: string;
  index: number;
  indexedDate: string;
  key: string;
  latest: boolean;
  msn: number;
  occurrenceCount: number;
  occurrenceHistory: OccurenceHistory[];
  operatorId: string;
  origin: string;
  priority: string;
  smEventDate: string;
  smUiEventDate: string;
  spmEventId: string;
  spmMaturity?: number;
  spmOccurrenceHistory?: SPMOccurenceHistory[];
  style: any;
  titleFromAircraft: string;
  type: string;
  uiWorkOrderStatus: string;
  workOrderStatus: string;
  workOrderStatusKey: string;
}

export interface SPMOccurenceHistory {
  flightDate?: string;
  isAlert?: boolean;
  isMissing?: boolean;
  updatedStatus?: WorkOrderStatusEnum;
}

export const SPMActions = {
  [WorkOrderStatus.IGNORED]: [
    'SPM_RESTORE'
  ],
  [WorkOrderStatus.OPENED]: [
    'SPM_PLAN_ACTION',
    'SPM_IGNORE'
  ],
  [WorkOrderStatus.PLANNED]: [
    'SPM_REGISTER_ACTION',
    'SPM_IGNORE'
  ],
  [WorkOrderStatus.TO_BE_MONITORED]: [
    'SPM_VALIDATE',
    'SPM_REJECT',
    'SPM_IGNORE',
  ],
  [WorkOrderStatus.TO_BE_REVIEWED]: [
    'SPM_WATCH',
    'SPM_PLAN_ACTION',
    'SPM_IGNORE'
  ],
  [WorkOrderStatus.CLOSED]: []
};
