export interface Comment {
  eventId: string;
  dateTime: string;
  author: string;
  text: string;
}
