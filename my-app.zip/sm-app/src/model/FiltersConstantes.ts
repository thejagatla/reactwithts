export enum FilterPeriods {
    HALF_DAY = '12 hours',
    DAY = '24 hours',
    TWO_DAYS = '48 hours',
    THREE_DAYS = '72 hours',
    WEEK = 'Last week',
}

export enum HoursByLabel {
    HALF_DAY = 12,
    DAY = 24,
    TWO_DAYS = 48,
    THREE_DAYS = 72,
    WEEK = 168,
}
