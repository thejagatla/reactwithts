import * as Strings from '../lang/strings.json';

/**
 * File description: Declaration of constants related to the aircraft event.
 * @author Capgemini
 * @version 1.0
 */

export enum WorkOrderStatusEnum {
  TO_BE_REVIEWED,
  OPENED,
  PLANNED,
  TO_BE_MONITORED,
  CLOSED,
  IGNORED
}

export enum WorkOrderStatus {
  TO_BE_REVIEWED = 'Review',
  OPENED = 'Opened',
  PLANNED = 'Planned',
  TO_BE_MONITORED = 'Monitor',
  CLOSED = 'Closed',
  NONE = 'None',
  IGNORED = 'Ignored'
}

export enum OccurrenceEnum {
  LAST,
  NOT_IN_LAST
}

export enum Occurrence {
  LAST = 'Last',
  NOT_IN_LAST = 'Not in last'
}

export const EventOrigin = {
  SHM: 'SHM',
  SPM: 'SPM',
  SRS: 'SRS'
};

export enum MessageTypeEnum {
  CmsSaFaultMessage,
  CmsSaPfr,
  CmsSaWarning,
  CmsLrFaultmessage,
  CmsLrWarning,
  CmsLrXfr
}

export enum MessageType {
  CmsSaFaultMessage = 'CFR',
  CmsSaPfr = 'PFR',
  CmsSaWarning = 'CFR',
  CmsLrFaultmessage = 'CFR',
  CmsLrWarning = 'CFR',
  CmsLrXfr = 'PFR'
}

export enum EventType {
  FAULT_MESSAGE,
  WARNING
}

export enum IgnoredWorkStatusReason {
  SPURIOUS,
  NO_ACTION,
  OTHER_REASON
}

export enum IgnoredWorkStatusReasonEnum {
  SPURIOUS = 'Spurious',
  NO_ACTION = 'No action',
  OTHER_REASON = 'Other reason'
}

export enum WorkflowAction {
  RESTORE,
  REGISTER_ACTION,
  PLAN_ACTION,
  LAUNCH_ACTION,
  IGNORE,
  EDIT,
  SPM_WATCH,
  SPM_PLAN_ACTION,
  SPM_REGISTER_ACTION,
  SPM_VALIDATE,
  SPM_REJECT,
  SPM_RESTORE,
  SPM_IGNORE
}

export enum WorkflowActionEnum {
  RESTORE = 'Restore',
  REGISTER_ACTION = 'Register action',
  PLAN_ACTION = 'Plan action',
  LAUNCH_ACTION = 'Launch action',
  IGNORE = 'Ignore',
  EDIT = 'Edit',
  SPM_WATCH = 'Watch',
  SPM_PLAN_ACTION = 'Plan action',
  SPM_REGISTER_ACTION = 'Register action',
  SPM_VALIDATE = 'Validate',
  SPM_REJECT = 'Reject',
  SPM_RESTORE = 'Restore',
  SPM_IGNORE = 'Ignore'
}

export enum StatusText {
  SUCCESS = 'success',
  FAIL = 'fail',
  ERROR = 'error'
}

export enum WorkflowPageOrigin {
  SHM = 'SHM',
  SPM = 'SPM',
  SRS = 'SRS'
}

export enum RiskPriority {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH'
}

export const PHASE_SEPARATOR = '_';

export const FLIGHT_OCCURRENCES = 15;

export const Months = {
  1: 'JAN',
  2: 'FEB',
  3: 'MAR',
  4: 'APR',
  5: 'MAY',
  6: 'JUN',
  7: 'JUL',
  8: 'AUG',
  9: 'SEP',
  10: 'OCT',
  11: 'NOV',
  12: 'DEC'
};

export const SpmWorkStatusMaxComment = 400;

export const ListInfoDisplayed = [
  'acMatricule',
  'flightNumber',
  'smEventDate',
  'isDateHighlighted',
  'isDateEventHighlighted',
  'workOrderStatus',
  'priority',
  'ata6',
  'sourceSystem',
  'dataSource',
  'viewMelLinks',
  'titleFromAircraft',
  'workOrderComment',
  'highlightedWorkOrderComment',
  'origin',
  'hashKey',
  'workOrderStatus',
  'workOrderReference',
  'workOrderIgnoredReason',
  'workOrderPlannedDate',
  'workOrderReference',
  'occurrenceHistory',
  'flightOccurrence'
];

export const EventListInfoDisplayed = {
  SHM: [
    {
      key: 'ata6',
      label: Strings.ataCellTitle
    },
    {
      key: 'sourceSystem',
      label: Strings.sourceCellTitle
    },
    {
      key: 'eventClass',
      label: Strings.classCellTitle
    },
    {
      key: 'lrfrType'
    }
  ],
  SPM: [
    {
      key: 'ata6',
      label: Strings.ataCellTitle
    },
    {
      key: 'dataSource',
      label: Strings.sourceCellTitle
    },
    {
      key: 'sourceSystem',
      label: Strings.sourceCellTitle
    }
  ],
  SRS: [
    {
      key: 'ata6',
      label: Strings.ataCellTitle
    },
    {
      key: 'partNumber',
      label: Strings.partNumberLabel
    }
  ]
};

export const EventTypeShortDisplay = {
  FAULT_MESSAGE: 'FAULT',
  Logbook: 'Logbook',
  MTBUR: 'MTBUR',
  OR: 'OR',
  PREDICTIVE: 'PRED',
  SE: 'SE',  
  WARNING: 'WARN'
};
