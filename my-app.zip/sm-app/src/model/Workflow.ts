/* SHM WORKFLOW
*********************************/
export const ShmActionsToOpened = {
  TO_BE_REVIEWED: 'EDIT'
};
export const ShmActionsToBeMonitored = {
  OPENED: 'EDIT',
  PLANNED: 'EDIT',
  TO_BE_REVIEWED: 'EDIT',
};
export const ShmActionsIgnored = {
  PLANNED: 'IGNORE',
  TO_BE_MONITORED: 'IGNORE',
  TO_BE_REVIEWED: 'IGNORE',
};

export const ShmActionsToPlanned = {
  OPENED: 'EDIT',
  TO_BE_REVIEWED: 'EDIT',
};

export const ShmStatusDone = {
  CLOSED: [
    'TO_BE_REVIEWED',
    'OPENED',
    'PLANNED',
    'TO_BE_MONITORED'
  ],
  IGNORED: [],
  OPENED: [
    'TO_BE_REVIEWED'
  ],
  PLANNED: [
    'TO_BE_REVIEWED',
    'OPENED'
  ],
  TO_BE_MONITORED: [
    'TO_BE_REVIEWED',
    'OPENED',
    'PLANNED'
  ],
  TO_BE_REVIEWED: [],
};

/* SPM WORKFLOW
*********************************/

export const SpmActionsToStatus = {
  SPM_IGNORE: 'IGNORED',
  SPM_PLAN_ACTION: 'PLANNED',
  SPM_REGISTER_ACTION: 'TO_BE_MONITORED',
  SPM_REJECT: 'OPENED',
  SPM_VALIDATE: 'CLOSED',
  SPM_WATCH: 'OPENED',
};

export const SpmActionsFrom = {
  CLOSED: {
    TO_BE_MONITORED: 'SPM_VALIDATE'
  },
  IGNORED: {},
  OPENED: {
    TO_BE_MONITORED: 'SPM_REJECT',
    TO_BE_REVIEWED: 'SPM_WATCH',
  },
  PLANNED: {
    OPENED: 'SPM_PLAN_ACTION',
    TO_BE_REVIEWED: 'SPM_PLAN_ACTION',
  },
  TO_BE_MONITORED: {
    PLANNED: 'SPM_REGISTER_ACTION'
  },
  TO_BE_REVIEWED: {},
};

export const SpmStatusDone = {
  CLOSED: [
    'TO_BE_REVIEWED',
    'OPENED',
    'PLANNED',
    'TO_BE_MONITORED'
  ],
  IGNORED: [],
  OPENED: [
    'TO_BE_REVIEWED'
  ],
  PLANNED: [
    'TO_BE_REVIEWED',
    'OPENED'
  ],
  TO_BE_MONITORED: [
    'TO_BE_REVIEWED',
    'OPENED',
    'PLANNED'
  ],
  TO_BE_REVIEWED: [],
};
