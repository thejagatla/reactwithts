import { WorkOrderStatus } from './EventsConstantes';

export interface SRSEvent {
  ataChapter: string;
  srsEventId: string;
  acMatricule: string;
  aircraftType: string;
  eventType: 'OR' | 'SE' | 'MTBUR' | 'LOGBOOK';
  msn: number;
  operatorId: string;
  titleFromAircraft: string;
  priority: string;
  origin: string;
  detailsHyperlink: string;
  srsAlertType: string;
  srsAlertComputationDate: string;
  srsAlertValue: number;
  srsAlertTargetValue: number;
  srsAlertTargetName: string;
  srsDetailsLink: string;
}

export interface SRSOccurenceHistory {
  level?: 'NO_DATA' | 'NO_ALERT' | 'HIGH' | 'MEDIUM' | 'LOW';
  month?: string;
  value?: string;
}

export const SRSActions = {
  [WorkOrderStatus.IGNORED]: [],
  [WorkOrderStatus.OPENED]: [],
  [WorkOrderStatus.PLANNED]: [],
  [WorkOrderStatus.TO_BE_MONITORED]: [],
  [WorkOrderStatus.TO_BE_REVIEWED]: [],
  [WorkOrderStatus.CLOSED]: []
};
