import { EventType, WorkOrderStatus } from './EventsConstantes';
import { OccurenceHistory } from './OccurenceHistory';

export interface SHMEvent {
  acEventId: number;
  acMatricule: string;
  aircraftType: string;
  ata6: string;
  correlationId: string;
  createdBy: string;
  eventAta: string;
  eventDate: string;
  eventType: EventType;
  fcid: number;
  flightCount: number;
  flightNumber: string;
  flightOccurrence: string[];
  flightPhase: string;
  hashKey: string;
  highlightedWorkOrderComment: string;
  index: number;
  indexedDate: string;
  isDateHighlighted: boolean;
  isDateEventHighlighted: boolean;
  isWorkOrderStatusHighlighted: boolean;
  key: string;
  latest: boolean;
  messageID: string;
  msn: number;
  occurrenceCount: number;
  occurrenceHistory: OccurenceHistory[];
  operatorId: string;
  origin: string;
  priority: string;
  smEventDate: string;
  smUiEventDate: string;
  sourceSystem: string;
  style: any;
  titleFromAircraft: string;
  type: string;
  uiWorkOrderReference: string;
  uiWorkOrderStatus: string;
  workOrderStatus: string;
  workOrderStatusKey: string;
  workOrderComment: string;
}

export const SHMActions = {
  [WorkOrderStatus.IGNORED]: [
    'EDIT'
  ],
  [WorkOrderStatus.OPENED]: [
    'EDIT',
    'IGNORE'
  ],
  [WorkOrderStatus.PLANNED]: [
    'EDIT',
    'IGNORE'
  ],
  [WorkOrderStatus.TO_BE_MONITORED]: [
    'EDIT',
    'IGNORE'
  ],
  [WorkOrderStatus.TO_BE_REVIEWED]: [
    'EDIT',
    'IGNORE'
  ],
  [WorkOrderStatus.CLOSED]: []
};

export const CockpitEventColumns = [
  'priority',
  'icon',
  'aircraft',
  'dateTime',
  'title',
  'oh',
  'workflow',
  'comment'
];

export const CorrelatedEventColumns = [
  'priority',
  'icon',
  'aircraft',
  'dateTime',
  'title',
  'oh'
];

export const EventDetailsEventColumns = [
  'aircraft',
  'title',
  'goNoGo',
  'workflow',
  'comment'
];
