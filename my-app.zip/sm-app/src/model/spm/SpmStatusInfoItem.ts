export interface SpmStatusInfoItem {
  airport: string;
  attachments: any[];
  author: string;
  comment: string;
  dateTime: string;
  deleted: boolean;
  eventId: string;
  fltBefore: string;
  possibleCause: string;
  status: string;
  workDatetime: string;
  workReference: string;
}
