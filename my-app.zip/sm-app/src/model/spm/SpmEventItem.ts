export interface SpmEventItem {
    eventId: string;
    eventItemId: string;
    family: string;
    flightNb: string;
    flightUid: number;
    from: string;
    fromDate: string;
    isAlert: boolean;
    isMissingItem: boolean;
    isMissingFlight: boolean;
    modelRef: string;
    parameters: any;
    tailNumber: string;
    threshold: number[];
    to: string;
    toDate: string;
    values: number[];
    xmsn: string;
    graphData: any[];
}
