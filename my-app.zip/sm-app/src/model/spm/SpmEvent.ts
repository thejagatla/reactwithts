import { SpmStatusInfoItem } from './SpmStatusInfoItem';

export interface SpmEvent {
    ataChapter: string;
    eventClosureTimestamp: string;
    eventCreationTimestamp: string;
    eventId: string;
    eventType: string;
    family: string;
    flightCount: number;
    lastFlightNb: string;
    occurenceCount: number;
    ohFlights: string[];
    ohOccurrences: string[];
    ohOpenDate: string;
    ohPlannedDate: string;
    ohToBeMonitoredDate: string;
    origin: string;
    riskName: string;
    riskPriority: string;
    statusInfoItem: SpmStatusInfoItem;
    tailNumber: string;
    xmsn: string;
}
