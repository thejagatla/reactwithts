export interface SpmEventDetailsDisplay {
    displayTitle: string;
    maxFlightsDisplayed: number;
    numFlightsVisible: number;
    ordinateLabel: string;
    thresholds: string[];
    eventType: string;
    values: string;
}
