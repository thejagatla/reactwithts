export interface SpmChartDetail {
  chartData?: {
    chartDataColors: {},
    chartDataColumns: any[],
    chartDataTypes: {},
  };
  chartThresholds: {
    areThresholdsDisplayed: boolean,
    thresholds: string[]
  };
  chartTitle: string;
  chartTooltip: {
    tooltipContent: React.ReactElement<any>,
    tooltipEnabled: boolean,
    tooltipHtmlId: string
  };
  series: any[];
  threshold: boolean;
  yAxisLabel: string;
}
