export interface FleetInfos {
    acFamily: string;
    aircrafts: string[];
    models: string[];
}
