/**
 * Interface for Occurence History
 */
export interface OccurenceHistory {
  /** SM event date which is the transmission date for SPM */
  d?: string;

  /** Phase in flight */
  p?: string;

  /** Message type: Cfr or Pfr */
  m?: 'C' | 'P';

  /** Flight number */
  f?: string;
}

export interface FlightOccurence {
  /** list of CFR dates */
  c?: string[];

  /** Flight number */
  f?: string;

  /** PFR date */
  p?: string;

}

export const months = ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'];
