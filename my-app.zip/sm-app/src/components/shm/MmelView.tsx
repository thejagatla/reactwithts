import { DSFlag } from '@sm/skywise-react-library';
import * as React from 'react';

/**
 * Class description: Mmel Cell rendering component
 * @author Capgemini
 * @version 1.0
 */
export const MmelView: React.SFC = (props) => {
  return (
    <div className="event-mmel">
      <DSFlag title="MEL" />
    </div>
  );
};

MmelView.displayName = 'MmelView';
