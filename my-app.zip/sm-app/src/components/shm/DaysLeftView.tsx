import * as React from 'react';
import * as Strings from '../../lang/strings.json';

interface DaysLeftViewProps {
  workOrderPlannedDate: any;
}

/**
 * Class description: Days left cell rendering component
 * @author Capgemini
 * @version 1.0
 */
export const DaysLeftView: React.SFC<DaysLeftViewProps> = (props: DaysLeftViewProps) => {
  const { workOrderPlannedDate } = props;
  let daysLeft = -1;
  const today: number = new Date().setHours(13, 0, 0, 0);
  const lWorkOrderPlannedDate: number = new Date(workOrderPlannedDate).setHours(13, 0, 0, 0);
  daysLeft = Math.floor((lWorkOrderPlannedDate - today) / (24 * 3600 * 1000));

  return (
    <React.Fragment>
      {daysLeft !== -1 &&
        <div className="event-days-left">
          {daysLeft} {Strings.daysLeft}
        </div>
      }
    </React.Fragment>
  );
};

DaysLeftView.displayName = 'DaysLeftView';
