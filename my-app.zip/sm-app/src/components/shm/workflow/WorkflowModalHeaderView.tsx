import { DSGridColumn, DSGridRow, DSList } from '@sm/skywise-react-library';
import * as React from 'react';
import * as Strings from '../../../lang/strings.json';
import { stripTags } from '../../../utils/RenderUtils';
import { LabelAndInfoView } from '../../common/events/cells/LabelAndInfoView';
import { MmelView } from '../MmelView';

interface WorkflowModalHeaderViewProps {
  ata?: string;
  source?: string;
  viewMelLinks?: string;
  acMatricule?: string;
  acNickName?: string;
  msn?: string;
  titleFromAircraft?: string;
  displayName?: string;
}

/**
 * Class description: Header component of the workflow modal.
 * @author Capgemini
 * @version 1.0
 */
export const WorkflowModalHeaderView: React.SFC<
  WorkflowModalHeaderViewProps
> = (props: WorkflowModalHeaderViewProps) => {
  let nameToDisplay = 'acMatricule';

  const list: JSX.Element[] = [];
  if (props.ata != null && props.ata.length > 0) {
    list.push(
      <LabelAndInfoView
        className="event-shortinfo__ata"
        label={Strings.ataCellTitle}
        value={stripTags(props.ata)}
      />
    );
  }

  if (props.source != null && props.source.length > 0) {
    list.push(
      <LabelAndInfoView
        className="event-shortinfo__source"
        label={Strings.sourceCellTitle}
        value={stripTags(props.source)}
      />
    );
  }

  if (props.viewMelLinks) {
    list.push(<MmelView />);
  }

  if (props.displayName && props[props.displayName]) {
    nameToDisplay = props.displayName;
  }

  return (
    <DSGridRow>
      <DSGridColumn width={8}>
        <span id="event-shortinfo__aircraft">
          {stripTags(props[nameToDisplay])}
        </span>
      </DSGridColumn>
      <DSGridColumn width={40}>
        <DSList
          direction="horizontal"
          list={list}
          className="event-flight-information"
        />
        <div className="full-width-block event-shortinfo__title">
          {stripTags(props.titleFromAircraft)}
        </div>
      </DSGridColumn>
    </DSGridRow>
  );
};

WorkflowModalHeaderView.displayName = 'WorkflowModalHeaderView';
