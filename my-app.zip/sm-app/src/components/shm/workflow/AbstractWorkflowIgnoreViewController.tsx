import {
  DSButton,
  DSGridColumn,
  DSGridRow,
  DSModal
} from '@sm/skywise-react-library';
import * as React from 'react';
import * as Strings from '../../../lang/strings.json';
import {
  IgnoredWorkStatusReason,
  WorkflowAction,
  WorkOrderStatusEnum
} from '../../../model/EventsConstantes';
import { WorkflowModalHeaderView } from './WorkflowModalHeaderView';
import { WorkflowModalIgnoreActionView } from './WorkflowModalIgnoreActionView';
import { WorkflowModalSteppersController } from './workflowModalSteppers/WorkflowModalSteppersController';

export interface WorkflowModalIgnoreProps
  extends React.Props<AbstractWorkflowModalIgnoreViewController> {
  event: any;
  closeModal(pTimer: number): void;
  setWorkOrderStatus(
    pWorkOrderStatus: string,
    pUsername: string,
    pWorkOrderReference?: string,
    pWorkOrderComment?: string,
    pWorkOrderIgnoredReason?: string,
    pFormattedDate?: string
  ): void;
  displayName: string;
}

interface WorkflowModalIgnoreState {
  formErrors: any;
  isSubmitDisabled: boolean;
  workOrderComment: string;
  workOrderIgnoredReason: string;
  workOrderOldStatus: string;
  workOrderPlannedDate: string;
  workOrderReference: string;
  workOrderStatus: string;
}

/**
 * Class description: Workflow modal controller, Ignore action
 * @author Capgemini
 * @version 1.0
 */
export abstract class AbstractWorkflowModalIgnoreViewController extends React.Component<
  WorkflowModalIgnoreProps,
  WorkflowModalIgnoreState
> {
  protected modalLabelTitle = '';
  protected modalClearLabel = '';

  /**
   * Controller
   * @param props React props
   */
  constructor(props: WorkflowModalIgnoreProps) {
    super(props);

    this.state = {
      formErrors: {},
      isSubmitDisabled: true,
      workOrderComment: this.props.event.workOrderComment
        ? this.props.event.workOrderComment
        : '',
      workOrderIgnoredReason: this.props.event.workOrderIgnoredReason
        ? this.props.event.workOrderIgnoredReason
        : '',
      workOrderOldStatus: this.props.event.workOrderStatus,
      workOrderPlannedDate: this.props.event.workOrderPlannedDate
        ? this.props.event.workOrderPlannedDate
        : '',
      workOrderReference: this.props.event.workOrderReference
        ? this.props.event.workOrderReference
        : '',
      workOrderStatus: this.props.event.workOrderStatus
    };

    this.handleCommentChange = this.handleCommentChange.bind(this);
    this.handleIgnoredReasonChange = this.handleIgnoredReasonChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.clearForm = this.clearForm.bind(this);
  }

  /**
   * Clear form
   */
  protected abstract clearForm();

  /**
   * Handle change on comment field
   * @param pEvent the event throwed
   */
  protected abstract handleCommentChange(pEvent: any);

  /**
   * Handle ignored reason field and check that reason isn't empty when "Other reason" is selected.
   * @param selectedReason
   */
  protected handleIgnoredReasonChange(pEvent: any) {
    pEvent.stopPropagation();

    const lFieldValidationErrors = this.state.formErrors;
    let lNewWorkOrderStatus = this.state.workOrderOldStatus;

    // si other reason et comment vide
    if (
      pEvent.currentTarget.value ===
        IgnoredWorkStatusReason[IgnoredWorkStatusReason.OTHER_REASON] &&
      this.state.workOrderComment === ''
    ) {
      lFieldValidationErrors.comment = Strings.workflowModalIgnoreCommentError;
    } else {
      lNewWorkOrderStatus = WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED];
      delete lFieldValidationErrors.comment;
    }

    this.setState({
      formErrors: lFieldValidationErrors,
      isSubmitDisabled: this.checkIgnoreAction(
        pEvent.currentTarget.value,
        this.state.workOrderComment,
        lNewWorkOrderStatus
      ),
      workOrderIgnoredReason: pEvent.currentTarget.value,
      workOrderStatus: lNewWorkOrderStatus
    });
  }

  /**
   * Handle form submission
   * @param event Submit event
   */
  protected abstract handleSubmit(event: any);

  protected stripTags(str: string) {
    const goodStr = str.toString();
    return goodStr.replace(/<\/?[^>]+>/gi, '');
  }

  /**
   * Check ignore action to enable/disable apply button
   */
  protected checkIgnoreAction(
    pWorkOrderReason: string,
    pWorkOrderComment: string,
    pWorkOrderStatus: string
  ) {
    if (
      pWorkOrderStatus ===
      WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]
    ) {
      return false;
    }
    // Check comment : comment mandatory for other reason option
    if (pWorkOrderReason.length !== 0) {
      if (
        pWorkOrderReason !== 'OTHER_REASON' ||
        pWorkOrderComment.length !== 0
      ) {
        return false;
      }
    }
    return true;
  }

  protected renderInHTML(value: string) {
    return <span dangerouslySetInnerHTML={{ __html: value }} />;
  }

  // modal header components
  protected getModalHeader(): any {
    return (
      <WorkflowModalHeaderView
        ata={
          this.props.event.ata6
            ? this.props.event.ata6
            : this.props.event.ataChapter
        }
        source={this.props.event.sourceSystem}
        titleFromAircraft={
          this.props.event.titleFromAircraft
            ? this.props.event.titleFromAircraft
            : this.props.event.riskName
        }
        acMatricule={
          this.props.event.acMatricule
            ? this.props.event.acMatricule
            : this.props.event.tailNumber
        }
        acNickName={
          this.props.event.acNickName
            ? this.props.event.acNickName
            : this.props.event.tailNumber
        }
        msn={
          this.props.event.msn
            ? this.props.event.msn
            : this.props.event.tailNumber
        }
        displayName={
          this.props.displayName ? this.props.displayName : 'acMatricule'
        }
      />
    );
  }

  // modal content components
  protected getModalContent(): any {
    return (
      <DSGridRow>
        <DSGridColumn width={20} className="workflow-steppers-container">
          <WorkflowModalSteppersController
            currentStep={this.state.workOrderStatus}
            previousStep={this.state.workOrderOldStatus}
            action={WorkflowAction[WorkflowAction.IGNORE]}
          />
        </DSGridColumn>
        <DSGridColumn width={28}>
          <WorkflowModalIgnoreActionView
            handleCommentChange={this.handleCommentChange}
            handleIgnoredReasonChange={this.handleIgnoredReasonChange}
            workOrderIgnoredReason={this.state.workOrderIgnoredReason}
            workOrderComment={this.state.workOrderComment}
            clearForm={this.clearForm}
            clearLabel={this.modalClearLabel}
          />
        </DSGridColumn>
      </DSGridRow>
    );
  }

  // modal footer components
  protected getModalFooter(): any {
    return (
      <div>
        <DSButton content="Cancel" handleClick={this.props.closeModal} />
        <DSButton
          type="primary"
          content="Apply"
          isSubmit={true}
          disabled={this.state.isSubmitDisabled}
          handleClick={() => null}
        />
      </div>
    );
  }
  /**
   * Rendering method
   */
  public render() {
    return (
      <DSModal
        className={'workflow-modal'}
        modalTitle={this.modalLabelTitle}
        withHeaderIntro={true}
        withForm={true}
        withFooterBackground={true}
        onSubmit={this.handleSubmit}
        onRequestClose={this.props.closeModal}
        modalHeaderIntro={this.getModalHeader()}
        modalContent={this.getModalContent()}
        modalFooter={this.getModalFooter()}
      />
    );
  }
}
