import * as Strings from '../../../lang/strings.json';
import {
  IgnoredWorkStatusReason,
  WorkOrderStatusEnum
} from '../../../model/EventsConstantes';
import { getUsername } from '../../../utils/AuthenticationUtils';
import {
  AbstractWorkflowModalIgnoreViewController,
  WorkflowModalIgnoreProps
} from './AbstractWorkflowIgnoreViewController';

/**
 * Class description: Workflow modal controller, Ignore action
 * @author Capgemini
 * @version 1.0
 */
export class WorkflowModalIgnoreViewController extends AbstractWorkflowModalIgnoreViewController {
  /**
   * Controller
   * @param props React props
   */
  constructor(props: WorkflowModalIgnoreProps) {
    super(props);
    this.modalLabelTitle = Strings.ignore;
    this.modalClearLabel = Strings.workflowIgnoreClearAll;
  }

  /**
   * Handle change on comment field
   * @param pEvent the event throwed
   */
  protected handleCommentChange(pEvent: any) {
    const lCommentValue = pEvent.target.value;
    let lWorkOrderStatus = '';

    this.setState({
      workOrderComment: lCommentValue
    });

    // Compute work order status
    switch (this.state.workOrderIgnoredReason) {
      case IgnoredWorkStatusReason[IgnoredWorkStatusReason.OTHER_REASON]:
        if (lCommentValue.length === 0) {
          lWorkOrderStatus = this.state.workOrderOldStatus;
        } else {
          lWorkOrderStatus = WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED];
        }
        break;
      case IgnoredWorkStatusReason[IgnoredWorkStatusReason.SPURIOUS]:
      case IgnoredWorkStatusReason[IgnoredWorkStatusReason.NO_ACTION]:
        lWorkOrderStatus = WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED];
        break;
      default:
        lWorkOrderStatus = this.state.workOrderOldStatus;
    }

    // disable submit if necessary
    this.setState({
      isSubmitDisabled: this.checkIgnoreAction(
        this.state.workOrderIgnoredReason,
        lCommentValue,
        lWorkOrderStatus
      ),
      workOrderStatus: lWorkOrderStatus
    });
  }

  /**
   * Handle form submission
   * @param event Submit event
   */
  protected handleSubmit(event: any) {
    event.preventDefault();

    let lFormattedDate = '';
    if (this.state.workOrderPlannedDate !== '') {
      lFormattedDate = new Date(this.state.workOrderPlannedDate).toISOString();
    }

    this.props.setWorkOrderStatus(
      this.state.workOrderStatus,
      getUsername(),
      this.state.workOrderReference,
      this.state.workOrderComment,
      this.state.workOrderIgnoredReason,
      lFormattedDate
    );
  }

  /**
   * Clear form
   */
  protected clearForm() {
    this.setState({
      isSubmitDisabled: true,
      workOrderComment: '',
      workOrderIgnoredReason: '',
      workOrderStatus: this.props.event.workOrderStatus
    });
  }
}
