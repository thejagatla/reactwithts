import * as React from 'react';
import * as Strings from '../../../lang/strings.json';
import { IgnoredWorkStatusReason, IgnoredWorkStatusReasonEnum } from '../../../model/EventsConstantes';
import { DSRadio } from '../../storybook/controls/DSRadio';
import { Textarea } from '../../storybook/text/Textarea';

interface WorkflowModalIgnoreActionViewProps {
  clearForm(): void;
  clearLabel: string;
  handleCommentChange(pEvent: any): void;
  handleIgnoredReasonChange(pEvent: any): void;
  workOrderComment: string;
  workOrderIgnoredReason: string;
}

/**
 * Class description: Workflow modal rendering component for Ignore action
 * @author Capgemini
 * @version 1.0
 */
export const WorkflowModalIgnoreActionView: React.SFC<WorkflowModalIgnoreActionViewProps> =
(props: WorkflowModalIgnoreActionViewProps) => {
  return (
    <div id="ignore-action-form">
      <a className="clear-form" onClick={props.clearForm}>
        {props.clearLabel}
            </a>
      <div className="ds-form-group">
        <label>{Strings.workflowModalSelectReasonLabel}</label>
        <DSRadio
          value={IgnoredWorkStatusReason[IgnoredWorkStatusReason.SPURIOUS]}
          id={'IgnoredWorkStatusReasonEnumSPURIOUS'}
          isChecked={props.workOrderIgnoredReason ===
            IgnoredWorkStatusReason[IgnoredWorkStatusReason.SPURIOUS]}
          handleChange={props.handleIgnoredReasonChange}
          label={IgnoredWorkStatusReasonEnum.SPURIOUS}
          name={'ignoredWorkStatusReason'}
        />
        <DSRadio
          value={IgnoredWorkStatusReason[IgnoredWorkStatusReason.NO_ACTION]}
          id={'IgnoredWorkStatusReasonEnumNO_ACTION'}
          isChecked={props.workOrderIgnoredReason ===
            IgnoredWorkStatusReason[IgnoredWorkStatusReason.NO_ACTION]}
          handleChange={props.handleIgnoredReasonChange}
          label={IgnoredWorkStatusReasonEnum.NO_ACTION}
          name={'ignoredWorkStatusReason'}
        />
        <DSRadio
          value={IgnoredWorkStatusReason[IgnoredWorkStatusReason.OTHER_REASON]}
          id={'IgnoredWorkStatusReasonEnumOTHER_REASON'}
          isChecked={props.workOrderIgnoredReason ===
            IgnoredWorkStatusReason[IgnoredWorkStatusReason.OTHER_REASON]}
          handleChange={props.handleIgnoredReasonChange}
          label={IgnoredWorkStatusReasonEnum.OTHER_REASON}
          name={'ignoredWorkStatusReason'}
        />
      </div>
      <Textarea
        label={Strings.workflowModalCommentLabel}
        isMandatory={
          props.workOrderIgnoredReason === IgnoredWorkStatusReason[IgnoredWorkStatusReason.OTHER_REASON]
        }
        name={'workOrderComment'}
        handleChange={props.handleCommentChange}
        cols={40}
        value={props.workOrderComment}
      />
    </div>
  );
};

WorkflowModalIgnoreActionView.displayName = 'WorkflowModalIgnoreActionView';
