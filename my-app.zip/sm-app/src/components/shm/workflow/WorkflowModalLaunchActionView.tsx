import { DSDatepicker, DSText, DSTextarea } from '@sm/skywise-react-library';
import * as React from 'react';
import * as Strings from '../../../lang/strings.json';

interface WorkflowModalLaunchActionViewProps {
  clearForm(): void;
  dateProps: {inputProps: { disable: boolean, readOnly: boolean}, value: any};
  handleDayChange(pSelectedDay: Date): void;
  handleWorkReferenceChange(pEvent: React.FormEvent<HTMLInputElement>): void;
  handleCommentChange(pEvent: React.FormEvent<HTMLTextAreaElement>): void;
  workOrderComment: string;
  workOrderReference: string;
}

/**
 * Class description: Workflow rendering component for Launch action
 * @author Capgemini
 * @version 1.0
 */
export const WorkflowModalLaunchActionView: React.SFC<WorkflowModalLaunchActionViewProps>
= (props: WorkflowModalLaunchActionViewProps) => {
  return (
    <div id="launch-action-form">
      <a className="clear-form" onClick={props.clearForm}>
      {Strings.workflowModalClearLabel}
            </a>
      <DSText
        name={'workOrderReference'}
        value={props.workOrderReference}
        handleChange={props.handleWorkReferenceChange}
        label={Strings.workflowModalWorkReferenceLabel}
      />
      <div className="ds-form-group">
        <label>
          {Strings.workflowModalPlannedDateLabel}
        </label>
        <div>
          <DSDatepicker
            handleDayChange={props.handleDayChange}
            dateProps={props.dateProps}
          />
          <div className="dotted-line" />
        </div>
      </div>
      <DSTextarea
        label={Strings.workflowModalCommentLabel}
        name={'workOrderComment'}
        handleChange={props.handleCommentChange}
        cols={40}
        rows={8}
        value={props.workOrderComment}
      />
    </div>
  );
};

WorkflowModalLaunchActionView.displayName = 'WorkflowModalLaunchActionView';
