import {
  DSButton,
  DSGridColumn,
  DSGridRow,
  DSModal
} from '@sm/skywise-react-library';
import * as React from 'react';
import { formatDate } from 'react-day-picker/moment';
import * as Strings from '../../../lang/strings.json';
import {
  WorkflowAction,
  WorkOrderStatusEnum
} from '../../../model/EventsConstantes';
import { getUsername } from '../../../utils/AuthenticationUtils';
import { WorkflowModalHeaderView } from './WorkflowModalHeaderView';
import { WorkflowModalLaunchActionView } from './WorkflowModalLaunchActionView';
import { WorkflowModalSteppersController } from './workflowModalSteppers/WorkflowModalSteppersController';

interface WorkflowEditState {
  dateDisabled: boolean;
  dateSet: boolean;
  displayName: string;
  isSubmitEnabled: boolean;
  workOrderComment: string;
  workOrderOldStatus: string;
  workOrderPlannedDate: string;
  workOrderReference: string;
  workOrderStatus: string;
}

export interface WorkflowEditProps
  extends React.Props<WorkflowModalEditViewController> {
  closeModal(pTimer: number): void;
  event: any;
  setWorkOrderStatus(
    pWorkOrderStatus: string,
    pUsername: string,
    pWorkOrderReference?: string,
    pWorkOrderComment?: string,
    pWorkOrderIgnoredReason?: string,
    pFormattedDate?: string
  ): void;
  displayName: string;
}

/**
 * Class description: Workflow modal controller for edit action
 * @author Capgemini
 * @version 1.0
 */
export class WorkflowModalEditViewController extends React.Component<
  WorkflowEditProps,
  WorkflowEditState
> {
  /**
   * Constructor
   * @param props React props
   */
  constructor(props: WorkflowEditProps) {
    super(props);

    this.state = {
      dateDisabled: !this.props.event.workOrderReference,
      dateSet: this.props.event.workOrderPlannedDate,
      displayName: this.props.displayName,
      isSubmitEnabled: false,
      workOrderComment: this.props.event.workOrderComment,
      workOrderOldStatus: this.props.event.workOrderStatus,
      workOrderPlannedDate: this.props.event.workOrderPlannedDate,
      workOrderReference: this.props.event.workOrderReference
        ? this.props.event.workOrderReference
        : '',
      workOrderStatus: this.props.event.workOrderStatus
    };

    this.handleCommentChange = this.handleCommentChange.bind(this);
    this.handleWorkReferenceChange = this.handleWorkReferenceChange.bind(this);
    this.handleDayChange = this.handleDayChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.clearForm = this.clearForm.bind(this);
  }

  /**
   * Date formatting to UI Display
   * @param pDate Date to format
   */
  private formatDateUi(pDate: Date = new Date()) {
    return formatDate(pDate, 'DD MMM YYYY');
  }

  /**
   * Handle change on comment field
   * @param pEvent the event throwed
   */
  private handleCommentChange(pEvent: React.FormEvent<HTMLTextAreaElement>) {
    pEvent.preventDefault();
    const lCommentValue = pEvent.currentTarget.value;

    this.setState({
      isSubmitEnabled: true,
      workOrderComment: lCommentValue
    });
  }

  /**
   * Clear form
   */
  private clearForm() {
    this.setState({
      dateDisabled: true,
      dateSet: false,
      isSubmitEnabled: true,
      workOrderComment: '',
      workOrderOldStatus: this.props.event.workOrderStatus,
      workOrderPlannedDate: '',
      workOrderReference: '',
      workOrderStatus: WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]
    });
  }

  /**
   *  the state with the new day selected
   * @param pSelectedDay New day selected
   */
  private handleDayChange(pSelectedDay: Date) {
    if (pSelectedDay) {
      const lSelectedDay = new Date(pSelectedDay.setHours(13, 0, 0, 0));
      const today = new Date(new Date().setHours(13, 0, 0, 0));

      this.setState({
        dateSet: true,
        isSubmitEnabled: true,
        workOrderPlannedDate: lSelectedDay.toISOString(),
        workOrderStatus:
          lSelectedDay < today
            ? WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_MONITORED]
            : WorkOrderStatusEnum[WorkOrderStatusEnum.PLANNED]
      });
    } else {
      this.setState({
        dateSet: false,
        isSubmitEnabled: true,
        workOrderPlannedDate: '',
        workOrderStatus: WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED]
      });
    }
  }

  /**
   * Handle on work reference change event
   * @param pEvent work reference change event
   */
  private handleWorkReferenceChange(pEvent: React.FormEvent<HTMLInputElement>) {
    pEvent.preventDefault();

    const lWorkReference: string = pEvent.currentTarget.value;

    if (lWorkReference.trim().length > 0) {
      this.setState({
        dateDisabled: false,
        isSubmitEnabled: true,
        workOrderReference: lWorkReference
      });

      if (this.state.dateSet) {
        this.setState({
          workOrderStatus: WorkOrderStatusEnum[WorkOrderStatusEnum.PLANNED]
        });
      } else {
        this.setState({
          workOrderStatus: WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED]
        });
      }
    } else {
      this.setState({
        dateDisabled: true,
        dateSet: false,
        isSubmitEnabled: true,
        workOrderPlannedDate: null,
        workOrderReference: lWorkReference,
        workOrderStatus: WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]
      });
    }
  }

  /**
   * Return date props
   * @returns object
   */
  private getDateProps(): any {
    const lDateProps: any = {};
    if (this.state.workOrderPlannedDate) {
      const lDate = new Date(this.state.workOrderPlannedDate);
      lDateProps.value = this.formatDateUi(lDate);
    }
    if (this.state.dateDisabled) {
      lDateProps.inputProps = { disabled: true };
    } else {
      lDateProps.inputProps = { readOnly: false };
    }

    return lDateProps;
  }

  /**
   * Handle form submission
   * @param pEvent Submit event
   */
  private handleSubmit(pEvent: any) {
    pEvent.preventDefault();

    let lWorkOrderReference: string = '';
    let lWorkOrderComment: string = '';
    let lFormattedDate: string = '';

    if (this.state.dateSet) {
      lFormattedDate = new Date(this.state.workOrderPlannedDate).toISOString();
    }

    if (this.state.workOrderReference) {
      lWorkOrderReference = this.state.workOrderReference.trim();
    }

    if (this.state.workOrderComment) {
      lWorkOrderComment = this.state.workOrderComment.trim();
    }

    this.props.setWorkOrderStatus(
      this.state.workOrderStatus,
      getUsername(),
      lWorkOrderReference,
      lWorkOrderComment,
      undefined,
      lFormattedDate
    );
  }

  /**
   * Return the workflow modal header
   * @returns the workflow modal header
   */
  private getModalHeader(): JSX.Element {
    return (
      <WorkflowModalHeaderView
        ata={
          this.props.event.ata6
            ? this.props.event.ata6
            : this.props.event.ataChapter
        }
        source={this.props.event.sourceSystem}
        titleFromAircraft={
          this.props.event.titleFromAircraft
            ? this.props.event.titleFromAircraft
            : this.props.event.riskName
        }
        acMatricule={
          this.props.event.acMatricule
            ? this.props.event.acMatricule
            : this.props.event.tailNumber
        }
        acNickName={
          this.props.event.acNickName
            ? this.props.event.acNickName
            : this.props.event.tailNumber
        }
        msn={
          this.props.event.msn
            ? this.props.event.msn
            : this.props.event.tailNumber
        }
        displayName={
          this.props.displayName ? this.props.displayName : 'acMatricule'
        }
      />
    );
  }

  /**
   * Build the workflow modal content
   * @returns the workflow modal content
   */
  private getModalContent(): JSX.Element {
    return (
      <DSGridRow>
        <DSGridColumn width={20} className="workflow-steppers-container">
          <WorkflowModalSteppersController
            currentStep={this.state.workOrderStatus}
            previousStep={this.state.workOrderOldStatus}
            action={WorkflowAction[WorkflowAction.EDIT]}
          />
        </DSGridColumn>
        <DSGridColumn width={28}>
          <WorkflowModalLaunchActionView
            workOrderReference={this.state.workOrderReference}
            handleWorkReferenceChange={this.handleWorkReferenceChange}
            workOrderComment={this.state.workOrderComment}
            handleCommentChange={this.handleCommentChange}
            handleDayChange={this.handleDayChange}
            dateProps={this.getDateProps()}
            clearForm={this.clearForm}
          />
        </DSGridColumn>
      </DSGridRow>
    );
  }

  /**
   * Return the workflow modal footer
   * @returns the workflow modal footer
   */
  private getModalFooter(): JSX.Element {
    return (
      <div>
        <DSButton content="Cancel" handleClick={this.props.closeModal} />
        <DSButton
          type="primary"
          content="Apply"
          isSubmit={true}
          disabled={!this.state.isSubmitEnabled}
          handleClick={() => null}
        />
      </div>
    );
  }

  /**
   * React lifecycle method
   */
  public render(): JSX.Element {
    return (
      <DSModal
        className={'workflow-modal'}
        modalTitle={Strings.edit}
        withHeaderIntro={true}
        withForm={true}
        withFooterBackground={true}
        onSubmit={this.handleSubmit}
        onRequestClose={this.props.closeModal}
        modalHeaderIntro={this.getModalHeader()}
        modalContent={this.getModalContent()}
        modalFooter={this.getModalFooter()}
      />
    );
  }
}
