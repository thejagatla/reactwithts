import * as classNames from 'classnames';
import * as React from 'react';
import { WorkflowAction, WorkOrderStatus, WorkOrderStatusEnum } from '../../../../model/EventsConstantes';
import {
  ShmActionsIgnored,
  ShmActionsToBeMonitored,
  ShmActionsToOpened,
  ShmActionsToPlanned,
  ShmStatusDone,
} from '../../../../model/Workflow';
import { WorkflowModalSteppers } from './WorkflowModalSteppers';

interface SteppersControllerProps {
  action?: any;
  currentStep?: any;
  previousStep?: any;
}

/**
 * Class description: Component of Steppers displayed in the workflow event modal.
 * Component type: Business Controller
 * @author Capgemini
 * @version 1.0
 */
export class WorkflowModalSteppersController extends React.Component<SteppersControllerProps, any> {

  /**
   * Controller
   * @param props React props
   */
  constructor(props: SteppersControllerProps) {
    super(props);

    this.isStatusDone = this.isStatusDone.bind(this);
    this.isStatusAchieved = this.isStatusAchieved.bind(this);
    this.isStatusReachable = this.isStatusReachable.bind(this);
    this.isStatusReachableAndNotLastOne = this.isStatusReachableAndNotLastOne.bind(this);
    this.isNextStatusNotAdjacent = this.isNextStatusNotAdjacent.bind(this);
    this.isPrevStatusNotAdjacent = this.isPrevStatusNotAdjacent.bind(this);

    this.getStepClassnames = this.getStepClassnames.bind(this);
  }
  /**
   * Change eventually state to Opened
   * @param pValue work order reference
   */
  private getStepClassnames(status: any): string {
    return classNames({
      'ds-step--reachable': this.isStatusReachable(
        WorkOrderStatusEnum[status]
      ),
      'ds-step--reachable-not-last': this.isStatusReachableAndNotLastOne(
        WorkOrderStatusEnum[status]
      ),
      'next-step--not-adj': this.isNextStatusNotAdjacent(
        WorkOrderStatusEnum[status]
      ),
      'prev-step--not-adj': this.isPrevStatusNotAdjacent(
        WorkOrderStatusEnum[status]
      )
    });
  }

  /**
   * Defines if the scheme status have to be colored as Done status
   * @param status Current scheme status evaluated
   */
  public isStatusDone(status: string): boolean {
    return ShmStatusDone[this.props.currentStep].indexOf(status) !== -1;
  }

  /**
   * Defines if the scheme status is an achieved status
   * @param status Current scheme status evaluated
   */
  public isStatusAchieved(status: string): boolean {
    return (this.props.currentStep === status) && (this.props.currentStep !== this.props.previousStep);
  }

  /**
   * Defines is the scheme status have to be colored as Reachable status
   * according to current WorkStatus and WorkAction
   * @param status Current scheme status evaluated
   */
  public isStatusReachableAndNotLastOne(status: string): boolean {
    if (status === WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED] &&
      ShmActionsToOpened[this.props.currentStep] === this.props.action) {
      return true;
    }
    if (status === WorkOrderStatusEnum[WorkOrderStatusEnum.PLANNED] &&
      ShmActionsToPlanned[this.props.currentStep] === this.props.action) {
      return true;
    }
    return false;
  }

  /**
   * Defines is the scheme status have to be colored as Reachable status
   * according to current WorkStatus and WorkAction
   * @param status Current scheme status evaluated
   */
  public isStatusReachable(status: string): boolean {
    switch (status) {
      case WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED]:
        if (ShmActionsToOpened[this.props.currentStep] === this.props.action) {
          return true;
        }
        break;
      case WorkOrderStatusEnum[WorkOrderStatusEnum.PLANNED]:
        if (ShmActionsToPlanned[this.props.currentStep] === this.props.action) {
          return true;
        }
        break;
      case WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_MONITORED]:
        if (ShmActionsToBeMonitored[this.props.currentStep] === this.props.action) {
          return true;
        }
        break;
      case WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED]:
        if (ShmActionsIgnored[this.props.currentStep] === this.props.action) {
          return true;
        }
        break;
      case WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]:
      default:
        return false;
    }
    return this.isStatusReachableIgnoreAction(status);

  }

  private isStatusReachableIgnoreAction(status: string): any {
    if (this.props.action === 'IGNORE'
      && status === this.props.previousStep
      && status !== this.props.currentStep) {
      return true;
    }
    return false;
  }

  /**
   * Defines is the status which is reachable is not adjacent to current WorkStatus
   * @param status Current scheme status evaluated
   */
  public isNextStatusNotAdjacent(status: string): boolean {
    if (this.props.action === WorkflowAction[WorkflowAction.IGNORE]) {
      return true;
    }
    switch (status) {
      case WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_MONITORED]:
        return true;
      case WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]:
      default:
        return false;
    }
  }

  /**
   * Defines if the status which is reachable is not adjacent to current status
   * @param status Current scheme status evaluated
   */
  public isPrevStatusNotAdjacent(status: any): boolean {
    if (this.props.action === WorkflowAction[WorkflowAction.IGNORE]) {
      return true;
    }
    return false;
  }

  /**
   *
   * @param workOrderStatus
   */
  private getStep(status: string): object {
    const step: { active: boolean; classnames: string; done: boolean; label: string; icon?: string; key?: string } = {
      active: this.props.currentStep === status,
      classnames: this.getStepClassnames(WorkOrderStatusEnum[status]),
      done: this.isStatusDone(status),
      label: WorkOrderStatus[status],
    };

    switch (status) {
      case WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]:
        step.icon = 'location';
        step.key = 'tbr';
        break;
      case WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED]:
        step.icon = 'eye';
        step.key = 'opened';
        break;
      case WorkOrderStatusEnum[WorkOrderStatusEnum.PLANNED]:
        step.icon = 'date_range';
        step.key = 'planned';
        break;
      case WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_MONITORED]:
        step.icon = 'build';
        step.key = 'tbm';
        break;
      case WorkOrderStatusEnum[WorkOrderStatusEnum.CLOSED]:
        step.icon = 'check_checkbox';
        step.key = 'closed';
        break;
      case WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED]:
        step.icon = 'close';
        step.key = 'ignored';
        step.classnames = classNames({
          'ds-step--reachable': this.isStatusReachable(
            WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED]
          )
        });
        break;
      default:
    }

    return step;
  }

  //

  /**
   * Rendering method
   */
  public render() {
    const steps = [];
    for (const key in WorkOrderStatus) {
      if (key !== undefined && (key !== 'NONE' && key !== 'IGNORED')) {
        steps.push(this.getStep(key));
      }
    }
    const ignoreStep = [];
    ignoreStep.push(this.getStep(WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED]));

    return (
      <React.Fragment>
        <WorkflowModalSteppers steppers={steps} />
        <WorkflowModalSteppers steppers={ignoreStep} />
      </React.Fragment>
    );
  }
}
