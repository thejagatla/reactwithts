import { DSStep, DSSteppers } from '@sm/skywise-react-library';
import * as React from 'react';

interface Step {
  active?: boolean;
  classnames?: string;
  done?: boolean;
  icon: string;
  key?: string;
  label: string;
}

interface WorkflowModalSteppersProps {
  steppers: Step[];
}

/**
 * Class description: Component of Steppers displayed in the workflow event modal.
 * Component type: Business Presenter
 * @author Capgemini
 * @version 1.0
 */
export const WorkflowModalSteppers: React.SFC<WorkflowModalSteppersProps> = (props: WorkflowModalSteppersProps) => {
  return (
    <DSSteppers
      animated={true}
    >
      {props.steppers.map((step: Step, index: number) => {
        return (
          <DSStep
            key={step.key}
            id={'workflow-step-' + step.key}
            className={step.classnames}
            icon={step.icon}
            label={step.label}
            current={step.active}
            done={step.done}
          />
        );
      })}
    </DSSteppers>
  );
};

WorkflowModalSteppers.displayName = 'WorkflowModalSteppers';
