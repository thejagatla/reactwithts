import * as Strings from '../../../lang/strings.json';
import { WorkOrderStatusEnum } from '../../../model/EventsConstantes';
import { getUsername } from '../../../utils/AuthenticationUtils';
import {
  AbstractWorkflowModalIgnoreViewController,
  WorkflowModalIgnoreProps
} from './AbstractWorkflowIgnoreViewController';

/**
 * Class description: Workflow modal controller Edit action on Ignore status
 * @author Capgemini
 * @version 1.0
 */
export class WorkflowModalIgnoredEditViewController extends AbstractWorkflowModalIgnoreViewController {
  /**
   * Controller
   * @param props React props
   */
  constructor(props: WorkflowModalIgnoreProps) {
    super(props);
    this.modalLabelTitle = Strings.edit;
    this.modalClearLabel = Strings.workflowIgnoreClearReason;
  }

  /**
   * Clear form
   */
  protected clearForm() {
    // set status to review when clear filter.
    // keep comment
    this.setState({
      isSubmitDisabled: false,
      workOrderIgnoredReason: '',
      workOrderStatus: WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]
    });
  }

  /**
   * Handle change on comment field
   * @param pEvent the event throwed
   */
  protected handleCommentChange(pEvent: any) {
    const lCommentValue = pEvent.target.value;

    // disable submit if necessary
    this.setState({
      isSubmitDisabled: this.checkIgnoreAction(
        this.state.workOrderIgnoredReason,
        lCommentValue,
        this.state.workOrderStatus
      ),
      workOrderComment: lCommentValue
    });
  }

  /**
   * Handle form submission
   * @param event Submit event
   */
  protected handleSubmit(event: any) {
    event.preventDefault();

    // Empty planned date and work reference if status set to Review
    let lFormattedDate = '';
    let lWorkOrderReference = '';
    if (
      this.state.workOrderStatus !==
      WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]
    ) {
      lWorkOrderReference = this.state.workOrderReference;
      if (this.state.workOrderPlannedDate !== '') {
        lFormattedDate = new Date(
          this.state.workOrderPlannedDate
        ).toISOString();
      }
    }

    this.props.setWorkOrderStatus(
      this.state.workOrderStatus,
      getUsername(),
      lWorkOrderReference,
      this.state.workOrderComment,
      this.state.workOrderIgnoredReason,
      lFormattedDate
    );
  }
}
