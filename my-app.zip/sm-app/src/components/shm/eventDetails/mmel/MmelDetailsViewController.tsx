/**
 * Class description: React predictive event details page view controller
 * @author Capgemini
 * @version 1.0
 */

import * as React from 'react';
import { MmelDetailsView } from './MmelDetailsView';

/**
 * Component of the event details page
 */
export class MmelDetailsViewController extends React.Component<any, any> {

  /**
   * Constructor
   * @param props Component props
   */
  constructor(props: any) {
    super(props);
  }

  /**
   * Render the component
   */
  public render() {
    return(
      <MmelDetailsView 
        melLinksList={this.props.melLinksList}
      />
    );
  }
}
