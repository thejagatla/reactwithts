import { DSFlag } from '@sm/skywise-react-library';
import * as React from 'react';
import * as Strings from '../../../../lang/strings.json';
import { MmelTasksView } from './MmelTasksView';

interface MmelDetailsViewProps {
  melLinksList: any;
}

/**
 * Class description: React events component
 * @author Capgemini
 * @version 1.0
 */
export const MmelDetailsView: React.SFC<MmelDetailsViewProps> = (props:  MmelDetailsViewProps) => {
  return (
    <div className="mmel-details">
      {props.melLinksList.map((mmel, index) => {
        const tasks = mmel.tasks ? mmel.tasks.join(', ') : '';
        const tools = mmel.tools ? mmel.tools.join(', ') : '';
        const ops = mmel.ops ? mmel.ops.join(', ') : '';
        const access = mmel.access ? mmel.access.join(', ') : '';
        const badRefs = ['Multiple Ref', 'NO_DISPATCH', 'Not Related to MEL', 'Affected System'];
        const withPaddingClass = 'with-padding';
        return (
          <div className="mmel-details-row" key={'mmel' + index}>
            <h2 className="h4-like">
              <label>
                <DSFlag title="MEL" />
              </label>
              <span>
                {mmel.mmelReference}
              </span>
            </h2>

            {badRefs.indexOf(mmel.mmelReference) === -1 &&
              <React.Fragment>
                <div>
                  {ops.length > 0 &&
                    <p className={withPaddingClass}>
                      <label>
                        {Strings.flightOpsImpacts}:
                      </label>
                      {ops}
                    </p>
                  }
                  {tasks.length > 0 &&
                    <MmelTasksView
                      tasks={tasks}
                      mmel={mmel}
                    />
                  }
                  {tools.length > 0 &&
                    <p className={withPaddingClass}>
                      <label>
                        {Strings.tools}:
                      </label>
                      {tools}
                    </p>
                  }
                  {access.length > 0 &&
                    <p className={withPaddingClass}>
                      <label>
                        {Strings.access}:
                      </label>
                      {access}
                    </p>
                  }
                </div>
              </React.Fragment>
            }
          </div>
        );
      })}
    </div>
  );
};

MmelDetailsView.displayName = 'MmelDetailsView';
