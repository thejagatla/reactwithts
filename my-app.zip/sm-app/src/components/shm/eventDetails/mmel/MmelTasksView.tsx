import * as React from 'react';
import * as Strings from '../../../../lang/strings.json';

interface MmelTasksViewProps {
  mmel: any;
  tasks: string;
}

/**
 * Class description: React MMelTasks component
 * @author Capgemini
 * @version 1.0
 */
export const MmelTasksView: React.SFC<MmelTasksViewProps> = (props: MmelTasksViewProps) => {
  return (
    <p>
      <label>{Strings.maintenance}:</label>
      {props.tasks.length > 0 &&
        <span>
          <label>{Strings.tasks}:</label>{props.tasks}
        </span>
      }
      {props.mmel.estimatedTime &&
        <span>
          <label>{Strings.estimatedTime}:</label>{props.mmel.estimatedTime}
        </span>
      }
      {props.mmel.checkRequired &&
        <span>
          <label>{props.mmel.checkRequired}</label>
        </span>
      }
    </p>
  );
};

MmelTasksView.displayName = 'MmelTasksView';
