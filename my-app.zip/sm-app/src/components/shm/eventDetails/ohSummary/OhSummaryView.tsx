import * as classNames from 'classnames';
import * as React from 'react';
import * as Draggable from 'react-draggable';
import * as Strings from '../../../../lang/strings.json';
import { OhSummaryPagerView } from './pager/OhSummaryPagerView';

/**
 * Class description: React Occurence History on Event Details View
 * @author Capgemini
 * @version 1.0
 */
export const OhSummaryView: React.SFC<any> = (props: any) => {
  const { draggablePosition, ohItemsPerPage, ohPage, ohSize, ohSummary, total } = props;
  let finalOhSize = ohSize;
  const skippedElements = -1 * Math.floor((draggablePosition - 6) / 12) - 1;
  const from = total - (ohPage * ohItemsPerPage);
  const to = from - ohItemsPerPage < 1 ? 1 : from - ohItemsPerPage;
  const elementsToDisplay = ohSummary.slice(to - 1, from);

  if (elementsToDisplay.length < ohSize) {
    finalOhSize = elementsToDisplay.length;
  }

  const draggableStyle = {
    width: finalOhSize * 12 + 6
  };

  const flightsIndicationsList = [];
  let i = ohPage === 0 ? 20 : 1;
  while (i < ohItemsPerPage - 2 && i + (ohPage * ohItemsPerPage) < total) {
    const goodNumber = i + (ohPage * ohItemsPerPage);
    const goodRightPos = (i * 12) - 15;
    flightsIndicationsList.push({
      number: goodNumber,
      right: goodRightPos
    });
    i = i + 20;
  }

  const controlledPosition = {
    x: draggablePosition, y: 0
  };

  return (
    <div className="oh-details">
        <div className="flights-indications">
          {ohPage === 0 &&
            <span>{Strings.flights}</span>
          }
          <ul>
            {flightsIndicationsList.map((elem, index) => {
              return (
                <li key={index} style={{ right: elem.right }}>
                  -{elem.number}
                </li>
              );
            })}
          </ul>
        </div>
        <div className="oh-summary">
          <Draggable.default
            axis="x"
            bounds="parent"
            position={controlledPosition}
            onDrag={props.handleDrag}
          >
            <div 
              style={draggableStyle}
              className="oh-selector"
            />
          </Draggable.default>
          <ul>
            {elementsToDisplay.map((elem, index) => {
              const hovered = (
                to + index <= from - skippedElements &&
                to + index > from - (skippedElements + ohSize)
              );

              const classes = classNames({
                'dragging-hover': hovered,            
                'oh-summary__flight': elem.type === 'shm',  
                'oh-summary__no-flight': elem.type === 'no-flight',
                small: true,
              });
            
              return (
                <li className={classes} key={index} />
              );
            })}
          </ul>
        </div>
        <OhSummaryPagerView
          hasNextPage={from !== total}
          hasPreviousPage={to !== 1}
          setNextPage={props.setNextPage}
          setPreviousPage={props.setPreviousPage}
        />
      </div>
  );
};
