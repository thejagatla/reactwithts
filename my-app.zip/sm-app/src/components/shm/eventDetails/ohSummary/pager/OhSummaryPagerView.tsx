import { DSLink } from '@sm/skywise-react-library';
import * as React from 'react';
import * as Strings from '../../../../../lang/strings.json';

interface OhSummaryPagerViewProps {
  hasNextPage: boolean;
  hasPreviousPage: boolean;
  setPreviousPage(event: React.MouseEvent<HTMLLinkElement>): void;
  setNextPage(event: React.MouseEvent<HTMLLinkElement>): void;
}

/**
 * Class description: Occurrence History Summary Pager View
 * @author Capgemini
 * @version 1.0
 */
export const OhSummaryPagerView: React.SFC<OhSummaryPagerViewProps> = (props: OhSummaryPagerViewProps) => {
  return (
    <div className="oh-summary-pager">
      {props.hasPreviousPage &&
        <DSLink
          as="button"
          className="previous-page"
          handleClick={props.setPreviousPage}
        >
          {Strings.previousFlights}
        </DSLink>
      }
      {props.hasNextPage &&
        <DSLink
          as="button"
          className="next-page"
          handleClick={props.setNextPage}
        >
          {Strings.nextFlights}
        </DSLink>
      }
    </div> 
  );
};
