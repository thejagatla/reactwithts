import * as React from 'react';
import {
  PHASE_SEPARATOR
} from '../../../../model/EventsConstantes';
import { OhSummaryView } from './OhSummaryView';

/**
 * Class description: React Occurence History on Event Details Controller
 * @author Capgemini
 * @version 1.0
 */
export class OhSummaryViewController extends React.Component<any, any> {
  /**
   * Constructor
   * @param props Component props
   */
  constructor(props: any) {
    super(props);

    this.state = {
      ohSummary: [],
      total: 0
    };

    this.buildFullList = this.buildFullList.bind(this);
    this.handleDrag = this.handleDrag.bind(this);
  }

  public componentDidMount() {
    this.buildFullList();
  }

  private buildFullList() {
    const eventsList = [];
    this.props.correlatedEvents.forEach((correlatedEvent) => {
      eventsList.push(correlatedEvent);
    });

    const lFinalResult = [];
    let maxItems = 0;

    eventsList.forEach((elem, index) => {
      maxItems = elem.flightOccurrence && elem.flightOccurrence.length > maxItems ?
        elem.flightOccurrence.length : maxItems;
    });

    for (let i = 0; i < maxItems; i = i + 1) {
      lFinalResult[i] = {
        type: 'no-flight'
      };
      eventsList.forEach((event) => {
        const oh = this.getSHMSummaryOccurrence(event.occurrenceHistory, event.flightOccurrence[i]);
        if (oh.type === 'shm') {
          lFinalResult[i].type = 'shm';
        }
      });
    }

    this.setState({
      ohSummary: lFinalResult,
      total: maxItems
    });
  }

  private getSHMSummaryOccurrence = (occurrenceHistory: any, flightOccurrence: any) => {
    let sameDate: boolean = false;
    let lPhaseNumber: string = '';
    let lFound: boolean = false;
  
    for (let index = 0; index < occurrenceHistory.length && !lFound; index = index + 1) {
      if (occurrenceHistory[index].m === 'P') {
        sameDate = occurrenceHistory[index].d === flightOccurrence.p;
      } else if (flightOccurrence.c) {
        sameDate = (flightOccurrence.c.indexOf(occurrenceHistory[index].d) > -1);
      }
  
      if (sameDate) {
        lPhaseNumber = occurrenceHistory[index].p.substring(occurrenceHistory[index].p.indexOf(PHASE_SEPARATOR) + 1);
        lFound = true;
        if (occurrenceHistory[index].p === '') {
          return {
            type: 'missing'
          };
        }
        return {
          type: 'shm',
          value: lPhaseNumber
        };
      }
    }
  
    return {
      type: 'no-flight'
    };
  }

  private handleDrag(e: any, ui: any) {
    this.props.changeDraggablePosition(this.props.draggablePosition + ui.deltaX);
  }

  /**
   * Render the component
   */
  public render() {
    return (
      <React.Fragment>
        <OhSummaryView
          handleDrag={this.handleDrag}
          draggablePosition={this.props.draggablePosition}
          ohItemsPerPage={this.props.ohItemsPerPage}
          ohPage={this.props.ohPage}
          ohSize={this.props.ohSize}
          ohSummary={this.state.ohSummary}
          total={this.state.total}
          setNextPage={this.props.setNextPage}
          setPreviousPage={this.props.setPreviousPage}
        />
      </React.Fragment>
    );
  }
}
