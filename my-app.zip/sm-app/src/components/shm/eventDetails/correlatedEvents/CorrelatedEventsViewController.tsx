import * as React from 'react';
import * as ReactResizeDetector from 'react-resize-detector';
import { CorrelatedEventsView } from './CorrelatedEventsView';

/**
 * Class description: Correlated Events Controller on events details page
 * @author Capgemini
 * @version 1.0
 */
export class CorrelatedEventsViewController extends React.Component<any, any> {
  private containerRef;

  /**
   * Constructor
   * @param props Component props
   */
  constructor(props: any) {
    super(props);

    this.state = {
      draggablePosition: 0,
      ohItemsPerPage: 0,
      ohPage: 0,
      ohSize: 28
    };

    this.changeDraggablePosition = this.changeDraggablePosition.bind(this);
    this.setNextPage = this.setNextPage.bind(this);
    this.setPreviousPage = this.setPreviousPage.bind(this);
    this.setNumberOfItemsPerPage = this.setNumberOfItemsPerPage.bind(this);
    this.onResize = this.onResize.bind(this);
    this.getMaximumNumberOfElement = this.getMaximumNumberOfElement.bind(this);
  }

  public componentDidMount() {
    this.setNumberOfItemsPerPage();
  }

  public setNumberOfItemsPerPage() {
    this.setState({
      ohItemsPerPage: Math.floor((this.containerRef.offsetWidth - 4) / 12) - 1
    });
    const selectorSize = this.state.ohSize * 12 + 6;
    const limit = -1 * (this.state.ohItemsPerPage * 12 + 4 - selectorSize);
    if (
      this.state.ohPage * this.state.ohItemsPerPage >
      this.getMaximumNumberOfElement()
    ) {
      while (
        this.state.ohPage * this.state.ohItemsPerPage >
        this.getMaximumNumberOfElement()
      ) {
        this.setState({
          ohPage: this.state.ohPage - 1
        });
      }
      this.changeDraggablePosition(0);
    }
    if (this.state.draggablePosition < limit) {
      this.changeDraggablePosition(limit);
    } else if (this.state.draggablePosition > 0) {
      this.changeDraggablePosition(0);
    }
  }

  public getMaximumNumberOfElement() {
    let maxItems = 0;
    if (this.props.eventLoaded) {
      const eventsList = [];
      eventsList.push(this.props.event);
      this.props.correlatedEvents.forEach(correlatedEvent => {
        eventsList.push(correlatedEvent);
      });

      eventsList.forEach((elem, index) => {
        maxItems =
          elem.flightOccurrence && elem.flightOccurrence.length > maxItems
            ? elem.flightOccurrence.length
            : maxItems;
      });
    }
    return maxItems;
  }

  /**
   * Update the state with the new Draggable position
   */
  public changeDraggablePosition(newPostion: number) {
    this.setState({
      draggablePosition: newPostion
    });
  }

  private setPreviousPage() {
    this.setState({
      ohPage: this.state.ohPage + 1
    });
    this.changeDraggablePosition(0);
  }

  private setNextPage() {
    this.setState({
      ohPage: this.state.ohPage - 1
    });
    const selectorSize = this.state.ohSize * 12 + 6;
    this.changeDraggablePosition(
      -1 * ((this.state.ohItemsPerPage + 1) * 12 + 4 - selectorSize)
    );
  }

  private onResize() {
    this.setNumberOfItemsPerPage();
  }

  /**
   * Render the component
   */
  public render() {
    return (
      <div
        ref={containerRef => {
          this.containerRef = containerRef;
        }}
      >
        <ReactResizeDetector.default
          handleWidth={true}
          handleHeight={true}
          onResize={this.onResize}
        />
        {this.props.correlatedEventsLoaded && (
          <CorrelatedEventsView
            changeDraggablePosition={this.changeDraggablePosition}
            correlatedEvents={this.props.correlatedEvents}
            correlatedEventsLoaded={this.props.correlatedEventsLoaded}
            correlatedLinksList={this.props.correlatedLinksList}
            displayName={this.props.displayName}
            draggablePosition={this.state.draggablePosition}
            event={this.props.event}
            loadingCorrelation={this.props.loadingCorrelation}
            ohItemsPerPage={this.state.ohItemsPerPage}
            ohPage={this.state.ohPage}
            cardWidth={
              this.containerRef ? this.containerRef.offsetWidth / 12 : 0
            }
            setNextPage={this.setNextPage}
            setPreviousPage={this.setPreviousPage}
            ohSize={this.state.ohSize}
          />
        )}
      </div>
    );
  }
}
