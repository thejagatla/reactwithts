import { DSLoader } from '@sm/skywise-react-library';
import * as React from 'react';
import * as Strings from '../../../../lang/strings.json';
import { EventLine } from '../../../common/events/eventLine/EventLine';
import { OhSummaryViewController } from '../ohSummary/OhSummaryViewController';
import { FaultCaseLinkView } from '../tsm/FaultCaseLinkView';

interface CorrelatedEventsViewProps {
  cardWidth: number;
  correlatedEvents: any;
  correlatedEventsLoaded: boolean;
  correlatedLinksList: any;
  displayName: string;
  draggablePosition: number;
  event: any;
  loadingCorrelation: boolean;
  ohItemsPerPage: number;
  ohPage: number;
  ohSize: number;
  changeDraggablePosition(newPostion: number): void;
  setPreviousPage(event: React.MouseEvent<HTMLLinkElement>): void;
  setNextPage(event: React.MouseEvent<HTMLLinkElement>): void;
}

/**
 * Class description: Correlated Events View on events details page
 * @author Capgemini
 * @version 1.0
 */
export const CorrelatedEventsView: React.SFC<CorrelatedEventsViewProps> = (
  props: CorrelatedEventsViewProps
) => {
  return (
    <div className="correlated-events-list">
      {props.correlatedEvents &&
        props.correlatedEvents.map((elem, index) => {
          return (
            <EventLine
              key={index}
              displayName={props.displayName}
              event={elem}
              hideAircraftInfos={true}
              isCorrelatedEvent={true}
              isEventClickable={true}
              isWorkflowHidden={true}
              isLoadedEvent={true}
              ohPage={props.ohPage}
              ohItemsPerPage={props.ohItemsPerPage}
              ohSize={props.ohSize}
              ohDraggablePosition={props.draggablePosition}
              style={{
                overflowX: false,
                overflowY: false
              }}
            />
          );
        })}
      {props.loadingCorrelation && (
        <DSLoader label={Strings.loaderAssociatedEventsLabel} />
      )}
      {props.correlatedEventsLoaded && !props.loadingCorrelation && (
        <OhSummaryViewController
          cardWidth={props.cardWidth}
          changeDraggablePosition={props.changeDraggablePosition}
          correlatedEvents={props.correlatedEvents}
          draggablePosition={props.draggablePosition}
          ohItemsPerPage={props.ohItemsPerPage}
          ohPage={props.ohPage}
          ohSize={props.ohSize}
          setNextPage={props.setNextPage}
          setPreviousPage={props.setPreviousPage}
        />
      )}
      {props.correlatedLinksList && props.correlatedLinksList.length > 0 && (
        <FaultCaseLinkView correlatedLinksList={props.correlatedLinksList} />
      )}
    </div>
  );
};
