/**
 * Class description: React predictive event details page component
 * @author Capgemini
 * @version 1.0
 */
import {
  DSIcon,
  DSLink,
  DSLoader,
  DSTable,
  DSTableBody,
  DSTableCell,
  DSTableHeader,
  DSTableRow
}
  from '@sm/skywise-react-library';
import moment = require('moment');
import * as React from 'react';
import * as Strings from '../../../lang/strings.json';
import { CollapsedSidebarPage } from '../../presenter/CollapsedSidebarPage';
import { DSCardListing } from '../../storybook/DSCardListing';
import CheckFeatureFlipping from '../../utils/featureFlipping/CheckFeatureFlipping';
import { CorrelatedEventsViewController } from './correlatedEvents/CorrelatedEventsViewController';
import { MmelDetailsViewController } from './mmel/MmelDetailsViewController';
import { TSMViewController } from './tsm/TSMViewController';

export const EventDetailsPageView = (props: any) => {
  return (
    <CollapsedSidebarPage
      content={
        <React.Fragment>
          {props.history.length > 1 && (
            <div className="event-details-navigation">
              <DSLink as="button" handleClick={props.history.goBack}>
                <DSIcon type="chevron_left" />
                {Strings.back}
              </DSLink>
            </div>
          )}
          <DSCardListing>
            <DSCardListing.Card
              title={Strings.associatedEvents}
              content={
                <React.Fragment>
                  <CorrelatedEventsViewController {...props} />
                  {!props.correlatedEventsLoaded && (
                    <DSLoader label={Strings.loaderEventLabel} />
                  )}
                </React.Fragment>
              }
            />
            {props.melLinksList && props.melLinksList.length > 0 && (
              <DSCardListing.Card
                title="MEL"
                content={<MmelDetailsViewController {...props} />}
              />
            )}
            {props.correlatedEventsLoaded &&
              (props.esTaskRefList.length > 0 ||
                props.tsmCorrelationMessage.length > 0) && (
                <DSCardListing.Card
                  title="TSM Tasks"
                  content={
                    <TSMViewController
                      tsmCorrelationMessage={props.tsmCorrelationMessage}
                      esTaskRefList={props.esTaskRefList}
                      tsmLink={props.tsmLink}
                      correlatedEvents={props.correlatedEvents}
                    />
                  }
                />
              )}
            <CheckFeatureFlipping feature={'display_mis_data'}>
              {isActive => (
                isActive && props.misDataLoaded && (
                  <DSCardListing.Card
                    title="MIS data"
                    content={props.misData ? (
                      <DSTable>
                        <DSTableHeader thItems={['Status', 'ATA', 'Date', 'Description', 'Action']} />
                        <DSTableBody>
                          <DSTableRow>
                            <DSTableCell text={props.misData.status} />
                            <DSTableCell text={props.misData.ataChapter ?
                              props.misData.ataChapter + ' / ' + props.misData.ataSection : '-'} />
                            <DSTableCell text={props.misData.closedDate ?
                              moment(props.misData.closedDate).format('DD/MM/YYYY') : '-'} />
                            <DSTableCell text={props.misData.description} />
                            <DSTableCell text={props.misData.action} />
                          </DSTableRow>
                        </DSTableBody>
                      </DSTable>
                    ) : (
                        'No MIS data found'
                      )}
                  />
                )
              )}
            </CheckFeatureFlipping>
          </DSCardListing>
        </React.Fragment>
      }
      sidebarHeader=""
    />
  );
};
