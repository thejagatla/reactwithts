import * as React from 'react';

export const SubtitlesView = (props: any) => {  
  return (
    <React.Fragment>
      <ul>
        {props.taskRef.warningWithSubTitles.map(
        (warningWithSubTitle: any, indexwarningWithSubTitle: number) => {
          return (<li key={indexwarningWithSubTitle}>If {warningWithSubTitle}</li>);
        })}
      </ul>
    </React.Fragment>
  );
};
