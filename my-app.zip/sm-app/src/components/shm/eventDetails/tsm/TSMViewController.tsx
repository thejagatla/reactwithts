import * as React from 'react';
import { TSMView } from './TSMView';

/**
 * Class description: React SHM event details TSM view controller
 * @author Capgemini
 * @version 1.0
 */
export class TSMViewController extends React.Component<any, any> {
  /**
   * Constructor
   * @param props Component props
   */
  constructor(props: any) {
    super(props);

    this.state = {
      collapsed: []
    };

    this.toggleCollapse = this.toggleCollapse.bind(this);
  }

  public componentWillMount() {
    const tasksRefs = Object.keys(this.props.esTaskRefList);
    const initCollapsed = [];
    tasksRefs.forEach(element => {
      initCollapsed.push(true);
    });
    this.setState({
      collapsed: initCollapsed
    });
  }

  private toggleCollapse(value: number) {
    const collapsedState = this.state.collapsed;
    collapsedState[value] = !collapsedState[value];
    this.setState({
      collapsed: collapsedState
    });
  }

  /**
   * Render the component
   */
  public render() {
    return (
      <TSMView
        tsmCorrelationMessage={this.props.tsmCorrelationMessage}
        toggleCollapse={this.toggleCollapse}
        collapsed={this.state.collapsed}
        esTaskRefList={this.props.esTaskRefList}
        tsmLink={this.props.tsmLink}
        correlatedEvents={this.props.correlatedEvents}
      />
    );
  }
}
