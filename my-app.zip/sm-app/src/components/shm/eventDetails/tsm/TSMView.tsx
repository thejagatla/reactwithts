import * as classNames from 'classnames';
import * as React from 'react';
import * as Strings from '../../../../lang/strings.json';
import { buildURL } from '../../../../utils/LinkUtils';
import { ObservationView } from './ObservationView';
import { PossibleCausesView } from './PossibleCausesView';
import { SubtitlesView } from './SubtitlesView';

export const TSMView = (props: any) => {
  const tsmCorrelationMessage = props.tsmCorrelationMessage;
  const classes = classNames({
    'no-tsm-data': tsmCorrelationMessage === 'NO_TSM_DATA',
    'no-tsm-found': tsmCorrelationMessage === 'NO_TSM_FOUND'
  });

  return (
    <React.Fragment>
      {(tsmCorrelationMessage === 'NO_TSM_DATA' ||
        tsmCorrelationMessage === 'NO_TSM_FOUND') && (
        <div className={classes}>
          {Strings[tsmCorrelationMessage]
            ? Strings[tsmCorrelationMessage]
            : tsmCorrelationMessage}
        </div>
      )}
      {props.esTaskRefList.map((taskRef: any, index: number) => {
        const noPossibleCauseIdentifeied = 'NO_POSSIBLE_CAUSE_IDENTIFIED';

        return (
          <div className="task-ref" key={'task' + index}>
            {taskRef.airnavxUrl && taskRef.airnavxUrl.length > 0 ? (
              <a
                href={buildURL(
                  'TSM',
                  taskRef,
                  props.tsmLink,
                  props.correlatedEvents[0]
                )}
                target="_blank"
              >
                <h5>
                  <b>{taskRef.ref}</b> {taskRef.title}
                </h5>
              </a>
            ) : (
              <h5>
                <b>{taskRef.ref}</b> {taskRef.title}
              </h5>
            )}
            {taskRef.warningWithSubTitles &&
              taskRef.warningWithSubTitles.length > 0 && (
                <SubtitlesView taskRef={taskRef} />
              )}
            {taskRef.observations && taskRef.observations.length > 0 && (
              <ObservationView taskRef={taskRef} />
            )}

            {taskRef.possibleCauses.length > 0 && (
              <PossibleCausesView
                taskRef={taskRef}
                collapsed={props.collapsed}
                index={index}
                toggleCollapse={props.toggleCollapse}
              />
            )}
            {taskRef.possibleCauses.length === 0 && (
              <div>{Strings[noPossibleCauseIdentifeied]}</div>
            )}
          </div>
        );
      })}
    </React.Fragment>
  );
};
