import { DSIcon } from '@sm/skywise-react-library';
import * as classNames from 'classnames';
import * as React from 'react';
import * as Strings from '../../../../lang/strings.json';

export const PossibleCausesView = (props: any) => {  
  const collapsed = props.collapsed[props.index] ? 'chevron_down' : 'chevron_up';
  const possibleCausesClass = classNames({
    hidden: props.collapsed[props.index]
  });

  return (
    <React.Fragment>
      <h5>
        {Strings.possibleCauses}
        <span onClick={() => props.toggleCollapse(props.index)}>
          <DSIcon type={collapsed}/>
        </span>
      </h5>
      
      <ul className={possibleCausesClass}>
        {props.taskRef.possibleCauses.map((possibleCause: any, indexPossibleCause: number) => {
          const possibleCauseFormatted: any = JSON.parse(possibleCause);
          return (
            <li key={'possibleCause' + indexPossibleCause}>
              {possibleCauseFormatted.lru.length > 0 && 
                <React.Fragment>
                  {possibleCauseFormatted.lru[0]}
                </React.Fragment>
              }
              {possibleCauseFormatted.nlru.length > 0 && 
                <React.Fragment>
                  {possibleCauseFormatted.nlru[0]}
                </React.Fragment>
              }
              {possibleCauseFormatted.fltwire.length > 0 && 
                <React.Fragment>
                  {possibleCauseFormatted.fltwire[0]}
                </React.Fragment>
              } 
            </li>
          );
        })}
      </ul>
    </React.Fragment>
  );
};
