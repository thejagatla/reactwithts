import * as React from 'react';
import * as Strings from '../../../../lang/strings.json';

export const FaultCaseLinkView = (props: any) => {
  return (
    <React.Fragment>
      <h3 className="ds-card--title">{Strings.associatedLinksTitle}</h3>
      {props.correlatedLinksList.map((elem, index) => {
        return (
          <a href={elem.link} target="_blank" key={index}>
            <h5>
              <b>{elem.title}</b>
            </h5>
          </a>
        );
      })}
    </React.Fragment>
  );
};
