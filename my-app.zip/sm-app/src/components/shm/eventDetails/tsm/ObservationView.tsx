import * as React from 'react';
import * as Strings from '../../../../lang/strings.json';

export const ObservationView = (props: any) => {  
  return (
    <React.Fragment>
      <ul>
        {props.taskRef.observations.map((observation: any, indexObservations: number) => {
          const observationFormatted: any = JSON.parse(observation);

          return (
            <li key={'observation' + indexObservations}>
              <React.Fragment>
                {observationFormatted.tsmJoin.name === 'fltDescOptional' ?
                  <React.Fragment>
                    If {Strings[observationFormatted.fltDesc.categ]}
                    : {observationFormatted.fltDesc.msgRaw}&nbsp;
                    {Strings.ataCellTitle} : {observationFormatted.fltDesc.fltNbr.substring(0, 6)}
                  </React.Fragment>
                :
                  <React.Fragment>
                    If {Strings.fault} : {observationFormatted.cmsDesc.msgRaw}&nbsp;
                    {Strings. ataCellTitle} : {observationFormatted.cmsDesc.ataCms}&nbsp;
                    {Strings.sourceCellTitle} : {observationFormatted.cmsDesc.source}&nbsp;
                    {Strings.classCellTitle} : {observationFormatted.cmsDesc.classInfo}&nbsp;
                  </React.Fragment>
                }
              </React.Fragment>
            </li>
          );
        })}
      </ul>
    </React.Fragment>    
  );
};
