/**
 * Class description: React SHM event details page view controller
 * @author Capgemini
 * @version 1.0
 */
import * as moment from 'moment';
import * as React from 'react';
import { withRouter } from 'react-router';
import 'url-search-params-polyfill';
import { EventDetailsPageView } from './EventDetailsPageView';

/**
 * Component of the event details page
 */
export class EventDetailsPageViewController extends React.Component<any, any> {
  /**
   * Constructor
   * @param props Component props
   */
  constructor(props: any) {
    super(props);

    this.state = {
      correlId: '',
      hashKey: '',
      smEventDate: ''
    };

    this.updateLoadedEvent = this.updateLoadedEvent.bind(this);
  }

  /**
   * Starts before the component is mount
   */
  public componentWillMount() {
    this.updateLoadedEvent();
  }

  public componentDidUpdate() {
    this.updateLoadedEvent();
  }

  public updateLoadedEvent() {
    if (this.props.state.route.match.path === '/shm-event/:id') {
      const urlParams = new URLSearchParams(window.location.search);

      const lCorrelId = decodeURIComponent(urlParams.get('correlId'));
      const lSmEventDate = moment
        .utc(decodeURIComponent(urlParams.get('smEventDate')))
        .format('YYYY-MM-DD' + 'T' + 'HH:mm:ss');
      const hashKey = this.props.state.hashKey;

      if (
        this.state.correlId !== lCorrelId ||
        this.state.smEventDate !== lSmEventDate ||
        this.state.hashKey !== hashKey
      ) {
        this.props.clearEvent();
        this.setState({
          correlId: lCorrelId,
          hashKey: this.props.state.hashKey,
          smEventDate: lSmEventDate
        });
        this.props.loadEvent(this.props.state.hashKey, lSmEventDate, lCorrelId);
      }
      this.props.getMisDataDetails(this.props.state.hashKey);
    }
  }

  private buildMelLinksList(correlatedEvents: any) {
    const melLinksList = [];

    if (correlatedEvents != null && correlatedEvents.length !== 0) {
      correlatedEvents.forEach((evt: any) => {
        if (evt.hasOwnProperty('melLinks') && evt.melLinks.length !== 0) {
          evt.melLinks.forEach(data => {
            melLinksList.push(data);
          });
        }
      });
    }

    return melLinksList;
  }

  /**
   * Render the component
   */
  public render() {
    return (
      <EventDetailsPageView
        correlatedEvents={this.props.state.correlatedEvents}
        correlatedEventsLoaded={this.props.state.correlatedEventsLoaded}
        correlatedLinksList={this.props.state.correlatedLinksList}
        displayName={this.props.state.displayName}
        esTaskRefList={this.props.state.esTaskRefList}
        history={this.props.history}
        hashKey={this.props.state.hashKey}
        loadingCorrelation={this.props.state.loadingCorrelation}
        loadingMmel={this.props.state.loadingMmel}
        misData={this.props.state.misData}
        misDataLoaded={this.props.state.misDataLoaded}
        tsmCorrelationMessage={this.props.state.tsmCorrelationMessage}
        tsmLink={this.props.state.tsmLink}
        melLinksList={this.buildMelLinksList(this.props.state.correlatedEvents)}
      />
    );
  }
}

withRouter(EventDetailsPageViewController);
