import * as _ from 'lodash';
import * as React from 'react';
import { Redirect, Route, Switch } from 'react-router';
import { BrowserRouter as Router } from 'react-router-dom';
import PrivatePage from './common/layouts/PrivatePage';
import PublicPage from './common/layouts/PublicPage';
import privateRoutes from './common/routes/privateRoutes';
import publicRoutes from './common/routes/publicRoutes';

import {
  ONELOGIN_LOGGED_IN,
  ONELOGIN_LOGGIN_IN,
  ONELOGIN_LOGGIN_OUT
} from '../store/actions/LoginActions';

import { CognitoState } from 'react-cognito';

/**
 * @name App
 * @description Main React component.
 * @todo rework component to don't pass props to PublicPage and PrivatePage
 */
export const App = props => {
  const LoadedCognitoRoute = () => {
    return (
      <Router>
        <Switch>
          {_.map(publicRoutes, (publicRoute, key) => {
            const { component, path, exact } = publicRoute;
            return (
              <Route
                exact={exact}
                path={path}
                key={key}
                render={route => (
                  <PublicPage component={component} route={route} {...props} />
                )}
              />
            );
          })}
          {_.map(privateRoutes, (privateRoute, key) => {
            const { component, path, exact } = privateRoute;
            return (
              <PrivateRoute
                exact={exact}
                path={path}
                key={key}
                render={route => (
                  // props est utilisé dans header
                  <PrivatePage
                    component={component}
                    route={route}
                    loading={!props.userProfile.requestDone}
                    {...props}
                  />
                )}
              />
            );
          })}
        </Switch>
      </Router>
    );
  };

  const PrivateRoute = ({ exact, path, key, render }) => {
    // Default path
    let lRedirect: string = '/onelogin';

    if (props.oneLogin.state === ONELOGIN_LOGGIN_OUT) {
      lRedirect = '/logout';
    } else if (props.oneLogin.state === ONELOGIN_LOGGIN_IN) {
      lRedirect = '/onelogin' + window.location.search;
    } else if (props.cognito.state === CognitoState.LOGGED_IN) {
      lRedirect = '/login';
    }
    if (
      props.cognito.state === CognitoState.LOGGED_IN ||
      props.oneLogin.state === ONELOGIN_LOGGED_IN
    ) {
      return <Route exact={exact} path={path} key={key} render={render} />;
    }
    return <Redirect to={lRedirect} />;
  };

  const MainRoutes = () => {
    return LoadedCognitoRoute();
  };

  return MainRoutes();
};
