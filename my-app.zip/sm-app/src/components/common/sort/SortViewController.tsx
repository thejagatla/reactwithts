import * as React from 'react';
import { SortValues, SortValuesEnum } from '../../../model/sort/SortConstantes';
import { startTimeout } from '../../../utils/EventsUtils';
import { SortView } from './SortView';

interface SortViewControllerProps {
  currentSort: string;
  changeSort(pNewSortValue: string): void;
}

/**
 * Class description: Sort view controller
 * @author Capgemini
 * @version 1.0
 */
export class SortViewController extends React.Component<SortViewControllerProps, any> {

  private sortValuesList: any[] = [
    {
      as: 'button',
      text: SortValues.DATE_TIME,
      value: SortValuesEnum[SortValuesEnum.DATE_TIME]
    },
    {
      as: 'button',
      text: SortValues.PRIORITY,
      value: SortValuesEnum[SortValuesEnum.PRIORITY]
    },
    {
      as: 'button',
      text: SortValues.AC,
      value: SortValuesEnum[SortValuesEnum.AC]
    },
    {
      as: 'button',
      text: SortValues.ATA,
      value: SortValuesEnum[SortValuesEnum.ATA]
    }
  ];

  /**
   * Constructor
   * @param props React props
   */
  constructor(props: SortViewControllerProps) {
    super(props);
    this.changeSort = this.changeSort.bind(this);
  }

  /**
   * Triggers sort change
   * @param pNewSortValue new sort value
   */
  private changeSort(pNewSortValue: string) {
    this.props.changeSort(pNewSortValue);
    startTimeout(true);
  }
  
  /**
   * React lifecycle method
   */
  public render() {
    const { currentSort } = this.props;

    return (
      <SortView
        changeSort={this.changeSort}
        currentSort={currentSort}
        sortValues={this.sortValuesList}
      />
    );
  }
}
