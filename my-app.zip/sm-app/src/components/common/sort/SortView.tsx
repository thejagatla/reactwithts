import * as React from 'react';
import * as Strings from '../../../lang/strings.json';
import { DSDropdown } from '../../storybook/DSDropdown/DSDropdown';

interface SortViewProps {
  currentSort: string;
  changeSort(pNewSortValue: string): void;
  sortValues: any[];
}

/**
 * Class description: Sort view
 * @author Capgemini
 * @version 1.0
 */
export const SortView: React.SFC<SortViewProps> = (props: SortViewProps) => {
  const { changeSort, currentSort, sortValues } = props;

  return (
    <div className="sort-events">
      <DSDropdown
        label={Strings.sortBy}
        options={sortValues}
        value={currentSort}
        onItemClick={changeSort}
        direction="left"
      />
    </div>
  );
};

SortView.displayName = 'SortView';
