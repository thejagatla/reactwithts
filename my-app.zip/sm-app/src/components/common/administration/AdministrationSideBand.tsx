import * as React from 'react';
import { match, NavLink } from 'react-router-dom';
import ModalPageSideBand from '../../presenter/layouts/modalPage/ModalPageSideBand';
import { List } from '../../storybook/List/List';
import CheckAuthorization from '../../utils/authorization/CheckAuthorization';
import CheckFeatureFlipping from '../../utils/featureFlipping/CheckFeatureFlipping';

/**
 * Class description: SideBar display list of link for administration page.
 * Component Type: Business Presenter
 */
const AdministrationSideBand = (matches: match<any>) => {
  const classLink = 'list-menu__link';
  return (
    <ModalPageSideBand>
      <List as="ul" className="list-menu">
        <List.Item as="li">
          <NavLink
            to={`${matches.url}/general`}
            className={classLink}
            activeClassName="is-active"
          >
            General
          </NavLink>
        </List.Item>
        <List.Item as="li">
          {/* <NavLink
            to={`${matches.url}/alerts`}
            className={classLink}
            activeClassName="is-active"
          > */}
          <div className={classLink}>Alerts monitoring</div>
          {/* </NavLink> */}
          <List.List as="ul">
            <CheckFeatureFlipping feature={'custom_priority'}>
              {isActive =>
                isActive && (
                  <CheckAuthorization
                    allowedPermissions={['READ_PRIORITY']}
                    renderNoAccess={() => ''}
                  >
                    <List.Item as="li">
                      <NavLink
                        to={`${matches.url}/health-monitoring`}
                        className={classLink}
                        activeClassName="is-active"
                      >
                        Health Monitoring
                      </NavLink>
                    </List.Item>
                  </CheckAuthorization>
                )
              }
            </CheckFeatureFlipping>
            <CheckAuthorization
              allowedPermissions={['PREDICTIVE']}
              renderNoAccess={() => ''}
            >
              <List.Item as="li">
                <NavLink
                  to={`${matches.url}/predictive-maintenance`}
                  className={classLink}
                  activeClassName="is-active"
                >
                  Predictive Maintenance
                </NavLink>
              </List.Item>
            </CheckAuthorization>
          </List.List>
        </List.Item>
      </List>
    </ModalPageSideBand>
  );
};

export default AdministrationSideBand;
