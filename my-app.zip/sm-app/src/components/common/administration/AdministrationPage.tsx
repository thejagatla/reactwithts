import * as React from 'react';
import { Redirect, Route, Switch } from 'react-router';
import ModalPage from '../../presenter/layouts/modalPage/ModalPage';
import CheckAuthorization from '../../utils/authorization/CheckAuthorization';
import WithAuthorization from '../../utils/authorization/WithAuthorization';
import CheckFeatureFlipping from '../../utils/featureFlipping/CheckFeatureFlipping';
import AdministrationSideBand from './AdministrationSideBand';
import SHMPrioritiesController from './alertmonitoring/healthmonitoring/SHMPrioritiesController';

/**
 * @name AdministrationPage
 * @description Composes the structure of the administration page.
 * @type [Business Presenter]
 */
const AdministrationPage = ({ route }) => {
  /**
   * TODO: delete this function when ModalPage will be displayed like ribbon menu.
   */
  const handleModalClose = (event: React.MouseEvent<HTMLElement>) => {
    event.preventDefault();
    route.history.push('/');
  };

  return (
    <ModalPage title="Settings" onClose={handleModalClose}>
      <AdministrationSideBand {...route.match} />
      <Switch>
        <CheckFeatureFlipping feature={'custom_priority'}>
          {isActive =>
            isActive && (
              <CheckAuthorization
                allowedPermissions={['READ_PRIORITY']}
                renderNoAccess={() => ''}
              >
                <Route
                  path={`${route.match.url}/health-monitoring`}
                  component={SHMPrioritiesController}
                />
              </CheckAuthorization>
            )
          }
        </CheckFeatureFlipping>
      </Switch>
    </ModalPage>
  );
};

export default WithAuthorization(['ADMIN_PAGE'], () => <Redirect to="/" />)(
  AdministrationPage
);
