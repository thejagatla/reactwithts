import { DSBanner, DSButton } from '@sm/skywise-react-library';
import * as React from 'react';
import { ModalManager } from 'react-dynamic-modal';
import { Redirect } from 'react-router';
import { AdministrationController } from '../../../../../controllers/AdministrationController';
import { store } from '../../../../../store/configureStore';
import { getIdToken } from '../../../../../utils/AuthenticationUtils';
import { startTimeout } from '../../../../../utils/EventsUtils';
import { closeModal } from '../../../../../utils/ModalsUtils';
import WithAuthorization from '../../../../utils/authorization/WithAuthorization';
import { ExportPrioritiesViewController } from './ExportPrioritiesViewController';
import { ImportPrioritiesViewController } from './ImportPrioritiesViewController';

import ModalPageContent from '../../../../presenter/layouts/modalPage/ModalPageContent';

import { ButtonGroup } from '../../../../storybook/ButtonGroup';

import * as Strings from '../../../../../lang/strings.json';
import { SkywiseBannerTYPES } from '../../../../storybook';
import {
  SIFileDownloadOutline,
  SIFileUploadOutline
} from '../../../../storybook/skywiseIcons';

interface AlertMessage {
  priorityFileUploadStatus: SkywiseBannerTYPES;
  priorityFileUploadMessage: string;
  priorityFileUploadTitle: string;
}
interface SHMPrioritiesControllerState {
  alertMessages: AlertMessage[];
}

/**
 * @name SHMPrioritiesController
 * @description  SHM priorities page
 * @example
 */
export class SHMPrioritiesController extends React.Component<
  any,
  SHMPrioritiesControllerState
> {
  /**
   * Constructor
   * @param props React props
   */
  public constructor(props: any) {
    super(props);
    this.state = {
      alertMessages: []
    };
    this.closeModal = this.closeModal.bind(this);
    this.exportPriorities = this.exportPriorities.bind(this);
    this.importPriorityFile = this.importPriorityFile.bind(this);
    this.openExportPrioritiesModal = this.openExportPrioritiesModal.bind(this);
    this.openImportPriorityFileModal = this.openImportPriorityFileModal.bind(
      this
    );
  }

  /**
   * Close modal
   */
  private closeModal(): void {
    startTimeout();
    closeModal();
  }

  /**
   * Export priorities
   * @param pAirline airline
   * @param pAircraftFamily aircraft family
   */
  private exportPriorities(pAirline: string, pAircraftFamily: string): void {
    const lApiUrl: string = '/api/priorities';
    const lIdToken: string = getIdToken();

    // Launch export process
    AdministrationController.exportPrioritiesFile(
      lApiUrl,
      pAirline,
      pAircraftFamily,
      lIdToken
    )
      .then((response: any) => {
        const lExportFilename: string = response.headers
          .get('Content-Disposition')
          .split('filename=')[1];
        response.blob().then(blob => {
          const lBlob: Blob = new Blob([blob], { type: 'text/plain' });
          const lUrl: string = window.URL.createObjectURL(lBlob);
          const a = document.createElement('a');
          a.href = lUrl;
          a.download = lExportFilename;
          a.click();

          // Close modal
          this.closeModal();
        });
      })
      .catch(error => {
        // Close modal
        this.closeModal();

        console.error('Unable to export priorities file', error);
      });
  }

  /**
   * Open export priorities modal
   */
  private openExportPrioritiesModal(): void {
    const storedValues: any = store.getState();

    ModalManager.open(
      <ExportPrioritiesViewController
        aircraftFamilies={['SA', 'LR']}
        airlines={storedValues.userProfile.airlines}
        closeModal={this.closeModal}
        exportPriorities={this.exportPriorities}
      />
    );
  }

  /**
   * Open import priorities file modal
   */
  private openImportPriorityFileModal(): void {
    const storedValues: any = store.getState();

    ModalManager.open(
      <ImportPrioritiesViewController
        aircraftFamilies={['SA', 'LR']}
        airlines={storedValues.userProfile.airlines}
        closeModal={this.closeModal}
        importPriorityFile={this.importPriorityFile}
      />
    );
  }

  /**
   * Launch import priorities file process
   * @param pAirline airline
   * @param pAircraftFamily aircraft family
   * @param pFiles File to upload
   */
  private importPriorityFile(
    pAirline: string,
    pAircraftFamily: string,
    pFiles: FileList
  ): void {
    const lUploadFile: File = pFiles[0];
    const lIdToken: string = getIdToken();
    const checkPriorityFile = this.checkPriorityFile(lUploadFile);

    if (checkPriorityFile !== null) {
      this.popupMessage('error', checkPriorityFile, 'Error');
      this.closeModal();
    } else {
      AdministrationController.uploadImportPrioritiesFile(
        pAirline,
        pAircraftFamily,
        lUploadFile,
        lIdToken
      )
        .then(response => {
          this.closeModal();
          this.popupMessage(
            'success',
            Strings.priorityFileSuccessfully,
            'Success'
          );
        })
        .catch(error => {
          this.manageImportPriorityError(error);
          this.closeModal();
        });
    }
  }

  /**
   * Close the message banner.
   * @param pMessageIndex Index of the message in the message list.
   */
  private closeMessage(pMessageIndex: number): void {
    const newAlertMessages = [...this.state.alertMessages];
    newAlertMessages.splice(pMessageIndex, 1);
    this.setState({
      alertMessages: newAlertMessages
    });
  }

  /**
   * Pop up the message banner.
   * @param pStatus Error or success banner.
   * @param pMessage Message in the banner.
   * @param pTitle Title of the banner.
   */
  private popupMessage(
    pStatus: SkywiseBannerTYPES,
    pMessage: string,
    pTitle: string
  ): void {
    const newAlertMessages = [...this.state.alertMessages];
    const alertMessage: AlertMessage = {
      priorityFileUploadMessage: pMessage,
      priorityFileUploadStatus: pStatus,
      priorityFileUploadTitle: pTitle
    };
    newAlertMessages.push(alertMessage);
    this.setState({
      alertMessages: newAlertMessages
    });
  }

  /**
   * Manage feedback message from priority importing API.
   * @param error Error response received.
   */
  private manageImportPriorityError(pError: Response): void {
    const error = pError.json();
    error.then(errorValue => {
      if (errorValue.exception != null) {
        this.popupMessage('error', errorValue.exception.message, 'Error');
      }
    });
  }

  /**
   * Check if the uploading file is acceptable.
   * @param pFile uploading file
   */
  private checkPriorityFile(pFile: File): string {
    // check file extension
    const nameRegrex = RegExp('/*.txt');
    if (!nameRegrex.test(pFile.name)) {
      return Strings.priorityFileBadExtension;
    }

    // check file size
    const fileSize = pFile.size / 1024 ** 2;
    if (fileSize > 10) {
      return Strings.priorityFileExceed10mb;
    }

    return null;
  }

  /**
   * Return alert message elements those are rendered in the page.
   */
  private alertMessages(): JSX.Element {
    const alertMessageElements = this.state.alertMessages.map(
      (alertMessage, alertMessageIndex) => {
        return (
          <DSBanner
            key={alertMessageIndex}
            type={alertMessage.priorityFileUploadStatus}
            title={alertMessage.priorityFileUploadTitle}
            id={'import-priority-message-' + alertMessageIndex}
            withCloseButton={true}
            center={false}
            handleClose={() => this.closeMessage(alertMessageIndex)}
          >
            {alertMessage.priorityFileUploadMessage}
          </DSBanner>
        );
      }
    );

    return <div className="alert-message">{alertMessageElements}</div>;
  }
  /**
   * Render method
   */
  public render() {
    return (
      <ModalPageContent
        actions={
          <ButtonGroup>
            <DSButton
              size="medium"
              icon={<SIFileUploadOutline className="ds-icon" />}
              content="Export"
              isSubmit={true}
              disabled={false}
              handleClick={this.openExportPrioritiesModal}
            />
            <DSButton
              size="medium"
              icon={<SIFileDownloadOutline className="ds-icon" />}
              content="Import"
              isSubmit={true}
              disabled={false}
              handleClick={this.openImportPriorityFileModal}
            />
          </ButtonGroup>
        }
        title="Manage Airlines Priority"
      >
        {this.alertMessages()}
      </ModalPageContent>
    );
  }
}

export default WithAuthorization(['READ_PRIORITY'], () => <Redirect to="/" />)(
  SHMPrioritiesController
);
