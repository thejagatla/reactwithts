import { DSButton, DSModal } from '@sm/skywise-react-library';
import * as _ from 'lodash';
import * as React from 'react';
import InputFile from '../../../../storybook/InputFile';
import Select, { SelectOption } from '../../../../storybook/Select';

interface ImportPrioritiesState {
  aircraftFamily: string;
  airline: string;
  file: FileList;
}

interface ImportPrioritiesProps {
  aircraftFamilies: string[];
  airlines: string[];
  closeModal(): void;
  importPriorityFile(
    pAirline: string,
    pAircraftFamily: string,
    pFile: FileList
  ): void;
}

/**
 * Import priorities file class
 */
export class ImportPrioritiesViewController extends React.Component<
  ImportPrioritiesProps,
  ImportPrioritiesState
> {
  /**
   * Constructor
   * @param props React props
   */
  public constructor(props: ImportPrioritiesProps) {
    super(props);

    this.state = {
      aircraftFamily: props.aircraftFamilies[0],
      airline: props.airlines[0],
      file: null
    };

    this.handleSubmit = this.handleSubmit.bind(this);
    this.updateAircraftFamily = this.updateAircraftFamily.bind(this);
    this.updateAirline = this.updateAirline.bind(this);
    this.updateFile = this.updateFile.bind(this);
  }

  /**
   * Update aircraft family
   * @param pEvent event
   */
  private updateAircraftFamily(pEvent: any) {
    pEvent.preventDefault();

    this.setState({
      aircraftFamily: pEvent.target.value
    });
  }

  /**
   * Update airline
   * @param pEvent event
   */
  private updateAirline(pEvent: any) {
    pEvent.preventDefault();

    this.setState({
      airline: pEvent.target.value
    });
  }

  /**
   * Update file
   * @param pEvent event
   */
  private updateFile(pEvent: any) {
    pEvent.preventDefault();
    console.log(pEvent.target.files);
    console.log(pEvent.target.values);

    this.setState({
      file: pEvent.target.files
    });
  }

  /**
   * Handle click on Confirm button
   * @param pEvent event
   */
  private handleSubmit(pEvent: any) {
    pEvent.preventDefault();

    // Call import priorities
    this.props.importPriorityFile(
      this.state.airline,
      this.state.aircraftFamily,
      this.state.file
    );
  }

  /**
   * Get modal body
   * @return modal body
   */
  private getModalContent(): JSX.Element {
    const lAirlineOptions: SelectOption[] = _.map(
      this.props.airlines,
      (airline: string, id: number) => {
        return {
          label: airline,
          value: airline
        };
      }
    );

    const lAircraftFamilyOptions: SelectOption[] = _.map(
      this.props.aircraftFamilies,
      (aircraftFamily: string, id: number) => {
        return {
          label: aircraftFamily,
          value: aircraftFamily
        };
      }
    );

    return (
      <React.Fragment>
        <Select
          id="airline-options"
          label="Airline"
          handleChange={this.updateAirline}
          options={lAirlineOptions}
        />
        <Select
          id="aircraft-family-options"
          label="Aircraft familly"
          handleChange={this.updateAircraftFamily}
          options={lAircraftFamilyOptions}
        />
        <InputFile
          id="prority-file"
          label="File name"
          className="form-file"
          handleChange={e => this.updateFile(e)}
        />
      </React.Fragment>
    );
  }

  /**
   * Get modal footer
   * @return modal footer
   */
  private getModalFooter(): JSX.Element {
    return (
      <DSButton
        type="primary"
        content="Confirm"
        isSubmit={true}
        disabled={false}
        handleClick={() => null}
      />
    );
  }

  /**
   * React method
   */
  public render(): JSX.Element {
    return (
      <DSModal
        className="priorities-modal"
        size="480px"
        id="import-priorities-modal"
        modalTitle="Import priority configuration file"
        withHeaderIntro={false}
        onRequestClose={this.props.closeModal}
        withForm={true}
        withFooterBackground={true}
        onSubmit={this.handleSubmit}
        modalContent={this.getModalContent()}
        modalFooter={this.getModalFooter()}
      />
    );
  }
}
