import { DSButton, DSModal } from '@sm/skywise-react-library';
import * as _ from 'lodash';
import * as React from 'react';
import Select, { SelectOption } from '../../../../storybook/Select';

interface ExportPrioritiesState {
  aircraftFamily: string;
  airline: string;
}

interface ExportPrioritiesProps {
  aircraftFamilies: string[];
  airlines: string[];
  closeModal(): void;
  exportPriorities(pAirline: string, pAircraftFamily: string): void;
}

/**
 * Export priorities file class
 */
export class ExportPrioritiesViewController extends React.Component<
  ExportPrioritiesProps,
  ExportPrioritiesState
> {
  /**
   * Constructor
   * @param props React props
   */
  public constructor(props: ExportPrioritiesProps) {
    super(props);
    this.state = {
      aircraftFamily: props.aircraftFamilies[0],
      airline: props.airlines[0]
    };

    this.handleSubmit = this.handleSubmit.bind(this);
    this.updateAircraftFamily = this.updateAircraftFamily.bind(this);
    this.updateAirline = this.updateAirline.bind(this);
  }

  /**
   * Handle click on Confirm button
   * @param pEvent event
   */
  private handleSubmit(pEvent: any) {
    pEvent.preventDefault();

    // Call export priorities
    this.props.exportPriorities(this.state.airline, this.state.aircraftFamily);
  }

  /**
   * Update aircraft family
   * @param pEvent event
   */
  private updateAircraftFamily(pEvent: any) {
    pEvent.preventDefault();

    this.setState({
      aircraftFamily: pEvent.target.value
    });
  }

  /**
   * Update airline
   * @param pEvent event
   */
  private updateAirline(pEvent: any) {
    pEvent.preventDefault();

    this.setState({
      airline: pEvent.target.value
    });
  }

  /**
   * Get modal body
   * @return modal body
   */
  private getModalContent(): JSX.Element {
    const lAirlineOptions: SelectOption[] = _.map(
      this.props.airlines,
      (airline: string, id: number) => {
        return {
          label: airline,
          value: airline
        };
      }
    );

    const lAircraftFamilyOptions: SelectOption[] = _.map(
      this.props.aircraftFamilies,
      (aircraftFamily: string, id: number) => {
        return {
          label: aircraftFamily,
          value: aircraftFamily
        };
      }
    );

    return (
      <React.Fragment>
        <Select
          id="airline-options"
          label="Airline"
          handleChange={this.updateAirline}
          options={lAirlineOptions}
        />
        <Select
          id="aircraft-family-options"
          label="Aircraft familly"
          handleChange={this.updateAircraftFamily}
          options={lAircraftFamilyOptions}
        />
      </React.Fragment>
    );
  }

  /**
   * Get modal footer
   * @return modal footer
   */
  private getModalFooter(): JSX.Element {
    return (
      <DSButton
        type="primary"
        content="Confirm"
        isSubmit={true}
        disabled={false}
        handleClick={() => null}
      />
    );
  }

  /**
   * React method
   */
  public render(): JSX.Element {
    return (
      <DSModal
        className="priorities-modal"
        size="480px"
        id="export-priorities-modal"
        modalTitle="Export priorities"
        withHeaderIntro={false}
        onRequestClose={this.props.closeModal}
        withForm={true}
        withFooterBackground={true}
        onSubmit={this.handleSubmit}
        modalContent={this.getModalContent()}
        modalFooter={this.getModalFooter()}
      />
    );
  }
}
