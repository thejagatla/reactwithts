/**
 * Class description: Header React component
 * @author Capgemini
 * @version 1.0
 */
import * as React from 'react';
import { MdMenu, MdSettings } from 'react-icons/md';
import { DSDropdown } from '../../storybook/DSDropdown/DSDropdown';
import SkywiseLogo from '../../storybook/logo/SkywiseLogo';
import CheckFeatureFlipping from '../../utils/featureFlipping/CheckFeatureFlipping';

import { List } from '../../storybook/List/List';

import { Link } from 'react-router-dom';

import CheckAuthorization from '../../utils/authorization/CheckAuthorization';

export const HeaderView = props => {
  const actionsList: any = [];
  props.actions.map(action => {
    actionsList.push({
      text: action.label,
      value: action.valueKey
    });
  });

  return (
    <div className="appbar">
      <CheckFeatureFlipping feature={'navigation_panel'}>
        {isActive =>
          isActive && (
            <div className="appbar__burger" onClick={props.handleClickBurger}>
              <MdMenu size="1.6rem" />
              Menu
            </div>
          )
        }
      </CheckFeatureFlipping>
      <div className="appbar__content">
        <div className="appbar__logo">
          <SkywiseLogo width={124} height={32} />
          {/* <img src="/img/skywise-left.png" alt="Skywise" /> */}
        </div>
        <h1 className="appbar__title">{props.title}</h1>
        <CheckAuthorization
          allowedPermissions={['ADMIN_PAGE']}
          renderNoAccess={() => ''}
        >
          <div className="appbar__quick-access">
            <List className="list--horizontal">
              <List.Item>
                <Link to="/administration/general">
                  <MdSettings size="18px" />
                </Link>
              </List.Item>
            </List>
          </div>
        </CheckAuthorization>
        {props.userMenu && (
          <div id="user-menu" className="appbar__menu">
            <DSDropdown
              options={actionsList}
              text={props.userProps.username}
              className="user-menu__username"
              negative={true}
              direction="left"
            />
          </div>
        )}
      </div>
    </div>
  );
};
