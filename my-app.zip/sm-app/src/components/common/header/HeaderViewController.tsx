import * as React from 'react';
import { CognitoState, Logout } from 'react-cognito';
import { withRouter } from 'react-router';
import * as Strings from '../../../lang/strings.json';
import * as types from '../../../store/actions/LoginActions';
import CheckAuthorization from '../../utils/authorization/CheckAuthorization';
import { HeaderView } from './HeaderView';

/**
 * Class description: Header view controller
 * @author Capgemini
 * @version 1.0
 */
class HeaderViewController extends React.Component<any, any> {
  /**
   * Constructor
   * @param props props
   */
  constructor(props: any) {
    super(props);
    this.handleClickBurger = this.handleClickBurger.bind(this);
    this.handleLogoutClick = this.handleLogoutClick.bind(this);
    this.handleAdministrationPageClick = this.handleAdministrationPageClick.bind(
      this
    );
  }

  private handleLogoutClick(pEvent: React.MouseEvent<HTMLElement>): void {
    pEvent.preventDefault();
    this.props.oneLoginLogout();
  }

  private handleAdminPageClick(pEvent: React.MouseEvent<HTMLElement>): void {
    pEvent.preventDefault();
    const adminPageLink = encodeURI('/admin');
    window.open(adminPageLink, '_blank');
  }

  // private handleModelTrendsClick(pEvent: React.MouseEvent<HTMLElement>): void {
  //   pEvent.preventDefault();
  //   const modelTrendsLink = encodeURI('/trends');
  //   window.open(modelTrendsLink, '_blank');
  // }

  /**
   * Generate logout action.
   * @param list The list needed to be updated by logout item menu.
   */
  public getLogoutAction(list: any[]): void {
    let lLabel;
    if (
      this.props.cognito &&
      this.props.cognito.state === CognitoState.LOGGED_IN
    ) {
      lLabel = (
        <Logout>
          <div>{Strings.header.rightMenuLogout}</div>
        </Logout>
      );
    } else if (this.props.oneLogin.state === types.ONELOGIN_LOGGED_IN) {
      lLabel = (
        <div onClick={this.handleLogoutClick}>
          {Strings.header.rightMenuLogout}
        </div>
      );
    }

    if (lLabel) {
      list.push({
        action: () => '',
        label: lLabel,
        valueKey: 'Logout'
      });
    }
  }

  /**
   * Generate Help center action.
   * @param list The list needed to be updated
   */
  private getHelpCenterAction(list: any[]): void {
    const helpCenterLabel = (
      <div
        onClick={e => {
          e.preventDefault();
          window.open(
            'https://w3.airbus.com/crs/A233_Strategic_dev/Predictive_Maintenance/customer/enduser/index.html',
            '_blank'
          );
        }}
      >
        {Strings.header.rightMenuHelp}
      </div>
    );

    list.push({
      action: () => '',
      label: helpCenterLabel,
      valueKey: 'Help centre'
    });
  }

  private getAdminPageAction(list: any[]): void {
    if (
      (this.props.cognito &&
        this.props.cognito.state === CognitoState.LOGGED_IN) ||
      this.props.oneLogin.state === types.ONELOGIN_LOGGED_IN
    ) {
      list.push({
        action: () => '',
        label: (
          <CheckAuthorization
            allowedPermissions={['SPM_ADMINISTRATOR']}
            renderNoAccess={() => ''}
          >
            <div onClick={this.handleAdminPageClick}>
              {Strings.header.rightMenuPredictiveAdmin}
            </div>
          </CheckAuthorization>
        ),
        valueKey: 'spmadmin'
      });
    }
  }

  private getPrivatePolicy(list: any[]): void {
    list.push({
      action: () => '',
      label: (
        <div
          onClick={() => {
            window.open('http://www.airbus.com/privacy-policy.html', '_blank');
          }}
        >
          {Strings.header.rightMenuPrivacyPolicy}
        </div>
      ),
      valueKey: 'privatepolicy'
    });
  }

  private handleAdministrationPageClick(
    pEvent: React.MouseEvent<HTMLElement>
  ): any {
    pEvent.preventDefault();
    this.props.history.push('/administration');
  }

  private handleClickBurger(event: React.MouseEvent<HTMLElement>): any {
    event.preventDefault();
    this.props.updateVisibility(!this.props.visibilityPanel);
  }

  // private getModelTrendsAction(list: any[]): void {
  //   let lLabel;
  //   if (this.props.cognito && this.props.cognito.state === CognitoState.LOGGED_IN) {
  //     lLabel = (
  //       <div onClick={this.handleModelTrendsClick}>
  //       Trends
  //     </div>
  //     );
  //   } else if (this.props.oneLogin.state === types.ONELOGIN_LOGGED_IN) {
  //     lLabel = (
  //       <div onClick={this.handleModelTrendsClick}>
  //         Trends
  //       </div>
  //     );
  //   }
  //   if (lLabel) {
  //     list.push({
  //       action: () => '',
  //       label: lLabel,
  //       valueKey: 'Trends'
  //     });
  //   }
  // }

  /**
   * Get the user information according to the type of connection.
   * @returns user object.
   */
  private getUserProps() {
    const user: { username: string } = { username: '' };
    if (
      this.props.cognito &&
      this.props.cognito.state === CognitoState.LOGGED_IN
    ) {
      user.username = this.props.cognito.user.username;
    } else if (this.props.oneLogin.state === types.ONELOGIN_LOGGED_IN) {
      user.username = this.props.oneLogin.username;
    }
    return user;
  }

  /**
   * Rendering method
   */
  public render() {
    const actionsList: any = [];
    let userMenu = false;

    this.getHelpCenterAction(actionsList);
    this.getAdminPageAction(actionsList);
    this.getPrivatePolicy(actionsList);
    this.getLogoutAction(actionsList);
    // this.getModelTrendsAction(actionsList);
    if (actionsList.length) {
      userMenu = true;
    }

    const user = this.getUserProps();

    return (
      <HeaderView
        userMenu={userMenu}
        actions={actionsList}
        userProps={user}
        title={Strings.header.title}
        handleClickBurger={this.handleClickBurger}
      />
    );
  }
}

export default withRouter(HeaderViewController);
