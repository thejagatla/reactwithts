import { DSHeading } from '@sm/skywise-react-library';
import * as React from 'react';
import EventsContainer from '../../../store/containers/events/EventsContainer';
import FiltersContainer from '../../../store/containers/filters/FiltersContainer';
import SearchContainer from '../../../store/containers/search/SearchContainer';
import SortContainer from '../../../store/containers/sort/SortContainer';
import { FilterablePage } from '../../presenter/layouts/FilterablePage';

interface EventCockpitProps {
  totalEvents: number;
}

/**
 * Class description: Composes the structure of the cockpit event page.
 *
 * Component Type: Business Presenter
 */
export const EventCockpit: React.SFC<EventCockpitProps> = (
  props: EventCockpitProps
) => {
  const { totalEvents } = props;

  return (
    <FilterablePage
      filters={<FiltersContainer />}
      title={
        <DSHeading
          as="h1"
          like="h3"
          className="search-title"
          id="d-events-number"
        >
          <span className="search-title__number">{totalEvents}</span>&nbsp;event
          {totalEvents > 1 && 's'}
        </DSHeading>
      }
      search={<SearchContainer />}
      sort={<SortContainer />}
    >
      <EventsContainer />
    </FilterablePage>
  );
};
