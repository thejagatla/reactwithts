import * as _ from 'lodash';
import * as React from 'react';
import { MdMultilineChart, MdPlaylistAddCheck } from 'react-icons/md';
import { UrlsConfigController } from '../../../controllers/UrlsConfigController';
import * as Strings from '../../../lang/strings.json';
import SkywiseLogo from '../../storybook/logo/SkywiseLogo';
import { Ribbon } from '../../storybook/ribbon/Ribbon';
import { RibbonItem } from '../../storybook/ribbon/RibbonItem';
import { RibbonNavigation } from '../../storybook/ribbon/RibbonNavigation';

const URLS_CONFIG_URL = '/conf/urls/urls.json';

interface ComponentNavigationPanelState {
  links: string[];
}

/**
 * @name ComponentNavigationPanel
 * @description Retrieves the list of Skywise components links to insert them into the ribbon.
 * @type [Business Controller]
 */
class ComponentNavigationPanel extends React.Component<
  any,
  ComponentNavigationPanelState
> {
  /**
   * Constructor
   * @param props props
   */
  public constructor(props: any) {
    super(props);
    this.state = {
      links: []
    };
    this.handleClose = this.handleClose.bind(this);
  }

  public componentDidMount(): void {
    UrlsConfigController.getUrlsConfig(URLS_CONFIG_URL)
      .then((response: any) => {
        const urls = response;
        this.setState({
          links: urls
        });
      })
      .catch(error => {
        console.error('Exception getting urls config', error);
      });
  }

  private handleClose(e: React.SyntheticEvent<HTMLElement>): void {
    e.preventDefault();
    this.props.updateVisibility(false);
  }

  public render() {
    const { links } = this.state;
    if (!_.isNil(links)) {
      return (
        <Ribbon
          open={this.props.visibilityPanel}
          onClose={this.handleClose}
          logo={<SkywiseLogo width={124} />}
        >
          <RibbonNavigation>
            <RibbonItem
              target="/"
              active={true}
              text={Strings.ribbon.alertsMonitoring}
              icon={<MdPlaylistAddCheck className="ribbon-icon" />}
            />
            {links['srsUrl'] && (
              <RibbonItem
                href={links['srsUrl']}
                text={Strings.ribbon.fleetMetrics}
                icon={<MdMultilineChart className="ribbon-icon" />}
              />
            )}
          </RibbonNavigation>
        </Ribbon>
      );
    }
    return null;
  }
}

export default ComponentNavigationPanel;
