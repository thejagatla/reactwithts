import { DSButton, DSHelp, DSIcon } from '@sm/skywise-react-library';
import * as React from 'react';
import { SearchHelpView } from '../help/SearchHelpView';
import { SearchAutocomplete } from './SearchAutocomplete';

const searchDropdownMenuStyle = { minWidth: '480px', position: 'absolute', zIndex: '10' };

interface SearchViewProps {
  activeClass: string;
  searchClass: string;
  handleSearchKeyPress(pEvent: KeyboardEvent): void;
  searchText: string;
  removeClass: string;
  tooltipSearch: string;
  tooltipRemove: string;
  filterText(pEvent: any): void;
  submitTextSearch(): void;
  removeTextSearch(): void;
  setText(pText: string): void;
  suggestions: any;
  totalEvents: number;
  setSuggestions(pValue: any): void;
}

/**
 * Class description: React events component
 * @author Capgemini
 * @version 1.0
 */
export const SearchView: React.SFC<SearchViewProps> = (props: SearchViewProps) => {

  return (
    <React.Fragment>
      <div className="search-form" id="f-search">
        <SearchAutocomplete
          setText={props.setText}
          filterText={props.filterText}
          onChange={props.filterText}
          name="textFilter"
          value={props.searchText}
          className={props.searchClass}
          menuStyle={searchDropdownMenuStyle}
          onKeyPress={props.handleSearchKeyPress}
          activeClass={props.activeClass}
          suggestions={props.suggestions}
          setSuggestions={props.setSuggestions}
        />
        <span
          className={props.searchClass}
          onClick={props.submitTextSearch}
          title={props.tooltipSearch}
        />
        <DSButton
          icon={<DSIcon type="close" />}
          handleClick={props.removeTextSearch}
          className={props.removeClass}
          label={props.tooltipRemove}
        />
      </div>
      <DSHelp
        title="Search Help"
        content={<SearchHelpView />}
        size="700px"
      />
    </React.Fragment>
  );
};

SearchView.displayName = 'SearchView';
