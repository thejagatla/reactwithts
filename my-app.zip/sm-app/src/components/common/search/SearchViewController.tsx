/**
 * Class description: Events view controller
 * @author Capgemini
 * @version 1.0
 */
import * as React from 'react';
import 'react-virtualized/styles.css';
import { startTimeout } from '../../../utils/EventsUtils';
import { SearchView } from './SearchView';

const minimumSearchLength = 1;
const removeFormClass = 'search-form__remove';
const searchFormClass = 'search-form__launch';

export class SearchViewController extends React.Component<any, any> {
  /**
   * Constructor
   * @param props props
   */
  constructor(props: any) {
    super(props);

    this.state = {
      activeClass: '',
      removeClass: removeFormClass + ' ' + removeFormClass + '--hidden',
      searchClass: searchFormClass,
      searchLaunched: false,
      searchText: '',
      suggestions: [],
      tooltipRemove: '',
      tooltipSearch: ''
    };
    this.filterText = this.filterText.bind(this);
    this.handleSearchKeyPress = this.handleSearchKeyPress.bind(this);
    this.submitTextSearch = this.submitTextSearch.bind(this);
    this.removeTextSearch = this.removeTextSearch.bind(this);
    this.setText = this.setText.bind(this);
    this.setSuggestions = this.setSuggestions.bind(this);
  }

  public componentDidMount() {
    if (this.props.searchText !== '') {
      this.setState({
        activeClass: 'active',
        removeClass: removeFormClass + ' ' + removeFormClass + '--active',
        searchClass: searchFormClass,
        searchText: this.props.searchText,
        tooltipRemove: 'Remove',
        tooltipSearch: 'Search'
      });
    }
  }

  public shouldComponentUpdate(nextProps: any, nextState: any) {
    if (this.state !== nextState || this.props !== nextProps) {
      return true;
    }
    return false;
  }

  /**
   * Apply search filter
   * @param event event
   */
  public filterText(event: any) {
    const target = event.target;
    let value: string = '';
    if (target.value) {
      value = target.value;
    } else {
      value = target.id.substring(0, target.id.length - 5);
    }

    this.setState({
      searchText: value
    });
    if (value.length >= minimumSearchLength) {
      this.setState({
        activeClass: 'active',
        removeClass: removeFormClass + ' ' + removeFormClass + '--active',
        searchClass: searchFormClass,
        tooltipRemove: 'Remove',
        tooltipSearch: 'Search'
      });
    } else {
      this.setState({
        activeClass: '',
        removeClass: removeFormClass + ' ' + removeFormClass + '--hidden',
        searchClass: removeFormClass,
        tooltipRemove: '',
        tooltipSearch: ''
      });
      if (this.state.searchLaunched && value.length === 0) {
        this.props.setSearchText('');
        startTimeout(true);
      }
    }
  }

  /**
   * Submit text search
   */
  public submitTextSearch() {
    this.setState({ searchLaunched: true });
    this.props.setSearchText(this.state.searchText);
    startTimeout(true);
  }

  /**
   * Remove text search
   */
  public removeTextSearch() {
    this.props.setSearchText('');
    startTimeout(true);
    this.setState({
      activeClass: '',
      removeClass: removeFormClass + ' ' + removeFormClass + '--hidden',
      searchClass: searchFormClass,
      searchLaunched: false,
      searchText: ''
    });
  }

  /**
   * Key pressed event
   * @param target event
   */
  public handleSearchKeyPress(target: KeyboardEvent) {
    if (target.charCode === 13) {
      if (this.state.searchText.length >= minimumSearchLength) {
        this.submitTextSearch();
      }
    }
  }

  /**
   * Key pressed event
   * @param target event
   */
  public setText(value: string) {
    this.setState({
      searchText: value
    });
  }

  public setSuggestions(value: any) {
    this.setState({
      suggestions: value
    });
  }

  /**
   * Rendering method
   */
  public render() {
    return (
      <SearchView
        searchClass={this.state.searchClass}
        activeClass={this.state.activeClass}
        handleSearchKeyPress={this.handleSearchKeyPress}
        searchText={this.state.searchText}
        removeClass={this.state.removeClass}
        tooltipSearch={this.state.tooltipSearch}
        tooltipRemove={this.state.tooltipRemove}
        filterText={this.filterText}
        submitTextSearch={this.submitTextSearch}
        removeTextSearch={this.removeTextSearch}
        setText={this.setText}
        suggestions={this.state.suggestions}
        totalEvents={this.props.totalEvents}
        setSuggestions={this.setSuggestions}
      />
    );
  }
}
