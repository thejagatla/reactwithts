import * as React from 'react';
import * as Autosuggest from 'react-autosuggest';

export const SearchAutocomplete = (props) => {
  const inputProps: any = {
    className: 'search-form__input ' + props.activeClass,
    onChange: props.filterText,
    onKeyPress: props.onKeyPress,
    placeholder: 'Search',
    type: 'search',
    value: props.value
  };
  const isHighlightColor = '#E0E3E9';
  const suggestions = [
    { label: 'ata' },
    { label: 'registrationNumber' },
    { label: 'aircraftType' },
    { label: 'eventType' },
    { label: 'flightNumber' },
    { label: 'priority' },
    { label: 'eventDate' },
    { label: 'eventTitle' },
    { label: 'viewMEL' },
    { label: 'source' },
    { label: 'workflowStatus' },
    { label: 'workRef' },
    { label: 'workComment' },
    { label: 'workAuthor' },
    { label: 'nickName' },
    { label: 'displayed' }
  ];

  const getSuggestions = (value) => {
    const inputValue = value.trim().toLowerCase();
    const inputLength = inputValue.length;

    return inputLength === 0 ? [] : suggestions.filter(lang =>
      lang.label.toLowerCase().slice(0, inputLength) === inputValue
    );
  };

  const renderSuggestions = (suggestion, { query, isHighlighted }) => {
    return (
      <div
        key={suggestion.label}
        style={{ background: isHighlighted ? isHighlightColor : 'white', padding: '0px 0px 0px 8px' }}
        id={suggestion.label + 'Label'}
      >
        {suggestion.label}
      </div>
    );
  };

  return (
    <Autosuggest
      getSuggestionValue={suggestion => suggestion.label}
      suggestions={props.suggestions}
      renderSuggestion={renderSuggestions}
      renderSuggestionsContainer={({ containerProps, children }) => (
        <div style={props.menuStyle} id="searchDropdownMenu" {...containerProps}>
          {children}
        </div>
      )}
      onSuggestionSelected={(event, { suggestionValue, method }) => {
        event.preventDefault();
        props.setText(suggestionValue + ':');
      }}
      onSuggestionsFetchRequested={({ value }) => props.setSuggestions(getSuggestions(value))}
      onSuggestionsClearRequested={() => props.setSuggestions([])}
      shouldRenderSuggestions={(value) => {
        return value.trim().length >= 3;
      }}
      inputProps={inputProps}
    />
  );
};
