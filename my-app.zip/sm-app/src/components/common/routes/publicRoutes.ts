import LoginContainer from '../../../store/containers/login/LoginContainer';
import OneLoginContainer from '../../../store/containers/login/OneLoginContainer';
import OneLoginLogoutContainer from '../../../store/containers/login/OneLoginLogoutContainer';
import PasswordChange from '../login/PasswordChange';
import PasswordReset from '../login/PasswordReset';

export default {
  Login: {
    component: LoginContainer,
    exact: true,
    path: '/login'
  },
  Logout: {
    component: OneLoginLogoutContainer,
    exact: true,
    path: '/logout'
  },
  OneLogin: {
    component: OneLoginContainer,
    exact: true,
    path: '/onelogin'
  },
  PasswordChange: {
    component: PasswordChange,
    exact: true,
    path: '/change-password'
  },
  PasswordReset: {
    component: PasswordReset,
    exact: true,
    path: '/reset'
  }  
};
