import EventCockpitContainer from '../../../store/containers/cockpit/EventCockpitContainer';
import ShmEventDetailsContainer from '../../../store/containers/eventDetails/ShmEventDetailsContainer';
import SpmEventDetailsContainer from '../../../store/containers/eventDetails/SpmEventDetailsContainer';
import SpmModelTrendsContainer from '../../../store/containers/modelTrends/SpmModelTrendsContainer';
import SpmAdminContainer from '../../../store/containers/spmAdmin/SpmAdminContainer';
import AdministrationPage from '../administration/AdministrationPage';
// import { SHMPrioritiesController } from '../administration/alertmonitoring/healthmonitoring/SHMPrioritiesController';

export default {
  Cockpit: {
    component: EventCockpitContainer,
    exact: true,
    path: '/'
  },
  HealthMonitoringAdministration: {
    component: AdministrationPage,
    exact: false,
    path: '/administration'
  },
  // HealthMonitoringPriorities: {
  //   component: SHMPrioritiesController,
  //   exact: true,
  //   path: '/administration/health-monitoring/config-priorities'
  // },
  PredictiveAdministration: {
    component: SpmAdminContainer,
    exact: true,
    path: '/admin'
  },
  ShmEvent: {
    component: ShmEventDetailsContainer,
    exact: true,
    path: '/shm-event/:id'
  },
  SpmEvent: {
    component: SpmEventDetailsContainer,
    exact: true,
    path: '/spm-event/:id'
  },
  Trends: {
    component: SpmModelTrendsContainer,
    exact: true,
    path: '/trends'
  }
};
