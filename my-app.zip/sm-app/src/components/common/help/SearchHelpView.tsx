/**
 * Class description: Occurrence History Help rendering component
 * @author Capgemini
 * @version 1.0
 */
import * as React from 'react';

export const SearchHelpView = props => {
  const demoLegend = 'demo-legend';
  const searchHelp = 'search-help';
  return (
    <div>
      <p>
        The search function makes it possible to search all the event data of
        the Event Cockpit
      </p>
      <div className={demoLegend}>
        <div>
          <p>By default, the search function:</p>
          <ul className={searchHelp}>
            <li>
              returns only the events containing the <b>exact typed text</b>
            </li>
            <li>
              refreshes in <b>real-time</b> the events containing the exact
              typed text
            </li>
            <li>
              orders events in a <b>chronological order</b> from newest to
              oldest
            </li>
            <li>
              is <b>not case sensitive</b>
            </li>
            <li>
              implicitly applies <b>AND</b> between words separated with a space
              character
            </li>
          </ul>
        </div>
      </div>
      <p>Advanced wildcards:</p>
      <div className={demoLegend}>
        <div>
          <ul className={searchHelp}>
            <li>
              * replaces <b>any placeholder</b>
              <br />
              E.g. AC-4* <b>-></b> returns events containing AC-45, AC-46A,
              AC-47C,…
            </li>
          </ul>
        </div>
      </div>
      <p>Search by parameter:</p>
      <div className={demoLegend}>
        <div>
          <ul className={searchHelp}>
            <li>Search can be restricted to specific parameters</li>
          </ul>
        </div>
        <table>
          <tbody>
            <tr>
              <th>Parameter</th>
              <th>Values</th>
              <th>Example</th>
            </tr>
            <tr>
              <td>aircraftType</td>
              <td>A318 ; A319 ; A320 ; A321 ; A330 ; A340 ; A350 ; A380</td>
              <td>
                aircraftType:A320 -> returns events that have occurred on A320
                aircraft
              </td>
            </tr>
            <tr>
              <td>ata</td>
              <td>Free text</td>
              <td>ata:32*</td>
            </tr>
            <tr>
              <td>displayed</td>
              <td>true ; false</td>
              <td>displayed:true</td>
            </tr>
            <tr>
              <td>eventDate</td>
              <td>Free text</td>
              <td>eventDate:"29 apr 2018"</td>
            </tr>
            <tr>
              <td>eventTitle</td>
              <td>Free text</td>
              <td>eventTitle:"AIR BLEED"</td>
            </tr>
            <tr>
              <td>eventType</td>
              <td>warning ; fault_message ; predictive</td>
              <td>eventType:predictive</td>
            </tr>
            <tr>
              <td>flightNumber</td>
              <td>Free text</td>
              <td>flightNumber:B6842</td>
            </tr>
            <tr>
              <td>nickName</td>
              <td>Free text</td>
              <td>nickName:F*</td>
            </tr>
            <tr>
              <td>priority</td>
              <td>high ; medium ; low ; none ; spurious</td>
              <td>priority:high</td>
            </tr>
            <tr>
              <td>registrationNumber</td>
              <td>Free text</td>
              <td>registrationNumber:F*</td>
            </tr>
            <tr>
              <td>source</td>
              <td>Free text</td>
              <td>source:CFDS</td>
            </tr>
            <tr>
              <td>viewMEL</td>
              <td>true ; false</td>
              <td>viewMEL:true</td>
            </tr>
            <tr>
              <td>workAuthor</td>
              <td>Free text</td>
              <td>workAuthor:John</td>
            </tr>
            <tr>
              <td>workComment</td>
              <td>Free text</td>
              <td>workComment:"High frequency"</td>
            </tr>
            <tr>
              <td>workflowStatus</td>
              <td>review ; opened ; planned ; monitor ; closed ; ignored</td>
              <td>workflowStatus:review</td>
            </tr>
            <tr>
              <td>workRef</td>
              <td>Free text</td>
              <td>workRef:1234*</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};
