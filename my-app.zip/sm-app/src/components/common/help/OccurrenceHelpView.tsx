/**
 * Class description: Occurrence History Help rendering component
 * @author Capgemini
 * @version 1.0
 */
// import { DSCard } from '@sm/skywise-react-library';
import * as React from 'react';
import { OccurencesHistory, OccurencesHistoryOccProps } from '../events/cells/occurrenceHistory/OccurenceHistory';

export const OccurrenceHelpView = (props) => {
  const demoBackground = 'demo-background';

  const firstOcc: OccurencesHistoryOccProps[] = [{
    level: 'EMPTY'
  }];

  const secondOcc: OccurencesHistoryOccProps[] = [{
    level: 'NONE', 
    value: 5
  }];

  const thirdOcc: OccurencesHistoryOccProps[] = [{
    level: 'NONE' 
  }];

  const fourthOcc: OccurencesHistoryOccProps[] = [{
    level: 'MISSING'
  }];

  const testOcc: OccurencesHistoryOccProps[] = [
    { level: 'EMPTY' },
    { level: 'EMPTY' },
    { level: 'EMPTY' },
    { level: 'NONE', value: 5 },
    { level: 'EMPTY' },
    { level: 'EMPTY' },
    { level: 'EMPTY' },
    { level: 'EMPTY' },
    { level: 'EMPTY' },
    { level: 'EMPTY' },
    { level: 'EMPTY' },
    { level: 'EMPTY' },
    { level: 'NONE', value: 4 },
    { level: 'EMPTY' },
    { level: 'NONE', value: 5 },
  ]; 
 
  return (
    <div>
      <p>
        Occurrence history represents the history of occurrences of a given event in the last 15 flights
      </p>
      <div className={demoBackground}>
        <OccurencesHistory>
          {testOcc} 
        </OccurencesHistory>
      </div>
      <div className="demo-legend">
        <div>
          <div className={demoBackground}>
            <OccurencesHistory>
              {firstOcc} 
            </OccurencesHistory>
          </div>
          <ul>
            <li>
              Fault Message or Warning <b>not received</b> in PFR
            </li>
            <li>
              Predictive maintenance alert <b>not raised</b>
            </li>
          </ul>
        </div>
        <div>
          <div className={demoBackground}>
            <OccurencesHistory>
              {secondOcc} 
            </OccurencesHistory>
          </div>
          <ul>
            <li>
              Fault Message or Warning <b>received</b> in PFR
            </li>
            <li>
              Number is the <b>Flight Phase</b> of occurrence of Fault Message or Warning
            </li>
          </ul>
        </div>
        <div>
          <div className={demoBackground}>
            <OccurencesHistory>
              {thirdOcc} 
            </OccurencesHistory>
          </div>
          <ul>
            <li>
              Predictive Maintenance alert <b>raised</b> (no Flight Phase associated)
            </li>
          </ul>
        </div>
        <div>
          <div className={demoBackground}>
            <OccurencesHistory>
              {fourthOcc} 
            </OccurencesHistory>
          </div>
          <ul>
            <li>
              <b>Missing</b> flight data (no data received but flight occurred)
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
