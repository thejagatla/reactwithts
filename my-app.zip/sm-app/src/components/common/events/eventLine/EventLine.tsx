import * as classNames from 'classnames';
import * as React from 'react';
import { Pass } from '../../../storybook/Pass/Pass';
import { FirstSection } from './sections/FirstSection';
import { SecondSection } from './sections/SecondSection';
import { ThirdSection } from './sections/ThirdSection';

/**
 * Class description: Event Card renderer
 * @author Capgemini
 * @version 1.0
 */
export class EventLine extends React.Component<any, any> {
  /**
   * Constructor
   * @param props props
   */
  constructor(props: any) {
    super(props);

    this.getEventLink = this.getEventLink.bind(this);
  }

  private getEventLink(): any {
    let eventLink = '';

    if (this.props.isEventClickable) {
      const event = this.props.event;
      switch (event.origin) {
        case 'SHM':
          if (event.correlationId) {
            eventLink = encodeURI(
              '/shm-event/' +
                encodeURIComponent(event.hashKey) +
                '?smEventDate=' +
                encodeURIComponent(event.smEventDate) +
                '&correlId=' +
                encodeURIComponent(event.correlationId)
            );
          } else {
            eventLink = encodeURI(
              '/shm-event/' +
                encodeURIComponent(event.hashKey) +
                '?smEventDate=' +
                encodeURIComponent(event.smEventDate)
            );
          }
          break;

        case 'SPM':
          eventLink = encodeURI(
            '/spm-event/' + encodeURIComponent(event.spmEventId)
          );
          break;

        case 'SRS':
          eventLink = event.srsDetailsLink;
          break;

        default:
          break;
      }
    }
    return eventLink;
  }

  /**
   * Rendering method
   */
  public render() {
    const classes = classNames('gridflex', {
      'associated-event': this.props.event.isAssociated,
      'pass-event--loaded': this.props.isLoadedEvent,
      'pass-event--local': this.props.isLocalEvent
    });

    return (
      <Pass style={this.props.style} className={classes}>
        <FirstSection {...this.props} />
        <SecondSection {...this.props} eventLink={this.getEventLink()} />
        {!this.props.isWorkflowHidden && <ThirdSection {...this.props} />}
      </Pass>
    );
  }
}
