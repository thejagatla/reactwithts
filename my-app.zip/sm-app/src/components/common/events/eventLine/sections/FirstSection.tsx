import { DSIcon } from '@sm/skywise-react-library';
import * as classNames from 'classnames';
import * as React from 'react';
import { EventTypeShortDisplay } from '../../../../../model/EventsConstantes';
import { getIconByEventType } from '../../../../../utils/EventsUtils';
import { formatDate, renderInHTML } from '../../../../../utils/RenderUtils';
import { List } from '../../../../storybook/List/List';
import { ListHeader } from '../../../../storybook/List/ListHeader';
import { ListItem } from '../../../../storybook/List/ListItem';
import { Pass } from '../../../../storybook/Pass/Pass';
import { SkywiseICONS } from '../../../../storybook/SkywiseInterface';

/**
 * Class description: First section rendering component
 * @author Capgemini
 * @version 1.0
 */
export class FirstSection extends React.Component<any, any> {
  /**
   * Constructor
   * @param props props
   */
  constructor(props: any) {
    super(props);

    this.state = {};
  }

  /**
   * Rendering method
   */
  public render() {
    const event = this.props.event;
    const priority = event.priority
      ? event.priority.toLowerCase()
      : 'no-priority';

    const priorityClasses = classNames(
      [priority],
      'col-6',
      'priority-column',
      'full-column'
    );

    const dateClasses = classNames({
      'result-highlighted': event.isDateHighlighted
    });

    const icon: SkywiseICONS = getIconByEventType(event.origin);
    const label = EventTypeShortDisplay[event.eventType];
    const flightNumber = event.flightNumber ? event.flightNumber : event.srsMsn;
    const messageType = event.messageType === 'CmsSaPfr' ? 'PFR' : 'CFR';

    return (
      <Pass.Section className="col-3">
        <Pass.Column className={priorityClasses}>
          <Pass.Cell>
            <DSIcon type={icon} />
          </Pass.Cell>
          <Pass.Cell className="event-type">{label}</Pass.Cell>
        </Pass.Column>
        <Pass.Column className="col-11">
          <Pass.Cell>
            <List className="pass-event--aircraft__details list--horizontal">
              <ListItem verticalAlign="start">
                <ListHeader>
                  {event.acNickName && this.props.displayName === 'acNickName'
                    ? renderInHTML(event.acNickName)
                    : event.msn && this.props.displayName === 'msn'
                    ? renderInHTML(event.msn)
                    : renderInHTML(event.acMatricule)}
                </ListHeader>
                {renderInHTML(flightNumber)}
              </ListItem>
            </List>
          </Pass.Cell>
          {event.origin === 'SHM' && event.smEventDate && (
            <Pass.Cell>
              <List className="list--horizontal">
                <ListItem verticalAlign="start">
                  <ListHeader>{messageType}</ListHeader>
                  <span className={dateClasses}>
                    {formatDate(event.smEventDate, 'HH:mm | DD MMM YYYY')}
                  </span>
                </ListItem>
              </List>
            </Pass.Cell>
          )}
        </Pass.Column>
      </Pass.Section>
    );
  }
}
