import * as classNames from 'classnames';
import * as React from 'react';
import * as Strings from '../../../../../lang/strings.json';
import {
  WorkflowPageOrigin,
  WorkOrderStatusEnum
} from '../../../../../model/EventsConstantes';
import { DaysLeftView } from '../../../../shm/DaysLeftView';
import { Pass } from '../../../../storybook/Pass/Pass';
import { WorkflowStatusCellViewController } from '../../../events/cells/workflow/WorkflowStatusCellViewController';
import { CommentViewController } from '../../cells/comment/CommentViewController';
import { WorkReferenceView } from '../../cells/WorkReferenceView';

/**
 * Class description: Third section rendering component
 * @author Capgemini
 * @version 1.0
 */
export class ThirdSection extends React.Component<any, any> {
  /**
   * Constructor
   * @param props props
   */
  constructor(props: any) {
    super(props);

    this.state = {};
  }

  /**
   * Rendering method
   */
  public render() {
    const { isWorkOrderStatusHighlighted, workOrderStatus } = this.props.event;

    const classes = classNames({
      'col-2': this.props.pageOrigin === WorkflowPageOrigin.SPM,
      'col-4': this.props.pageOrigin !== WorkflowPageOrigin.SPM
    });

    const firstColumnClass = classNames({
      'col-16': this.props.pageOrigin === WorkflowPageOrigin.SPM,
      'col-4': this.props.pageOrigin !== WorkflowPageOrigin.SPM
    });

    return (
      <Pass.Section className={classes}>
        <Pass.Column className={firstColumnClass}>
          <Pass.Cell className="aligncenter pass-event--workflow-status">
            <WorkflowStatusCellViewController
              {...this.props}
              lWorkOrderStatus={workOrderStatus}
              workOrderStatus={workOrderStatus}
              isWorkOrderStatusHighlighted={isWorkOrderStatusHighlighted}
            />
          </Pass.Cell>
          {workOrderStatus ===
            WorkOrderStatusEnum[WorkOrderStatusEnum.PLANNED] &&
            this.props.event.origin === 'SHM' && (
              <Pass.Cell className="aligncenter">
                <DaysLeftView
                  workOrderPlannedDate={this.props.event.workOrderPlannedDate}
                />
              </Pass.Cell>
            )}
        </Pass.Column>
        {this.props.pageOrigin === WorkflowPageOrigin.SHM &&
          this.props.event.origin !== 'SRS' && (
            <Pass.Column className="col-12">
              <Pass.Cell className="pass-event--work-status-infos">
                {(this.props.event.uiWorkOrderReference ||
                  this.props.event.workOrderReference) && (
                  <WorkReferenceView event={this.props.event} />
                )}
                <CommentViewController {...this.props} />
                {this.props.isLocalEvent && (
                  <div className="local-event-saving">
                    <img src="/img/baseline-cached-24px.svg" />
                    {Strings.saving}
                  </div>
                )}
              </Pass.Cell>
            </Pass.Column>
          )}
      </Pass.Section>
    );
  }
}
