interface PreferenceMock {
  displayName: string;
}
declare const value: PreferenceMock;
export = value;
