import * as classNames from 'classnames';
import * as _ from 'lodash';
import * as React from 'react';
import * as ReactOverflowTooltip from 'react-overflow-tooltip';
import { Link } from 'react-router-dom';
import * as Strings from '../../../../../lang/strings.json';
import { WorkflowPageOrigin } from '../../../../../model/EventsConstantes';
import { renderInHTML, stripTags } from '../../../../../utils/RenderUtils';
import { EventInfosList } from '../../cells/EventInfosList';
import { OccurenceRate } from '../../cells/OccurenceRate';
import { OccurencesHistory } from '../../cells/occurrenceHistory/OccurenceHistory';
import { WorkflowHistory } from '../../cells/WorkflowHistory';

import { List } from '../../../../storybook/List/List';
import { ListHeader } from '../../../../storybook/List/ListHeader';
import { ListItem } from '../../../../storybook/List/ListItem';
import { Pass } from '../../../../storybook/Pass/Pass';
import {
  ComputeSHMOcurrenceList,
  ComputeSPMOcurrenceList,
  ComputeSPMOcurrenceListOld,
  ComputeSRSOcurrenceList
} from '../../cells/occurrenceHistory/OccurenceHistoryManager';

/**
 * Class description: Second section rendering component
 */
export class SecondSection extends React.Component<any, any> {
  /**
   * Constructor
   * @param props props
   */
  constructor(props: any) {
    super(props);

    this.state = {};

    this.shouldRenderSecondColumn = this.shouldRenderSecondColumn.bind(this);
    this.manageSHMResult = this.manageSHMResult.bind(this);
  }

  private shouldRenderSecondColumn() {
    return (
      this.props.pageOrigin === WorkflowPageOrigin.SHM ||
      this.props.event.origin === 'SHM'
    );
  }

  private manageSHMResult() {
    if (_.isNil(this.props.ohDraggablePosition) && _.isNil(this.props.ohSize)) {
      return {
        flightOccurrence: this.props.event.flightOccurrence,
        occurrenceHistory: this.props.event.occurrenceHistory
      };
    }
    const {
      ohDraggablePosition,
      event,
      ohPage,
      ohItemsPerPage,
      ohSize
    } = this.props;
    const draggedLeft: number = ohDraggablePosition ? ohDraggablePosition : 0;
    const skippedElements =
      -1 * Math.floor((draggedLeft - 6) / 12) + ohPage * ohItemsPerPage;
    const flightOccurrences = event.flightOccurrence
      ? event.flightOccurrence
      : [];
    const to = flightOccurrences.length - skippedElements + 1;
    const from = to - ohSize > 0 ? to - ohSize : 0;
    const displayedFlightOccurrences = flightOccurrences.slice(from, to);

    return {
      flightOccurrence: displayedFlightOccurrences,
      occurrenceHistory: this.props.event.occurrenceHistory
    };
  }

  private renderSecondColumn() {
    const { event } = this.props;
    let occurencesFormated = [];
    switch (event.origin) {
      case 'SPM':
        if (event.eventLastUpdateTimestamp) {
          occurencesFormated = ComputeSPMOcurrenceList(
            event.spmOccurrenceHistory
          );
        } else {
          occurencesFormated = ComputeSPMOcurrenceListOld(
            event.occurrenceHistory,
            event.flightOccurrence
          );
        }
        break;

      case 'SHM':
        const eventOcc = this.manageSHMResult();
        occurencesFormated = ComputeSHMOcurrenceList(
          eventOcc.occurrenceHistory,
          eventOcc.flightOccurrence
        );
        break;

      case 'SRS':
        // srs todo
        occurencesFormated = ComputeSRSOcurrenceList(event.occurrenceHistory);
        break;
      default:
        // do nothing;
        break;
    }

    const classes = classNames({
      'badge--filled': event.origin === 'SPM',
      'col-11': this.props.isWorkflowHidden,
      'col-9': !this.props.isWorkflowHidden,
    });

    return (
      <Pass.Column className={classes}>
        <Pass.Cell direction="column">
          {!_.isNil(occurencesFormated) && !_.isEmpty(occurencesFormated) && (
            <OccurencesHistory children={occurencesFormated} />
          )}
          {event.origin === 'SPM' && event.spmOccurrenceHistory && (
            <WorkflowHistory
              occurenceHistory={event.spmOccurrenceHistory}
              currentStatus={event.statusInfoItem.status}
              children={event}
            />
          )}
        </Pass.Cell>
        {event.origin === 'SPM' &&
          !_.includes(
            ['TO_BE_REVIEWED', 'CLOSED', 'IGNORED'],
            event.statusInfoItem.status
          ) &&
          (!_.isUndefined(event.occurrenceRate) &&
            !_.isUndefined(event.flightCount)) && (
            <Pass.Cell>
              <OccurenceRate
                rate={event.occurrenceRate}
                flightCount={event.flightCount}
              />
            </Pass.Cell>
          )}
      </Pass.Column>
    );
  }

  private renderFirstColumn() {
    const { event } = this.props;
    const title =
      event.partDescription !== undefined
        ? event.partDescription
        : event.titleFromAircraft;

    let titlePrefix = '';
    if (event.partNumber && event.partNumber.length > 0) {
      titlePrefix = event.partNumber;
    } else if (event.value) {
      const alertValueSuffix =
        event.eventType.toUpperCase() === 'OR' ? '%' : '';
      titlePrefix = event.value + alertValueSuffix;
    }

    const titleClasses = classNames('event-aircraft', {
      'col-5': this.props.isWorkflowHidden,
      'col-6': event.origin === 'SRS',
      'col-7': event.origin !== 'SRS' && !this.props.isWorkflowHidden,
      'is-clickabled': this.props.isEventClickable
    });
    const srsClasses = classNames('event-aircraft', 'col-1', {
      'is-clickabled': this.props.isEventClickable
    });

    return (
      <React.Fragment>
        {event.origin === 'SRS' && event.smUiEventDate ? (
          <React.Fragment>
            <Pass.Column className={srsClasses}>
              <Pass.Cell className="event-aircraft__title-prefix">
                <a target="_blank" href={this.props.eventLink}>
                  {titlePrefix}
                </a>
              </Pass.Cell>
              <Pass.Cell>
                <a target="_blank" href={this.props.eventLink}>
                  <List className="event-aircraft__details list--horizontal">
                    <ListItem verticalAlign="start">
                      {Strings.date}
                      <ListHeader
                        className={
                          event.isDateEventHighlighted && 'result-highlighted'
                        }
                      >
                        {renderInHTML(event.smUiEventDate)}
                      </ListHeader>
                    </ListItem>
                  </List>
                </a>
              </Pass.Cell>
            </Pass.Column>
            <Pass.Column
              className={titleClasses}
              onClick={this.props.openDetails}
            >
              <Pass.Cell>
                <a target="_blank" href={this.props.eventLink}>
                  <ReactOverflowTooltip
                    title={stripTags(event.titleFromAircraft)}
                  >
                    <span
                      className="event-aircraft__title"
                      dangerouslySetInnerHTML={{ __html: title }}
                    />
                  </ReactOverflowTooltip>
                </a>
              </Pass.Cell>
              <Pass.Cell>
                <a target="_blank" href={this.props.eventLink}>
                  <EventInfosList event={event} />
                </a>
              </Pass.Cell>
            </Pass.Column>
          </React.Fragment>
        ) : (
          <Pass.Column
            className={titleClasses}
            onClick={this.props.openDetails}
          >
            <Pass.Cell>
              <Link to={this.props.eventLink}>
                <ReactOverflowTooltip
                  title={stripTags(event.titleFromAircraft)}
                >
                  <span
                    className="event-aircraft__title"
                    dangerouslySetInnerHTML={{ __html: title }}
                  />
                </ReactOverflowTooltip>
              </Link>
            </Pass.Cell>
            <Pass.Cell>
              <Link to={this.props.eventLink}>
                <EventInfosList event={event} />
              </Link>
            </Pass.Cell>
          </Pass.Column>
        )}
      </React.Fragment>
    );
  }

  /**
   * Rendering method
   */
  public render() {
    const classes = classNames('gridflex', {
      'col-11': this.props.pageOrigin === WorkflowPageOrigin.SPM,
      'col-13': this.props.isWorkflowHidden,
      'col-9': !this.props.isWorkflowHidden
    });

    return (
      <Pass.Section className={classes}>
        {this.renderFirstColumn()}
        {this.shouldRenderSecondColumn && this.renderSecondColumn()}
      </Pass.Section>
    );
  }
}
