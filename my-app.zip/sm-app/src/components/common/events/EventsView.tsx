import { DSLoader, DSScrollbar, DSScrollTop } from '@sm/skywise-react-library';
import * as classNames from 'classnames';
import * as React from 'react';
import { AutoSizer, InfiniteLoader, List } from 'react-virtualized';
import * as Strings from '../../../lang/strings.json';
import { Message } from '../../storybook/Message';

/**
 * Class description: React events component
 * @author Capgemini
 * @version 1.0
 */
export const EventsView = props => {
  const classes = classNames({
    'is-hidden': !props.displayScrollTop,
    'sm-scroll-top': true
  });

  return (
    <React.Fragment>
      {props.rowCount === 0 &&
        props.isFetching &&
        !props.firstRequestProcessed &&
        !props.lastRequestError && (
          <DSLoader
            className="event-container--spinner"
            label="Fetching Events"
          />
        )}
      {props.firstRequestProcessed &&
        props.rowCount === 0 &&
        !props.lastRequestError && (
          <Message icon="airplane-inactive" text={Strings.noResult} />
        )}
      {props.rowCount === 0 && props.lastRequestError && (
        <Message icon="error" text={Strings.refreshError} />
      )}
      <InfiniteLoader
        isRowLoaded={props.isRowLoaded}
        loadMoreRows={props.loadMoreRows}
        rowCount={props.totalEvents}
        threshold={props.threshold}
        minimumBatchSize={props.minimumBatchSize}
      >
        {({ onRowsRendered, registerChild }) => (
          <AutoSizer onResize={props.updateHeight}>
            {({ height, width }) => (
              <div>
                <DSScrollbar
                  height={height}
                  width={width}
                  scrollRef={props.scrollRef}
                  handleScroll={props.handleScroll}
                  handleScrollEvent={props.handleScrollEvent}
                  hide={false}
                >
                  <List
                    id={'c-events'}
                    height={height}
                    onRowsRendered={onRowsRendered}
                    ref={props.listRef}
                    rowHeight={props.rowHeight}
                    rowCount={props.rowCount}
                    rowRenderer={props.renderRow}
                    width={width}
                    style={{
                      overflowX: false,
                      overflowY: false
                    }}
                    scrollToRow={10}
                  />
                </DSScrollbar>
                <DSScrollTop
                  id="scroll-to-top"
                  className={classes}
                  onClick={props.scrollToTop}
                />
              </div>
            )}
          </AutoSizer>
        )}
      </InfiniteLoader>
    </React.Fragment>
  );
};

EventsView.displayName = 'EventsView';
