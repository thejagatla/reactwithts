import * as _ from 'lodash';
import * as React from 'react';
import {
  StepperTracker,
  StepperTrackerStep
} from '../../../storybook/stepperTracker/StepperTracker';

import { SkywiseICONS } from '@sm/skywise-react-library/dist/SkywiseInterface';
import { getIconFromWorkStatusEnum } from '../../../../utils/FleetsweepUtils';

import { WorkOrderStatusEnum } from '../../../../model/EventsConstantes';

interface WorkflowOccurence {
  flightDate?: string;
  isMissign?: boolean;
  isAlert?: boolean;
  updatedStatus?: string;
}

interface WorkflowHistoryProps {
  /** List of occurence */
  occurenceHistory?: WorkflowOccurence[];
  currentStatus?: WorkOrderStatusEnum;

  children?: any;
}
export interface S {
  icon?: SkywiseICONS;
  timelineRatio?: number;
}

/**
 * @name OccurenceRate
 * @description Use to display occurrence rate in relation to the number of theft.
 * @return String of 'Occurrence rate over {flightCount} flights: {rate}%'
 * @example
 * <OccurencesRate flightCount={3} rate={40} />
 */
export const WorkflowHistory: React.SFC<WorkflowHistoryProps> = (
  props: WorkflowHistoryProps
) => {
  /**
   *
   * @param occurences
   */
  const ComputeWorkflowList = (
    occurences: any
  ): StepperTrackerStep[] | null => {
    const workflowList: StepperTrackerStep[] = [];
    if (!_.isNil(occurences)) {
      occurences.map((occurence: WorkflowOccurence, index: number) => {
        if (occurence.hasOwnProperty('updatedStatus')) {
          workflowList.push({
            icon: getIconFromWorkStatusEnum(occurence.updatedStatus),
            timelineRatio: index
          });
        }
      });

      ComputeWorkflowFirstStatus(workflowList);

      ComputeWorkflowCurrentStatus(workflowList);

      if (!_.isNil(workflowList) && _.isArray(workflowList)) {
        return workflowList;
      }
    }
    return null;
  };

  const ComputeWorkflowFirstStatus = (
    workflowList: StepperTrackerStep[]
  ): void => {
    if (_.isArray(workflowList) && workflowList.length > 0) {
      if (
        workflowList[0].icon ===
        getIconFromWorkStatusEnum(
          WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_MONITORED]
        )
      ) {
        workflowList.unshift({
          icon: getIconFromWorkStatusEnum(
            WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED]
          ),
          timelineRatio: -1
        });
      } else if (
        workflowList[0].icon ===
        getIconFromWorkStatusEnum(
          WorkOrderStatusEnum[WorkOrderStatusEnum.CLOSED]
        )
      ) {
        workflowList.unshift({
          icon: getIconFromWorkStatusEnum(
            WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_MONITORED]
          ),
          timelineRatio: -1
        });
      }
    }
  };

  const ComputeWorkflowCurrentStatus = (
    workflowList: StepperTrackerStep[]
  ): void => {
    if (workflowList.length === 0) {
      const { currentStatus } = props;
      if (_.includes(['OPENED', 'PLANNED'], currentStatus.toString())) {
        workflowList.push({
          icon: getIconFromWorkStatusEnum(WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED]),
          timelineRatio: -1
        });
      } else if (_.includes(['TO_BE_MONITORED', 'CLOSED'], currentStatus.toString())) {
        workflowList.push({
          icon: getIconFromWorkStatusEnum(WorkOrderStatusEnum[WorkOrderStatusEnum[currentStatus]]),
          timelineRatio: -1
        });
      }
    }
  };

  const ComputeWorkflowSize = (
    statusList: StepperTrackerStep[],
    size: number
  ): { start: number, size: number } => {
    let lSize = size;
    let lStart = 0;
    switch (statusList.length) {
      case 0:
        lSize = 0;
        break;
      case 1:
        const status: StepperTrackerStep =  statusList.slice(0, 1)[0];
        if (status.icon === getIconFromWorkStatusEnum(WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED])) {
          lSize = lSize - status.timelineRatio - 1;
          lStart = status.timelineRatio + 1;
        }
        if (status.icon === getIconFromWorkStatusEnum(WorkOrderStatusEnum[WorkOrderStatusEnum.CLOSED])) {
          lSize = status.timelineRatio + 1;
        }
        break;
      default:
        const last: StepperTrackerStep = statusList.slice(-1)[0];
        if (last.icon === getIconFromWorkStatusEnum(WorkOrderStatusEnum[WorkOrderStatusEnum.CLOSED])) {
          lSize = last.timelineRatio + 1;
        }
    }
    return { start: lStart, size: lSize };
  };

  const { occurenceHistory } = props;
  const list = ComputeWorkflowList(occurenceHistory);
  const lLine = ComputeWorkflowSize(list, occurenceHistory.length);

  if (_.isArray(list)) {
    return (
      <StepperTracker
        className="workflow-history"
        unit="22px"
        line={lLine}
        total={15}
        items={list}
      />
    );
  }
  return null;
};
