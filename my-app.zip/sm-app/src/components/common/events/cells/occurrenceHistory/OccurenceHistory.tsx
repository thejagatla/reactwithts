import * as _ from 'lodash';
import * as React from 'react';
import { Badge, BadgeColor } from '../../../../storybook/Badge';
import { Dot } from '../../../../storybook/Dot';
import { List } from '../../../../storybook/List/List';

/** Représente un occurence de l'historique */
export interface OccurencesHistoryOccProps {
  basic?: boolean;
  label?: string;

  /** Correspond a la priorité de l'évennement rattaché à cette occurence
   *
   * NONE: pas de priorité
   * EMPTY: pas d'occurence durant le vol
   */
  level?: 'HIGH' | 'MEDIUM' | 'LOW' | 'NONE' | 'MISSING' | 'EMPTY';

  /** Value de l'occurence */
  value?: number;
}

export interface OccurencesHistoryProps {
  /** List of occurences. */
  children?: OccurencesHistoryOccProps[];
}

/**
 * @name OccurenceHistoryEventsProps
 * @description Permet d'afficher une liste d'occurence sous forme de Badge et de point.
 * @example
 * <OccurenceHistory></OccurenceHistory>
 */
export const OccurencesHistory: React.SFC<OccurencesHistoryProps> = (
  props: OccurencesHistoryProps
) => {
  const { children } = props;

  const convertLevelToColor = (level: string): BadgeColor => {
    switch (level) {
      case 'HIGH':
        return 'red';
      case 'MEDIUM':
        return 'orange';
      case 'LOW':
        return 'yellow';
      case 'MISSING':
        return 'light-grey';
      case 'NONE':
      default:
        return 'grey';
    }
  };

  const renderAnOccurence = (
    occurence?: any,
    index?: number
  ): React.ReactNode => {
    const { label, level, value, basic } = occurence;

    if (level === 'EMPTY') {
      return (
        <List.Item key={level + value + index} verticalAlign="center" className="pass-event--occ-empty">
          {!_.isNil(label) && <List.Header className="pass-event--occ-label">{label}</List.Header>}
          <Dot color="light-grey" />
        </List.Item>
      );
    }

    return (
      <List.Item key={level + value + index} className="pass-event--occ">
        {!_.isNil(label) && <List.Header className="pass-event--occ-label">{label}</List.Header>}
        <Badge color={convertLevelToColor(level)} size="small" basic={basic}>{value}</Badge>
      </List.Item>
    );
  };

  return (
    <React.Fragment>
      {children.length && (
        <List className="pass-event--occ-hist list--horizontal">
          {children.map((elem: OccurencesHistoryOccProps, index: number) => {
            return renderAnOccurence(elem, index);
          })}
        </List>
      )}
    </React.Fragment>
  );
};
