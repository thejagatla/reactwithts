import * as _ from 'lodash';
import { PHASE_SEPARATOR } from '../../../../../model/EventsConstantes';
import {
  FlightOccurence,
  months,
  OccurenceHistory
} from '../../../../../model/OccurenceHistory';
import { SPMOccurenceHistory } from '../../../../../model/SPMEvent';

import { SRSOccurenceHistory } from '../../../../../model/SRSEvent';
import { OccurencesHistoryOccProps } from './OccurenceHistory';

const OccurenceNotNilAndEmpty = (value: any): boolean => {
  if (!_.isNil(value) || !_.isEmpty(value)) {
    return true;
  }
  return false;
};

export const ComputeSPMOcurrenceListOld = (
  occurrencesHistory: OccurenceHistory[],
  flightOccurrences: FlightOccurence[]
): OccurencesHistoryOccProps[] => {
  if (OccurenceNotNilAndEmpty(occurrencesHistory) && OccurenceNotNilAndEmpty(flightOccurrences)) {
    return flightOccurrences.map((fightOccurrence: FlightOccurence) => {
      return ComputeSPMOcurrenceOld(occurrencesHistory, fightOccurrence);
    });
  }
  return null;
};

export const ComputeSPMOcurrenceOld = (
  occurrencesHistory: OccurenceHistory[],
  flightOccurrence: FlightOccurence
): any => {
  return occurrencesHistory.map((occurrenceHistory: OccurenceHistory) => {
    if (occurrenceHistory.d === flightOccurrence) {
      return { level: 'NONE', basic: false };
    }
    return { level: 'EMPTY', basic: false };
  });
};

// la fonction connait le format des occurence spm, si ca change,
// c'est remonté dans la console en error.
export const ComputeSPMOcurrenceList = (
  occurences: SPMOccurenceHistory[]
): OccurencesHistoryOccProps[] => {
  if (OccurenceNotNilAndEmpty(occurences)) {
    return occurences.map((occurence: SPMOccurenceHistory): OccurencesHistoryOccProps => {
      if (occurence.isMissing === true) {
        return { level: 'MISSING' };
      }
      if (occurence.isAlert === true) {
        return { level: 'NONE' };
      }
      return { level: 'EMPTY' };
    });
  }
  return null;
};

export const ComputeSHMOcurrenceList = (
  occurrencesHistory: OccurenceHistory[],
  flightOccurrences: FlightOccurence[]
): OccurencesHistoryOccProps[] => {
  if (OccurenceNotNilAndEmpty(occurrencesHistory) && OccurenceNotNilAndEmpty(flightOccurrences)) {
    return flightOccurrences.map(
      (flightOccurrence: FlightOccurence) => {
        return ComputeSHMOcurrence(occurrencesHistory, flightOccurrence);
      }
    );
  }
  return null;
};

/**
 *
 * @param occurrencesHistory Occurences list for one event.
 * @param flightOccurrence Flight occurence need to be find in occurences list.
 */
export const ComputeSHMOcurrence = (
  occurrencesHistory: OccurenceHistory[],
  flightOccurrence: FlightOccurence
): OccurencesHistoryOccProps => {
  let sameDate: boolean = false;
  let lPhaseNumber: string = '';
  let lFound: boolean = false;

  for (
    let index = 0;
    index < occurrencesHistory.length && !lFound;
    index = index + 1
  ) {
    if (occurrencesHistory[index].m === 'P') {
      sameDate = occurrencesHistory[index].d === flightOccurrence.p;
    } else if (flightOccurrence.c) {
      sameDate = flightOccurrence.c.indexOf(occurrencesHistory[index].d) > -1;
    }

    if (sameDate) {
      lPhaseNumber = occurrencesHistory[index].p.substring(
        occurrencesHistory[index].p.indexOf(PHASE_SEPARATOR) + 1
      );
      lFound = true;
      if (occurrencesHistory[index].p === '') {
        return {
          basic: true,
          level: 'NONE'
        };
      }
      return {
        level: 'NONE',
        value: Number(lPhaseNumber)
      };
    }
  }

  return { level: 'EMPTY', basic: false };
};

export const ComputeSRSOcurrenceList = (
  occurrencesHistory: SRSOccurenceHistory[]
): OccurencesHistoryOccProps[] => {
  if (OccurenceNotNilAndEmpty(occurrencesHistory)) {
    return occurrencesHistory.map(
      (occurrenceHistory: SRSOccurenceHistory) => {
        if (occurrenceHistory.month) {
          return ComputeSRSOcurrence(occurrenceHistory);
        }
        return null;
      }
    );
  }
  return null;
};

export const ComputeSRSOcurrence = (
  occurrenceHistory: SRSOccurenceHistory,
): OccurencesHistoryOccProps => {
  const monthLabel = months[Number(occurrenceHistory.month.slice(-2)) - 1];
  let lLevel: any = occurrenceHistory.level;
  if (occurrenceHistory.level === 'NO_ALERT') {
    lLevel = 'NONE';
  } else if (occurrenceHistory.level === 'NO_DATA') {
    lLevel = 'MISSING';
  }

  if (!_.isNil(occurrenceHistory.value) && !_.isEmpty(occurrenceHistory.value)) {
    return {
      label: monthLabel,
      level: lLevel,
      value: Number(occurrenceHistory.value)
    };
  }
  return {
    label: monthLabel,
    level: lLevel
  };
};
