import * as _ from 'lodash';
import * as React from 'react';
import * as Strings from '../../../../lang/strings.json';
import { EventListInfoDisplayed } from '../../../../model/EventsConstantes';
import { formatDate, renderInHTML } from '../../../../utils/RenderUtils';
import { MmelView } from '../../../shm/MmelView';
import { List } from '../../../storybook/List/List';
import { ListHeader } from '../../../storybook/List/ListHeader';
import { ListItem } from '../../../storybook/List/ListItem';

interface EventInfosListProps {
  event: any;
}

/**
 * Class description: Event Infos rendering component
 * @author Capgemini
 * @version 1.0
 */
export const EventInfosList: React.SFC<EventInfosListProps> = (props: EventInfosListProps) => {

  const getDisplayedValue = (pDisplayed: boolean): string => {
    let lResult: string = null;

    if (pDisplayed !== null && pDisplayed !== undefined) {
      if (!pDisplayed) {
        lResult = Strings.notDisplayed;
      } else {
        lResult = Strings.displayed;
      }
    }

    return lResult;
  };

  /**
   * Cette fonction doit retourner la liste des infos sous le format <List>
   * Elle pourrait etre exporté de ce composant lorsqu'on va revoir l'organisation du EventRowRenderer
   *
   */
  const computeListDetails = () => {
    const list: JSX.Element[] = [];
    const event = props.event;
    let currentKey = 0;
    const infosToDisplay = EventListInfoDisplayed[event.origin];

    infosToDisplay.forEach((info: any, key: number) => {
      currentKey = key;
      if (!_.isNil(event[info.key])) {
        list.push(
          <ListItem 
            verticalAlign="start" 
            key={key}
          >
            {!_.isNil(info.label) && 
              <React.Fragment>
                {info.label}
              </React.Fragment>
            }
            <ListHeader>
              {renderInHTML(event[info.key])}
            </ListHeader>
          </ListItem>
        );
      }
    });

    if (!_.isNil(event.displayed)) {
      list.push(
        <ListItem 
          verticalAlign="start" 
          key={currentKey + 1}
        >
          &nbsp;
          <ListHeader>
            {renderInHTML(getDisplayedValue(event.displayed))}
          </ListHeader>
        </ListItem>
      );
    }

    if (event.viewMelLinks) {
      list.push(<ListItem verticalAlign="start" key={currentKey + 2}><MmelView /></ListItem>);
    }

    if (event.origin === 'SHM') {
      list.unshift(
        <ListItem 
          verticalAlign="start"
          className={event.isDateEventHighlighted && 'result-highlighted'}
          key={currentKey + 3}
        >
          {formatDate(event.eventDate, 'DD MMM YYYY')}
          <ListHeader>
            {formatDate(event.eventDate, 'HH:mm')}
          </ListHeader>
        </ListItem>
      );
    }
    if (event.origin === 'SPM') {
      list.unshift(
        <ListItem 
          verticalAlign="start"
          className={event.isDateEventHighlighted && 'result-highlighted'}
          key={currentKey + 3}
        >
          {formatDate(event.smEventDate, 'DD MMM YYYY')}
          <ListHeader>
            {formatDate(event.smEventDate, 'HH:mm')}
          </ListHeader>
        </ListItem>
      );
    }

    if (event.origin === 'SRS' && event.alertTargetName && event.alertTargetName.length > 0) {
      list.unshift(
        <ListItem 
          verticalAlign="start" 
          key={currentKey + 4}
        >
          {event.alertTargetName}
          <ListHeader>
            {renderInHTML(event.alertTargetValue + (event.eventType === 'OR' && '%'))}
          </ListHeader>
        </ListItem>
      );
    }

    return list;
  };

  const listFormatted = computeListDetails();

  return (
    <List 
      className="event-aircraft__details list--horizontal"
    >
      {listFormatted}
    </List>
  );
};

EventInfosList.displayName = 'EventInfosList';
