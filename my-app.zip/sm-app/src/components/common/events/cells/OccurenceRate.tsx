import * as React from 'react';
import * as Strings from '../../../../lang/strings.json';

interface OccurenceRateProps {
  flightCount?: number;
  rate?: number;
}

/**
 * @name OccurenceRate
 * @description Use to display occurrence rate in relation to the number of theft.
 * @return String of 'Occurrence rate over {flightCount} flights: {rate}%'
 * @example
 * <OccurencesRate flightCount={3} rate={40} />
 */
export const OccurenceRate: React.SFC<OccurenceRateProps> = (
  props: OccurenceRateProps
) => {
  const { flightCount, rate } = props;

  return (
    <p className="pass--occurence-rate">
      {Strings.occurenceRate.replace('%s', flightCount.toString())}
      {' '}
      <strong>{rate + '%'}</strong>
    </p>
  );
};
