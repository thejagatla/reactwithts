import * as React from 'react';
import { ModalManager } from 'react-dynamic-modal';
import { WorkStatusController } from '../../../../../controllers/WorkStatusController';
import {
  EventOrigin,
  WorkflowAction,
  WorkflowActionEnum,
  WorkOrderStatus,
  WorkOrderStatusEnum
} from '../../../../../model/EventsConstantes';
import { SHMActions } from '../../../../../model/SHMEvent';
import { SPMActions } from '../../../../../model/SPMEvent';
import { SRSActions } from '../../../../../model/SRSEvent';
import { store } from '../../../../../store/configureStore';
import { getIdToken } from '../../../../../utils/AuthenticationUtils';
import { startTimeout } from '../../../../../utils/EventsUtils';
import { closeModal, openErrorModal } from '../../../../../utils/ModalsUtils';
import { WorkflowModalEditViewController } from '../../../../shm/workflow/WorkflowModalEditViewController';
// tslint:disable-next-line:max-line-length
import { WorkflowModalIgnoredEditViewController } from '../../../../shm/workflow/WorkflowModalIgnoredEditViewController';
import { WorkflowModalIgnoreViewController } from '../../../../shm/workflow/WorkflowModalIgnoreViewController';
// tslint:disable-next-line:max-line-length
import { WorkflowModalViewController as SpmWorkflowModalViewController } from '../../../../spm/eventWorkflow/WorkflowModalViewController';
import CheckAuthorization from '../../../../utils/authorization/CheckAuthorization';
import { WorkflowStatusCellView } from './WorkflowStatusCellView';
import WorkflowStatusReadOnlyCellView from './WorkflowStatusReadOnlyCellView';

/**
 * Class description: Dropdown component for workStatus
 * @author Capgemini
 * @version 1.0
 */
export class WorkflowStatusCellViewController extends React.Component<
  any,
  any
> {
  /**
   * Constructor
   * @param props React props
   */
  constructor(props: any) {
    super(props);

    this.state = {
      displayedDropdown: false
    };

    this.hideDropdown = this.hideDropdown.bind(this);
    this.openWorkflowModal = this.openWorkflowModal.bind(this);
    this.displayDropdown = this.displayDropdown.bind(this);
    this.setWorkOrderStatus = this.setWorkOrderStatus.bind(this);
    this.closeModal = this.closeModal.bind(this);
  }

  /**
   * Display the dropdown list
   */
  public displayDropdown() {
    this.setState({ displayedDropdown: true });
  }

  /**
   * Hide the dropdown list
   */
  public hideDropdown() {
    this.setState({ displayedDropdown: false });
  }

  /**
   * Hide the modal
   */
  public closeModal() {
    startTimeout();
    closeModal();
  }

  /**
   * Open workflow modal
   * @param pAction : IGNORE, EDIT...
   */
  private openWorkflowModal(pAction: string) {
    // Stop the refresh
    const storedValues: any = store.getState();
    clearTimeout(storedValues.eventReducer.timeoutId);

    if (this.props.event.origin === EventOrigin.SHM) {
      // Open Ignore modal or Edit modal
      if (pAction === WorkflowAction[WorkflowAction.IGNORE]) {
        ModalManager.open(
          <WorkflowModalIgnoreViewController
            event={this.props.event}
            closeModal={this.closeModal}
            displayName={this.props.displayName}
            setWorkOrderStatus={this.setWorkOrderStatus}
          />
        );
      } else {
        if (
          this.props.event.workOrderStatus ===
          WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED]
        ) {
          // Edit event with workflow status ignore
          ModalManager.open(
            <WorkflowModalIgnoredEditViewController
              event={this.props.event}
              closeModal={this.closeModal}
              displayName={this.props.displayName}
              setWorkOrderStatus={this.setWorkOrderStatus}
            />
          );
        } else {
          ModalManager.open(
            <WorkflowModalEditViewController
              event={this.props.event}
              closeModal={this.closeModal}
              displayName={this.props.displayName}
              setWorkOrderStatus={this.setWorkOrderStatus}
            />
          );
        }
      }
    } else if (this.props.event.origin === EventOrigin.SPM) {
      ModalManager.open(
        <SpmWorkflowModalViewController
          addLocalEvent={this.props.addLocalEvent}
          displayName={this.props.displayName}
          title={WorkflowActionEnum[pAction]}
          event={this.props.event}
          closeModal={this.closeModal}
          action={pAction}
          pageOrigin={this.props.pageOrigin}
          removeLocalEvent={this.props.removeLocalEvent}
        />
      );
    }
  }

  /**
   * Change work order status.
   * @param pNewWorkOrderStatus New work order status
   * @param pWorkOrderCommentAuthor Work order author
   * @param pWorkOrderReference Work order reference
   * @param pWorkOrderComment Work order comment.
   *  It is mandatory if the new status is IGNORED and the reason is OTHER_REASON.
   * @param pWorkOrderIgnoredReason Ignore reason.
   *  It is mandatory if the new status is IGNORED.
   * @param pPlannedDate Planned date.
   *  It is mandatory if the new status is PLANNED.
   */
  public setWorkOrderStatus(
    pNewWorkOrderStatus: string,
    pWorkOrderCommentAuthor: string,
    pWorkOrderReference: string,
    pWorkOrderComment?: string,
    pWorkOrderIgnoredReason?: string,
    pPlannedDate?: string
  ) {
    const oldStatus = this.props.event.workOrderStatus;

    const localEvent = JSON.parse(JSON.stringify(this.props.event));
    localEvent.workOrderComment = pWorkOrderComment;
    localEvent.workOrderCommentAuthor = pWorkOrderCommentAuthor;
    localEvent.workOrderStatus = pNewWorkOrderStatus;
    localEvent.statusInfoItem.status = pNewWorkOrderStatus;
    localEvent.workOrderReference = pWorkOrderReference;
    localEvent.statusInfoItem.workReference = pWorkOrderReference;

    if (pPlannedDate !== '') {
      localEvent.workOrderPlannedDate = pPlannedDate;
    } else {
      delete localEvent.workOrderPlannedDate;
    }

    // Launch periodic refresh
    startTimeout();

    this.props.addLocalEvent(localEvent);

    closeModal();

    return WorkStatusController.setWorkOrderStatus(
      this.props.event.hashKey,
      oldStatus,
      pNewWorkOrderStatus,
      getIdToken(),
      pWorkOrderCommentAuthor,
      pWorkOrderReference,
      pWorkOrderComment,
      pPlannedDate,
      pWorkOrderIgnoredReason
    )
      .then((response: any) => {
        switch (response.status) {
          case 200:
          case 201:
          case 202:
          case 204:
            break;
          case 400:
          case 401:
          case 403:
          case 404:
          case 409:
          case 412:
          case 500:
            openErrorModal(
              response.body.exception.smTraceId,
              '',
              response.body.exception.support.techRequestUrl,
              response.body.exception.support.contactEnglish,
              response.body.exception.support.contactChinese
            );
            this.props.removeLocalEvent(this.props.event.hashKey);
            break;
          case 501:
          default:
            openErrorModal('Unknown');
            this.props.removeLocalEvent(this.props.event.hashKey);
        }
      })
      .catch(error => {
        openErrorModal('Unknown');
        this.props.removeLocalEvent(this.props.event.hashKey);
      });
  }

  /**
   * Rendering method
   */
  public render() {
    let lActionsList: any = [];
    if (!this.props.isLocalEvent) {
      switch (this.props.event.origin) {
        case EventOrigin.SPM:
          lActionsList =
            SPMActions[WorkOrderStatus[this.props.workOrderStatus]];
          break;
        case EventOrigin.SRS:
          lActionsList =
            SRSActions[WorkOrderStatus[this.props.workOrderStatus]];
          break;
        case EventOrigin.SHM:
        default:
          lActionsList =
            SHMActions[WorkOrderStatus[this.props.workOrderStatus]];
          break;
      }
    }

    // Handle read only action for SPM Event
    if (this.props.event.origin === EventOrigin.SPM) {
      const modelAccessLevel =
        this.props.event.modelAccessLevel ||
        this.props.event.spmModelAccessLevel;
      return (
        <CheckAuthorization
          allowedPermissions={[`WRITE_SPM_LEVEL_${modelAccessLevel}`]}
          renderNoAccess={() => {
            return (
              <WorkflowStatusReadOnlyCellView
                isWorkOrderStatusHighlighted={
                  this.props.isWorkOrderStatusHighlighted
                }
                workOrderStatus={this.props.workOrderStatus}
              />
            );
          }}
        >
          <WorkflowStatusCellView
            isWorkOrderStatusHighlighted={
              this.props.isWorkOrderStatusHighlighted
            }
            displayedDropdown={this.state.displayedDropdown}
            actions={lActionsList}
            workOrderStatus={this.props.workOrderStatus}
            newWorkOrderStatus={this.state.newWorkOrderStatus}
            displayDropdown={this.displayDropdown}
            hideDropdown={this.hideDropdown}
            openWorkflowModal={this.openWorkflowModal}
          />
        </CheckAuthorization>
      );
    }

    return (
      <WorkflowStatusCellView
        isWorkOrderStatusHighlighted={this.props.isWorkOrderStatusHighlighted}
        displayedDropdown={this.state.displayedDropdown}
        actions={lActionsList}
        workOrderStatus={this.props.workOrderStatus}
        newWorkOrderStatus={this.state.newWorkOrderStatus}
        displayDropdown={this.displayDropdown}
        hideDropdown={this.hideDropdown}
        openWorkflowModal={this.openWorkflowModal}
      />
    );
  }
}
