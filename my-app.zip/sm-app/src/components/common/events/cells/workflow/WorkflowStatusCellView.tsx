import { DSStepIcon } from '@sm/skywise-react-library';
import * as classNames from 'classnames';
import * as React from 'react';
import { 
  WorkflowActionEnum,
  WorkOrderStatus,
  WorkOrderStatusEnum
} from '../../../../../model/EventsConstantes';
import {
  getIconFromWorkStatusEnum,
  getShortClassFromWorkStatusEnum
} from '../../../../../utils/FleetsweepUtils';
import { DSDropdown } from '../../../../storybook/DSDropdown/DSDropdown';

interface WorkflowStatusCellViewProps {
  actions?: any;
  isWorkOrderStatusHighlighted: boolean;
  displayedDropdown: boolean;
  workOrderStatus: string;
  newWorkOrderStatus: string;
  displayDropdown(): void;
  hideDropdown(): void;
  openWorkflowModal(pAction: string): void;
}

/**
 * Class description: Workflow status Cell rendering component
 * @author Capgemini
 * @version 1.0
 */
export const WorkflowStatusCellView: React.SFC<WorkflowStatusCellViewProps> = (props: WorkflowStatusCellViewProps) => {
  const titleClass = classNames(
    'event-status'
  );

  const actionsList: any = [];
  props.actions.map((action, index) => {
    actionsList.push({
      text: WorkflowActionEnum[action],
      value: action
    });
  });

  const iconContainerClass = getShortClassFromWorkStatusEnum(
    WorkOrderStatusEnum[WorkOrderStatusEnum[props.workOrderStatus]]
  );
  const iconClass = getIconFromWorkStatusEnum(WorkOrderStatusEnum[WorkOrderStatusEnum[props.workOrderStatus]]);

  const textDisplay: any = !props.isWorkOrderStatusHighlighted ? WorkOrderStatus[props.workOrderStatus]
    : <span className="result-highlighted">{WorkOrderStatus[props.workOrderStatus]}</span>;

  return (
    <div className={titleClass}>
      <DSStepIcon icon={iconClass} classNames={iconContainerClass} />
      <DSDropdown
        options={actionsList}
        onItemClick={props.openWorkflowModal}
        text={textDisplay}
      />
    </div>
  );
};

WorkflowStatusCellView.displayName = 'WorkflowStatusCellView';
