import { DSStepIcon } from '@sm/skywise-react-library';
import * as classNames from 'classnames';
import * as React from 'react';
import { 
  WorkOrderStatus,
  WorkOrderStatusEnum
} from '../../../../../model/EventsConstantes';
import {
  getIconFromWorkStatusEnum,
  getShortClassFromWorkStatusEnum
} from '../../../../../utils/FleetsweepUtils';

/**
 * Class description: read only Workflow status Cell rendering component
 * @author Capgemini
 * @version 1.0
 */
const workflowStatusReadOnlyCellView = (props: any) => {
  const titleClass = classNames(
    'event-status'
  );

  const iconContainerClass = getShortClassFromWorkStatusEnum(
    WorkOrderStatusEnum[WorkOrderStatusEnum[props.workOrderStatus]]
  );
  const iconClass = getIconFromWorkStatusEnum(WorkOrderStatusEnum[WorkOrderStatusEnum[props.workOrderStatus]]);

  const textDisplay: any = !props.isWorkOrderStatusHighlighted ? WorkOrderStatus[props.workOrderStatus]
    : <span className="result-highlighted">{WorkOrderStatus[props.workOrderStatus]}</span>;

  return (
    <div className={titleClass}>
      <div className="disabled">
        <DSStepIcon icon={iconClass} classNames={iconContainerClass} />
        <div className="workflow-label">{textDisplay}</div>
      </div>
    </div>
  );
};

export default workflowStatusReadOnlyCellView;
