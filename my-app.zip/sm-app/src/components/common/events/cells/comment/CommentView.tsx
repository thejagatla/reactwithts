import { DSIcon } from '@sm/skywise-react-library';
import * as classNames from 'classnames';
import * as React from 'react';
import * as Truncate from 'react-truncate-html';
import { renderInHTML } from '../../../../../utils/RenderUtils';

interface CommentProps {
  author?: string;
  comment: string; // Null because formatComment() can be return null.
  hasWorkOrderReference: boolean;
  highlighted?: boolean;
  selected?: boolean;
  onMouseOver?(event: React.MouseEvent<HTMLElement>): void;
  onMouseLeave?(event: React.MouseEvent<HTMLElement>): void;
  onClick?(event: React.MouseEvent<HTMLElement>): void;
  onKeyPress?(event:  React.KeyboardEvent<HTMLElement>);
}

/**
 * Class description: Comment rendering component
 * @author Capgemini
 * @version 1.0
 */
export const CommentView: React.SFC<CommentProps> = (props: CommentProps) => {
  const { author, comment, hasWorkOrderReference, highlighted } = props;
  const classWrapper = classNames(
    'comment',
    {
      'comment--active': props.selected,
      'comment--with-author': author !== undefined
    }
  );
  const classCommentText = classNames(
    'comment--text',
    {
      'result-children-highlighted' : highlighted,
    }
  );

  let nbLines = author !== undefined ? 4 : 5;
  if (hasWorkOrderReference) {
    nbLines = nbLines - 1;
  }

  return (
    <div
      className={classWrapper}
      onMouseOver={props.onMouseOver}
      onMouseLeave={props.onMouseLeave}
      onClick={props.onClick}
      onKeyPress={props.onKeyPress}      
    >
      <Truncate.default
        lines={nbLines}
        dangerouslySetInnerHTML={{ __html: comment }}
        className={classCommentText}
      />
      <DSIcon type="pencil" className="comment--edit-icon" />
      {author &&
        <div className="comment--author">
          {renderInHTML(author)}
        </div>
      }
    </div>
  );
};

CommentView.displayName = 'CommentView';
