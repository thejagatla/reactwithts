import { DSButton, DSTextarea } from '@sm/skywise-react-library';
import * as classNames from 'classnames';
import { isEmpty, isEqual, isNil } from 'lodash';
import * as React from 'react';
import { SpmEventController } from '../../../../../controllers/SpmEventController';
import { WorkStatusController } from '../../../../../controllers/WorkStatusController';
import * as Language from '../../../../../lang/strings.json';
import { Comment } from '../../../../../model/Comment';
import { EventOrigin } from '../../../../../model/EventsConstantes';
import { store } from '../../../../../store/configureStore';
import {
  getIdToken,
  getUsername
} from '../../../../../utils/AuthenticationUtils';
import { startTimeout } from '../../../../../utils/EventsUtils';
import { openErrorModal } from '../../../../../utils/ModalsUtils';
import CheckAuthorization from '../../../../utils/authorization/CheckAuthorization';
import { CommentView } from './CommentView';

interface CommentViewState {
  isCommentSelecting: boolean;
  editionMode: boolean;
  newComment: string;
}

/**
 * Class description: Comment Cell rendering component
 * @author Capgemini
 * @version 1.0
 */
export class CommentViewController extends React.Component<
  any,
  CommentViewState
> {
  /**
   * Constructor
   * @param props React props
   */
  constructor(props: any) {
    super(props);

    this.state = {
      editionMode: false,
      isCommentSelecting: false,
      newComment: ''
    };

    this.saveLocalEvent = this.saveLocalEvent.bind(this);
    this.handleLinkClick = this.handleLinkClick.bind(this);
    this.handleTextareaChange = this.handleTextareaChange.bind(this);
    this.handleTextareaOnBlur = this.handleTextareaOnBlur.bind(this);
    this.handleCommentMouseOver = this.handleCommentMouseOver.bind(this);
    this.handleCommentMouseLeave = this.handleCommentMouseLeave.bind(this);
    this.handleCommentClick = this.handleCommentClick.bind(this);
    this.onKeyPress = this.onKeyPress.bind(this);
    this.manageSubmit = this.manageSubmit.bind(this);
  }

  /**
   * Fires when the user clicks the left mouse button on the button.
   * @param {MouseEvent<HTMLLinkElement>} event Mouse event click.
   */
  private handleLinkClick(event: React.MouseEvent<HTMLLinkElement>) {
    event.preventDefault();

    // Stop the refresh
    const storedValues: any = store.getState();
    clearTimeout(storedValues.eventReducer.timeoutId);

    event.preventDefault();
    // set also eventId to be always sure that we have the right event id when we set a comment
    this.setState({
      editionMode: true
    });
  }

  private handleTextareaChange(event: React.FocusEvent<HTMLTextAreaElement>) {
    event.preventDefault();
    const { value } = event.currentTarget;
    this.setState({
      newComment: value
    });
  }

  private manageSubmit() {
    const newComment = this.state.newComment;
    const commentFromEvent = this.props.event.workOrderComment;

    if (
      !isNil(newComment) &&
      !isEmpty(newComment.trim()) &&
      !isEqual(newComment.trim(), commentFromEvent)
    ) {
      // Send comment
      this.handleSubmit();
    } else if (isNil(newComment) || isEmpty(newComment.trim())) {
      this.setState({ newComment: commentFromEvent });
    }

    this.setState({ editionMode: false });

    // Launch periodic refresh
    startTimeout();
  }

  private handleTextareaOnBlur(event: React.FocusEvent<HTMLTextAreaElement>) {
    event.preventDefault();
    this.manageSubmit();
  }

  private handleCommentMouseOver(event: React.MouseEvent<HTMLElement>) {
    event.preventDefault();
    if (!this.props.isLocalEvent && !this.state.isCommentSelecting) {
      this.setState({
        isCommentSelecting: true
      });
    }
  }

  private handleCommentMouseLeave(event: React.MouseEvent<HTMLElement>) {
    event.preventDefault();
    if (!this.props.isLocalEvent) {
      this.setState({
        isCommentSelecting: false
      });
    }
  }

  private handleCommentClick(event: React.MouseEvent<HTMLLinkElement>) {
    event.preventDefault();
    // si un textarea déjà apparent, le faire disparaitre.
    // faire apparaitre le nouveau textarea.

    // Stop the refresh
    const storedValues: any = store.getState();
    clearTimeout(storedValues.eventReducer.timeoutId);

    if (this.state.isCommentSelecting) {
      this.setState({
        editionMode: true,
        isCommentSelecting: false,
        newComment: this.props.event.workOrderComment
          ? this.props.event.workOrderComment
          : ''
      });
    }
  }

  /**
   * Save the event as a temporary event display
   * @param pUserName username
   */
  private saveLocalEvent(userName: string) {
    const localEvent = JSON.parse(JSON.stringify(this.props.event));
    localEvent.workOrderComment = this.state.newComment.trim();
    localEvent.workOrderCommentAuthor = userName;
    localEvent.statusInfoItem.comment = this.state.newComment.trim();
    this.props.addLocalEvent(localEvent);
  }

  /**
   * Submit a free SPM comment
   * @param pIdToken token id
   * @param pUserName username
   */
  private handleSubmitSpmComment(pIdToken: string, pUserName: string): void {
    this.saveLocalEvent(pUserName);

    const eventId = this.props.event.statusInfoItem
      ? this.props.event.statusInfoItem.eventId
      : this.props.event.hashKey;

    const lNow = new Date(Date.now()).toUTCString();
    const newComment: Comment = {
      author: pUserName,
      dateTime: new Date(lNow).toISOString(),
      eventId: this.props.event.statusInfoItem
        ? this.props.event.statusInfoItem.eventId
        : this.props.event.hashKey,
      text: this.state.newComment.trim()
    };

    Promise.resolve(
      SpmEventController.postCommentByEventId(
        eventId,
        newComment,
        pIdToken
      ).catch((error: Response) => {
        this.props.removeLocalEvent(this.props.event.hashKey);

        switch (error.status) {
          case 400:
          case 401:
          case 403:
          case 404:
          case 409:
          case 412:
            // Decode response
            error.json().then(res => {
              openErrorModal(
                res.exception.smTraceId,
                '',
                res.exception.support.techRequestUrl,
                res.exception.support.contactEnglish,
                res.exception.support.contactChinese
              );
            });
            break;
          case 500:
          case 501:
          default:
            openErrorModal('Unknown');
        }
      })
    );
  }

  private onKeyPress(event: React.KeyboardEvent<HTMLElement>) {
    // si un textarea déjà apparent, le faire disparaitre.
    // faire apparaitre le nouveau textarea.
    if (event.keyCode === 13) {
      this.manageSubmit();
    } else if (event.keyCode === 27) {
      this.setState({
        editionMode: false,
        isCommentSelecting: true,
        newComment: this.props.event.workOrderComment
      });
    }

    // Launch periodic refresh
    startTimeout();
  }

  /**
   * Submit a free SHM comment
   * @param pIdToken token id
   * @param pUserName username
   */
  private handleSubmitShmComment(pIdToken: string, pUserName: string): void {
    this.saveLocalEvent(pUserName);

    Promise.resolve(
      WorkStatusController.setWorkOrderStatus(
        this.props.event.statusInfoItem
          ? this.props.event.statusInfoItem.eventId
          : this.props.event.hashKey,
        this.props.event.workOrderStatus,
        this.props.event.workOrderStatus,
        pIdToken,
        pUserName,
        this.props.event.workOrderReference,
        this.state.newComment.trim(),
        this.props.event.workOrderPlannedDate,
        this.props.event.workOrderIgnoredReason
      )
        .then((response: any) => {
          switch (response.status) {
            case 200:
            case 201:
            case 202:
            case 204:
              break;
            case 400:
            case 401:
            case 403:
            case 404:
            case 409:
            case 412:
            case 500:
              openErrorModal(
                response.body.exception.smTraceId,
                '',
                response.body.exception.support.techRequestUrl,
                response.body.exception.support.contactEnglish,
                response.body.exception.support.contactChinese
              );
              this.props.removeLocalEvent(this.props.event.hashKey);
              break;
            case 501:
            default:
              openErrorModal('Unknown');
              this.props.removeLocalEvent(this.props.event.hashKey);
          }
        })
        .catch(error => {
          openErrorModal('Unknown');
          this.props.removeLocalEvent(this.props.event.hashKey);
        })
    );
  }

  /**
   * Handle submit
   */
  private handleSubmit(): void {
    // Get token id
    const lIdToken: string = getIdToken();
    // Get username
    const lUsername: string = getUsername();

    switch (this.props.event.origin) {
      case EventOrigin.SPM:
        this.handleSubmitSpmComment(lIdToken, lUsername);
        break;
      case EventOrigin.SHM:
        this.handleSubmitShmComment(lIdToken, lUsername);
        break;
      default:
    }
  }

  /**
   * Rendering method
   */
  public render() {
    let commentText: string;
    let highlighted: boolean = false;
    const event = this.props.event;

    if (
      !isNil(event.highlightedWorkOrderComment) &&
      !isEmpty(event.highlightedWorkOrderComment)
    ) {
      commentText = event.highlightedWorkOrderComment;
      highlighted = true;
    } else {
      commentText = event.workOrderComment;
    }

    const isCommentExisting = commentText && commentText.length !== 0;

    const classes = classNames({
      aligncenter: true,
      'pass-event--comment': true
    });

    const CommentViewRender = () => (
      <div className={classes}>
        {!this.state.editionMode && isCommentExisting && (
          <CommentView
            hasWorkOrderReference={
              event.uiWorkOrderReference || event.workOrderReference
            }
            comment={commentText}
            author={event.workOrderCommentAuthor}
            onMouseOver={this.handleCommentMouseOver}
            onMouseLeave={this.handleCommentMouseLeave}
            onClick={this.handleCommentClick}
            selected={this.state.isCommentSelecting}
            highlighted={highlighted}
          />
        )}
        {!this.state.editionMode && !isCommentExisting && (
          <DSButton
            as="a"
            disabled={this.props.isLocalEvent}
            handleClick={this.handleLinkClick}
            className="pass-event--comment-button"
            content={Language.addComment}
            size="medium"
            type="ghost"
          />
        )}
        {!this.props.isLocalEvent && this.state.editionMode && (
          <DSTextarea
            autoFocus={true}
            value={this.state.newComment}
            resize="none"
            className="pass-event--comment-textarea"
            handleChange={this.handleTextareaChange}
            onBlur={this.handleTextareaOnBlur}
            rows={3}
            onKeyDown={this.onKeyPress}
          />
        )}
      </div>
    );

    // Handle read only action for SPM Event
    if (this.props.event.origin === EventOrigin.SPM) {
      const modelAccessLevel =
        this.props.event.modelAccessLevel ||
        this.props.event.spmModelAccessLevel;
      return (
        <CheckAuthorization
          allowedPermissions={[`WRITE_SPM_LEVEL_${modelAccessLevel}`]}
          renderNoAccess={() => {
            return isCommentExisting === true ? (
              <CommentView
                hasWorkOrderReference={
                  event.uiWorkOrderReference || event.workOrderReference
                }
                comment={commentText}
                author={event.workOrderCommentAuthor}
                selected={this.state.isCommentSelecting}
                highlighted={highlighted}
              />
            ) : (
              ''
            );
          }}
        >
          <CommentViewRender />
        </CheckAuthorization>
      );
    }

    // externalisé event-comments das un composant type <EventWrapper/>
    // qui contient le num colonne et la classe event-xxx
    return <CommentViewRender />;
  }
}
