import * as React from 'react';
import * as Strings from '../../../../lang/strings.json';
import { renderInHTML } from '../../../../utils/RenderUtils';

interface WorkReferenceViewProps {
  event: any;
}

/**
 * Class description: WorkOrder Reference rendering component
 * @author Capgemini
 * @version 1.0
 */
export const WorkReferenceView: React.SFC<WorkReferenceViewProps> = (props: WorkReferenceViewProps) => {
  const workOrderReference = 
    props.event.uiWorkOrderReference ? props.event.uiWorkOrderReference[0] : props.event.workOrderReference;
    
  return (
    <div className="pass-event--work-reference">
        <label>{Strings.workflowReferenceCellLabel}:&nbsp;</label>
        {renderInHTML(workOrderReference)}
    </div>
  );
};

WorkReferenceView.displayName = 'WorkReferenceView';
