import * as React from 'react';

interface LabelAndInfoViewProps {
  className: string;
  label?: string;
  value: React.ReactNode;
}

/**
 * Class description: Label + info rendering component
 * @author Capgemini
 * @version 1.0
 */
export const LabelAndInfoView: React.SFC<LabelAndInfoViewProps> = (props: LabelAndInfoViewProps) => {
  const { className, label, value } = props;

  return (
    <div className={className}>
      {label && <label>{label}</label>}
      {value}
    </div>
  );
};

LabelAndInfoView.displayName = 'LabelAndInfoView';
