import { DSTextIcon } from '@sm/skywise-react-library';
import * as classNames from 'classnames';
import * as React from 'react';

interface IconViewProps {
  iconType?: any;
  label?: string;
  priority?: any;  
}

/**
 * Class description: Icon Cell rendering component
 * @author Capgemini
 * @version 1.0
 */
export const IconView: React.SFC<IconViewProps> = (props: IconViewProps) => {
  const classes = classNames({
    high: props.priority && props.priority.toLowerCase() === 'high',
    low: props.priority && props.priority.toLowerCase() === 'low',
    medium: props.priority && props.priority.toLowerCase() === 'medium',
    none: props.priority && props.priority.toLowerCase() === 'none',    
  });

  return (
      <DSTextIcon
        className={'event-icon ' + classes}
        children={<span className={'event-icon--label ' + classes}>{props.label}</span>}
        iconType={props.iconType}
      />
  );
};

IconView.displayName = 'IconView';
