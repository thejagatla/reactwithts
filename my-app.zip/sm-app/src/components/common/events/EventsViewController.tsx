import * as React from 'react';
import { Scrollbars } from 'react-custom-scrollbars';
import { List } from 'react-virtualized';
import 'react-virtualized/styles.css';
import {
  EventOrigin,
  WorkflowPageOrigin
} from '../../../model/EventsConstantes';
import { startTimeout } from '../../../utils/EventsUtils';
import { EventLine } from './eventLine/EventLine';
import { EventsView } from './EventsView';

const STATUS_LOADED = 2;

/**
 * Class description: Events view controller
 * @author Capgemini
 * @version 1.0
 */
export class EventsViewController extends React.Component<any, any> {
  private listRef: List;
  private scrollRef: Scrollbars;

  /**
   * Constructor
   * @param props props
   */
  constructor(props: any) {
    super(props);

    this.state = {
      displayScrollTop: false,
      intervalId: 0,
      rowHeight: 118,
      scrollTop: 0,
      searchLaunched: false,
      threshold: 50,
      width: 100
    };

    this.listRefFunc = this.listRefFunc.bind(this);
    this.scrollRefFunc = this.scrollRefFunc.bind(this);
    this.getEventObject = this.getEventObject.bind(this);
    this.isRowLoaded = this.isRowLoaded.bind(this);
    this.loadMoreRows = this.loadMoreRows.bind(this);
    this.renderRow = this.renderRow.bind(this);
    this.scrollToTop = this.scrollToTop.bind(this);
    this.handleScroll = this.handleScroll.bind(this);
    this.handleScrollEvent = this.handleScrollEvent.bind(this);
    this.updateHeight = this.updateHeight.bind(this);
  }

  /**
   * Component will mount
   */
  public listRefFunc(el: any) {
    if (this.listRef) {
      return this.listRef;
    }
    this.listRef = el;
    this.props.setListRef(el);
    return this.listRef;
  }

  /**
   * Component will mount
   */
  public scrollRefFunc(el: any): string {
    if (this.scrollRef) {
      return this.scrollRef;
    }
    this.scrollRef = el;
    return this.scrollRef;
  }

  /**
   * Indicates if a row is loaded
   * @param param row
   */
  public isRowLoaded({ index }: { index: number }): boolean {
    const loadedRowsMap = this.props.state.loadedRowsMap;
    return !!loadedRowsMap[index];
  }

  /**
   * Component did mount
   */
  public componentDidMount() {
    if (!this.props.state.firstRequestProcessed) {
      startTimeout(true);
    }
  }

  /**
   * Fetch more events
   * @param param param
   */
  public loadMoreRows({
    startIndex,
    stopIndex
  }: {
    startIndex: number;
    stopIndex: number;
  }) {
    const size = stopIndex - startIndex;

    if (startIndex > 0) {
      clearTimeout(this.props.state.timeoutId);
    }

    if (size > 0) {
      this.props.setNewIntervals(startIndex, size);
    }

    return new Promise(resolve => {
      resolve(this.props.state.events);
    });
  }

  /**
   * Is the remote object updated since our update
   * @param localEvent The Local event
   * @param remoteEvent The remote event
   */
  public shouldRemoveLocalEvent(localEvent: any, remoteEvent: any) {
    if (localEvent.origin === EventOrigin.SHM) {
      return localEvent.version < remoteEvent.version;
    }
    const remoteDate1 = localEvent.eventLastUpdateTimestamp
      ? new Date(localEvent.eventLastUpdateTimestamp).getTime()
      : 0;
    const remoteDate2 = localEvent.eventLastUpdateTimestamp
      ? new Date(remoteEvent.eventLastUpdateTimestamp).getTime()
      : 0;
    return remoteDate1 < remoteDate2;
  }

  /**
   * Clean the local event after 24 hours
   * @param localEvent The Local event
   */
  public timedOutLocalEvent(localEvent: any) {
    const actualDate = new Date().getTime();
    const localEventDate = localEvent.localEventCreationDate;

    if (actualDate - localEventDate > 86400000) {
      return true;
    }
    return false;
  }

  /**
   * Manage local context event
   * @param index Number of the event stored in redux
   */
  public getEventObject(index: number) {
    let pEvent = this.props.state.events[index];
    let pIsLocalEvent = false;
    if (this.props.state.localEventsHashKeys.indexOf(pEvent.hashKey) !== -1) {
      this.props.state.localEvents.map((localEvent: any) => {
        if (localEvent.hashKey === pEvent.hashKey) {
          if (this.shouldRemoveLocalEvent(localEvent, pEvent)) {
            this.props.removeLocalEvent(pEvent.hashKey);
          } else {
            pEvent = localEvent;
            pIsLocalEvent = true;
          }
        }
      });
    } else {
      this.props.state.localEvents.map((localEvent: any) => {
        if (this.timedOutLocalEvent(localEvent)) {
          this.props.removeLocalEvent(pEvent.hashKey);
        }
      });
    }

    return {
      event: pEvent,
      isLocalEvent: pIsLocalEvent
    };
  }

  /**
   * Display row
   * @param param0 row informations
   */
  public renderRow({
    style,
    key,
    index
  }: {
    style: any;
    key: string;
    index: number;
  }) {
    if (
      this.props.state.loadedRowsMap[index] === STATUS_LOADED &&
      this.props.state.events[index]
    ) {
      const { event, isLocalEvent } = this.getEventObject(index);
      const isLoadedEvent = event.loaded;

      return (
        <EventLine
          addLocalEvent={this.props.addLocalEvent}
          displayName={this.props.state.displayName}
          key={key}
          event={event}
          index={index}
          isLoadedEvent={isLoadedEvent}
          isLocalEvent={isLocalEvent}
          isEventClickable={true}
          isWorkflowHidden={false}
          style={style}
          pageOrigin={WorkflowPageOrigin.SHM}
          removeLocalEvent={this.props.removeLocalEvent}
        />
      );
    }
    return (
      <div className="event-container empty-row" key={key}>
        Loading row data ...
      </div>
    );
  }

  /**
   * Method to scroll to top on click
   */
  private scrollToTop(): void {
    if (this.draw()) {
      // Si draw() retourne true alors next animation
      requestAnimationFrame(this.scrollToTop);
    }
  }
  private draw(): boolean {
    let display = this.scrollRef.getValues().scrollTop;
    const time = display / 15;
    if (display > 0) {
      display = display - time;
      this.scrollRef.scrollTop(display);
      return true;
    }
    this.scrollRef.scrollTop(0);
    startTimeout(false, true);
    return false;
  }

  /**
   * Method to display scroll to top button on scroll
   */
  private handleScroll(values: any): void {
    if (values.scrollTop === 0) {
      this.setState({ displayScrollTop: false });
    } else {
      if (!this.state.displayScrollTop) {
        this.setState({ displayScrollTop: true });
      }
    }
  }

  /**
   * Method to link scroll to react-virtualize behavior
   */
  private handleScrollEvent({ target }: any): void {
    const { scrollTop } = target;
    const { Grid: grid } = this.listRef;
    grid.handleScrollEvent({ scrollTop });
  }

  /**
   * Method to update the autosizer height saved in store
   */
  private updateHeight(newSize: any): void {
    this.props.setAutosizerHeight(newSize.height);
  }

  /**
   * Rendering method
   */
  public render() {
    return (
      <EventsView
        lastRequestError={this.props.state.lastRequestError}
        firstRequestProcessed={this.props.state.firstRequestProcessed}
        isFetching={this.props.state.isFetching}
        listRef={this.listRefFunc}
        scrollRef={this.scrollRefFunc}
        rowHeight={this.props.state.rowHeight}
        totalEvents={this.props.state.totalEvents}
        rowCount={this.props.state.numberLoaded}
        isRowLoaded={this.isRowLoaded}
        loadMoreRows={this.loadMoreRows}
        threshold={this.state.threshold}
        minimumBatchSize={60}
        renderRow={this.renderRow}
        scrollToTop={this.scrollToTop}
        updateHeight={this.updateHeight}
        handleScroll={this.handleScroll}
        handleScrollEvent={this.handleScrollEvent}
        displayScrollTop={this.state.displayScrollTop}
      />
    );
  }
}
