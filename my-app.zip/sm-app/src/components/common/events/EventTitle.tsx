import * as classNames from 'classnames';
import * as React from 'react';
import * as ReactOverflowTooltip from 'react-overflow-tooltip';
import { stripTags } from '../../../utils/RenderUtils';

interface EventTitleProps {
  clickFunction?: any;
  event?: any;
  text: string;
}

/**
 * Class description: Common Event Title renderer
 * @author Capgemini
 * @version 1.0
 */
export const EventTitle: React.SFC<EventTitleProps> = (props: EventTitleProps) => {
  const classes = classNames({
    clickable: props.clickFunction,
    'event-shortinfo__title': true
  });

  return (
    <ReactOverflowTooltip title={stripTags(props.text)}>
      <div
        className={classes}
        dangerouslySetInnerHTML={{ __html: props.text }}
        onClick={(event) => {
          if (props.clickFunction) {
            props.clickFunction(props.event);
          }
        }}
      />
    </ReactOverflowTooltip>
  );
};

EventTitle.displayName = 'EventTitle';
