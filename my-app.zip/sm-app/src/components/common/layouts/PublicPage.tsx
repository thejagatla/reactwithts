import * as React from 'react';

const PublicPage = (props) => {
  const Component = props.component;
  return (
    <Component route={props.route} />
  );
};

export default PublicPage;
