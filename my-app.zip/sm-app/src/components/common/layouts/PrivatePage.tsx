import * as React from 'react';
import ComponentHeaderContainer from '../../../store/containers/componentHeader/ComponentHeaderContainer';
// tslint:disable-next-line:max-line-length
import ComponentNavigationPanelContainer from '../../../store/containers/componentNavigationPanel/ComponentNavigationPanelContainer';
import { withLoader } from '../../../utils/withLoader';
import { Page } from '../../presenter/templates/Page';
import CheckFeatureFlipping from '../../utils/featureFlipping/CheckFeatureFlipping';

/**
 * @name PrivatePage
 * @description Composes the main DOM for private access pages.
 * @type [Business Presenter]
 */
class PrivatePage extends React.Component<any> {
  public render() {
    const Component = this.props.component;
    return (
      <CheckFeatureFlipping feature={'navigation_panel'}>
        {isActive => (
          <Page
            header={<ComponentHeaderContainer {...this.props} />}
            navigation={isActive ? <ComponentNavigationPanelContainer /> : null}
          >
            <Component {...this.props} />
          </Page>
        )}
      </CheckFeatureFlipping>
    );
  }
}

export default withLoader(PrivatePage);
