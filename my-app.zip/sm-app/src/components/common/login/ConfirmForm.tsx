import * as React from 'react';

export class ConfirmForm extends React.Component<any, any> {

  constructor(props: any) {
    super(props);
    this.state = {
      error: '',
      verificationCode: '',
    };
  }

  private onSubmit = (event) => {
    event.preventDefault();
    this.props.onSubmit(this.state.verificationCode)
     .then((user) => {
       console.log(user);
     })
     .catch((error) => {
       this.setState({ error });
     });
  }

  private onResend = (event) => {
    event.preventDefault();
    this.props.onResend()
     .then((user) => {
       this.setState({ error: 'Code resent' });
     })
     .catch((error) => {
       this.setState({ error });
     });

  }

  private changeVerificationCode = (event: any) => {
    this.setState({ verificationCode: event.target.value });
  }

  public render() {
    return (
      <form onSubmit={this.onSubmit}>
        <div>{this.state.error}</div>
        <label>
          Verification Code
          <input placeholder="code" onChange={this.changeVerificationCode} required={true} />
        </label>
        <button type="submit">Submit</button>
        <button type="button" onClick={this.onResend}>Resend code</button>
        <button type="button" onClick={this.props.onCancel}>Cancel</button>

      </form>
    );
  }
}

export default ConfirmForm;
