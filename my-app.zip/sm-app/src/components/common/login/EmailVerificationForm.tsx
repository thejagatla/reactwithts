import * as React from 'react';

class EmailVerificationForm extends React.Component<any, any> {

  constructor(props: any) {
    super(props);
    this.state = {
      error: props.error,
      verificationCode: '',
    };
  }

  private onSubmit = (event: any) => {
    event.preventDefault();
    this.props.onSubmit(this.state.verificationCode);
  }

  private changeVerificationCode = (event: any) => {
    this.setState({ verificationCode: event.target.value });
  }

  public render() {
    return (
      <form onSubmit={this.onSubmit}>
        <div>{this.props.error}</div>
        <label>
          Verification Code
          <input placeholder="code" onChange={this.changeVerificationCode} required={true} />
        </label>
        <button type="submit">Submit</button>
        <button type="button" onClick={this.props.onCancel}>Cancel</button>
      </form>
    );
  }
}

export default EmailVerificationForm;
