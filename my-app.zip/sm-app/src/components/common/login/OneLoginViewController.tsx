import { DSLoader, DSSegment } from '@sm/skywise-react-library';
import * as React from 'react';
import { CognitoState } from 'react-cognito';
import { Redirect } from 'react-router';
import * as Message from '../../../lang/strings.json';
import {
  ONELOGIN_LOGGED_IN,
  ONELOGIN_LOGGED_OUT
} from '../../../store/actions/LoginActions';

export class OneLoginViewController extends React.Component<any, any> {
  /**
   * Constructor
   * @param props Component props
   */
  constructor(props: any) {
    super(props);

    this.state = {
      message: Message.logginDefaultMessage
    };
  }

  /**
   * React lifecycle method
   */
  public componentWillMount() {
    switch (this.props.oneLogin.state) {
      case ONELOGIN_LOGGED_IN:
        this.setState({
          message: Message.loggedInMessage
        });
        break;
      case ONELOGIN_LOGGED_OUT:
        this.setState({
          message: Message.logginInMessage
        });
        break;
      default:
    }

    // Setup onelogin config only if onelogin and cognito state are not logged in
    // => prevent switch to cognito/onelogin switch
    if (
      this.props.oneLogin.state !== ONELOGIN_LOGGED_IN &&
      this.props.cognito.state !== CognitoState.LOGGED_IN
    ) {
      this.props.setupOneLoginConfig();
    }
  }

  /**
   * React render method
   */
  public render() {
    // user is logged if he is loggin on onelogin or cognito
    // => prevent switch to cognito/onelogin switch
    const isLogged: boolean =
      this.props.oneLogin.state === ONELOGIN_LOGGED_IN ||
      this.props.cognito.state === CognitoState.LOGGED_IN;

    return (
      <React.Fragment>
        {isLogged ? (
          <Redirect to="/" />
        ) : (
          <DSSegment alignment="center" textAlign="center">
            <DSLoader />
            <p>{this.state.message}</p>
          </DSSegment>
        )}
      </React.Fragment>
    );
  }
}
