import { DSButton } from '@sm/skywise-react-library';
import * as React from 'react';

export class LoginForm extends React.Component<any, any> {

  constructor(props: any) {
    super(props);
    this.state = {
      email: props.email,
      password: '',
      username: props.username
    };
  }

  private onSubmit = (event: any) => {
    event.preventDefault();
    this.props.onSubmit(this.state.username, this.state.password);
  }

  private changeUsername = (event: any) => {
    this.setState({ username: event.target.value });
  }

  private changePassword = (event: any) => {
    this.setState({ password: event.target.value });
  }

  public componentWillUnmount() {
    this.props.clearCache();
  }

  public render() {
    return (
    <form onSubmit={this.onSubmit}>
      { this.props.error &&
        <div className="error">{this.props.error}</div>
      }
      { this.props.email &&
        <div>{this.state.email}</div>
      }
      <div>
        <label>
          Username
        </label>
        <input
          placeholder="Username"
          value={this.state.username}
          onChange={this.changeUsername}
          required={true}
          name="username"
          type="text"
        />
      </div>
      <div>
        <label>
          Password
        </label>
        <input
          placeholder="Password"
          onChange={this.changePassword}
          type="password"
          required={true}
          name="password"
        />
      </div>
      <DSButton
        content="Sign in"
        handleClick={this.onSubmit}
        color="white"
        isSubmit={true}
      />
    </form>
    );
  }
}

export default LoginForm;
