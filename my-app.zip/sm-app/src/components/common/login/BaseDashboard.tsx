import * as React from 'react';
import {
  CognitoState,
  Confirm,
  EmailVerification,
  Login,
  NewPasswordRequired
} from 'react-cognito';
import { Link, Redirect } from 'react-router-dom';
import { ONELOGIN_LOGGED_IN } from '../../../store/actions/LoginActions';
import ConfirmForm from './ConfirmForm';
import EmailVerificationForm from './EmailVerificationForm';
import LoginForm from './LoginForm';
import NewPasswordRequiredForm from './NewPasswordRequiredForm';

const loggedOutPage = () => (
  <div className="login-form">
    <p>You must log in to access the dashboard</p>
    <Login>
      <LoginForm />
    </Login>
    <Link to="/reset">Password reset</Link>
  </div>
);

const newPasswordPage = () => (
  <div className="login-form">
    <p>New password required, since this is your first login</p>
    <NewPasswordRequired>
      <NewPasswordRequiredForm />
    </NewPasswordRequired>
  </div>
);

const emailVerificationPage = () => (
  <div>
    <p>
      You must verify your email address. Please check your email for a code
    </p>
    <EmailVerification>
      <EmailVerificationForm />
    </EmailVerification>
  </div>
);

const confirmForm = () => (
  <div>
    <p>A confirmation code has been sent to your email address</p>
    <Confirm>
      <ConfirmForm />
    </Confirm>
  </div>
);

const mfaPage = () => (
  <div>
    <p>You need to enter an MFA, but this library does not yet support them.</p>
  </div>
);

export class BaseDashboard extends React.Component<any, any> {
  constructor(props: any) {
    super(props);
  }

  public componentWillMount() {
    // Setup onelogin config only if onelogin and cognito state are not logged in
    // => prevent switch to cognito/onelogin switch
    if (
      this.props.state === CognitoState.LOGGED_OUT &&
      this.props.oneLogin.state !== ONELOGIN_LOGGED_IN
    ) {
      this.props.setupCognitoConfig();
    }
  }

  public render() {
    const { location } = this.props.route;
    const redirectUrl = location.state ? location.state.urlToRedirect : '/';
    if (this.props.oneLogin.state !== ONELOGIN_LOGGED_IN) {
      // check Cognito state
      switch (this.props.state) {
        case CognitoState.LOGGED_IN:
          // Get userprofile
          this.props.getUserProfileAndFeatureFlipping();
          return <Redirect to={redirectUrl} />;
        case CognitoState.AUTHENTICATED:
        case CognitoState.LOGGING_IN:
          return (
            <div>
              <img src="ajax-loader.gif" alt="" />
            </div>
          );
        case CognitoState.LOGGED_OUT:
        case CognitoState.LOGIN_FAILURE:
          return loggedOutPage();
        case CognitoState.MFA_REQUIRED:
          return mfaPage();
        case CognitoState.NEW_PASSWORD_REQUIRED:
          return newPasswordPage();
        case CognitoState.EMAIL_VERIFICATION_REQUIRED:
          return emailVerificationPage();
        case CognitoState.CONFIRMATION_REQUIRED:
          return confirmForm();
        default:
          return (
            <div>
              <p>Unrecognised cognito state</p>
            </div>
          );
      }
    }
    // connect with one login, go to main page
    return <Redirect to={redirectUrl} />;
  }
}
