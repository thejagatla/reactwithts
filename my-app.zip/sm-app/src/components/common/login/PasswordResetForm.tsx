import { DSButton } from '@sm/skywise-react-library';
import * as React from 'react';
import { Link } from 'react-router-dom';

export class PasswordResetForm extends React.Component<any, any> {

  constructor(props: any) {
    super(props);
    this.state = {
      code: '',
      error: '',
      loginLinkDisplayed: false,
      message: '',
      password: '',
      passwordConfirm: '',
      username: props.username
    };
  }

  private onSubmit = (event: any) => {
    event.preventDefault();

    if (this.state.password === this.state.passwordConfirm) {
      this.props.setPassword(this.state.username, this.state.code, this.state.password)
        .then(() => {
          this.setState({
            error: '',
            loginLinkDisplayed: true,
            message: 'Password reset. You can now '
          });
        })
        .catch(err => this.setState({
          error: err.message,
          message: ''
        }));
    } else {
      this.setState({
        error: 'the password and the confirm password are different'
      });
    }
  }

  private sendVerificationCode = (event: any) => {
    event.preventDefault();
    this.props.sendVerificationCode(this.state.username)
      .then(() => this.setState({
        error: '',
        message: 'Verification code sent'
      }))
      .catch((err) => {
        if (err.code === 'UserNotFoundException') {
          this.setState({ error: 'User not found' });
        } else {
          this.setState({ error: err.message });
        }
      });
  }

  private changePassword = (event: any) => {
    this.setState({ password: event.target.value });
  }

  private confirmPassword = (event: any) => {
    this.setState({ passwordConfirm: event.target.value });
  }

  private changeCode = (event) => {
    this.setState({ code: event.target.value });
  }

  private changeUsername = (event) => {
    this.setState({ username: event.target.value });
  }

  public render() {
    return (
      <div className="login-form">
        <div className="error">{this.state.error}</div>
        {this.state.message.length > 0 &&
          <div className="info">
            {this.state.message}
            {this.state.loginLinkDisplayed &&
              <Link to="/login">login with your new password</Link>
            }
          </div>
        }
        <form onSubmit={this.sendVerificationCode}>
          <div>
            <label>
              Username
            </label>
            <input
              type="text"
              placeholder="username"
              value={this.state.username}
              onChange={this.changeUsername}
              required={true}
            />
            <button type="submit">Send verification code</button>
          </div>
        </form>
        <form onSubmit={this.onSubmit}>
          <div>
            <label>
              Verification code
            </label>
            <input placeholder="code" onChange={this.changeCode} required={true} />
          </div>
          <div className="password">
            <label>
              Password
            </label>
            <input
              type="password"
              placeholder="new password"
              onChange={this.changePassword}
              required={true}
            />
          </div>
          <div>
            <label>
              Confirm Password
            </label>
            <input
              type="password"
              placeholder="confirm new password"
              onChange={this.confirmPassword}
              required={true}
            />
          </div>
          <DSButton
            content="Set new password"
            handleClick={this.onSubmit}
            color="white"
          />
        </form>
        <Link to="/login">Back to Login</Link>
      </div>
    );
  }
}

export default PasswordResetForm;
