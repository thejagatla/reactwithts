import * as React from 'react';

export class NewPasswordRequiredForm extends React.Component<any, any> {

  constructor(props: any) {
    super(props);
    this.state = {
      error: props.error,
      password: '',
    };
  }

  private onSubmit = (event: any) => {
    event.preventDefault();
    this.props.onSubmit(this.state.password);
  }

  private changePassword = (event: any) => {
    this.setState({ password: event.target.value });
  }

  public render() { 
    return (
      <form onSubmit={this.onSubmit}>
        <div className="error">{this.props.error}</div>
        <div>
          <label>
          Password
          </label>
          <input type="password" placeholder="new password" onChange={this.changePassword} required={true} />
        </div>
        <button type="submit">Set new password</button>
      </form>
    );
  }
}

export default NewPasswordRequiredForm;
