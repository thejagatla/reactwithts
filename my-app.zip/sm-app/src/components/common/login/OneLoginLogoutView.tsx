/**
 * OneLogin Log-out view
 * @author Capgemini
 * @version 1.0
 */
import { DSLoader, DSSegment } from '@sm/skywise-react-library';
import * as React from 'react';
import { Redirect } from 'react-router';
import * as Strings from '../../../lang/strings.json';
import { ONELOGIN_LOGGIN_OUT } from '../../../store/actions/LoginActions';

export class OneLoginLogoutView extends React.Component<any, any> {

  /**
   * Constructor
   * @param props properties
   */
  constructor(props: any) {
    super(props);
  }

  /**
   * React lifecycle method
   */
  public componentDidMount() {
    if (this.props.oneLogin.state === ONELOGIN_LOGGIN_OUT) {
      setTimeout(() => { this.props.confirmLogout(); }, 1000);
    }
  }

  /**
   * React lifecycle method
   */
  public render() {
    const isLogginOut: boolean = this.props.oneLogin.state === ONELOGIN_LOGGIN_OUT;

    return (
      <React.Fragment>
        {isLogginOut ? (
          <DSSegment alignment="center" textAlign="center">
            <DSLoader />
            <p>{Strings.loggedOutMessage}</p>
          </DSSegment>
        ) : (
            <Redirect to="/onelogin" />
          )}
      </React.Fragment>
    );
  }
}
