import * as React from 'react';
import { changePassword } from 'react-cognito';

export class ChangePasswordForm extends React.Component<any, any> {

  constructor(props: any) {
    super(props);
    this.state = {
      error: '',
      newPassword: '',
      oldPassword: ''
    };
  }

  private onSubmit = (event: any) => {
    const { store } = this.context;
    const state = store.getState();
    const user = state.cognito.user;
    event.preventDefault();
    changePassword(user, this.state.oldPassword, this.state.newPassword).then(
      () => this.setState({ error: 'Password changed' }),
      error => this.setState({ error }));
  }

  private changeOldPassword = (event: any) => {
    this.setState({ oldPassword: event.target.value });
  }

  private changeNewPassword = (event: any) => {
    this.setState({ newPassword: event.target.value });
  }

  public render() {
    return (
      <form onSubmit={this.onSubmit}>
        <div>{this.state.error}</div>
        <label>
          Old Password
          <input placeholder="old password" onChange={this.changeOldPassword} required={true} />
        </label>
        <label>
          New Password
          <input placeholder="new password" onChange={this.changeNewPassword} required={true} />
        </label>
        <button type="submit">Set new password</button>
      </form>
    );
  }
}

export default ChangePasswordForm;
