import * as React from 'react';
import { PasswordReset } from 'react-cognito';
import PasswordResetForm from './PasswordResetForm';

const PasswordReset = () => {
  return (
    <PasswordReset>
      <PasswordResetForm />
    </PasswordReset>
  );
};

export default PasswordReset;
