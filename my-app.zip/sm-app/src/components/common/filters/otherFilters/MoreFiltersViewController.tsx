import * as React from 'react';
import { FleetsweepFilterTypeEnum } from '../../../../model/fleetsweep/FleetsweepConstantes';
import { FleetsweepFilter, FleetsweepFilterValue } from '../../../../model/fleetsweep/FleetsweepInterfaces';
import { startTimeout } from '../../../../utils/EventsUtils';
import { getFullFleetsweepValueFromEnum } from '../../../../utils/FleetsweepUtils';
import { HtmlCheckboxProps } from '../../../storybook';
import { Filter } from '../../../storybook/filter/Filter';

interface MoreFiltersViewControllerProps {
  filters: FleetsweepFilter[];
  setMoreFilters(pMoreFilters: FleetsweepFilter[]): void;
}

interface MoreFiltersViewControllerState {
  filters: FleetsweepFilter[];
}

/**
 * Controller class for 'more filters' button
 * Component type: UI controller 
 */
export default class MoreFiltersViewController
  extends React.Component<MoreFiltersViewControllerProps, MoreFiltersViewControllerState> {

  /**
   * Constructor
   * @param props React props 
   */
  public constructor(props: MoreFiltersViewControllerProps) {
    super(props);
    this.state = { filters: this.props.filters };

    this.getTextList = this.getTextList.bind(this);
    this.isEmpty = this.isEmpty.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    this.convertFilterValues = this.convertFilterValues.bind(this);
    this.clearFilters = this.clearFilters.bind(this);
    this.handleCheckboxChange = this.handleCheckboxChange.bind(this);
    this.handleCancelClick = this.handleCancelClick.bind(this);
  }

  /**
   * React lifecycle method
   * @param nextProps next props
   * @param nextState next state
   */
  public shouldComponentUpdate(
    nextProps: MoreFiltersViewControllerProps,
    nextState: MoreFiltersViewControllerState): boolean {
    
    return nextState !== this.state;
  }

  /**
   * Return text to display in the button
   * @param pType filter type (AIRCRAFT_TYPE...)
   */
  private getTextList(pType: string): string[] {
    const lResult: string[] = [];

    this.state.filters.forEach((lFilter) => {
      if (lFilter.type === pType) {
        lResult.push(lFilter.title);
      }
    });

    return lResult;
  }

  /**
   * Convert filter values text into presentational form
   * @param pType filter type (AIRCRAFT_TYPE...)
   */
  private convertFilterValues(pType: string): HtmlCheckboxProps[] {
    const lResult: HtmlCheckboxProps[] = [];

    this.state.filters.forEach((lFilter) => {
      if (lFilter.type === pType) {
        lFilter.values.forEach((lValue) => {
          const type: any = FleetsweepFilterTypeEnum[lFilter.type];

          lResult.push({
            active: lValue.active,
            id: lValue.value,
            label: getFullFleetsweepValueFromEnum(type, lValue.value)
          });
        });
      }
    });

    return lResult;
  }

  /**
   * Handle click on the clear filters button
   * @param pType filter type (AIRCRAFT_TYPE...)
   */
  private clearFilters(pType: string): void {    
    const lMoreFilters: FleetsweepFilter[] = this.state.filters.map((lFilter) => {
      if (lFilter.type === pType) {
        const lMoreFiltersValues: FleetsweepFilterValue[] = lFilter.values.map((lFilterValue) => {
          return {
            active: false,
            value: lFilterValue.value
          };
        });
        return { title: lFilter.title, type: lFilter.type, values: lMoreFiltersValues };
      }
      return lFilter;
    });

    this.setState({ filters: lMoreFilters });
  }

  /**
   * Return true if the button is empty, false otherwise
   * @param pType filter type (AIRCRAFT_TYPE...)
   */
  private isEmpty(pType: string): boolean {
    
    let lResult: boolean = true;

    this.state.filters.forEach((lFilter) => {
      if (lFilter.type === pType) {
        lFilter.values.forEach((lFilterValue) => {
          if (lFilterValue.active) {
            lResult = false;
          }
        });
      }
    });

    return lResult;
  }

  /**
   * Handle click on the cancel filters button
   * @param pType filter type (AIRCRAFT_TYPE...)
   */
  private handleCancelClick(pType: string): void {
    const lMoreFilters: FleetsweepFilter[] = this.state.filters.map((lFilter, index) => {
      if (lFilter.type === pType) {
        return this.props.filters[index];
      }
      return lFilter;
    });

    this.setState({ filters: lMoreFilters });
  }

  /**
   * Handle click on a checkbox
   * @param pType filter type (AIRCRAFT_TYPE...)
   * @param pId checkbox id
   */
  private handleCheckboxChange(pType: string, pId: string): void {
    const lMoreFilters: FleetsweepFilter[] = this.state.filters.map((lFilter, index) => {
      if (lFilter.type === pType) {
        const lMoreFiltersValues: FleetsweepFilterValue[] =
          lFilter.values.map((lFilterValue: FleetsweepFilterValue) => {
            if (lFilterValue.value === pId) {
              return { active: !lFilterValue.active, value: lFilterValue.value };
            }

            return lFilterValue;
          });
        
        return { title: lFilter.title, type: lFilter.type, values: lMoreFiltersValues };
      }
      return lFilter;
    });

    this.setState({ filters: lMoreFilters });
  }

  /**
   * Save filters and launch search
   * @param pType filter type (AIRCRAFT_TYPE...)
   */
  private onSubmit(pType: string): void {
    this.props.setMoreFilters(this.state.filters);
    // launch search
    startTimeout(true);
  }

  /**
   * React method
   */
  public render() {
    
    const lMoreFilters: React.ReactNode = this.state.filters.map((lFilter, index) => {
      const lLabel: string = !this.isEmpty(lFilter.type) ? '' : lFilter.title;

      return (
        <Filter
          key={index}
          type={lFilter.type}
          label={lLabel}
          textList={this.getTextList}
          handleCancelClick={this.handleCancelClick}
          handleCheckboxChange={this.handleCheckboxChange}
          clearFilters={this.clearFilters}
          onSubmit={this.onSubmit}
          isEmpty={this.isEmpty}
          values={this.convertFilterValues}
        />
      );
    });
  
    return (
      <React.Fragment>
        {lMoreFilters}
      </React.Fragment>
    );
  }
}
