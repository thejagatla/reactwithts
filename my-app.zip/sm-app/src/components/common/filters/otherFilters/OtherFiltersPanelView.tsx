import * as React from 'react';
import { FleetsweepFilter } from '../../../../model/fleetsweep/FleetsweepInterfaces';
import MoreFiltersViewController from './MoreFiltersViewController';
import { PeriodFilterView } from './PeriodFilterView';

interface OtherFiltersPanelViewProps {
  filters: FleetsweepFilter[];
  period: number;
  setMoreFilters(pMoreFilters: FleetsweepFilter[]): void;
  setPeriod(pPeriod: number): void;
}

/**
 * File description: Other filters main panel controller
 * Component type: UI controller
 */
export const OtherFiltersPanelView = (props: OtherFiltersPanelViewProps) => {

  const { filters, period, setMoreFilters, setPeriod } = props;
  
  return (
    <div className="l-other-filters">
      <div>
        <PeriodFilterView
          setPeriod={setPeriod}
          period={period}
        />
        <MoreFiltersViewController
          filters={filters}
          setMoreFilters={setMoreFilters}
        />
      </div>
    </div>
  );
};
