/**
 * File description: Fleet Sweep main panel controller
 * @author Capgemini
 * @version 1.0
 */

import * as React from 'react';
import { FilterPeriods } from '../../../../model/FiltersConstantes';
import * as periodFilter from '../../../../resources/periodFilter.json';
import { startTimeout } from '../../../../utils/EventsUtils';
import { HtmlCheckboxProps } from '../../../storybook';
import { Filter } from '../../../storybook/filter/Filter';

export class PeriodFilterView extends React.Component<any, any> {
  /**
   * Constructor
   * @param props React props 
   */
  public constructor(props: any) {
    super(props);

    this.state = {
      initial: true,
      selected: props.period ? props.period : -1,
      selectedDisplay: props.period,
      textList: [FilterPeriods[props.period]]
    };

    this.isEmpty = this.isEmpty.bind(this);
    this.convertFilterValues = this.convertFilterValues.bind(this);
    this.handleRadioChange = this.handleRadioChange.bind(this);
    this.clearFilter = this.clearFilter.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    this.getTextList = this.getTextList.bind(this);
    this.handleCancelClick = this.handleCancelClick.bind(this);
  }

  /**
   * React lifecycle method
   * @param nextProps next props
   * @param nextState next state
   */
  public shouldComponentUpdate(nextProps: any, nextState: any): boolean {
    return (nextState !== this.state);
  }

  /**
   * Convert filter values text into presentational form
   */
  private convertFilterValues(): HtmlCheckboxProps[] {
    const lResult: HtmlCheckboxProps[] = [];

    periodFilter.values.forEach((lValue) => {
      let activeRadio = lValue.active;
      if (this.state.selected === lValue.value) {
        activeRadio = true;
      }
      lResult.push({
        active: activeRadio,
        id: lValue.value,
        label: FilterPeriods[lValue.value]
      });
    });

    return lResult;
  }

  /**
   * Convert filter values text into presentational form
   */
  public getTextList(pFilterType: string): string[] {
    return this.state.textList;
  }

  /**
   * Return true if should be empty, false otherwise
   */
  private isEmpty(): boolean {
    return (
      this.state.selectedDisplay === -1
    );
  }

  /**
   * Return true if should be empty, false otherwise
   */
  private clearFilter(): void {
    this.setState({
      selected: -1
    });
  }

  /**
   * Return true if should be empty, false otherwise
   */
  private onSubmit(): void {
    if (this.state.selected !== -1) {
      this.setState({
        selectedDisplay: this.state.selected,
        textList: [FilterPeriods[this.state.selected]],
      });
    } else {
      this.setState({
        selectedDisplay: -1,
        textList: []
      });
    }

    this.props.setPeriod(this.state.selected);
    startTimeout(true);
  }

  /**
   * Return true if should be empty, false otherwise
   */
  private handleCancelClick(): void {
    this.setState({
      selected: this.props.period
    });
  }

  /**
   * Handle click on radioButton
   * @param pFilterType Filter type (WORK_STATUS, PRIORITY...)
   * @param pRadioId checkbxox id (TO_BE_REVIEWED, W, HIGH...)
   */
  private handleRadioChange(pFilterType: string, pRadioId: string): void {
    this.setState({
      selected: pRadioId
    });
  }

  /**
   * Render method
   */
  public render() {
    return (
      <Filter
        isEmpty={this.isEmpty}
        label="Period"
        type={periodFilter.type}
        textList={this.getTextList}
        values={this.convertFilterValues}
        inputType="radio"
        clearFilters={this.clearFilter}
        handleCheckboxChange={this.handleRadioChange}
        handleCancelClick={this.handleCancelClick}
        onSubmit={this.onSubmit}
      />
    );
  }
}
