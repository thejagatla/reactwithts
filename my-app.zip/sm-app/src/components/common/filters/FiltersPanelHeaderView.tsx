/**
 * File description: Fleet Sweep main panel controller
 * @author Capgemini
 * @version 1.0
 */
import { DSButton, DSIcon, DSList, DSTabs } from '@sm/skywise-react-library';
import * as React from 'react';

export const FiltersPanelHeaderView = (props) => {
  const list: JSX.Element[] = [];
  const type = props.filtersVisible ? 'chevron_up' : 'chevron_down';
  list.push(
    <DSButton
      id="toggle-filters"
      as="a"
      icon={
        <DSIcon
          type={type}
        />
      }
      handleClick={props.toggleFiltersVisibility}
    />
  );

  return (
    <div>
      <DSTabs
        onTabClick={props.setActiveTab}
        selectedIndex={props.selectedTabId}
        tabs={props.lTabs}
        stepping={true}
      />
      <div className="filters-panel__menu">
        <DSList
          direction="horizontal"
          list={list}
        />
      </div>
    </div>
  );
};
