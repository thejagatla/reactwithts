import * as React from 'react';
import { FLEETSWEEP_TAB_PREFIX } from '../../../model/fleetsweep/FleetsweepConstantes';
import {
  FleetsweepFilter,
  FleetsweepFilterValue
} from '../../../model/fleetsweep/FleetsweepInterfaces';
import { startTimeout } from '../../../utils/EventsUtils';
import { FiltersPanelContentView } from './FiltersPanelContentView';
import { FiltersPanelHeaderView } from './FiltersPanelHeaderView';

interface DSTabProps {
  id: string;
  title: string;
}

/**
 * File description: Fleet Sweep main panel controller
 * @author Capgemini
 * @version 1.0
 */
export class FiltersPanelViewController extends React.Component<any, any> {
  private oldPeriod: any;

  /**
   * Constructor
   * @param props React props
   */
  public constructor(props: any) {
    super(props);

    this.state = {
      customizeTab: props.state.customizeTab,
      filtersVisible: props.state.filtersVisible,
      selectedTabId: props.state.selectedTabId,
      tabs: props.state.tabs
    };

    this.setActiveTab = this.setActiveTab.bind(this);
    this.toggleFiltersVisibility = this.toggleFiltersVisibility.bind(this);
    this.setFiltersState = this.setFiltersState.bind(this);
    this.launchSearch = this.launchSearch.bind(this);
  }

  /**
   * Should component update
   */
  public shouldComponentUpdate(nextProps: any, nextState: any) {
    if (nextState === this.state && this.oldPeriod === nextProps.state.period) {
      return false;
    }
    return true;
  }

  /**
   * React lifecycle method
   * @param nextProps next props
   * @param nextState next state
   */
  public componentDidUpdate(prevProps: any, prevState: any) {
    if (prevState.selectedTabId !== this.state.selectedTabId) {
      this.launchSearch();
    }
  }

  public toggleFiltersVisibility() {
    this.props.setToggleFiltersVisibility(!this.state.filtersVisible);
  }

  /**
   * Launch search
   */
  private launchSearch(): void {
    this.props.setFilters(
      this.copyFilters(this.state.tabs[this.state.selectedTabId].filters)
    );
    startTimeout(true);
  }

  private setFiltersState(newState: any): void {
    this.props.setFleetsweepState(newState);
  }

  /**
   * Should component update
   */
  public componentWillReceiveProps(nextProps: any) {
    this.oldPeriod = this.props.state.period;

    this.setState({
      customizeTab: nextProps.state.customizeTab,
      filtersVisible: nextProps.state.filtersVisible,
      selectedTabId: nextProps.state.selectedTabId,
      tabs: nextProps.state.tabs
    });
  }

  /**
   * Copy source filters into a new filters array
   * @param pFromFilters origin filters
   */
  private copyFilters(pFromFilters: FleetsweepFilter[]): FleetsweepFilter[] {
    return pFromFilters.map(lFromFilter => {
      return {
        title: lFromFilter.title,
        type: lFromFilter.type,
        values: this.copyValues(lFromFilter.values)
      };
    });
  }

  /**
   * Copy source values into a new values array
   * @param pFromValues origin values
   */
  private copyValues(
    pFromValues: FleetsweepFilterValue[]
  ): FleetsweepFilterValue[] {
    return pFromValues.map(lFromValue => Object.assign({}, lFromValue));
  }

  /**
   * Change active tab and launch search
   * @param pSelectedTabId selected tab id
   */
  private setActiveTab(pSelectedTabId: string) {
    const lSelectedTabId: number = parseInt(
      pSelectedTabId.split(FLEETSWEEP_TAB_PREFIX)[1],
      10
    );

    // Change active tab
    this.props.setActiveTab(lSelectedTabId);
  }

  /**
   * Render method
   */
  public render() {
    const lTabs: DSTabProps[] = this.state.tabs.map((tab, index) => {
      return { id: FLEETSWEEP_TAB_PREFIX + index, title: tab.title };
    });

    return (
      <div className="filters-panel">
        <FiltersPanelHeaderView
          filtersVisible={this.state.filtersVisible}
          setActiveTab={this.setActiveTab}
          lTabs={lTabs}
          selectedTabId={this.state.selectedTabId}
          toggleFiltersVisibility={this.toggleFiltersVisibility}
        />
        <FiltersPanelContentView
          setFilters={this.props.setFilters}
          setPeriod={this.props.setPeriod}
          filters={this.props.state.filters}
          moreFilters={this.props.state.moreFilters}
          period={this.props.state.period}
          selectedTabId={this.state.selectedTabId}
          tabs={this.state.tabs}
          copyValues={this.copyValues}
          filterVisible={this.state.filtersVisible}
          copyFilters={this.copyFilters}
          customizeTab={this.state.customizeTab}
          launchSearch={this.launchSearch}
          setFiltersState={this.setFiltersState}
          setMoreFilters={this.props.setMoreFilters}
        />
      </div>
    );
  }
}
