/**
 * File description: Fleet Sweep main panel controller
 * @author Capgemini
 * @version 1.0
 */
import * as classNames from 'classnames';
import * as React from 'react';
import { FleetsweepPanelViewController } from './fleetsweep/FleetsweepPanelViewController';
import { OtherFiltersPanelView } from './otherFilters/OtherFiltersPanelView';

export const FiltersPanelContentView = (props) => {
  const filtersClass = classNames({
    filters: true,
    hidden: !props.filterVisible,
    'l-filters': true
  });

  return (
    <div className={filtersClass}>
      <FleetsweepPanelViewController
        setFilters={props.setFilters}
        filters={props.filters}
        selectedTabId={props.selectedTabId}
        tabs={props.tabs}
        copyValues={props.copyValues}
        copyFilters={props.copyFilters}
        setFiltersState={props.setFiltersState}
        customizeTab={props.customizeTab}
        launchSearch={props.launchSearch}
      />
      <OtherFiltersPanelView
        filters={props.moreFilters}
        period={props.period}
        setMoreFilters={props.setMoreFilters}
        setPeriod={props.setPeriod}
      />
    </div>
  );
};
