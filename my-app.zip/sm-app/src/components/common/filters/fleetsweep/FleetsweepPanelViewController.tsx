/**
 * File description: Fleet Sweep main panel controller
 * @author Capgemini
 * @version 1.0
 */
import { DSTabPanel } from '@sm/skywise-react-library';
import * as React from 'react';
import * as Strings from '../../../../lang/strings.json';
import { FleetsweepFilterTypeEnum } from '../../../../model/fleetsweep/FleetsweepConstantes';
import {
  FleetsweepFilter,
  FleetsweepTab
} from '../../../../model/fleetsweep/FleetsweepInterfaces';
import * as fleetsweepFilters from '../../../../resources/fleetsweepFilters.json';
import {
  getFullFleetsweepValueFromEnum,
  getIconFromWorkStatusEnum,
  getShortFleetsweepValueFromEnum
} from '../../../../utils/FleetsweepUtils';
import { HtmlCheckboxProps, SkywiseICONS } from '../../../storybook';
import { Filter } from '../../../storybook/filter/Filter';
import { OccurrenceHelpView } from '../../help/OccurrenceHelpView';

interface FleetsweepPanelViewState {
  customizeTab: boolean;
}

export class FleetsweepPanelViewController extends React.Component<any, FleetsweepPanelViewState> {

  /** Previous filter */
  private previousFilter: FleetsweepFilter;

  /**
   * Constructor
   * @param props React props
   */
  public constructor(props: any) {
    super(props);

    this.convertFilterValues = this.convertFilterValues.bind(this);
    this.clearFilters = this.clearFilters.bind(this);
    this.handleCancelClick = this.handleCancelClick.bind(this);
    this.handleCheckboxChange = this.handleCheckboxChange.bind(this);
    this.handleApplyClick = this.handleApplyClick.bind(this);
    this.handleButtonClick = this.handleButtonClick.bind(this);
    this.openCustomizeTab = this.openCustomizeTab.bind(this);
    this.getTextList = this.getTextList.bind(this);
    this.getIconsList = this.getIconsList.bind(this);
    this.isEmpty = this.isEmpty.bind(this);
    this.manageTabs = this.manageTabs.bind(this);
  }

  public manageTabs(pFilterType: string): FleetsweepFilter[] {
    return this.props.tabs[this.props.selectedTabId].filters.map((lFilter) => {
      if (lFilter.type === pFilterType) {
        return {
          title: lFilter.title,
          type: lFilter.type,
          values: this.props.copyValues(this.previousFilter.values)
        };
      }
      return lFilter;
    });
  }

  /**
   * Handle cancel click
   * @param pFilterType Filter type (WORK_STATUS, PRIORITY...)
   */
  private handleCancelClick(pFilterType: string): void {
    // Retrieve previous filter values of the selected tab
    const lTabs: FleetsweepTab[] = this.props.tabs.map((lDefaultTab, index) => {
      if (index === this.props.selectedTabId) {
        const lFleetsweepFilters = this.manageTabs(pFilterType);
        return { title: lDefaultTab.title, filters: lFleetsweepFilters };
      }
      return lDefaultTab;
    });

    this.props.setFiltersState({
      customizeTab: this.props.customizeTab,
      selectedTabId: this.props.selectedTabId,
      tabs: lTabs
    });
  }

  /**
   * Handle click on checkbox
   * @param pFilterType Filter type (WORK_STATUS, PRIORITY...)
   * @param pCheckboxId checkbxox id (TO_BE_REVIEWED, W, HIGH...)
   */
  private handleCheckboxChange(pFilterType: string, pCheckboxId: string): void {
    const lTabs: FleetsweepTab[] = this.props.tabs.map((lDefaultTab, index) => {
      if (index === this.props.selectedTabId) {
        const lFleetsweepFilters = this.props.tabs[this.props.selectedTabId].filters.map((lFilter) => {
          if (lFilter.type === pFilterType) {
            return this.createCustomFleetsweepFilter(lFilter, pCheckboxId);
          }
          return lFilter;
        });
        return { title: lDefaultTab.title, filters: lFleetsweepFilters };
      }
      return lDefaultTab;
    });

    this.props.setFiltersState({
      customizeTab: this.props.customizeTab,
      selectedTabId: this.props.selectedTabId,
      tabs: lTabs
    });
  }

  /**
   * Create custom FleetsweepFilter object
   * @param pFilter source filter
   * @param pCheckboxId checkbox id
   */
  private createCustomFleetsweepFilter(pFilter: FleetsweepFilter, pCheckboxId: string): FleetsweepFilter {

    const lFleetsweepFilterValues = pFilter.values.map((lValue) => {
      let lFilterValue: boolean = lValue.active;

      if (lValue.value === pCheckboxId) {
        lFilterValue = !lValue.active;
      }
      return { value: lValue.value, active: lFilterValue };
    });

    return { title: pFilter.title, type: pFilter.type, values: lFleetsweepFilterValues };
  }

  /**
   * Clear filters
   * @param pFilterType filter type (WORK_STATUS, PRIORITY...)
   */
  private clearFilters(pFilterType: string): void {
    const lTabs: FleetsweepTab[] = this.props.tabs.map((lDefaultTab, index) => {
      if (index === this.props.selectedTabId) {
        const lFleetsweepFilters = this.props.tabs[this.props.selectedTabId].filters.map((lFilter) => {
          if (lFilter.type === pFilterType) {
            const lFleetsweepFilterValues = lFilter.values.map((lValue) => {
              return { active: false, value: lValue.value };
            });
            return { title: lFilter.title, type: lFilter.type, values: lFleetsweepFilterValues };
          }
          return lFilter;
        });
        return { title: lDefaultTab.title, filters: lFleetsweepFilters };
      }
      return lDefaultTab;
    });

    this.props.setFiltersState({
      customizeTab: this.props.customizeTab,
      selectedTabId: this.props.selectedTabId,
      tabs: lTabs
    });
  }

  /**
   * Handle click on button opening
   * @param pFilterType filter type (WORK_STATUS, PRIORITY...)
   */
  private handleButtonClick(pFilterType: string): void {
    this.props.tabs[this.props.selectedTabId].filters.forEach((lFilter) => {
      if (lFilter.type === pFilterType) {
        // Store copy of selected tab filter values
        this.previousFilter = {
          title: lFilter.title,
          type: lFilter.type,
          values: this.props.copyValues(lFilter.values)
        };
      }
    });
  }

  /**
   * Create or update customize tab
   * @param pFilterType filter type (WORK_STATUS, PRIORITY...)
   */
  private openCustomizeTab(pFilterType: string): void {

    // Copy new filters values
    const lFleetsweepFilters: FleetsweepFilter[] =
      this.props.copyFilters(this.props.tabs[this.props.selectedTabId].filters);

    // Build customize tab
    const lCustomizeTab: FleetsweepTab = {
      filters: lFleetsweepFilters,
      title: Strings.customizeTabName
    };

    // Retrieve previous filter values of the selected tab
    const lTabs: FleetsweepTab[] = this.props.tabs.map((lDefaultTab, index) => {
      if (index === this.props.selectedTabId) {
        const lPreviousFleetsweepFilters: FleetsweepFilter[] = this.manageTabs(pFilterType);
        return { title: lDefaultTab.title, filters: lPreviousFleetsweepFilters };
      }
      return lDefaultTab;
    });

    // If there is no customize tab
    if (!this.props.customizeTab) {
      // Add customize tab to state
      lTabs.push(lCustomizeTab);

      this.props.setFiltersState({
        customizeTab: true,
        selectedTabId: lTabs.length - 1,
        tabs: lTabs
      });
    } else {
      // Update customize tab
      lTabs[this.props.tabs.length - 1] = lCustomizeTab;

      this.props.setFiltersState({
        customizeTab: this.props.customizeTab,
        selectedTabId: this.props.tabs.length - 1,
        tabs: lTabs
      });
    }
  }

  /**
   * Return text to dispplay on the filter button
   * @param pFilterType filter type (WORK_STATUS, PRIORITY...)
   */
  private getTextList(pFilterType: string): string[] {
    let lTextList: string[] = [];

    // Customize tab
    if (this.props.selectedTabId === fleetsweepFilters.tabs.length) {
      lTextList = this.getTextListForValues(pFilterType, this.props.tabs[this.props.selectedTabId].filters);
    } else {
      lTextList = this.getTextListForValues(
        pFilterType,
        fleetsweepFilters.tabs[this.props.selectedTabId].filters);
    }

    return lTextList;
  }

  /**
   * Return text to display on the filter button
   * @param pFilterType filter type (WORK_STATUS, PRIORITY...)
   * @param pFleetsweepFilters filters list
   */
  private getTextListForValues(pFilterType: string, pFleetsweepFilters: FleetsweepFilter[]): string[] {
    const lTempResult: string[] = [];
    const lTextList: string[] = [];

    pFleetsweepFilters.forEach((lFilter) => {
      if (lFilter.type === pFilterType) {
        // Count active elements
        lFilter.values.forEach((lValue) => {
          if (lValue.active) {
            lTempResult.push(lValue.value);
          }
        });

        // Build a short text list if number of filter values is higher than 2
        if (lTempResult.length > 2) {
          lTempResult.forEach((lValue) => {
            const lShortValue =
              getShortFleetsweepValueFromEnum(FleetsweepFilterTypeEnum[pFilterType], lValue);
            if (lShortValue !== '') {
              lTextList.push(lShortValue);
            }
          });
        } else {
          lTempResult.forEach((lValue) => {
            lTextList.push(getFullFleetsweepValueFromEnum(
              FleetsweepFilterTypeEnum[pFilterType], lValue));
          });
        }
      }
    });
    return lTextList;
  }

  /**
   * Return icons to display on the filter button
   * @param pFilterType filter type (WORK_STATUS, PRIORITY...)
   */
  private getIconsList(pFilterType: string): SkywiseICONS[] {
    let lIconList: SkywiseICONS[] = [];

    if (pFilterType === FleetsweepFilterTypeEnum[FleetsweepFilterTypeEnum.WORK_STATUS]) {

      // Customize tab
      if (this.props.selectedTabId === fleetsweepFilters.tabs.length) {
        lIconList = this.getIconsListForValues(this.props.tabs[this.props.selectedTabId].filters, pFilterType);
      } else {
        lIconList = this.getIconsListForValues(
          fleetsweepFilters.tabs[this.props.selectedTabId].filters,
          pFilterType);
      }
    }

    return lIconList;
  }

  /**
   * Return icons to display on the filter button
   * @param pFleetsweepFilters filters list
   * @param pFilterType filter type (WORK_STATUS, PRIORITY...)
   */
  private getIconsListForValues(pFleetsweepFilters: FleetsweepFilter[], pFilterType: string): SkywiseICONS[] {
    const lIconList: SkywiseICONS[] = [];

    pFleetsweepFilters.forEach((lFilter) => {
      if (lFilter.type === pFilterType) {
        lFilter.values.forEach((lValue) => {
          if (lValue.active) {
            lIconList.push(getIconFromWorkStatusEnum(lValue.value));
          }
        });
      }
    });

    return lIconList;
  }

  /**
   * Handle click on Apply button
   * @param pFilterType Filter type (WORK_STATUS, PRIROTY...)
   */
  private handleApplyClick(pFilterType: string): void {
    // Customize tab
    if (this.props.selectedTabId === fleetsweepFilters.tabs.length) {
      // State has already been updated with toggled checkboxes (handleCheckboxChange)
      this.props.launchSearch();
    } else {
      this.openCustomizeTab(pFilterType);
    }
  }

  /**
   * Convert filter values text into presentational form
   * @param pFilterType Filter type (WORK_STATUS, PRIROTY...)
   */
  private convertFilterValues(pFilterType: string): HtmlCheckboxProps[] {
    const lResult: HtmlCheckboxProps[] = [];

    this.props.tabs[this.props.selectedTabId].filters.forEach((lFilter) => {
      if (lFilter.type === pFilterType) {
        lFilter.values.forEach((lValue) => {
          const type: any = FleetsweepFilterTypeEnum[lFilter.type];

          lResult.push({
            active: lValue.active,
            id: lValue.value,
            label: getFullFleetsweepValueFromEnum(type, lValue.value)
          });
        });
      }
    });

    return lResult;
  }

  /**
   * Return true if should be empty, false otherwise
   * @param pFilterType Filter type (WORK_STATUS, PRIROTY...)
   */
  private isEmpty(pFilterType: string): boolean {
    return this.getTextList(pFilterType).length < 1 && this.getIconsList(pFilterType).length < 1;
  }

  private getHelpTitle(pFilterType: string): string {
    switch (pFilterType) {
      case FleetsweepFilterTypeEnum[FleetsweepFilterTypeEnum.WORK_STATUS]:
        return 'Workflow Status Help';

      case FleetsweepFilterTypeEnum[FleetsweepFilterTypeEnum.OCCURRENCE]:
        return 'Occurrence Help';

      case FleetsweepFilterTypeEnum[FleetsweepFilterTypeEnum.PRIORITY]:
      case FleetsweepFilterTypeEnum[FleetsweepFilterTypeEnum.EVENT_RANK]:
      default:
        return '';
    }

  }

  private getHelpContent(pFilterType: string): JSX.Element {
    switch (pFilterType) {
      case FleetsweepFilterTypeEnum[FleetsweepFilterTypeEnum.WORK_STATUS]:
        return (
          <img src="/img/workStatus.png" width="100%" />
        );
      case FleetsweepFilterTypeEnum[FleetsweepFilterTypeEnum.OCCURRENCE]:
        return (
          <OccurrenceHelpView />
        );
      case FleetsweepFilterTypeEnum[FleetsweepFilterTypeEnum.PRIORITY]:
      case FleetsweepFilterTypeEnum[FleetsweepFilterTypeEnum.EVENT_RANK]:
      default:
        return <React.Fragment />;
    }

  }

  /**
   * Render method
   */
  public render() {
    const lFilters: React.ReactNode =
      this.props.tabs[this.props.selectedTabId].filters.map((lFilter, index) => {
        return (
          <Filter
            key={index}
            type={lFilter.type}
            label={lFilter.title}
            textList={this.getTextList}
            iconList={this.getIconsList}
            handleCancelClick={this.handleCancelClick}
            handleButtonClick={this.handleButtonClick}
            handleCheckboxChange={this.handleCheckboxChange}
            clearFilters={this.clearFilters}
            onSubmit={this.handleApplyClick}
            isEmpty={this.isEmpty}
            getHelpContent={this.getHelpContent}
            getHelpTitle={this.getHelpTitle}
            values={this.convertFilterValues}
          />
        );
      });

    return (
      <div className="l-fleetsweep-tabs">
        <DSTabPanel>
          {lFilters}
        </DSTabPanel>
      </div>
    );
  }
}
