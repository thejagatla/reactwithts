/**
 * Class description: React predictive event chart section component
 * @author Capgemini
 * @version 1.0
 */

import * as React from 'react';
import { DShighchartsViewController } from '../eventChart/DShighchartsViewController';

declare global {
  interface Function {
    displayName?: string;
  }
}

export const EventChartSectionView = (props: any) => {
  return (
    <div className="chart-container">
      <DShighchartsViewController 
        highchartData={props.highchartData}
        redim={props.chartRedim}
        event={props.event}
        statusHistory={props.statusHistory}
      />
    </div>
  );
};

EventChartSectionView.displayName = 'EventChartSectionView';
