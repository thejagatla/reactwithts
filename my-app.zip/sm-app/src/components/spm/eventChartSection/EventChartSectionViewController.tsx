/**
 * Class description: React predictive event chart section view controller
 * @author Capgemini
 * @version 1.0
 */
import { DSBanner, DSLoader } from '@sm/skywise-react-library';
import * as React from 'react';
import * as Strings from '../../../lang/strings.json';
import { openErrorModal } from '../../../utils/ModalsUtils';
import { EventChartSectionView } from './EventChartSectionView';

export class EventChartSectionViewController extends React.Component<any, any> {

  constructor(props: any) {
    super(props);

    this.state = {
      chartRedim: {
        firstRedimDone: false,
        redimActionsDone: this.redimActionsDone.bind(this),
        redimAsked: false
      },
      graphicsDetails: [],
    };
  }

  public componentDidMount() {
    try {
      if (Object.getOwnPropertyNames(this.props.chart.eventItems).length > 0) {
        this.initGraphsDefinition(this.props.chart);
      }
      // tslint:disable-next-line
    } catch (e) { }
  }

  public componentWillReceiveProps(nextProps: any) {
    if (Object.getOwnPropertyNames(this.props.chart).length > 0
      && nextProps.chart.length !== this.props.chart.length) {
      this.initGraphsDefinition(nextProps.chart);
    }
  }

   /* Manage chart Display when workflow panel is visible
    * @param prevProps
    */
  private manageChartDisplay(prevProps: any) {
    if ((prevProps.workflowPanelVisible !== this.props.workflowPanelVisible)
    && (this.state.chartRedim.firstRedimDone === false) && (this.props.workflowPanelVisible === false)
    && (this.props.statusHistory[0] === undefined)) {
      this.setState({
        chartRedim: {
          ...this.state.chartRedim,
          firstRedimDone: true,
          redimAsked: false,
        }
      });
    } else if (prevProps.workflowPanelVisible !== this.props.workflowPanelVisible
    && this.state.chartRedim.firstRedimDone === false) {
      this.setState({
        chartRedim: {
          ...this.state.chartRedim,
          firstRedimDone: true,
          redimAsked: true,
        }
      });
    }
    if (prevProps.workflowPanelVisible !== this.props.workflowPanelVisible
      && this.state.chartRedim.firstRedimDone === true) {
      this.setState({
        chartRedim: {
          ...this.state.chartRedim,
          redimAsked: true
        }
      });
    }
  }

  public componentDidUpdate(prevProps: any) {
    this.manageChartDisplay(prevProps);
    if (this.state.chartRedim.redimAsked === true) {
      this.redimActionsDone();
    }
  }

  private initGraphsDefinition(chart: any) {

    this.setState({
      highchartData: chart,
    });
  }

  private redimActionsDone() {
    this.setState({
      chartRedim: {
        ...this.state.chartRedim,
        redimAsked: false,
      }
    });
  }

  public render() {
    if (!this.props.eventLoaded || (!this.props.chartLoaded && !this.props.chartLoadingError)) {
      return (
        <DSLoader
          id={'eventChartLoader'}
          label={Strings.loaderChartLabel}
        />
      );
    }
    if (this.props.chartLoaded && this.props.chartLoadingError) {
      if (this.props.exception !== undefined) {
        openErrorModal(
          this.props.exception.smTraceId,
          this.props.exception.message,
          this.props.exception.support.techRequestUrl,
          this.props.exception.support.contactEnglish,
          this.props.exception.support.contactChinese);
        return null;
      }
      return (
        <div className="ds-col-48 text-uppercase">
          <DSBanner
            type={'info'}
            title={Strings.chartLoadingErrorMessage}
            id={'error-message'}
            withCloseButton={false}
            center={true}
          />
        </div>
      );
    }
    return (
      <EventChartSectionView
        chartRescale={this.state.chartRescale}
        workflowPanelVisible={this.props.workflowPanelVisible}
        chartRedim={this.state.chartRedim}
        event={this.props.event}
        statusHistory={this.props.statusHistory}
        highchartData={this.props.chart}
      />
    );
  }
}
