/**
 * Class description: React predictive event chart tooltip component
 * @author Capgemini
 * @version 1.0
 */
import * as moment from 'moment';
import * as React from 'react';
import * as Strings from '../../../lang/strings.json';

const TOOLTIP_LABEL_CLASS = 'spm-tooltip-label';
const TOOLTIP_INFO_CLASS = 'spm-tooltip-info';

/**
 * Format tooltip value according to its value
 * @param value Value to format
 */
function defaultValue(value: any, type: 'text' | 'date' | 'number') {
  if (value === '' || value === null || value === undefined) {
    return Strings.defaultNoValueLabel;
  }
  const momentUTC = moment.utc(value);  
  switch (type) {
    case 'date':
      return momentUTC.format('DD MMM YYYY HH:mm');
    case 'number':
      return value % 1 !== 0 ? Number(value).toFixed(2) : Number(value);
    case 'text':
    default:
      return value;
  }
}

export const EventChartTooltipContentView = (props: any) => {
  return (
    <div>
      <div className="ds-row">
        <section className="ds-col-16">
          <p className={TOOLTIP_LABEL_CLASS}>Flight</p>
          <span className={TOOLTIP_INFO_CLASS} id="spm-flight-tooltip">
            {
              defaultValue(
                props.selectedPoint.businessData.flightNb,
                'text')
            }
          </span>
        </section>
        <section className="ds-col-16">
          <p className={TOOLTIP_LABEL_CLASS}>From</p>
          <span className={TOOLTIP_INFO_CLASS} id="spm-from-tooltip">
            {
              defaultValue(
                props.selectedPoint.businessData.from,
                'text')
            }
          </span>
        </section>
        <section className="ds-col-16">
          <p className={TOOLTIP_LABEL_CLASS}>To</p>
          <span className={TOOLTIP_INFO_CLASS} id="spm-to-tooltip">
            {
              defaultValue(
                props.selectedPoint.businessData.to,
                'text')
            }
          </span>
        </section>
      </div>
      <br />
      <div className="ds-row">
        <section className="ds-col-48">
          <p className={TOOLTIP_LABEL_CLASS}>Ended on</p>
          <span className={TOOLTIP_INFO_CLASS} id="spm-date-tooltip">
            {
              defaultValue(
                props.selectedPoint.businessData.toDate,
                'date')
            }
          </span>
        </section>
      </div>
      <br />
      <div className="ds-row">
        <section className="ds-col-48">
          <p className={TOOLTIP_LABEL_CLASS} id="">Value</p>
          {
            props.selectedPoint.chartData.map((item, index) => {
              if (!item.name.includes('THRESHOLD')) {
                return (
                  <span key={index} className="spm-tooltip-value" id={`spm-tooltip-value-${index + 1}`}>
                    {
                      defaultValue(
                        item.value,
                        'number'
                      )
                    }
                  </span>
                );
              } 
              return null;
            })
          }
        </section>
      </div>
    </div>
  );
};
