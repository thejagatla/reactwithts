/**
 * This Component allows to show informations about displayed trends
 * @author Capgemini
 * @version 1.0
 */
import * as React from 'react';

const trendInfo = (props: any) => {
  return (
    <div className="ds-row">
      <div style={{ color: props.color, backgroundColor: props.color }} className="trend-info ds-col-2" />
      <div className="ds-col-50">
        {props.description}
      </div>
    </div>
  );
};

export default trendInfo;
