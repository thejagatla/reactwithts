/**
 * Class description: React additional info view for events details
 * @author Capgemini
 * @version 1.0
 */
import { DSBanner, DSLoader } from '@sm/skywise-react-library';
import * as React from 'react';

export class EventAdditionalInfoView extends React.Component<any, any> {

  constructor(props: any) {
    super(props);
  }

  public render() {
    if (!this.props.eventLoaded) {
      return(
        <DSLoader
          label={this.props.loadingLabel}
        />
      );
    }
    if (this.props.eventLoaded && this.props.eventLoadingError) {
      return (
        <div className="ds-col-48 text-uppercase">
          <DSBanner
            type={'info'}
            title={this.props.loadingErrorMessage}
            id={'error-message'}
            withCloseButton={false}
            center={true}
          />
        </div>
      );
    }
    return this.props.children;
  }
}
