/**
 * Class description: React predictive event chart view controller
 * @author Capgemini
 * @version 1.0
 */
import * as React from 'react';
import * as spmColors from '../../../utils/spmColors.json';

/**
 * Component which create and displays event charts
 */
export class DShighchartsView extends React.Component<any, any> {

  private series;
  private chartCount;

  /**
   * Constructor
   * @param props Component props
   */
  constructor(props: any) {
    super(props);
    this.series = this.props.series;
    this.chartCount = this.props.highchartData.displayProperties.charts.length;
  }

  /**
   * Render the component
   */
  public render() {
    return (
      <div id="highchart-container" />
    );
  }

  /**
   * Starts after the component was mounted
   */
  public componentDidMount() {
    this.generateChart();
  }

  /**
   * Starts when component will receives new props
   * @param nextProps Next props of the component
   */
  public componentWillReceiveProps(nextProps: any) {
    this.redimChecks(nextProps);

    const iconSerieIndex = nextProps.series.length - 1;
    const nextPropsLength = (nextProps.series[iconSerieIndex].data.length) - 1;
    const iconSerieIndexOld = this.props.series.length - 1;
    const nextPropsLengthOld = (this.props.series[iconSerieIndexOld].data.length) - 1;

    if (this.props.series[iconSerieIndexOld].data.length !== nextProps.series[iconSerieIndex].data.length) {
      this.series = nextProps.series;
      this.generateChart();
    } else if (this.props.series[iconSerieIndexOld].data.length > 0) {
      if (nextProps.series[iconSerieIndex].data[nextPropsLength].marker.symbol !==
        this.props.series[iconSerieIndexOld].data[nextPropsLengthOld].marker.symbol) {
        this.series = nextProps.series;
        this.generateChart();
      }
    }

  }

  /**
   * Make checks on redim props if exists
   * @param nextProps
   */
  private redimChecks(nextProps: any) {
    if (nextProps.redim) {
      if (nextProps.redim.redimAsked &&
        nextProps.redim.redimAsked !== this.props.redim.redimAsked) {
        this.generateChart();
      }
    }
  }

  /**
   * Generate the chart
   * @param mountNode The DOM node which will contains the chart
   */
  private generateChart() {

    const Highcharts = require('highcharts/highstock');

    // Tooltip onclick WIP
    // ((H) => {
    //   H.wrap(H.Tooltip.prototype, 'refresh', function (this: any, proceed: any, point: any, e: any) {
    //     if (e && e.type !== 'mousemove') {
    //       proceed.call(this, point, e);
    //     }
    //   });
    //   H.addEvent(H.Point.prototype, 'click', (e) => {
    //     e.point.series.chart.tooltip.refresh(e.point, e);
    //   });
    // })(Highcharts);

    require('highcharts/modules/drag-panes')(Highcharts);
    require('highcharts/modules/map')(Highcharts);
    // require('highcharts/modules/exporting')(Highcharts);

    // return Highcharts.stockChart('highchart-container', {
    const chart = Highcharts.stockChart('highchart-container', {

      chart: {
        // panKey / panning / zoomType: zoom by drag and drop
        height: DShighchartsView.getChartHeight(this.chartCount),
        panKey: 'shift',
        panning: true,
        style: {
          fontFamily: 'roboto, Helvetica Neue, Helvetica, Arial, sans-serif'
        },
        zoomType: 'x',
      },

      // exporting: {
      //   sourceHeight: 780,
      //   sourceWidth: 1024,
      // },

      legend: {
        align: 'left',
        enabled: true,
        itemCheckboxStyle: {
          cursor: 'pointer',
          height: '16px',
          marginLeft: '-17px',
          width: '16px',
        },
        itemStyle: {
          fontWeight: 'normal',
        },
        verticalAlign: 'top',
        x: 5,
        y: 25,
      },

      plotOptions: {
        series: {
          events: {
            checkboxClick(event: any) {
              // Call show()/hide() using serie's state
              event.item[
                event.checked
                  ? 'show'
                  : 'hide'
              ]();
              // Disable event's bouncing/bubbling coming from checkbox displaed
              // on top of serie's title
              return false;
            },
            legendItemClick(event: any) {
              // Synchronized checkbox's state and legend's state
              event.target.checkbox.checked = !event.target.checkbox.checked;
            }
          },
          marker: {
            // All series display marker by default            
            enabled: true,
            fillColor: spmColors.iconsAxColor1,
            lineColor: null, // inherit from series
            lineWidth: 2,
            radius: 3,
            symbol: 'circle',
          },
          selected: true,
          showCheckbox: true,
          // Disable serie on minimap by default
          // Series of first chart is displayed dynamically in minimap
          showInNavigator: false,
        }
      },

      rangeSelector: this.props.rangeSelector,
      series: this.series,
      tooltip: this.props.tooltip,
      xAxis: this.props.xAxes,
      yAxis: this.props.yAxes,

      credits: {
        enabled: false
      },
    });

    // Display mandatory charts and hide Optional charts
    this.props.showSelectedCharts();

    return chart;
  }

  public static getChartHeight(chartCount: number) {
    return 520 + (130 * chartCount);
  }

}
