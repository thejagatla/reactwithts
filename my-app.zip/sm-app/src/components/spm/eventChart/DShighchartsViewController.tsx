import * as React from 'react';
import { HtmlCheckboxProps } from '../../storybook';
import { Filter } from '../../storybook/filter/Filter';
import { RangeSelectorController } from './controllers/RangeSelectorController';
import { SerieController } from './controllers/SerieController';
import { XAxisController } from './controllers/XAxisController';
import { YAxisController } from './controllers/YAxisController';
import { DShighchartsView } from './DShighchartsView';
import { DStooltipView } from './DStooltipView';

export class DShighchartsViewController extends React.Component<any, any> {

  private rawDisplayProperties;
  private rawEventItems;
  private rawStatusHistory;

  constructor(props: any) {
    super(props);

    this.rawDisplayProperties = props.highchartData.displayProperties;
    this.rawEventItems = this.props.highchartData.eventItems;
    this.rawStatusHistory = this.props.statusHistory;

    // Initialize list of mandatory charts to display on the opening page
    // HtmlCheckboxProps's id is managed as a string, that's why `${chart.id}` is used
    const chartsSelected = [];
    this.rawDisplayProperties.charts
    .filter(chart => chart.display === 'mandatory')
    .forEach(chart => chartsSelected.push(`${chart.id}`));

    this.state = {
      chartsSelected,
      initial: true,
      selectedDisplay: props.idItem ? props.idItem : -1,
    };

    this.getItemsCheckbox = this.getItemsCheckbox.bind(this);
    this.handleCheckboxChange = this.handleCheckboxChange.bind(this);
    this.clearFilters = this.clearFilters.bind(this);
    this.showSelectedCharts = this.showSelectedCharts.bind(this);
  }

  /**
   * Create list of checkbox models to display in the charts menu.
   * Checkbox status is defined by the React state.
   */
  private getItemsCheckbox(): HtmlCheckboxProps[] {
    const itemsCheckbox: HtmlCheckboxProps[] = [];

    this.rawDisplayProperties.charts
    .filter(chart => chart.display === 'optional')
    .forEach(chart => itemsCheckbox.push(
      {
        active: this.state.chartsSelected.indexOf(`${chart.id}`) > -1,
        id: `${chart.id}`,
        label: chart.title,
      }
    ));

    return itemsCheckbox;
  }

  /**
   * Empty array of selected checkboxes.
   */
  private clearFilters(): void {
    const chartsSelected = [];
    this.rawDisplayProperties.charts
    .filter(chart => chart.display === 'mandatory')
    .forEach(chart => chartsSelected.push(`${chart.id}`));

    this.setState({
      chartsSelected
    });
  }

  /**
   * Update the state on checkbox changes.
   * @param pFilterType
   * @param pCheckboxId
   */
  private handleCheckboxChange(pFilterType: string, pCheckboxId: string): void {
    const chartsSelected = this.state.chartsSelected;

    if (this.state.chartsSelected.indexOf(pCheckboxId) > -1) {
      delete chartsSelected[chartsSelected.indexOf(pCheckboxId)];
    } else {
      chartsSelected.push(pCheckboxId);
    }

    this.setState({
      // Remove 'undefined' items created by calling 'delete'
      // Keep the list sorted to display charts in default order
      chartsSelected: chartsSelected.filter(Boolean).sort()
    });
  }

  private showSelectedCharts(): void {
    // Get yAxis configuration for new chart selection
    const yAxisProperties = YAxisController.getYAxisProperties(this.state.chartsSelected.length);
    const marginPerGraph = yAxisProperties.marginPerGraph;
    const heightPerGraph = yAxisProperties.heightPerGraph;

    // Library Highcharts keeps track of previous created charts
    // Get only the last one
    const Highcharts = require('highcharts/highstock');
    const myHighchart = Highcharts.charts[Highcharts.charts.length - 1];

    // List each chart configuration as expected by checkbox menu
    const rawItemsCheckbox = [];
    this.rawDisplayProperties.charts
    .forEach(chart => rawItemsCheckbox.push(
      {
        id: `${chart.id}`,
        title: chart.title
      }
    ));

    const chartsSelected = this.state.chartsSelected;

    // Check each yAxis of each chart in the menu and make adjustment of titles, height, ect.
    rawItemsCheckbox.forEach(rawItemCheckbox => {
      const isChartHidden = chartsSelected.indexOf(rawItemCheckbox.id) === -1;

      myHighchart.yAxis.forEach((yAxis) => {
        // Position of charts and titles based on charts count
        const topPosition = (heightPerGraph  +  marginPerGraph) * chartsSelected.indexOf(rawItemCheckbox.id);

        // Update yAxis for chart titles
        if (rawItemCheckbox.title === yAxis.userOptions.title.text) {
          yAxis.update(
            {
              title: {
                style: {
                  visibility: isChartHidden
                    ? 'hidden'
                    : 'visible'
                }
              },
              top: topPosition + '%',
            },
            false
          );
        }

        // Update the main yAxis based on charts count: height and title
        if (
          yAxis.userOptions.custom
          && rawItemCheckbox.title === yAxis.userOptions.custom.chartTitle
        ) {

          yAxis.update(
            {
              height: isChartHidden
                ? '0%'
                : heightPerGraph + '%',
              resize: {
                enabled: isChartHidden
                  ? false
                  : chartsSelected.indexOf(rawItemCheckbox.id) + 1 < chartsSelected.length,
              },
              title: {
                style: {
                  visibility: isChartHidden
                    ? 'hidden'
                    : 'visible'
                }
              },
              top: topPosition + '%'
            },
            false
          );
        }
      });

      // Update series and default yAxis for each chart in the menu
      myHighchart.series
      .filter(serie =>
        serie.yAxis.userOptions.custom
        && rawItemCheckbox.title === serie.yAxis.userOptions.custom.chartTitle
      )
      .forEach((serie) => {
        serie.update(
          {
            marker: {
              enabled: !serie.userOptions.isThreshold && !isChartHidden
            },
            showInLegend: !isChartHidden,
            showInNavigator: chartsSelected.indexOf(rawItemCheckbox.id) === 0,
          },
          false
        );
      });
    });

    // Update height of global chart
    myHighchart.update(
      {
        chart: {
          height: DShighchartsView.getChartHeight(chartsSelected.length),
        }
      },
      false
    );

    myHighchart.redraw();
  }

  public render() {
    const yAxisController = new YAxisController(this.props.event, this.rawDisplayProperties);
    const xAxisController = new XAxisController(this.rawDisplayProperties);
    const serieController = new SerieController(this.rawDisplayProperties, this.rawEventItems, this.rawStatusHistory);

    const isOptionalChartsPresent = this.rawDisplayProperties.charts
      .filter(chart => chart.display === 'optional')
      .length > 0;

    return (
      <div className="filter-chart-container">
        <div
          className="administration-filter filter-container"
          style={{
            display: isOptionalChartsPresent
              ? 'visible'
              : 'none'
          }}
        >
          <Filter
            isEmpty={() => true}
            label="More charts"
            type="spm-optional-charts"
            textList={() => null}
            values={this.getItemsCheckbox}
            clearFilters={this.clearFilters}
            handleCheckboxChange={this.handleCheckboxChange}
            onSubmit={this.showSelectedCharts}
          />
        </div>
        <DShighchartsView
          highchartData={this.props.highchartData}
          redim={this.props.redim}
          event={this.props.event}
          statusHistory={this.props.statusHistory}
          showSelectedCharts={this.showSelectedCharts}

          xAxes={xAxisController.getXAxes()}
          yAxes={yAxisController.getYAxes()}
          series={serieController.getSeries()}
          rangeSelector={RangeSelectorController.getRangeSelector(isOptionalChartsPresent)}
          tooltip={DStooltipView.getTooltip()}
        />
      </div>
    );
  }

  public componentWillReceiveProps(nextProps: any) {
    /*updates the list of status history that we use to create icons once the list
    we get from the API is updated*/
    if (
      Object.getOwnPropertyNames(this.props.statusHistory).length > 0
      && nextProps.statusHistory.length > 0
      && !nextProps.statusHistory[0].tmp
    ) {
      this.rawStatusHistory = nextProps.statusHistory;
    }
  }

}
