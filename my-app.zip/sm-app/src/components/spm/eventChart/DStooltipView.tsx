import * as moment from 'moment';
import * as React from 'react';
import * as ReactDOMServer from 'react-dom/server';
import * as Strings from '../../../lang/strings.json';
import * as spmColors from '../../../utils/spmColors.json';

const TOOLTIP_LABEL_CLASS = 'spm-tooltip-label';
const TOOLTIP_INFO_CLASS = 'spm-tooltip-info';

export class DStooltipView extends React.Component<any, any> {

  constructor(props: any) {
    super(props);
  }

  public render() {

    // Get date and time from current event item
    const momentUTC = moment.utc(this.props.chart.points[0].point.toDate);
    const date = momentUTC.format('DD MMM YYYY');
    const time = momentUTC.format('HH:mm');
    
    const chartsNames = [];

    return (
      <div className="spm-tooltip-charts">
        <div className="tooltip-charts-container">
          <div id="tooltip-data" className="tooltip-content">

            <div className="spm-tooltip-header">
              <div className="ds-row">
                <section className="ds-col-16">
                  <p className={TOOLTIP_LABEL_CLASS}>Flight</p>
                  <span className={TOOLTIP_INFO_CLASS} id="spm-flight-tooltip">
                    {this.props.chart.points[0].point.flight !== null ? this.props.chart.points[0].point.flight 
                      : Strings.defaultNoValueLabel}
                  </span>
                </section>
                <section className="ds-col-16">
                  <p className={TOOLTIP_LABEL_CLASS}>From</p>
                  <span className={TOOLTIP_INFO_CLASS} id="spm-from-tooltip">
                    {this.props.chart.points[0].point.from !== null ? this.props.chart.points[0].point.from 
                      : Strings.defaultNoValueLabel}
                  </span>
                </section>
                <section className="ds-col-16">
                  <p className={TOOLTIP_LABEL_CLASS}>To</p>
                  <span className={TOOLTIP_INFO_CLASS} id="spm-to-tooltip">
                    {this.props.chart.points[0].point.to !== null ? this.props.chart.points[0].point.to 
                      : Strings.defaultNoValueLabel}
                  </span>
                </section>
              </div>
              <br />
              <div className="ds-row">
                <section className="ds-col-48">
                  <p className={TOOLTIP_LABEL_CLASS}>Ended on</p>
                  <span className={TOOLTIP_INFO_CLASS} id="spm-date-tooltip">
                    {date} {time}
                  </span>
                </section>
              </div>
              <br />
              <div className="ds-row">
                <section className="ds-col-48">
                  <p className={TOOLTIP_LABEL_CLASS} id="">Value</p>
                  {this.props.chart.points.slice(0, -1).map((pointConfig, index) => {

                    if (!pointConfig.point.series.userOptions.showInLegend) {
                      return null;
                    }

                    // Get chart's title
                    let chartTitle = pointConfig.series.yAxis.userOptions.custom.chartTitle;
                    if (chartsNames.indexOf(chartTitle) === -1) {
                      chartsNames.push(chartTitle);
                    } else {
                      chartTitle = null;
                    }

                    return <div key={pointConfig + index}>
                      {chartTitle !== null &&
                        <div style={{ color: 'white' }}>
                          <br/>
                          {chartTitle}
                        </div>
                      }
                      <div
                        style={{ backgroundColor: pointConfig.color, fontWeight: 'normal' }}
                        className="spm-tooltip-value"
                      >
                        {pointConfig.series.name === null
                          // Display serie's name
                          ? 'Unknown serie'
                          : pointConfig.series.name.trim()
                        }: {pointConfig.y &&
                          // Display series's value rounded to 2 decimals
                          Math.round(pointConfig.y * 100) / 100
                        }
                      </div>
                    </div>;
                  })}
                </section>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  /**
   * Get tooltip component
   */
  public static getTooltip() {
    return {
      // Use transparency
      backgroundColor: spmColors.tooltipBackgroundColor,
      borderColor: spmColors.tooltipBorderColor,
      borderWidth: 0,
      outside: true,
      shared: true,
      split: false,
      useHTML: true,
      formatter(this: any) {
        // No tooltip when there is a missing flight (which means no point on the chart) 
        // OR when the serie the serie is not a serie of values
        if (this.points[0].point.isMissingFlight || !this.points[0].point.isValueSerie) {
            return false;
          }

        return ReactDOMServer.renderToStaticMarkup((
          <DStooltipView
            chart={this}
          />
        ));
      },
    };
  }
}
