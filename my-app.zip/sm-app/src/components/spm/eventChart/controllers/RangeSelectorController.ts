/**
 * Definition of the buttons selector for a period like one week or one month.
 * See highcharts ilbrary at https://api.highcharts.com/highstock/rangeSelector
 * @author Capgemini
 * @version 1.0
 */

export class RangeSelectorController {

  public static getRangeSelector(isOptionalChartsPresent: boolean) {
    return {
      buttonPosition: {
        x: isOptionalChartsPresent
          ? 50 // leave spaces for the charts menu selector
          : 0
      },
      buttonTheme: {
        width: 60
      },
      buttons: [{
        count: 1,
        text: 'Day',
        type: 'day',
      }, {
        count: 1,
        text: 'Week',
        type: 'week',
      }, {
        count: 1,
        text: 'Month',
        type: 'month',
      }, {
        count: 3,
        text: '3 months',
        type: 'month',
      }, {
        count: 6,
        text: '6 months',
        type: 'month',
      }, {
        count: 1,
        text: 'Year',
        type: 'year',
      }, {
        text: 'YTD',
        type: 'ytd',
      }, {
        text: 'All',
        type: 'all',
      }],
      inputDateFormat: '%d %b %Y',
      selected: 2,
    };
  }

}
