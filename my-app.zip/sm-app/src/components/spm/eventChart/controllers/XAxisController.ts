/**
 * Definition of the xAxis for days.
 * See highcharts API at https://api.highcharts.com/highstock/xAxis
 * @author Capgemini
 * @version 1.0
 */

export class XAxisController {

  private rawDisplayProperties;

  constructor(rawDisplayProperties: any) {
    this.rawDisplayProperties = rawDisplayProperties;
  }

  public getXAxes() {
    const xAxes = [];

    // xAxis creation
    const usedXAxis = [];
    this.rawDisplayProperties.charts.forEach((chart) => {
      chart['x-axis'].forEach((xAxis) => {
        // SID multichart contains the same xAxis multiple times for Dates
        // Display only one xAxis based on the main graph
        if (usedXAxis.indexOf(xAxis.name) === -1) {
          // Days displayed on xAxis
          xAxes.push({
            alignTicks: true,
            alternateGridColor: '#f8f8f8',
            labels: {
              autoRotation: false,
              format: '{value:%e %b %Y}',
              style: {
                whiteSpace: 'nowrap',
              }
            },
            tickInterval: 24 * 3600 * 1000,
            title: {
              align: 'high',
              style: {
                color: '#000'
              },
              text: xAxis.legend,
            },
            units: [[
              'day',
              [1]
            ]]
          });
        }

        usedXAxis.push(xAxis.name);
      });
    });

    return xAxes;
  }

}
