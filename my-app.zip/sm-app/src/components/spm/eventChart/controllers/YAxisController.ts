/**
 * Definition of each yAxis:
 * - a standard one for each charts,
 * - a second one used as a horizontal title for each charts
 * - another one for workflow icons,
 * - one for alerts,
 * - last one for occurence ratio.
 * @author Capgemini
 * @version 1.0
 */

import * as Strings from '../../../../lang/strings.json';
import * as spmColors from '../../../../utils/spmColors.json';

export interface YAxisProperties {
  chartCount: number;
  heightGraphsWithoutAlerts: number;
  heightGraphsWithoutMargin: number;
  heightForAlertsOrIcons: number;
  totalMarginBetweenGraphs: number;
  marginPerGraph: number;
  heightPerGraph: number;
}

export class YAxisController {

  private event;
  private rawDisplayProperties;

  constructor(event: any, rawDisplayProperties: any) {
    this.event = event;
    this.rawDisplayProperties = rawDisplayProperties;
  }

  public getYAxes() {
    const yAxes = [];

    const yAxisProperties = YAxisController.getYAxisProperties(this.rawDisplayProperties.charts.length);

    const chartCount = yAxisProperties.chartCount;
    const heightGraphsWithoutAlerts = yAxisProperties.heightGraphsWithoutAlerts; 
    const marginPerGraph = yAxisProperties.marginPerGraph;
    const heightForAlertsOrIcons = yAxisProperties.heightForAlertsOrIcons;
    const heightPerGraph = yAxisProperties.heightPerGraph;
    
    // yAxis creation
    this.rawDisplayProperties.charts.forEach((chart, indexChart) => {
      const chartTitle = chart.title !== null
        ? chart.title.trim()
        : 'Unkown chart title'
      ;

      // the position we use to create each graph, 
      // it takes into account the height of the previous graph plus marginPerGraph
      const topPosition = (heightPerGraph  +  marginPerGraph) * indexChart;

      // Main yAxes for series
      chart['y-axis'].forEach((yAxis) => {
        yAxes.push({
          custom: {
            chartTitle // Custom data for tooltip/legend management
          },
          gridLineColor: spmColors.gridLineColor,
          gridLineDashStyle: 'ShortDot',
          gridLineWidth: 2,
          height: heightPerGraph + '%',
          labels: {
            align: 'right',
            x: -5,
          },
          maxLength: 0,
          minorGridLineColor: spmColors.minorGridLineColor,
          minorGridLineDashStyle: 'Dot',
          minorTicks: true,
          offset: 0,
          opposite: false,
          resize: {
            cursor: 'default',
            // Display chart's separator except for alerts
            enabled: indexChart + 1 < chartCount,
            lineColor: spmColors.separatorColor,
            y: 10,
          },
          title: {
            style: {
              color: spmColors.titleColor
            },
            text: yAxis.legend !== null
              ? yAxis.legend.trim()
              : 'Unkown yAxis title',
          },
          top: topPosition + '%',
        });
      });

      // Use an yAxis for the chart's title
      yAxes.push({
        gridLineWidth: 0,
        height: 20, // Fix cursor and alternateGridColor getting out of the chart
        labels: {
          formatter() {
            // Hide labels' number for this unusual axis
            return '';
          },
        },
        linkedTo: 0,
        minorGridLineWidth: 0,
        offset: 0,
        opposite: false,
        title: {
          // Display title horizontally on top on one line
          align: 'high',
          reserveSpace: false,
          rotation: 0,
          style: {
            color: spmColors.titleColor,
            whiteSpace: 'nowrap',
          },
          text: chartTitle,
          textAlign: 'left',
          y: -4,
        },
        top: topPosition + '%',
      });
  
    });

    // Use an yAxis for icons
    yAxes.push({
      gridLineWidth: 0,
      height: heightForAlertsOrIcons + '%',
      labels: {
        formatter() {
          return '';
        },
      },
      minorGridLineWidth: 0,
      top: heightGraphsWithoutAlerts  + '%',
    });

    // Use an yAxis for alerts
    yAxes.push({
      gridLineWidth: 0,
      height: heightForAlertsOrIcons + '%',
      labels: {
        formatter() {
          return '';
        },
      },
      minorGridLineWidth: 0,
      top: heightGraphsWithoutAlerts + heightForAlertsOrIcons + '%',
    });

    // Use an yAxis for occurence Rate
    yAxes.push({
      gridLineWidth: 0,
      labels: {
        formatter() {
          return '';
        },
      },
      linkedTo: 0,
      minorGridLineWidth: 0,
      offset: 0,
      opposite: true,
      title: {
        align: 'high',
        reserveSpace: false,
        rotation: 0,
        style: {
          color: spmColors.titleColor,
          whiteSpace: 'nowrap',
        },
        text: this.getOccurenceRate(),
        textAlign: 'right',
        y: -4,
      },
      top: 0 + '%',
    });

    return yAxes;
  }

  /**
   * returns the occurence Rate 
   */
  private getOccurenceRate() {
    let occRate = '';
    if (this.displayOccRate()) {
      occRate = 
        Strings.occurrenceRate 
        + this.event.occurenceRateFlightCount 
        + Strings.flightsOccRate 
        + this.event.occurenceRate 
        + '%'
      ;
    }
    return occRate;
  }

  /**
   * returns true if the occurenceRate should be displayed
   */
  private displayOccRate() {
    if (this.event.statusInfoItem === undefined) {
      return false;
    } 
    if (
      this.event.statusInfoItem.status === 'TO_BE_REVIEWED' 
      || this.event.statusInfoItem.status === 'IGNORED' 
      || this.event.statusInfoItem.status === 'CLOSED'
    ) {
      return false;
    }
    return true;
  }

  /**
   * @param chartCount used to defined height of charts using percent
   */
  public static getYAxisProperties(chartCount: number): YAxisProperties {
    // the percentage dedicated to graphs with margins and without alerts
    const heightGraphsWithoutAlerts = 90; 
    // height dedicated to graphs without margins 
    // 15% is divided among all the graphs and it is used to separate the graphs
    const heightGraphsWithoutMargin = heightGraphsWithoutAlerts - 15; 
    // percentage of the margins we use to separate the graphs
    const totalMarginBetweenGraphs = heightGraphsWithoutAlerts - heightGraphsWithoutMargin;
    // the margin we add after each graph, if we have only one graph there is no need to create a margin
    // that explains the use of (chartCount - 1)
    const marginPerGraph = totalMarginBetweenGraphs / (chartCount > 1 ? (chartCount - 1) : chartCount);
    // (100 - heightGraphsWithoutAlerts) is equally devided between both alerts and workflow icons
    const heightForAlertsOrIcons = (100 - heightGraphsWithoutAlerts) / 2;
    // if we have only one graph there is no need to create a margin,
    // so, the graph will fill the initial height(90%)
    const heightPerGraph = chartCount > 1 ? heightGraphsWithoutMargin / chartCount : heightGraphsWithoutAlerts;

    return {
      chartCount,
      heightForAlertsOrIcons,
      heightGraphsWithoutAlerts,
      heightGraphsWithoutMargin,
      heightPerGraph,
      marginPerGraph,
      totalMarginBetweenGraphs,
    };
  }

}
