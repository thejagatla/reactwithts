/**
 * Definition of every series:
 * - default series,
 * - workflow icons serie,
 * - alert serie.
 * See highcharts API at https://api.highcharts.com/highstock/series.line
 * @author Capgemini
 * @version 1.0
 */

import * as spmColors from '../../../../utils/spmColors.json';
import * as SpmIcons from '../../../../utils/spmIcons.json';

export class SerieController {

  private rawDisplayProperties;
  private rawEventItems;
  private rawStatusHistory;

  // possible color list for graphs
  private graphColors = [
    spmColors.graphColor1, spmColors.graphColor2, spmColors.graphColor3,
    spmColors.graphColor4, spmColors.graphColor5, spmColors.graphColor6,
    spmColors.graphColor7, spmColors.graphColor8
  ]; 

  // possible color list for thresholds
  private thresholdColors = [
    spmColors.thresholdColor1,  spmColors.thresholdColor2,  spmColors.thresholdColor3,
    spmColors.thresholdColor4,  spmColors.thresholdColor5,  spmColors.thresholdColor6,
    spmColors.thresholdColor7, spmColors.thresholdColor8
  ]; 

  constructor(rawDisplayProperties: any, rawEventItems: any, rawStatusHistory: any) {
    this.rawDisplayProperties = rawDisplayProperties;
    this.rawEventItems = rawEventItems;
    this.rawStatusHistory = rawStatusHistory;
  }

  public getSeries() {
    const seriesHighcharts = [];

    // Indexes for colors
    let iThreshold = 0;
    let iSerie = 0;
    
    // Series creation: get each serie from SID
    this.rawDisplayProperties.charts.forEach((chart, indexChart) => {
      chart['y-axis'].forEach(yAxis => {
        yAxis.groups.forEach(group => {
          group.series.forEach(serie => {

            const serieHighcharts = [];

            // Get all points for current serie
            this.rawEventItems.forEach(eventItem => {
              serieHighcharts.push(this.createFlight(eventItem, serie));
            });

            const serieType = this.getHighchartType(group.type);
            // Create a new serie for these points
            const newSerie = this.initializeNewSerie(serieHighcharts, indexChart, serieType);
            // Show serie in minimap only for the main graph
            if (indexChart === 0) {
              newSerie.showInNavigator = true;
            }
            
            // Configure the serie using serie's definition from SID
            const currentSerieRaw = this.rawDisplayProperties.series.find(serieRaw => serieRaw.name === serie);
            const isThreshold = currentSerieRaw.type === 'threshold';

            if (currentSerieRaw) {
              // Define serie's title with unit
              newSerie.name = 'Unkown serie title';
              if (currentSerieRaw.title !== null) {
                let unitCurrentSerie = '';
                if (currentSerieRaw.unit !== '') {
                  unitCurrentSerie = ' (' + currentSerieRaw.unit + ')';
                }
                newSerie.name = currentSerieRaw.title.trim() + unitCurrentSerie;
              }

              // Additional data to show/hide markers when user hide a chart
              newSerie.isThreshold = isThreshold;
              
              if (isThreshold) {
                // Remove marker and mouse hover for thresholds
                newSerie.states = {
                  hover: {
                    enabled: false
                  }
                };
                newSerie.marker = { enabled: false };
              } else {
                // Put regular serie on top of thresholds
                newSerie.zIndex = 1;
              }
            }

            // Use Skywise colors
            if (isThreshold) {
              newSerie.color = this.thresholdColors[iThreshold % this.thresholdColors.length];
              iThreshold = iThreshold + 1;
            } else {
              newSerie.color = this.graphColors[iSerie % this.graphColors.length];
              iSerie = iSerie + 1;
            }

            seriesHighcharts.push(newSerie);
          });
        });
      });
    });

    seriesHighcharts.push(this.getAlertsSerie());

    seriesHighcharts.push(this.getIconSerie());

    return seriesHighcharts;
  }

  /**
   * Creates a point for the flight
   * @param eventItem 
   */
  public createFlight(eventItem: any, serie: any) {
    return {
      flight: eventItem.flightNb,
      from: eventItem.from,
      isMissingFlight: eventItem.isMissingFlight,
      isMissingItem: eventItem.isMissingItem,
      // this attribute is used to distinguish the serie of values and the series of alerts and icons
      isValueSerie: true,
      to: eventItem.to,
      toDate: eventItem.toDate,
      x: new Date(eventItem.toDate).getTime(),
      // Get value from SID for current serie
      y: eventItem.graphData && eventItem.graphData[serie]
    };
  }

  /**
   * Return highchart graphic type
   * 
   */
  private getHighchartType = (chartType) => {
    switch (chartType) {
      case 'line': 
        return 'line';
      case 'stackedarea': 
        return 'area';
      case 'bar':
        return 'column';
      default: 
        return 'line';
    }
  }

  /**
   *  Returns a default newSerie and link it to an Yaxis
   */
  public initializeNewSerie(serieHighcharts: any, indexChart: any, serieType: string) {
    return {
      color: undefined,
      data: serieHighcharts,
      isThreshold: undefined,
      marker: { enabled: true },
      name: undefined,
      showInNavigator: false,
      states: {
        hover: {
          enabled: true,
        }
      },
      type: serieType,
      // Each chart is defined by two yAxis, one main yAxis and one for the graph's title
      // The index of each main yAxis for each chart is based on chart's index: 0, 2, 4, 6...
      yAxis: indexChart * 2,
      zIndex: undefined,
    };
  }

  public getAlertsSerie() {
    // Alerts data creation
    const alertsData = [];
    this.rawEventItems.forEach(eventItem => {
      alertsData.push({        
        // this attribute is used to distinguish the serie of values and the series of alerts and icons
        isValueSerie: false,
        marker: {
          symbol:
            // Define alert's icon based on event item's status
            eventItem.isMissingFlight || eventItem.isMissingItem 
            ? SpmIcons.missingIcon 
            : eventItem.isAlert 
              ? SpmIcons.alertIcon 
              : SpmIcons.defaultIcon
        },
        x: new Date(eventItem.toDate).getTime(),
        y: 0,
      });
    });

    return {
      data: alertsData,
      lineWidth: 0,
      marker: {
        radius: 0,
      },
      name: 'Alerts', // Displayed on legend
      showInNavigator: false,
      states: {
        hover: {
          enabled: false
        }
      },
      // The index of alert's yAxis comes last, after both main and title yAxis for each charts
      yAxis: this.rawDisplayProperties.charts.length * 2 + 1,
    };
  }

  /**
   * Add workflow icons to the chart
   */
  public getIconSerie() {
    // the  final list of icons that we display under the graph
    const statusHistoryHighcharts = [];
    /* a temporary list of icons used to check the case of multiple icons
     between two consecutive flights*/
    let temporaryHistoryStatus = [];
    // Filter list of status history
    const filtredRawStatusHistory = this.rawStatusHistory
      .filter(history => ['TO_BE_REVIEWED', 'PLANNED'].indexOf(history.status) === -1);

    this.rawEventItems.forEach((eventItem, indexEventItem) => {
      filtredRawStatusHistory.forEach(history => {
        // when we have 'to_be_monitored' we should take into account the workdatetime instead of dateTime
        let actionDate = history.status === 'TO_BE_MONITORED' ? history.workDatetime : history.dateTime;
        const nextFlightIndex = indexEventItem + 1; // the index of the next eventItem
        const isLastFlight = indexEventItem === this.rawEventItems.length - 1;

        // if the index of the next flight is greater that the length of rawEventItems
        // it means that we have no next flight
        const nextFlight = !isLastFlight ? this.rawEventItems[nextFlightIndex] : null;

        if (actionDate >= eventItem.toDate) {
          if (isLastFlight) {
            /**
             * if the date of status is after the last flight
             * we just add a little margin after the date in order to display
             * the icon
             */
            actionDate = new Date(eventItem.toDate).getTime() + 1;
            // add the icon in the temp list
            this.pushCreatedIconInTempList(temporaryHistoryStatus, history.status, actionDate);

          } else if (actionDate <= nextFlight.toDate) {
            /**
             * in order to put the icon exactly between two flights
             * we should calculate the difference between the dates of these flights and divide it by 2
             */
            const diffDate = new Date(nextFlight.toDate).getTime() - new Date(eventItem.toDate).getTime();
            actionDate = new Date(eventItem.toDate).getTime() + (diffDate / 2);
            // add the icon in the temp list
            this.pushCreatedIconInTempList(temporaryHistoryStatus, history.status, actionDate);
          }
        }
      });

      if (temporaryHistoryStatus.length !== 0) {
        // if the temp list contains more than one status we take always the last one
        // and we add it to the final list
        // we clean the temp list for later uses
        statusHistoryHighcharts.push(temporaryHistoryStatus[0]);
        temporaryHistoryStatus = [];
      }
    });

    // creates the serie of icons
    return this.createIconSerie(statusHistoryHighcharts);
  }

  /**
   * Pushes an icon in the temporary list
   */
  public pushCreatedIconInTempList(temporaryHistoryStatus: any[], status: any, actionDate: any) {
    if (this.getIconForStatus(status) !== null) {
      temporaryHistoryStatus.push(this.createIcon(status, actionDate));
    }
  }

  /**
   * Create Icon
   */
  public createIcon(status: any, actionDate: any) {
    return {
      // this attribute is used to distinguish the serie of values and the series of alerts and icons
      isValueSerie: false,
      marker: {
        height: 16,
        name: status,
        symbol: this.getIconForStatus(status),
        width: 16
      },
      x: actionDate,
      y: 0,
    };
  }

  // Get the right icon for the status
  public getIconForStatus(status: any) {
    switch (status) {
      case 'OPENED':
        return SpmIcons.iconEye;
      case 'TO_BE_MONITORED':
        return SpmIcons.iconWrench;
      case 'CLOSED':
        return SpmIcons.iconCheck;
      case 'IGNORED':
        return SpmIcons.iconIgnore;
      default:
        return null;
    }
  }

  /**
   * return an iconSerie composed of the elements of the list below
   * @param statusHistoryHighcharts 
   */
  public createIconSerie(statusHistoryHighcharts: any[]) {
    return {
      data: statusHistoryHighcharts,
      lineWidth: 3,
      marker: {
        radius: 0,
      },
      showInLegend: false,
      showInNavigator: false,
      states: {
        hover: {
          enabled: false
        }
      },
      yAxis: this.rawDisplayProperties.charts.length * 2,
      zoneAxis: 'x',
      zones: this.linkIcons(statusHistoryHighcharts),
    };
  }

  /**
   * displays transparent when the status is ignored and closed, shordot otherwise
   * @param statusHistoryHighcharts 
   */
  public linkIcons(statusHistoryHighcharts: any[]) {
    this.addAdditionalPointOnWorkflowSerie(statusHistoryHighcharts);

    const listZones = [];
    statusHistoryHighcharts.forEach((element, index) => {
      const isLineHidden = ['IGNORED', 'CLOSED'].indexOf(element.marker.name) > -1;

      listZones.push({
        color: isLineHidden
          ? spmColors.transparent
          : spmColors.iconsAxColor2,
        value: index + 1 !== statusHistoryHighcharts.length ? statusHistoryHighcharts[index + 1].x : element.x
      });
    });

    return listZones;
  }

  /**
   * This function add an additional point on workflow serie, to allow the link to be displayed continuously
   * @param statusHistoryHighcharts
   */
  private addAdditionalPointOnWorkflowSerie(statusHistoryHighcharts: any[]) {
    const lengthOfStatusHistoryHighCharts = statusHistoryHighcharts.length;

    if (lengthOfStatusHistoryHighCharts > 0) {
      const lastItem = this.rawEventItems[this.rawEventItems.length - 1];
      const lastItemDate = new Date(lastItem.toDate).getTime() ;

      if (statusHistoryHighcharts[lengthOfStatusHistoryHighCharts - 1].x < lastItemDate) {
        statusHistoryHighcharts.push({
          marker: {
            name: 'SPM-FAKE-LAST-POINT',
          },
          x: lastItemDate,
          y: 0
        });
      }
    }
  }

}
