/**
 * Class description: React predictive event details page component
 * @author Capgemini
 * @version 1.0
 */

import {
  DSBanner,
  DSIcon,
  DSLink,
  DSNotificationsPanel
} from '@sm/skywise-react-library';
import * as classNames from 'classnames';
import * as React from 'react';
import reactHtmlParser from 'react-html-parser';
import * as Strings from '../../../lang/strings.json';
import { EventAdditionalInfoView } from '../eventAdditionalInfo/EventAdditionalInfoView';
import { EventChartSectionViewController } from '../eventChartSection/EventChartSectionViewController';
import { EventDetailsPageHeaderViewController } from '../eventDetailsPageHeader/EventDetailsPageHeaderViewController';

declare global {
  interface Function {
    displayName?: string;
  }
}

export const EventDetailsPageView = (props: any) => {
  if (props.userNotAuthorized) {
    return (
      <div className="ds-col-50 text-uppercase">
        <DSBanner
          type={'info'}
          title={Strings.userNotAuthorizedMessage}
          id={'error-message'}
          withCloseButton={false}
          center={true}
        />
      </div>
    );
  }

  const colClass = classNames({
    'ds-col-38': props.workflowPanelVisible,
    'ds-col-48': !props.workflowPanelVisible
  });

  return (
    <div className="ds-container-fluid" id="eventDetailsPage">
      {props.history.length > 1 && (
        <div className="event-details-navigation">
          <DSLink as="button" handleClick={props.history.goBack}>
            <DSIcon type="chevron_left" />
            {Strings.back}
          </DSLink>
        </div>
      )}
      <section className={`${colClass} ds-card`} id="eventDetailsHeader">
        <EventDetailsPageHeaderViewController
          displayName={props.state.displayName}
          event={props.state.event}
          eventLoaded={props.state.eventLoaded}
          eventLoadingError={props.state.eventLoadingError}
          loadEventIgnoreError={props.loadEventIgnoreError}
          addWorkflowHistoryItem={props.addWorkflowHistoryItem}
          priorityClassName={props.priorityClassName}
          exception={props.state.loadEventException}
        />
      </section>
      <section className={colClass + ' ds-card'} id="eventDetailsChart">
        <EventChartSectionViewController
          event={props.state.event}
          eventLoaded={props.state.eventLoaded}
          chart={props.state.chart}
          statusHistory={props.state.statusHistory}
          eventItems={props.state.eventItems}
          eventDetailsDisplay={props.state.eventDetailsDisplay}
          threshold={props.state.threshold}
          chartLoaded={props.state.chartLoaded}
          chartLoadingError={props.state.chartLoadingError}
          workflowPanelVisible={props.workflowPanelVisible}
          loadEventItem={props.loadEventItem}
          exception={props.state.loadChartException}
        />
      </section>
      <section className={`${colClass} ds-card eventAdditionalInfo`}>
        <h3 className="ds-card--title">Model description</h3>
        <EventAdditionalInfoView
          eventLoaded={props.state.eventLoaded}
          eventLoadingError={props.state.eventLoadingError}
          loadingLabel={Strings.loadDescriptionLabel}
          loadingErrorMessage={Strings.descriptionLoadingErrorMessage}
        >
          <div className="ds-raw-additionalInfo">
            {props.state.description
              ? reactHtmlParser(props.state.description)
              : Strings.descriptionUnavailableMessage}
              <br />
              Model maturity: {props.state.event.maturity}
          </div>
        </EventAdditionalInfoView>
      </section>
      <section className={`${colClass} ds-card eventAdditionalInfo`}>
        <h3 className="ds-card--title">Maintenance advice</h3>
        <EventAdditionalInfoView
          eventLoaded={props.state.eventLoaded}
          eventLoadingError={props.state.eventLoadingError}
          loadingLabel={Strings.loadMaintAdvicesLabel}
          loadingErrorMessage={Strings.maintenanceAdvicesLoadingErrorMessage}
        >
          <div className="ds-raw-additionalInfo">
          {props.state.maintenanceAdvices
              ? reactHtmlParser(props.state.maintenanceAdvices)
              : Strings.maintenanceAdvicesUnavailableMessage}
          </div>
        </EventAdditionalInfoView>
      </section>
      <DSNotificationsPanel
        isVisible={props.workflowPanelVisible}
        elements={props.historyPanelElements}
        id={'workStatusHistoryPanel'}
        handleToggle={props.handlePanelState}
        withHeader={true}
        headerContent={<h3 className="h4-like">Workflow history</h3>}
      />
    </div>
  );
};

EventDetailsPageView.displayName = 'EventDetailsPageView';
