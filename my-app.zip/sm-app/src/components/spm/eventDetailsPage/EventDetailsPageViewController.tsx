/**
 * Class description: React predictive event details page view controller
 * @author Capgemini
 * @version 1.0
 */

import * as React from 'react';
import { withRouter } from 'react-router';
import { Comment } from '../../../model/Comment';
import {
  RiskPriority,
  WorkOrderStatusEnum
} from '../../../model/EventsConstantes';
import { SpmStatusInfoItem } from '../../../model/spm/SpmStatusInfoItem';
import { CommentHistoryItem } from '../workflowHistory/commentHistoryItem';
import { WorkflowHistoryItem } from '../workflowHistory/workflowHistoryItem';
import { WorkflowHistoryItemLoading } from '../workflowHistory/workflowHistoryItemLoading';
import { EventDetailsPageView } from './EventDetailsPageView';

/**
 * Component of the event details page
 */
export class EventDetailsPageViewController extends React.Component<any, any> {
  /**
   * Constructor
   * @param props Component props
   */
  constructor(props: any) {
    super(props);

    this.state = {
      historyPanelElements: [],
      intervalId: 0,
      priorityClassName: '',
      userNotAuthorized: false,
      workflowPanelVisible: false
    };

    this.handlePanelState = this.handlePanelState.bind(this);
    this.startRequestTimeout = this.startRequestTimeout.bind(this);
    this.launchRequest = this.launchRequest.bind(this);
  }

  /**
   * Starts after the component is mount
   */
  public componentDidMount() {
    this.props.clearEvent();
    this.props.loadEvent(this.props.state.eventId);
    this.props.loadChart(this.props.state.eventId);
  }

  /**
   * Starts before the component is unmount
   */
  public componentWillUnmount() {
    clearInterval(this.state.intervalId);
    this.props.clearEvent();
  }

  /**
   * Check if there is an error during loading action
   * @param nextProps
   */
  private checkLoadingError(props: any) {
    return props.state.eventLoadingError || props.state.chartLoadingError;
  }

  /**
   * Check if event / chart are loaded
   * @param props
   */
  private dataLoaded(props: any) {
    return props.state.eventLoaded && props.state.chartLoaded;
  }

  public componentWillReceiveProps(nextProps: any) {
    if (nextProps.state.eventLoaded && !nextProps.state.eventLoadingError) {
      if (nextProps.state.eventLoaded !== this.props.state.eventLoaded) {
        this.priorityToClassName(nextProps.state.event.riskPriority);
        this.toggleStatusHistoryDisplay(
          nextProps.state.event.statusInfoItem.status !==
            WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]
        );
        this.createPanelList(nextProps);
      }
    }
    if (this.dataLoaded(nextProps) && !this.checkLoadingError(nextProps)) {
      this.startRequestTimeout();
      if (
        this.isNextStatusHistoryDifferent(nextProps) ||
        this.isNextCommentHistoryDifferent(nextProps)
      ) {
        this.createPanelList(nextProps);
      }
    } else if (
      nextProps.state.eventLoaded &&
      nextProps.state.eventLoadingError
    ) {
      if (
        nextProps.state.eventLoadingErrorCode === 403 ||
        nextProps.state.chartLoadingErrorCode === 403
      ) {
        this.setState({
          userNotAuthorized: true
        });
      }
    }
  }

  public launchRequest() {
    this.props.loadEventIgnoreError(this.props.state.eventId);
  }

  /**
   * Launch periodical API calls to retrieve events
   */
  public startRequestTimeout() {
    if (this.state.intervalId === 0) {
      const lIntervalId = setInterval(this.launchRequest, 2000);
      this.setState({ intervalId: lIntervalId });
    }
  }

  /**
   * Handles when user click on notifications panel arrow
   * @param pEvent Event handled
   */
  private handlePanelState(pEvent: any) {
    this.toggleStatusHistoryDisplay(!this.state.workflowPanelVisible);
  }

  private isNextStatusHistoryDifferent(nextProps: any) {
    if (
      nextProps.state.statusHistory.length !==
      this.props.state.statusHistory.length
    ) {
      return true;
    }
    if (this.props.state.statusHistory[0].tmp) {
      if (!nextProps.state.statusHistory[0].tmp) {
        return true;
      }
    }
    return false;
  }

  private isNextCommentHistoryDifferent(nextProps: any) {
    return (
      nextProps.state.commentsHistory.length !==
      this.props.state.commentsHistory.length
    );
  }

  private createPanelList(nextProps: any) {
    const statusHistory: SpmStatusInfoItem[] = nextProps.state.statusHistory;
    const commentsHistory: Comment[] = nextProps.state.commentsHistory;
    const completeList: any[] = [];

    for (const status of statusHistory) {
      completeList.push(status);
    }
    for (const comment of commentsHistory) {
      completeList.push(comment);
    }

    completeList.sort((a: any, b: any) => {
      const aDate = new Date(a.dateTime).getTime();
      const bDate = new Date(b.dateTime).getTime();

      return bDate - aDate;
    });

    const notificationsElements = completeList.map((element, index) => {
      if (element.tmp) {
        return <WorkflowHistoryItemLoading key={index} status={element} />;
      }
      if (element.status) {
        return <WorkflowHistoryItem key={index} status={element} />;
      }
      return <CommentHistoryItem key={index} comment={element} />;
    });

    this.setState({
      historyPanelElements: notificationsElements
    });
  }

  private toggleStatusHistoryDisplay(isVisible: boolean) {
    this.setState({
      workflowPanelVisible: isVisible
    });
  }

  /**
   * Defines the style class to apply according to event priority
   * @param priority Event priority
   */
  private priorityToClassName(priority: string) {
    try {
      switch (priority) {
        case RiskPriority.LOW:
          this.setState({
            priorityClassName: 'low'
          });
          break;
        case RiskPriority.MEDIUM:
          this.setState({
            priorityClassName: 'medium'
          });
          break;
        case RiskPriority.HIGH:
          this.setState({
            priorityClassName: 'high'
          });
          break;
        default:
          this.setState({
            priorityClassName: ''
          });
      }
    } catch (e) {
      // istanbul ignore next
      this.setState({
        priorityClassName: ''
      });
    }
  }

  /**
   * Render the component
   */
  public render() {
    return (
      <EventDetailsPageView
        {...this.props}
        history={this.props.history}
        priorityClassName={this.state.priorityClassName}
        handlePanelState={this.handlePanelState}
        workflowPanelVisible={this.state.workflowPanelVisible}
        userNotAuthorized={this.state.userNotAuthorized}
        historyPanelElements={this.state.historyPanelElements}
      />
    );
  }
}

withRouter(EventDetailsPageViewController);
