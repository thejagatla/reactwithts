/**
 * Class description: React predictive event work status view controller
 * @author Capgemini
 * @version 1.0
 */

import * as React from 'react';
import { WorkOrderStatus, WorkOrderStatusEnum } from '../../../model/EventsConstantes';
import { SPMActions } from '../../../model/SPMEvent';
import { EventWorkStatusView } from './EventWorkStatusView';

export class EventWorkStatusViewController extends React.Component<any, any> {

  constructor(props: any) {
    super(props);

    this.state = {
      actionsList: SPMActions[WorkOrderStatus[props.status]]
    };
  }

  public componentWillReceiveProps(nextProps: any) {
    this.setState({
      actionsList: SPMActions[WorkOrderStatus[nextProps.status]]
    });
  }

  public render() {
    return (
      <div className="event-status">
        <EventWorkStatusView
          actions={this.state.actionsList}
          workOrderStatus={WorkOrderStatusEnum[WorkOrderStatusEnum[this.props.status]]}
          openWorkflowModal={this.props.openModal}
        />
      </div>
    );
  }
}
