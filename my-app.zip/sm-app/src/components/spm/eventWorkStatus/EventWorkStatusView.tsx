/**
 * Class description: React predictive event work status view
 * @author Capgemini
 * @version 1.0
 */
import { DSButton, DSStepIcon } from '@sm/skywise-react-library';
import * as classNames from 'classnames';
import * as React from 'react';
import * as Strings from '../../../lang/strings.json';
import { WorkflowActionEnum, WorkOrderStatus, WorkOrderStatusEnum } from '../../../model/EventsConstantes';
import {
  getIconFromWorkStatusEnum,
  getShortClassFromWorkStatusEnum
} from '../../../utils/FleetsweepUtils';
import { DSDropdown } from '../../storybook/DSDropdown/DSDropdown';

export const EventWorkStatusView = (props) => {
  const titleClass = classNames(
    'aligncenter',
    'event-status'
  );

  if (props.workOrderStatus !== undefined) {
    const actionsList: any = [];
    props.actions.map((action, index) => {
      actionsList.push({
        text: WorkflowActionEnum[action],
        value: action
      });
    });

    const iconContainerClass = getShortClassFromWorkStatusEnum(
      WorkOrderStatusEnum[WorkOrderStatusEnum[props.workOrderStatus]]
    );
    const iconClass = getIconFromWorkStatusEnum(
      WorkOrderStatusEnum[WorkOrderStatusEnum[props.workOrderStatus]]
    );

    return (
      <div className={titleClass}>
        <DSDropdown
          options={actionsList}
          onItemClick={props.openWorkflowModal}
          trigger={
            <DSButton
              icon={<DSStepIcon icon={iconClass} classNames={iconContainerClass + ' dropdown-ico'} />}
              content={WorkOrderStatus[props.workOrderStatus]}
              className="black-text dropdown-button"
            />
          }
        />
      </div>
    );
  }
  return (
    <div className={titleClass}>
      <DSButton
        content={Strings.defaultNoValueLabel}
        className="black-text"
      />
    </div>
  );
};
