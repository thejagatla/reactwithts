import { DSLoader } from '@sm/skywise-react-library';
import * as React from 'react';
import * as Strings from '../../../lang/strings.json';
import { SpmModelTrendsView } from './SpmModelTrendsView';

/**
 * Class description: Model trends page
 * @author Capgemini
 * @version 1.0
 */
export class SpmModelTrendsViewController extends React.Component<any, any> {
  constructor(props: any) {
    super(props);

    this.state = {
      filtersVisible: props.state.filtersVisible
    };

    this.toggleFiltersVisibility = this.toggleFiltersVisibility.bind(this);
  }

  public toggleFiltersVisibility() {
    this.props.setToggleFiltersVisibility(!this.state.filtersVisible);
  }

    /**
     * Starts before the component is mount
     */
  public componentDidMount() {
    this.props.loadFilters();
  }

    /**
     * Should component update
     */
  public componentWillReceiveProps(nextProps: any) {
    this.setState(
      {
        filtersVisible: nextProps.state.filtersVisible
      });
  }

  public render() {
    if (!this.props.fleetsInfosLoaded) {
      return (
        <DSLoader
          id={'fleetsInfosLoader'}
          label={Strings.loadFleetsInfosFilter}
        />
      );
    }

    return (
      <SpmModelTrendsView
        {...this.props}
        fleetsInfos={this.props.fleetsInfos}
        filtersVisible={this.state.filtersVisible}
        toggleFiltersVisibility={this.toggleFiltersVisibility}
      />
    );
  }
}
