/**
 * Class description: React model trends page component
 * @author Capgemini
 * @version 1.0
 */

import * as classNames from 'classnames';
import * as React from 'react';
import { FiltersPanelView } from './FiltersPanelView';

declare global {
  interface Function {
    displayName?: string;
  }
}

export const SpmModelTrendsView = (props: any) => {

  const filtersClass = classNames({
    filters: true,
    hidden: false,
    'l-filters': true
  });

  return (
    <div className={filtersClass}>
      <FiltersPanelView
        fleetsInfos={props.fleetsInfos}
        filtersVisible={props.state.filtersVisible}
        toggleFiltersVisibility={props.toggleFiltersVisibility}
      />
    </div>
  );
};

SpmModelTrendsView.displayName = 'SpmModelTrendsView';
