import { DSButton, DSIcon } from '@sm/skywise-react-library';
import * as classNames from 'classnames';
import * as React from 'react';
import { ACFamilyFilterView } from './ACFamilyFilterView';

/**
 * File description: Model trends filter view
 * Component type: UI View
 */
export const FiltersPanelView = (props: any) => {
  const type = props.filtersVisible ? 'chevron_up' : 'chevron_down';

  const filtersClass = classNames({
    filters: true,
    hidden: !props.filtersVisible,
    'l-other-filters': true
  });

  return (
    <div>
      <div className="filters-panel">
        <DSButton
          id="toggle-filters"
          as="a"
          icon={
            <DSIcon
              type={type}
            />
          }
          handleClick={props.toggleFiltersVisibility}
        />
      </div>
      <div className={filtersClass}>
        <ACFamilyFilterView
          fleetsInfos={props.fleetsInfos}
        />
      </div>
    </div>
  );
};
