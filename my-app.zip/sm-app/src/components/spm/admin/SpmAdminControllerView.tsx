import { DSCard, DSLoader } from '@sm/skywise-react-library';
import * as _ from 'lodash';
import * as React from 'react';
import { AdministrationController } from '../../../controllers/AdministrationController';
import * as Strings from '../../../lang/strings.json';
import { getIdToken } from '../../../utils/AuthenticationUtils';
import { openErrorModal } from '../../../utils/ModalsUtils';
import { Message } from '../../storybook/Message';
import { ErrorModalView } from '../../utils/errorModal/ErrorModalView';
import AdminFiltersViews from './adminFilters/AdminFiltersViews';
import ModelAccessLevelController from './modelAccessLevel/ModelAccessLevelController';
import ModelParametersController from './modelParameters/ModelParametersController';
import { AutomaticWorkflowController } from './workflow/AutomaticWorkflowController';

/**
 * Class description: Admin page
 * @author Capgemini
 * @version 1.0
 */
export class SpmAdminControllerView extends React.Component<any, any> {
  constructor(props: any) {
    super(props);

    this.state = {
      atas: [],
      atasForFilterView: [], // Atas displayed in radio
      // model: null,          // Data coming from API /airlines/{icao}/models/{id}
      modelAccessLevel: -1,
      modelConfiguration: {}, // model configuration list
      modelDefinition: null, // model definition list
      modelLoading: false,
      modelTitle: -1,
      modelsForFilterView: [],  // Models displayed in radio
      selectedAta: -1,
      selectedIcao: -1,
      selectedModel: -1,
      workflow: {
        automaticWorkflowConfiguration: {},
        automaticWorkflowConfigurationByUser: {},
        automaticWorkflowDefinition: null,
        newWorkflowIsLoading: false,
        workFlowParamName: ''
      }
    };

    this.airlineFilterHandler = this.airlineFilterHandler.bind(this);
    this.ataFilterHandler = this.ataFilterHandler.bind(this);
    this.modelFilterHandler = this.modelFilterHandler.bind(this);
  }

  // Enables a component to update its internal state when props are changed
  public static getDerivedStateFromProps(nextProps: any, prevState: any) {
    // check if received ataForSelectedAirline are equal to component atas
    if (
      _.difference(nextProps.ataForSelectedAirline, prevState.atas).length > 0
    ) {
      // set atas value if the value of ataForSelectedAirline is changed
      return { atas: nextProps.ataForSelectedAirline };
    }
    return null;
  }

  public componentDidUpdate(prevProps: any, prevState: any) {
    if (prevState.atas !== this.state.atas) {
      // Get group by atas
      let modelsSelectedByIcao = [];
      this.props.modelsForSelectedAirline.forEach(model => {
        modelsSelectedByIcao = modelsSelectedByIcao.concat(model.atas);
      });
      // Remove duplicates
      const atasAsSet = new Set(modelsSelectedByIcao);
      const atasSorted = Array.from(atasAsSet.values()).sort();
      const atasForFilterView = atasSorted.map(ata => {
        return {
          active: false,
          id: ata,
          label: ata
        };
      });

      this.setState({
        atasForFilterView
      });
    }
  }

  /**
   * Fill in the modal with the data
   */
  private fillErrorModalWithData(error: any) {
    // Decode the response
    error.json().then(res => {
      openErrorModal(
        res.exception.smTraceId,
        res.exception.message,
        res.exception.support.techRequestUrl,
        res.exception.support.contactChinese,
        res.exception.support.contactEnglish
      );
    });
  }

  public componentDidMount() {
    // Fetch authorizations and list of airlines' icaos
    this.props.getAirlines();
  }

  /**
   * Sort Alphanumerical values
   */
  private naturalCompare = (a, b) => {
    const ax = [];
    const bx = [];

    a.replace(/(\d+)|(\D+)/g, (_, $1, $2) => {
      ax.push([$1 || Infinity, $2 || '']);
    });
    b.replace(/(\d+)|(\D+)/g, (_, $1, $2) => {
      bx.push([$1 || Infinity, $2 || '']);
    });

    while (ax.length && bx.length) {
      const an = ax.shift();
      const bn = bx.shift();
      const nn = an[0] - bn[0] || an[1].localeCompare(bn[1]);
      if (nn) {
        return nn;
      }
    }
    return ax.length - bx.length;
  }

  /**
   * airline filter handler
   * @param {icaosFilter}
   */
  private airlineFilterHandler = (icaosFilter: any) => {
    const selectedIcao = icaosFilter.state.selected;
    if (selectedIcao === -1) {
      this.setState({
        atasForFilterView: [],
        modelsForFilterView: [],
        selectedAta: -1,
        selectedIcao,
        selectedModel: -1
      });
      return;
    }
    this.setState({
      modelsForFilterView: [],
      selectedAta: -1,
      selectedIcao,
      selectedModel: -1
    });
    // fetch models data
    this.props.getModels(selectedIcao);
  }

  /**
   * ATA filter Handler
   * @param {atasFilter}
   */
  private ataFilterHandler = (atasFilter: any) => {
    const selectedAta = atasFilter.state.selected;
    const sortedmodels = this.props.modelsForSelectedAirline.sort((a, b) => {
      return this.naturalCompare(a.id, b.id);
    });
    const modelsForFilterView = sortedmodels
      .filter(model => model.atas.includes(selectedAta))
      .map(model => {
        return {
          active: false,
          id: model.id,
          label: model.id
        };
      });
    this.setState({
      modelsForFilterView,
      selectedAta,
      selectedModel: -1
    });
  }

  /**
   * Model filter Handler
   * @param {modelFilter}
   */
  private modelFilterHandler = modelFilter => {
    this.setState({
      modelLoading: true
    });

    const selectedModel = modelFilter.state.selected;
    const selectedIcao = this.state.selectedIcao;
    AdministrationController.getModel(selectedIcao, selectedModel, getIdToken())
      .then((model: any) => {
        const automaticWorkflowConfiguration =
          model.automaticWorkflowConfiguration;
        const automaticWorkflowConfigurationByUser =
          model.automaticWorkflowConfiguration;
        this.setState({
          alertMessages: {},
          maturity: model.maturity,
          // model,
          modelAccessLevel: model.modelAccessLevel,
          modelConfiguration: model.modelConfigurations,
          modelDefinition: model.modelDefinition.parameters,
          modelLoading: false,
          modelTitle: model.title,
          selectedModel,
          workflow: {
            ...this.state.workflow,
            automaticWorkflowConfiguration,
            automaticWorkflowConfigurationByUser,
            automaticWorkflowDefinition: model.automaticWorkflowDefinition
          }
        });
      })
      .catch((error: any) => {
        this.fillErrorModalWithData(error);
      });
  }

  public render() {
    if (!this.props.icaosLoaded) {
      return <DSLoader id={'modelsLoader'} label={Strings.loadModelsLabel} />;
    }

    if (
      this.props.exception !== null &&
      this.props.exception.message !== null
    ) {
      return (
        <ErrorModalView
          UnauthorizedAccess={true}
          message={this.props.exception.message}
        />
      );
    }

    // throw error modal id there is a loding exception
    if (this.props.loadingModelsException) {
      this.fillErrorModalWithData(this.props.loadingModelsException);
    }

    const icaos = this.props.icaos.map(icao => {
      return {
        active: false,
        id: icao,
        label: icao
      };
    });

    const selectedModel =
      this.state.selectedModel === -1 && this.state.modelLoading === false ? (
        <Message
          icon="airplane-inactive"
          text="Please select airline, ATA and model"
        />
      ) : null;

    return (
      <div className="ds-container-fluid" id="spmAdminPage">
        <AdminFiltersViews
          icaos={icaos}
          selectedIcao={this.state.selectedIcao}
          selectedAta={this.state.selectedAta}
          selectedModel={this.state.selectedModel}
          atasForFilterView={this.state.atasForFilterView}
          modelsForFilterView={this.state.modelsForFilterView}
          airlineFilterHandler={this.airlineFilterHandler}
          ataFilterHandler={this.ataFilterHandler}
          modelFilterHandler={this.modelFilterHandler}
          showFilterLoading={this.props.modelsLoading}
        />
        <section className="customizationContent">
          {selectedModel ? (
            selectedModel
          ) : (
            <DSCard
              title={this.state.modelTitle !== null && this.state.modelTitle !== -1 && !this.state.modelLoading
                ? this.state.modelTitle
                : 
                this.state.modelLoading ? 'Title loading' : 'Title unknown'}
              content={
                <div>
                  <br />
                  <ModelAccessLevelController
                    showModelLoading={this.state.modelLoading}
                    selectedIcao={this.state.selectedIcao}
                    selectedModel={this.state.selectedModel}
                    maturity={this.state.maturity}
                    modelAccessLevel={this.state.modelAccessLevel}
                    fillErrorModalWithData={this.fillErrorModalWithData}
                  />
                  <br />
                  <ModelParametersController
                    modelConfiguration={this.state.modelConfiguration}
                    modelDefinition={this.state.modelDefinition}
                    selectedIcao={this.state.selectedIcao}
                    selectedModel={this.state.selectedModel}
                    naturalCompare={this.naturalCompare}
                    showModelLoading={this.state.modelLoading}
                    fillErrorModalWithData={this.fillErrorModalWithData}
                  />
                  <br />
                  <AutomaticWorkflowController
                    workflow={this.state.workflow}
                    selectedIcao={this.state.selectedIcao}
                    selectedModel={this.state.selectedModel}
                    showModelLoading={this.state.modelLoading}
                    fillErrorModalWithData={this.fillErrorModalWithData}
                  />
                </div>
              }
            />
          )}
        </section>
      </div>
    );
  }
}
