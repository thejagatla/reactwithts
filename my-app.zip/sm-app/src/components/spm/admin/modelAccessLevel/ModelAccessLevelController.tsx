import * as React from 'react';
import { AdministrationController } from '../../../../controllers/AdministrationController';
import { getIdToken } from '../../../../utils/AuthenticationUtils';
import ModelAccessLevelView from './ModelAccessLevelView';

export default class ModelAccessLevelController extends React.Component<any, any> {

  constructor(props: any) {
    super(props);
    this.state = {
      alertMessages: {
        showModelALSuccessBaner: false,
        showModelALWarningBanner: false,
      },
      applyButtonDisabledByDefaultForAL: true,
      modelAccessLevel: null,
      modelAccessLevelIsLoading: false
    };

    this.handleModelAccessLevel = this.handleModelAccessLevel.bind(this);
    this.putModelAccessLevelValue = this.putModelAccessLevelValue.bind(this);
    this.closeBannerHandler = this.closeBannerHandler.bind(this);
  }

  // Enables a component to update its internal state when props are changed
  public static getDerivedStateFromProps(nextProps: any, prevState: any) { 
    if (nextProps.modelAccessLevel !== prevState.modelAccessLevel) {
      return {
        alertMessages: {},
        modelAccessLevel: nextProps.modelAccessLevel
      };
    }
    return null;
  }

  /**
   * Change Handler for modelConfigurationList
   * @param pEvent
   */
  private handleModelAccessLevel(pEvent: React.FormEvent<HTMLInputElement>) {
    const currentTarget = pEvent.currentTarget;
    let tempModelAccessLevel;
    tempModelAccessLevel = parseInt(currentTarget.value.replace(/[^1-3]/g, ''), 10);
    if (tempModelAccessLevel > 0 && tempModelAccessLevel < 4) {
      this.setState({
        alertMessages: {
          ...this.state.alertMessages,
          showModelALWarningBanner: false
        },
        applyButtonDisabledByDefaultForAL: false,
        modelAccessLevel: tempModelAccessLevel,
      });
    } else if (currentTarget.value === '') {
      this.setState({
        alertMessages: {
          ...this.state.alertMessages,
          showModelALWarningBanner: false
        },
        applyButtonDisabledByDefaultForAL: false,
        modelAccessLevel: '',
      });
    } else {
      this.setState({
        alertMessages: {
          ...this.state.alertMessages,
          showModelALWarningBanner: true
        },
        applyButtonDisabledByDefaultForAL: true,
        modelAccessLevel: '',
      });
    }
  }

  /**
   * Set value of model access level
   */
  private putModelAccessLevelValue = () => {
    this.setState({
      modelAccessLevelIsLoading: true
    });

    const confValues = { modelAccessLevel: this.state.modelAccessLevel };
    AdministrationController
      .putModel(
        this.props.selectedIcao,
        this.props.selectedModel,
        confValues,
        getIdToken()
      )
      .then((res: any) => {
        this.setState({
          alertMessages: {
            ...this.state.alertMessages,
            showModelALSuccessBaner: true
          },
          modelAccessLevelIsLoading: false,
        });
      }).catch((error: any) => {
        this.props.fillErrorModalWithData(error);
        this.setState({
          modelAccessLevelIsLoading: false
        });
      });
  }

  /**
   * Close banners handler
   *  @param {bannerId} the banner id
   */
  private closeBannerHandler = (bannerId: string) => {
    const newAlertMessages = { ...this.state.alertMessages };
    newAlertMessages[bannerId] = false;
    this.setState({
      alertMessages: newAlertMessages,
    });
  }

  public render() {
    return (
      <ModelAccessLevelView
        showModelLoading={this.props.showModelLoading}
        modelAccessLevel={this.state.modelAccessLevel}
        maturity={this.props.maturity}
        handleModelAccessLevel={this.handleModelAccessLevel}
        modelAccessLevelIsLoading={this.state.modelAccessLevelIsLoading}
        putModelAccessLevelValue={this.putModelAccessLevelValue}
        showModelALSuccessBaner={this.state.alertMessages.showModelALSuccessBaner}
        showModelALWarningBanner={this.state.alertMessages.showModelALWarningBanner}
        closeBannerHandler={this.closeBannerHandler}
        isDisabled={this.state.applyButtonDisabledByDefaultForAL}
      />
    );
  }
}
