import {
  DSBanner, DSButton, DSCard, DSDotsLoader, DSHelp, DSLoader, DSTable, DSTableBody, DSTableRow, DSText
} from '@sm/skywise-react-library';
import * as React from 'react';
import * as Strings from '../../../../lang/strings.json';

const ModelAccessLevelView = (props: any) => (

  <DSCard
    
    content={
      (props.showModelLoading)
        ?
        <DSLoader
          id={'modelLoader'}
          label={Strings.modelLoadingMessage}
        />
        :
        <div>
          {
            props.showModelALSuccessBaner &&
            <DSBanner
              type={'success'}
              title={'Your configuration has been updated'}
              id={'success-model-conf-message'}
              withCloseButton={true}
              center={true}
              handleClose={() => props.closeBannerHandler('showModelALSuccessBaner')}
            />
          }
          {
            props.showModelALWarningBanner &&
            <DSBanner
              type={'warning'}
              title={'Incorrect input. Accepted values are 1, 2 or 3'}
              id={'warning-model-access-level'}
              withCloseButton={true}
              center={true}
              handleClose={() => props.closeBannerHandler('showModelALWarningBanner')}
            />
          }
          <div className="ds-card--title">
            {Strings.modelAccessLevelTitle}
            <DSHelp
              title={Strings.parameterDescriptionHelper}
              content={
                <div>
                  {Strings.modelAccessLevelHelp} {props.maturity}
                </div>
              }
              size="700px"
            />
          </div>
        
          <DSTable>
            <DSTableBody>
              <DSTableRow>
                <td>
                  <DSText
                    label=""
                    id=""
                    maxLength={1}
                    name="ModelAccessLevel"
                    value={props.modelAccessLevel ? props.modelAccessLevel : ''}
                    placeholder="1-2 or 3"
                    isDisabled={false}
                    handleChange={props.handleModelAccessLevel}
                  />
                </td>
              </DSTableRow>
              {Strings.modelAccessLevelHelp} {props.maturity}
              <DSTableRow>
                <td colSpan={12}>
                  <div className="ds-row ds-justify-content-end">
                    <div className="ds-col-6">
                      {props.modelAccessLevelIsLoading && <DSDotsLoader />}
                    </div>
                    <DSButton
                      type="primary"
                      content="Apply"
                      disabled={props.isDisabled}
                      handleClick={props.putModelAccessLevelValue}
                    />
                  </div>
                </td>
              </DSTableRow>

            </DSTableBody>
          </DSTable>
        </div>

    }
  />
);

export default ModelAccessLevelView;
