import { DSLoader, DSTabPanel } from '@sm/skywise-react-library';
import * as React from 'react';
import { FormFilterView } from './FormFilterView';

/**
 * Class description: This component contains all filters for SPM admin page
 * @author Capgemini
 * @version 1.0
 */

const AdminFiltersViews = (props: any) => (
  <DSTabPanel>
    <div
      className="administration-filter"
      style={{
        display: 'inline-block'
      }}
    >

      {props.showFilterLoading && (
        <DSLoader id={'ataAndModelsLoader'} label="ATA and models loading..." />
      )}
      {!props.showFilterLoading &&
        <div>
          <FormFilterView
            labelFilter="Airline"
            dataFilter={props.icaos}
            type="AIRLINE"
            idItem={props.selectedIcao}
            adminOnSubmit={props.airlineFilterHandler}
          />
          <FormFilterView
            key={'ATA' + props.selectedAta}
            labelFilter="ATA"
            dataFilter={props.atasForFilterView}
            idItem={props.selectedAta}
            type="ATA"
            adminOnSubmit={props.ataFilterHandler}
          />
          <FormFilterView
            key={'Model' + props.selectedModel}
            labelFilter="Model"
            dataFilter={props.modelsForFilterView}
            idItem={props.selectedModel}
            type="MODEL"
            adminOnSubmit={props.modelFilterHandler}
          />
        </div>
      }

    </div>
  </DSTabPanel>
);
export default AdminFiltersViews;
