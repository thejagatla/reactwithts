/**
 * File description: Fleet Sweep main panel controller
 * @author Capgemini
 * @version 1.0
 */

import * as React from 'react';
import { HtmlCheckboxProps } from '../../../storybook';
import { Filter } from '../../../storybook/filter/Filter';

export class FormFilterView extends React.Component<any, any> {
  /**
   * Constructor
   * @param props React props 
   */
  public constructor(props: any) {
    super(props);

    this.state = {
      initial: true,
      selected: props.idItem ? props.idItem : -1,
      selectedDisplay: props.idItem ? props.idItem : -1,
      textList: [props.idItem],
    };

    this.isEmpty = this.isEmpty.bind(this);
    this.convertFilterValues = this.convertFilterValues.bind(this);
    this.handleRadioChange = this.handleRadioChange.bind(this);
    this.clearFilter = this.clearFilter.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    this.getTextList = this.getTextList.bind(this);
    this.handleCancelClick = this.handleCancelClick.bind(this);
  }

  /**
   * React lifecycle method
   * @param nextProps next props
   * @param nextState next state
   */
  public shouldComponentUpdate(nextProps: any, nextState: any): boolean {
    return (nextState !== this.state);
  }

  /**
   * Convert filter values text into presentational form
   */
  private convertFilterValues(): HtmlCheckboxProps[] {
    const lResult: HtmlCheckboxProps[] = [];

    this.props.dataFilter.forEach((lValue) => {
      let activeRadio = false;
      if (this.state.selected === lValue.id) {
        activeRadio = true;
      }
      lResult.push({
        active: activeRadio,
        id: lValue.id,
        label: lValue.id,
      });
    });

    return lResult;
  }

  /**
   * Convert filter values text into presentational form
   */
  public getTextList(pFilterType: string): string[] {
    return this.state.textList;
  }

  /**
   * Return true if should be empty, false otherwise
   */
  private isEmpty(): boolean {
    return (
      this.state.selectedDisplay === -1
    );
  }

  /**
   * Return true if should be empty, false otherwise
   */
  private clearFilter(): void {
    this.setState({
      selected: -1
    });
  }

  /**
   * Return true if should be empty, false otherwise
   */
  private onSubmit(): void {
    if (this.state.selected !== -1) {
      this.setState({
        selectedDisplay: this.state.selected,
        textList: [this.state.selected],
      });
    } else {
      this.setState({
        selectedDisplay: -1,
        textList: []
      });
    }

    this.props.adminOnSubmit(this);
  }

  /**
   * Return true if should be empty, false otherwise
   */
  private handleCancelClick(): void {
    this.setState({
      selected: this.props.idItem
    });
  }

  /**
   * Handle click on radioButton
   * @param pFilterType Filter type (WORK_STATUS, PRIORITY...)
   * @param pRadioId checkbxox id (TO_BE_REVIEWED, W, HIGH...)
   */
  private handleRadioChange(pFilterType: string, pRadioId: string): void {
    this.setState({
      selected: pRadioId
    });
  }

  /**
   * Render method
   */
  public render() {
    return (
      <Filter
        isEmpty={this.isEmpty}
        label={this.props.labelFilter}
        type={this.props.type}
        textList={this.getTextList}
        values={this.convertFilterValues}
        inputType="radio"
        clearFilters={this.clearFilter}
        handleCheckboxChange={this.handleRadioChange}
        handleCancelClick={this.handleCancelClick}
        onSubmit={this.onSubmit}
      />
    );
  }
}
