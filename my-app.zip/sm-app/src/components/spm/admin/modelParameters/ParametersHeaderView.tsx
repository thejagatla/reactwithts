import { DSHelp, DSTableRow } from '@sm/skywise-react-library';
import * as React from 'react';
import * as Strings from '../../../../lang/strings.json';

/**
 * Class description: This component contains worflow parameters that can be modified
 * @author Capgemini
 * @version 1.0
 */

const ParametersHeaderView = (props: any) => (

  <DSTableRow key="headerParameters">
    <th>{Strings.adminHeaderACType}</th>
    <th>{Strings.adminHeaderEngineType}</th>
    {props.modelDefinitionList.map((threshold: any, index1: number) =>
      <th key={index1}>
        <div className="ds-label">
          {threshold.title ? threshold.title : threshold.name}
          {threshold.defaultValue !== null ? ' (Default: ' + parseInt(threshold.defaultValue, 10) + ') '
            : ' '}
          {(threshold.description !== null || threshold.type !== null || threshold.unit !== null) ?
            <DSHelp
              title={Strings.parameterDescriptionHelper}
              content={
              <HelpView
                threshold={threshold}
              />}
              size="700px"
            /> : ''}
        </div>
      </th>
    )}
  </DSTableRow>
  
);

const HelpView = (props: any) => (
  <div>
    <div>Description: {props.threshold.description !== null ? props.threshold.description : 'No description'}</div>
    <div>Type: {props.threshold.type !== null ? props.threshold.type : 'No type found'}</div>
    <div>Unit: {props.threshold.unit !== null ? props.threshold.unit : 'No unit found'}</div>
    <div>Data type: {props.threshold.dtype !== null 
      ? props.threshold.dtype === 'integer'
        ? 'integer (e.g. 15)'
        : (props.threshold.dtype === 'double' || props.threshold.dtype === 'float')
          ? props.threshold.dtype + ' (e.g. 0.34)'
          : props.threshold.dtype
      : 'No data found'
    }</div>
    <div>Min: {props.threshold.min !== null ? props.threshold.min : 'No min found'}</div>
    <div>Max: {props.threshold.max !== null ? props.threshold.max : 'No max found'}</div>
    <div>Default: {props.threshold.defaultValue !== null 
      ? props.threshold.defaultValue 
      : 'No default value found'
    }</div>
  </div>
);

export default ParametersHeaderView;
