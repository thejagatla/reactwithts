import {
  DSBanner, DSButton, DSCard, DSDotsLoader, DSLoader, DSTable, DSTableBody, DSTableRow
} from '@sm/skywise-react-library';
import * as React from 'react';
import * as Strings from '../../../../lang/strings.json';
import ParametersHeaderView from './ParametersHeaderView';
import ParametersRowView from './ParametersRowView';

/**
 * Class description: This component contains worflow parameters that can be modified
 * @author Capgemini
 * @version 1.0
 */

const ModelParametersView = (props: any) => (
  <DSCard
    content={
      (props.showModelLoading)
        ?
        <DSLoader
          id={'modelLoader'}
          label={Strings.modelLoadingMessage}
        />
        : ((props.modelDefinitionList === null) ?
          Strings.noModelParamFoundMessage :
          props.modelConfigurationListByUser === null ? Strings.noModelConfigFoundMessage :
            <div>
              <div style={{ overflow: 'auto' }}>
                {
                  props.showModelConfSuccessBaner &&
                  <DSBanner
                    type={'success'}
                    title={'Your configuration has been updated'}
                    id={'success-model-conf'}
                    withCloseButton={true}
                    center={true}
                    handleClose={() => props.closeBannerHandler('showModelConfSuccessBaner')}
                  />
                }
                {
                  props.showModelConfWarningBaner &&
                  <DSBanner
                    type={'warning'}
                    title={props.minMaxWarningforModelConf ? 'Value not in range'
                      : 'Only numbers are allowed. Please check input data type using the help button'}
                    id={'warning-model-conf'}
                    withCloseButton={true}
                    center={true}
                    handleClose={() => props.closeBannerHandler('showModelConfWarningBaner')}
                  />
                }
                <div className="ds-card--title"> {Strings.modelParametersTitle}
                </div>
                <DSTable>
                  <DSTableBody>
                    <ParametersHeaderView
                      modelDefinitionList={props.modelDefinitionList}
                    />
                    {props.modelConfigurationListByUser.sort((a, b) =>
                      props.naturalCompare(
                        (a.effectivity.aircraftType + '/' + a.effectivity.engineType),
                        (b.effectivity.aircraftType + '/' + b.effectivity.engineType))

                    ).map((element: any, index: number) =>
                      <DSTableRow key={index}>
                        <td>{element.effectivity.aircraftType}</td>
                        <td>{element.effectivity.engineType}</td>
                        <ParametersRowView
                          aircraftAndEngineType={element.effectivity.aircraftType +
                            ';' + element.effectivity.engineType}
                          index={index}
                          paramName={props.paramName}
                          rowIndex={props.rowIndex}
                          getThresholdValue={props.getThresholdValue}
                          modelConfigurationListByUser={props.modelConfigurationListByUser}
                          modelDefinitionList={props.modelDefinitionList}
                          parametersList={element.parameters}
                          minMaxWarningforModelConf={props.minMaxWarningforModelConf}
                          badInputAlert={props.badInputAlert}
                          handleChangeModelParameters={props.handleChangeModelParameters}
                        />
                      </DSTableRow>
                    )}
                  </DSTableBody>
                </DSTable>
              </div>
              <div>
                <DSTable>
                  <DSTableRow>
                    <td>
                      <div className="ds-row ds-justify-content-end">
                        <div className="ds-col-6">
                          {props.newModelConfigurationIsLoading && <DSDotsLoader />}
                        </div>
                        <DSButton
                          type="primary"
                          content="Apply"
                          disabled={props.isDisabled}
                          handleClick={props.putModelConfValues}
                        />
                      </div>
                    </td>
                  </DSTableRow>
                </DSTable>
              </div>
            </div>
        )
    }
  />
);

export default ModelParametersView;
