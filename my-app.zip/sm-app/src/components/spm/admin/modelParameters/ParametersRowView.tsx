import { DSTableCell, DSText } from '@sm/skywise-react-library';
import * as React from 'react';

/**
 * Class description: This component contains worflow parameters that can be modified
 * @author Capgemini
 * @version 1.0
 */

const ParametersRowView = (props: any) => (
  props.modelDefinitionList.map((threshold: any, index1: number) =>
    (
      <DSTableCell key={index1}>
        <DSText
          label=""
          id={threshold.name + ';' + props.index}
          isDisabled={(props.minMaxWarningforModelConf === true || props.badInputAlert === true) ?
            ((props.paramName === threshold.name) && (props.rowIndex === props.index) ? false : true)
            : false}
          name={props.aircraftAndEngineType + ';' + threshold.name + ';' +
            (threshold.min !== null ? threshold.min : ' ') + ';' +
            (threshold.max !== null ? threshold.max : ' ') + ';' +
            (threshold.dtype !== null ? threshold.dtype : ' ')}
          value={props.getThresholdValue(threshold, props.parametersList) !== null ?
            props.getThresholdValue(threshold, props.parametersList) : ''}
          placeholder={(threshold.min !== null ? ('Min: ' + threshold.min) : '')
            +
            (threshold.max !== null ? (' / Max: ' + threshold.max) : '')}
          handleChange={props.handleChangeModelParameters}
        />
      </DSTableCell>
    )
  )
);

export default ParametersRowView;
