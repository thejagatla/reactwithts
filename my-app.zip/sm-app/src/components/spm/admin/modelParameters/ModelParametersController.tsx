import * as React from 'react';
import { AdministrationController } from '../../../../controllers/AdministrationController';
import { getIdToken } from '../../../../utils/AuthenticationUtils';
import ModelParametersView from './ModelParametersView';

export default class ModelParametersController extends React.Component<any, any> {

  constructor(props: any) {
    super(props);
    this.state = {
      alertMessages: {
        showModelConfSuccessBaner: false,
        showModelConfWarningBaner: false,
      },
      applyButtonIsDisabled: true,
      badInputAlert: false,
      minMaxWarningforModelConf: false,
      modelConfiguration: {},
      modelDefinition: null,
      newModelConfigurationIsLoading: false,
      paramName: '',
      rowIndex: -1
    };

    this.handleChangeModelParameters = this.handleChangeModelParameters.bind(this);
    this.putModelConfValues = this.putModelConfValues.bind(this);
    this.closeBannerHandler = this.closeBannerHandler.bind(this);

  }

  // Enables a component to update its internal state when props are changed
  public static getDerivedStateFromProps(nextProps: any, prevState: any) { 
    if (nextProps.workflow !== prevState) {
      return {
        alertMessages: {}, 
        modelConfiguration: nextProps.modelConfiguration,
        modelDefinition: nextProps.modelDefinition
      };
    }
    return null;
  }

  /**
   * Change Handler for modelConfigurationList
   * @param pEvent
   */
  private handleChangeModelParameters(pEvent: React.FormEvent<HTMLInputElement>) {
    const currentTarget = pEvent.currentTarget;
    const tempValues = currentTarget.name.split(';', 6);
    const tempId = currentTarget.id.split(';', 2);
    this.setState({
      paramName: tempId[0],
      rowIndex: parseInt(tempId[1], 10)
    });
    this.setModifiedValue(this.state.modelConfiguration, tempValues, currentTarget);
  }

  /**
   * Set modified values(s) for a given parameter
   */
  private setModifiedValue(modelConfiguration: any[], values: any, currentTarget: any) {
    const tempModel = modelConfiguration;
    tempModel.forEach((element, index) => {
      if (element.effectivity.aircraftType === values[0] && element.effectivity.engineType === values[1]) {
        element.parameters.forEach((param, key) => {
          if (param.name === values[2]) {
            tempModel[index].parameters[key].value = currentTarget.value.replace(/[^-0-9.]/g, ''); 
            this.checkInputValueForModelConf(currentTarget.value, values[3], values[4], values[5]);
          }
        });
      }
    });
    this.setState({
      modelConfiguration: tempModel,
    });
  }

  /**
   * Check if user input value is within the correct range and if only numbers are submitted
   */
  private checkInputValueForModelConf(value: any, min: any, max: any, dtype: any) {
    if (value === null || value === '') { // Case 1 : No value - Apply button is disabled by default
      this.setState({
        alertMessages: {
          ...this.state.alertMessages,
          showModelConfWarningBaner: false,
        },
        applyButtonIsDisabled: false,
        minMaxWarningforModelConf: false,
      });

    } else { // Case 2: There is a value - check for special characters and MIN MAX
      
      let regexNumeric;
      if (dtype === 'integer') {
        regexNumeric = /^[+-]?[0-9]+$/g;
      } else {
        regexNumeric = /^[+-]?([0-9]+[.])?[0-9]+$/g;
      }
      
      if (!value.match(regexNumeric) === true) { // Case 2a: Regex doesn't match = bad input
        this.setState({
          alertMessages: {
            ...this.state.alertMessages,
            showModelConfWarningBaner: true
          },
          badInputAlert: true
        });
      } else { // Case 2b: Value match regex : Still need to check min and max
        this.setState({
          alertMessages: {
            ...this.state.alertMessages,
            showModelConfWarningBaner: false
          },
          applyButtonIsDisabled: false,
          badInputAlert: false
        });
        this.checkMinMax(value, min, max, dtype);
      }
    } 
  }

  private checkMinMax(value: any, min: any, max: any, dtype: any) {
    if (min !== ' ' || max !== ' ') { 
      let tempMin;
      let tempMax;
      let tempValue;
      if (dtype === 'integer') {
        tempMin = parseInt(min, 10);
        tempMax = parseInt(max, 10);
        tempValue = parseInt(value, 10);
      } else {
        tempMin = parseFloat(min);
        tempMax = parseFloat(max);
        tempValue = parseFloat(value);
      }

      if (tempValue > tempMax || tempValue < tempMin) { // check for range 
        this.setState({
          alertMessages: {
            ...this.state.alertMessages,
            showModelConfWarningBaner: true
          },
          applyButtonIsDisabled: false,
          minMaxWarningforModelConf: true,
        });
      } else {
        this.setState({
          alertMessages: {
            ...this.state.alertMessages,
            showModelConfWarningBaner: false
          },
          applyButtonIsDisabled: false,
          minMaxWarningforModelConf: false,
        });
      }
    }
  }

  /**
   * Get threshold value for a given threshold
   */
  public getThresholdValue = (threshold: any, parameterList: any[]) => {
    let tempThreshold = '';
    parameterList.forEach((element) => {
      if (element.name === threshold.name) {
        tempThreshold = element.value;
      }
    }
    );
    return tempThreshold;
  }

  /**
   * Call api to set a new configuration for the selected model 
   */
  private putModelConfValues = () => {
    this.setState({
      newModelConfigurationIsLoading: true
    });

    const confValues = { modelConfigurations: this.state.modelConfiguration };
    AdministrationController
      .putModel(
        this.props.selectedIcao,
        this.props.selectedModel,
        confValues,
        getIdToken()
      )
      .then((res: any) => {
        this.setState({
          alertMessages: {
            ...this.state.alertMessages,
            showModelConfSuccessBaner: true
          },
          newModelConfigurationIsLoading: false,
        });
      }).catch((error: any) => {
        this.props.fillErrorModalWithData(error);
        this.setState({
          newModelConfigurationIsLoading: false
        });
      });
  }

  /**
   * Close banners handler
   *  @param {bannerId} the banner id
   */
  private closeBannerHandler = (bannerId: string) => {
    const newAlertMessages = { ...this.state.alertMessages };
    newAlertMessages[bannerId] = false;
    this.setState({
      alertMessages: newAlertMessages,
    });
  }

  public render() {
    return (
      <ModelParametersView 
        showModelLoading={this.props.showModelLoading}
        modelConfigurationListByUser={this.state.modelConfiguration}
        modelDefinitionList={this.state.modelDefinition}
        handleChangeModelParameters={this.handleChangeModelParameters}
        putModelConfValues={this.putModelConfValues}
        naturalCompare={this.props.naturalCompare}
        getThresholdValue={this.getThresholdValue}
        showModelConfWarningBaner={this.state.alertMessages.showModelConfWarningBaner}
        minMaxWarningforModelConf={this.state.minMaxWarningforModelConf}
        newModelConfigurationIsLoading={this.state.newModelConfigurationIsLoading}
        showModelConfSuccessBaner={this.state.alertMessages.showModelConfSuccessBaner}
        closeBannerHandler={this.closeBannerHandler}
        paramName={this.state.paramName}
        rowIndex={this.state.rowIndex}
        badInputAlert={this.state.badInputAlert}
        isDisabled={this.state.minMaxWarningforModelConf || this.state.newModelConfigurationIsLoading
          || this.state.applyButtonIsDisabled || this.state.badInputAlert}
      />
    );
  }

}
