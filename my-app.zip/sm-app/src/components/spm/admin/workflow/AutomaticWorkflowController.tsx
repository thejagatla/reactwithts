import * as React from 'react';
import { AdministrationController } from '../../../../controllers/AdministrationController';
import { getIdToken } from '../../../../utils/AuthenticationUtils';
import AutomaticWorkflowView from './AutomaticWorkflowView';

export class AutomaticWorkflowController extends React.Component<any, any> {

  constructor(props: any) {
    super(props);
    this.state = {
      alertMessages: {
        workflowSuccessBaner: false,
        workflowWarningBaner: false,
      },
      applyButtonDisabledByDefaultForWF: true,
      workflow: {}
    };

    this.toggleAutomaticWorkflowHandler = this.toggleAutomaticWorkflowHandler.bind(this);
    this.putWorflowValues = this.putWorflowValues.bind(this);
    this.handleChangeNumberOfFlights = this.handleChangeNumberOfFlights.bind(this);
    this.closeBannerHandler = this.closeBannerHandler.bind(this);
  }

  // Enables a component to update its internal state when props are changed
  public static getDerivedStateFromProps(nextProps: any, prevState: any) { 
    if (nextProps !== prevState) {
      return { 
        alertMessages: {},
        workflow: nextProps.workflow,
      };
    }
    return null;
  }

  /**
   * Enable / disable automatic workflow
   */
  private toggleAutomaticWorkflowHandler = () => {
    const newAutomaticWorkflowConfiguration = {
      ...this.state.workflow.automaticWorkflowConfigurationByUser
    };
    newAutomaticWorkflowConfiguration.enabled = !newAutomaticWorkflowConfiguration.enabled;
    this.setState({
      applyButtonDisabledByDefaultForWF: false,
      workflow: {
        ...this.state.workflow,
        automaticWorkflowConfigurationByUser: newAutomaticWorkflowConfiguration,
      },
    });
  }

  /**
   * Close banners handler
   *  @param {bannerId} the banner id
   */
  private closeBannerHandler = (bannerId: string) => {
    const newAlertMessages = { ...this.state.alertMessages };
    newAlertMessages[bannerId] = false;
    this.setState({
      alertMessages: newAlertMessages,
    });
  }

  /**
   * Change Handler for automaticWorkflowConfigurationByUser
   * @param pEvent
   */
  private handleChangeNumberOfFlights(pEvent: React.FormEvent<HTMLInputElement>) {
    const automaticWorkflowConfigurationByUser = { ...this.state.workflow.automaticWorkflowConfigurationByUser };
    const currentTarget = pEvent.currentTarget;
    const tempMinMax = currentTarget.id.split(';', 2);
    automaticWorkflowConfigurationByUser[currentTarget.name].value = currentTarget.value.replace(/\D/, '');
    this.checkInputValueForWFConf(currentTarget.value, tempMinMax[0], tempMinMax[1]);

    this.setState({
      workflow: {
        ...this.state.workflow,
        automaticWorkflowConfigurationByUser,
        workFlowParamName: currentTarget.name
      }
    });
  }

  /**
   * Check if user input value is within the correct range and if only numbers are submitted
   */
  private checkInputValueForWFConf(value: any, min: any, max: any) {

    if (value === null || value === '') { // Case 1 : No value - Apply button is disabled by default
      this.setState({
        alertMessages: {
          ...this.state.alertMessages,
          workflowWarningBaner: false
        },
        applyButtonDisabledByDefaultForWF: false,
        minMaxWarningforWFConf: false,
      });

    } else if (min !== ' ' || max !== ' ') { // Case 2: There is a value with a range
      const tempMin = parseInt(min, 10);
      const tempMax = parseInt(max, 10);
      const tempValue = parseInt(value, 10);
      if (!value.match(/^[0-9]+$/) === true) { // Case 2 (Check 1/2): Check letters and specials characters 
        this.setState({
          alertMessages: {
            ...this.state.alertMessages,
            workflowWarningBaner: true
          },
        });
      } else if (tempValue > tempMax || tempValue < tempMin) { // Case 2 (Check 2/2): only numbers so check for range 
        this.setState({
          alertMessages: {
            ...this.state.alertMessages,
            workflowWarningBaner: true
          },
          applyButtonDisabledByDefaultForWF: false,
          minMaxWarningforWFConf: true,
        });
      } else {
        this.setState({
          alertMessages: {
            ...this.state.alertMessages,
            workflowWarningBaner: false
          },
          applyButtonDisabledByDefaultForWF: false,
          minMaxWarningforWFConf: false,
        });
      }

    } else { // Case 3: There is a value with no range - Only check for special characters and letters
      !value.match(/^[0-9]+$/) ?
        this.setState({
          alertMessages: {
            ...this.state.alertMessages,
            workflowWarningBaner: true
          }
        })
        :
        (this.setState({
          alertMessages: {
            ...this.state.alertMessages,
            workflowWarningBaner: false
          },
          applyButtonDisabledByDefaultForWF: false,
        }));
    }
  }

  /**
   * Call api to set a new configuration for workflow values
   * @param {event}
   */
  private putWorflowValues = (event) => {
    this.setState({
      workflow: {
        ...this.state.workflow,
        newWorkflowIsLoading: true
      }
    });
    const newWorkflowconfiguration = {
      automaticWorkflowConfiguration: {
        ...this.state.workflow.automaticWorkflowConfigurationByUser
      }
    };

    AdministrationController
      .putModel(
        this.props.selectedIcao,
        this.props.selectedModel,
        newWorkflowconfiguration,
        getIdToken()
      )
      .then((res: any) => {
        this.setState({
          alertMessages: {
            ...this.state.alertMessages,
            workflowSuccessBaner: true
          },
          workflow: {
            ...this.state.workflow,
            newWorkflowIsLoading: false,
          }
        });
      }).catch((error: any) => {
        this.props.fillErrorModalWithData(error);
        this.setState({
          workflow: {
            ...this.state.workflow,
            newWorkflowIsLoading: false,
          }
        });
      });
  }

  public render() {
    return (
      <AutomaticWorkflowView
        automaticWorkflowIsEnabled={this.state.workflow.automaticWorkflowConfigurationByUser.enabled}
        toggleAutomaticWorkflowHandler={this.toggleAutomaticWorkflowHandler}
        putWorflowValues={this.putWorflowValues}
        handleChangeNumberOfFlights={this.handleChangeNumberOfFlights}
        automaticWorkflowConfigurationByUser={this.state.workflow.automaticWorkflowConfigurationByUser}
        // automaticWorkflowConfiguration={this.state.workflow.automaticWorkflowConfiguration}
        automaticWorkflowDefinition={this.state.workflow.automaticWorkflowDefinition}
        showModelLoading={this.props.showModelLoading}
        newWorkflowIsLoading={this.state.workflow.newWorkflowIsLoading}
        workflowSuccessBaner={this.state.alertMessages.workflowSuccessBaner}
        closeBannerHandler={this.closeBannerHandler}
        showWarningWFConfBanerHandler={this.state.alertMessages.workflowWarningBaner}
        minMaxWarningforWFConf={this.state.minMaxWarningforWFConf}
        workFlowParamName={this.state.workflow.workFlowParamName}
        isDisabled={this.state.minMaxWarningforWFConf || this.state.workflow.newWorkflowIsLoading
          || this.state.applyButtonDisabledByDefaultForWF}

      />
    );
  }
}
