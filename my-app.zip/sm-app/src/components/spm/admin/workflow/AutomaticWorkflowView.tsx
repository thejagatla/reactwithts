import {
  DSBanner, DSButton, DSCard, DSDotsLoader, DSLoader, DSTable, DSTableBody, DSTableCell, DSTableRow, DSText, DSToggle
} from '@sm/skywise-react-library';
import * as React from 'react';
import * as Strings from '../../../../lang/strings.json';

/**
 * Class description: This component contains worflow parameters that can be modified
 * @author Capgemini
 * @version 1.0
 */

const AutomaticWorkflowView = (props: any) => {
  return(
    <DSCard
      content={
        props.showModelLoading
          ?
          <DSLoader
            id={'modelLoader'}
            label="Model loading..."
          />
          :
          <div>
            {
              props.workflowSuccessBaner &&
              <DSBanner
                type={'success'}
                title={'Your configuration has been updated'}
                id={'workflowSuccessBaner'}
                withCloseButton={true}
                center={true}
                handleClose={() => props.closeBannerHandler('workflowSuccessBaner')}
              />
            }
            {
              props.showWarningWFConfBanerHandler &&
              <DSBanner
                type={'warning'}
                title={props.minMaxWarningforWFConf ? 'Value not in range'
                  : 'Only integer numbers are allowed'}
                id={'workflowWarningBaner'}
                withCloseButton={true}
                center={true}
                handleClose={() => props.closeBannerHandler('workflowWarningBaner')}
              />
            }
            <div className="ds-card--title"> {Strings.AutomaticWorkflow}
              <DSToggle
                text="Activate"
                size="medium"
                checked={props.automaticWorkflowIsEnabled}
                id={'toggle-workflow-auto-activated'}
                handleChange={props.toggleAutomaticWorkflowHandler}
              />
            </div>
            <DSTable>
              <DSTableBody>
                <DSTableRow>
                  <CellWorflowParam
                    label="Number of flights before Review to Ignored "
                    name="flightsBeforeReviewToIgnored"
                    automaticWorkflowDef={props.automaticWorkflowDefinition.flightsBeforeReviewToIgnored}
                    automaticWorkflowConf={props.automaticWorkflowConfigurationByUser.flightsBeforeReviewToIgnored}
                    handleChangeNumberOfFlights={props.handleChangeNumberOfFlights}
                    workFlowParamName={props.workFlowParamName}
                    minMaxWarningforWFConf={props.minMaxWarningforWFConf}
                  />
                  <CellWorflowParam
                    label="Number of flights before Opened to Ignored "
                    name="flightsBeforeOpenedToIgnored"
                    automaticWorkflowDef={props.automaticWorkflowDefinition.flightsBeforeOpenedToIgnored}
                    automaticWorkflowConf={props.automaticWorkflowConfigurationByUser.flightsBeforeOpenedToIgnored}
                    handleChangeNumberOfFlights={props.handleChangeNumberOfFlights}
                    workFlowParamName={props.workFlowParamName}
                    minMaxWarningforWFConf={props.minMaxWarningforWFConf}
                  />
                  <CellWorflowParam
                    label="Number of flights before Monitor to Closed "
                    name="flightsBeforeMonitorToClosed"
                    automaticWorkflowDef={props.automaticWorkflowDefinition.flightsBeforeMonitorToClosed}
                    automaticWorkflowConf={props.automaticWorkflowConfigurationByUser.flightsBeforeMonitorToClosed}
                    handleChangeNumberOfFlights={props.handleChangeNumberOfFlights}
                    workFlowParamName={props.workFlowParamName}
                    minMaxWarningforWFConf={props.minMaxWarningforWFConf}
                  />
                </DSTableRow>
                <DSTableRow>
                  <td colSpan={4}>
                    <div className="ds-row ds-justify-content-end">
                      <div className="ds-col-6">
                        {props.newWorkflowIsLoading && <DSDotsLoader />}
                      </div>
                      <DSButton
                        type="primary"
                        content={'Apply'}
                        disabled={props.isDisabled}
                        handleClick={props.putWorflowValues}
                      />
                    </div>
                  </td>
                </DSTableRow>
              </DSTableBody>
            </DSTable>
          </div>
      }
    />
  );
};

const CellWorflowParam = (props: any) => (
  <DSTableCell>
    <div className="ds-label">
      {props.label}
      {` (Default: ${props.automaticWorkflowDef.defaultValue})`}
    </div>
    <DSText
      label=""
      id={props.automaticWorkflowDef.min + ';' + props.automaticWorkflowDef.max}
      name={props.name}
      value={props.automaticWorkflowConf.value ? props.automaticWorkflowConf.value : ''}
      placeholder={(props.automaticWorkflowDef.min ? ('Min: ' + parseInt(props.automaticWorkflowDef.min, 10)) : '') +
        (props.automaticWorkflowDef.max ? (' / Max: ' + parseInt(props.automaticWorkflowDef.max, 10)) : '')}
      isDisabled={props.minMaxWarningforWFConf ?
        ((props.workFlowParamName === props.name) ? false : true)
        : false}
      handleChange={props.handleChangeNumberOfFlights}
    />
  </DSTableCell>
);

export default AutomaticWorkflowView;
