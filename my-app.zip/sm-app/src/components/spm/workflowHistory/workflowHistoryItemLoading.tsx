/**
 * Class description: React predictive event details page component
 * @author Capgemini
 * @version 1.0
 */
import { DSLoader, DSStepIcon } from '@sm/skywise-react-library';
import * as React from 'react';
import { WorkOrderStatus } from '../../../model/EventsConstantes';
import {
  getIconFromWorkStatusEnum,
  getShortClassFromWorkStatusEnum
} from '../../../utils/FleetsweepUtils';

export const WorkflowHistoryItemLoading = (props: any) => {
  const iconContainerClass = getShortClassFromWorkStatusEnum(props.status.status);
  const iconClass = getIconFromWorkStatusEnum(props.status.status);

  return (
    <div className="ds-row notif-element">
      <div className="ds-col-10 text-center">
        <DSStepIcon icon={iconClass} classNames={iconContainerClass} />
      </div>
      <div className="ds-col-38">
        <h4>{WorkOrderStatus[props.status]}</h4>
        <DSLoader
          id={'newStatusHistoryItemLoader'}
          label={'Updating status...'}
          size={'small'}
        />
      </div>
    </div>
  );
};
