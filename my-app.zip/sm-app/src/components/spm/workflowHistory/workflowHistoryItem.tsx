/**
 * Class description: React predictive event details page component
 * @author Capgemini
 * @version 1.0
 */
import { DSStepIcon } from '@sm/skywise-react-library';
import * as moment from 'moment';
import * as React from 'react';
import { WorkOrderStatus } from '../../../model/EventsConstantes';
import {
  getIconFromWorkStatusEnum,
  getShortClassFromWorkStatusEnum
} from '../../../utils/FleetsweepUtils';

function isDisplayed(property: string) {
  return property !== null && property !== undefined && property !== ''
    ? 'block'
    : 'none';
}

export function formatComment(comment: string) {
  if (comment !== null && comment !== undefined && comment !== '') {
    const formattedComment = comment.split('\n').map((element, index) => {
      return (
        <span key={index}>
          {element}
          <br />
        </span>
      );
    });
    return formattedComment;
  }
  return null;
}

export const WorkflowHistoryItem = (props: any) => {
  const iconContainerClass = getShortClassFromWorkStatusEnum(
    props.status.status
  );
  const iconClass = getIconFromWorkStatusEnum(props.status.status);
  const dateTimeUTC = moment.utc(props.status.dateTime);
  const workDatetimeUtc = moment.utc(props.status.workDatetime);

  return (
    <div className="ds-row notif-element">
      <div className="ds-col-10 text-center">
        <DSStepIcon icon={iconClass} classNames={iconContainerClass} />
      </div>
      <div className="ds-col-38">
        <h4 className="h5-like">{WorkOrderStatus[props.status.status]}</h4>
        <p className="author-date">
          {props.status.author} on {dateTimeUTC.format('DD MMM YYYY')}
        </p>
        <p style={{ display: isDisplayed(props.status.fltBefore) }}>
          Flight before: {props.status.fltBefore}
        </p>
        <p style={{ display: isDisplayed(props.status.airport) }}>
          Airport: {props.status.airport}
        </p>
        <p style={{ display: isDisplayed(props.status.workReference) }}>
          Work reference: {props.status.workReference}
        </p>
        <p style={{ display: isDisplayed(props.status.workDatetime) }}>
          Work date: {workDatetimeUtc.format('DD MMM YYYY')}
        </p>
        <p style={{ display: isDisplayed(props.status.comment) }}>
          Comments:&nbsp;
          {formatComment(props.status.comment)}
        </p>
      </div>
    </div>
  );
};
