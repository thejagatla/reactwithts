/**
 * Class description: React predictive event details page component
 * @author Capgemini
 * @version 1.0
 */
import { DSStepIcon } from '@sm/skywise-react-library';
import * as moment from 'moment';
import * as React from 'react';

export function formatComment(comment: string) {
  if (comment !== null && comment !== undefined && comment !== '') {
    const formattedComment = comment.split('\n').map((element, index) => {
      return (<span key={index}>{element}<br /></span>);
    });
    return formattedComment;
  }
  return null;
}

export const CommentHistoryItem = (props: any) => {

  const momentUTC = moment.utc(props.comment.dateTime);  

  return (
    <div className="ds-row notif-element notif-element--comment">
      <div className="ds-col-10 text-center">
        <DSStepIcon icon={'bubble'} />
      </div>
      <div className="ds-col-38">
        <p className="author-date">
          {props.comment.author} on {momentUTC.format('DD MMM YYYY')}
        </p>
        <p>
          {formatComment(props.comment.text)}
        </p>
      </div>
    </div>
  );
};
