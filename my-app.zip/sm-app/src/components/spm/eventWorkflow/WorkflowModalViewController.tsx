/**
 * Class description: Workflow modal controller
 * @author Capgemini
 * @version 1.0
 */
import * as moment from 'moment';
import * as React from 'react';
import { formatDate } from 'react-day-picker/moment';
import { SpmEventController } from '../../../controllers/SpmEventController';
import {
  WorkflowAction, WorkflowPageOrigin, WorkOrderStatusEnum
} from '../../../model/EventsConstantes';
import { SpmEventItem } from '../../../model/spm/SpmEventItem';
import { SpmStatusInfoItem } from '../../../model/spm/SpmStatusInfoItem';
import {
  SpmActionsFrom, SpmActionsToStatus, SpmStatusDone
} from '../../../model/Workflow';
import { getIdToken, getUsername } from '../../../utils/AuthenticationUtils';
import { startTimeout } from '../../../utils/EventsUtils';
import { closeModal, openErrorModal } from '../../../utils/ModalsUtils';
import { WorkflowModalView } from './WorkflowModalView';

export class WorkflowModalViewController extends React.Component<any, any> {

  /**
   * Controller
   * @param props React props
   */
  constructor(props: any) {
    super(props);

    if (this.props.pageOrigin === WorkflowPageOrigin.SHM) {
      this.state = {
        airport: '',
        airportsList: [],
        comment: '',
        event: this.adaptShmEventFormat(this.props.event),
        flightBefore: '',
        flightsBeforeList: [],
        isCustomAirport: false,
        isCustomFlight: false,
        loadingFlights: false,
        noCommentChecked: false,
        noFlightsAvailable: false,
        registerEventItemSelected: null,
        registerEventItemsList: [],
        setWorkStatusError: false,
        setWorkStatusErrorMessage: '',
        submitDisabled: true,
        workOrderOldStatus: this.props.event.workOrderStatus,
        workOrderPlannedDate: (
          this.props.event.workOrderPlannedDate &&
          this.props.action === WorkflowAction[WorkflowAction.SPM_REGISTER_ACTION]
        ) ? this.props.event.workOrderPlannedDate : null,
        workOrderReference: (
          this.props.event.workOrderReference &&
          this.props.action === WorkflowAction[WorkflowAction.SPM_REGISTER_ACTION]
        ) ? this.props.event.workOrderReference : '',
        workOrderStatus: this.props.event.workOrderStatus,
      };
    } else {
      this.state = {
        airport: '',
        airportsList: [],
        comment: '',
        event: this.props.event,
        flightBefore: '',
        flightsBeforeList: [],
        isCustomAirport: false,
        isCustomFlight: false,
        loadingFlights: false,
        noCommentChecked: false,
        noFlightsAvailable: false,
        registerEventItemSelected: null,
        registerEventItemsList: [],
        setWorkStatusError: false,
        setWorkStatusErrorMessage: '',
        submitDisabled: true,
        workOrderOldStatus: String(this.props.event.statusInfoItem.status).toUpperCase(),
        workOrderPlannedDate: (
          this.props.event.statusInfoItem.workDatetime &&
          this.props.action === WorkflowAction[WorkflowAction.SPM_REGISTER_ACTION]
        ) ? this.props.event.statusInfoItem.workDatetime : null,
        workOrderReference: (
          this.props.event.statusInfoItem.workReference &&
          this.props.action === WorkflowAction[WorkflowAction.SPM_REGISTER_ACTION]
        ) ? this.props.event.statusInfoItem.workReference : '',
        workOrderStatus: String(this.props.event.statusInfoItem.status).toUpperCase(),
      };
    }

    this.saveLocalEvent = this.saveLocalEvent.bind(this);
    this.handleCommentChange = this.handleCommentChange.bind(this);
    this.handleWorkReferenceChange = this.handleWorkReferenceChange.bind(this);
    this.handleNoCommentCheck = this.handleNoCommentCheck.bind(this);
    this.handleDayChange = this.handleDayChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleBannerClose = this.handleBannerClose.bind(this);
    this.handleAirportChange = this.handleAirportChange.bind(this);
    this.handleCustomAirportChange = this.handleCustomAirportChange.bind(this);
    this.handleCustomFlightChange = this.handleCustomFlightChange.bind(this);
    this.handleFlightBeforeChange = this.handleFlightBeforeChange.bind(this);
    this.isStatusDone = this.isStatusDone.bind(this);
    this.isStatusCurrent = this.isStatusCurrent.bind(this);
    this.isStatusReachable = this.isStatusReachable.bind(this);
    this.isNextStatusNotAdjacent = this.isNextStatusNotAdjacent.bind(this);
    this.isPrevStatusNotAdjacent = this.isPrevStatusNotAdjacent.bind(this);
    this.isStatusAchieved = this.isStatusAchieved.bind(this);
    this.restoreStatus = this.restoreStatus.bind(this);
    this.closeModal = this.closeModal.bind(this);
  }

  private adaptShmEventFormat(event: any) {
    const spmFormattedEvent = {
      acNickName: event.acNickName,
      ataChapter: event.ata6,
      eventClosureTimestamp: null,
      eventCreationTimestamp: event.eventDate,
      eventId: event.spmEventId,
      eventType: event.type,
      family: null,
      flightCount: 0,
      occurenceCount: 0,
      ohFlights: event.flightOccurrence,
      ohOccurrences: event.occurenceHistory,
      ohOpenDate: '',
      ohPlannedDate: '',
      ohToBeMonitoredDate: '',
      riskName: event.titleFromAircraft,
      riskPriority: event.priority,
      statusInfoItem: event.statusInfoItem,
      tailNumber: event.acMatricule,
      xmsn: '',
    };
    return spmFormattedEvent;
  }

  public componentDidMount() {
    if (this.state.workOrderPlannedDate !== null) {
      this.handleDayChange(new Date(this.state.workOrderPlannedDate));
    }
  }

  private closeModal() {
    // Launch periodic refresh
    if (this.props.pageOrigin === 'SHM') {
      startTimeout();
    }
    closeModal();
  }

  /**
   * Handle change on comment field
   * @param pEvent the event throwed
   */
  private handleCommentChange(pEvent: any) {
    this.setState({ comment: pEvent.target.value, }, () => {
      this.defineApplyState();
    });
  }

  /**
   * Handle change on work reference field
   * @param pEvent the event throwed
   */
  private handleWorkReferenceChange(pEvent: any) {
    this.setState({ workOrderReference: pEvent.target.value, });
  }

  /**
   * Handle check of "no comment" checkbox
   * @param pEvent Checkbox event
   */
  public handleNoCommentCheck(pEvent: any): void {
    this.setState({ noCommentChecked: pEvent.currentTarget.checked }, () => {
      this.defineApplyState();
    });
  }

  /**
   * Handle value change of day picker
   * @param selectedDay The selected day by user
   */
  public handleDayChange(selectedDay: any): void {
    if (selectedDay) {
      selectedDay.setHours(13, 0, 0, 0);
      const newDate = selectedDay.toUTCString();

      if (this.props.action === WorkflowAction[WorkflowAction.SPM_REGISTER_ACTION]) {
        this.setState(
          {
            airport: '',
            airportsList: [],
            flightBefore: '',
            flightsBeforeList: [],
            isCustomAirport: false,
            isCustomFlight: false,
            loadingFlights: true,
            noFlightsAvailable: false,
            registerEventItemsList: [],
            submitDisabled: true,
          },
          () => {
            Promise.resolve(
              SpmEventController.getEventItemByEventIdAndDateBefore(this.state.event.eventId, newDate, getIdToken())
                .then((response: SpmEventItem[]) => {
                  this.setAirportsList(response);
                  this.setState({
                    loadingFlights: false,
                    noFlightsAvailable: false,
                    registerEventItemsList: response
                  });
                })
                .catch((error) => {
                  this.setAirportsList([] as SpmEventItem[]);
                  this.setState({
                    loadingFlights: false,
                    noFlightsAvailable: true,
                    registerEventItemsList: [],
                  });
                })
            );
          });
      }

      this.setState({ workOrderPlannedDate: newDate }, () => {
        this.defineApplyState();
      });
    } else {
      this.setState(
        {
          airport: '',
          airportsList: [],
          flightBefore: '',
          flightsBeforeList: [],
          isCustomAirport: false,
          isCustomFlight: false,
          noFlightsAvailable: false,
          registerEventItemSelected: null,
          registerEventItemsList: [],
          workOrderPlannedDate: null,
        },
        () => {
          this.defineApplyState();
        }
      );
    }
  }

  /**
   * Handle event when user close the error banner
   */
  private handleBannerClose() {
    this.setState({
      setWorkStatusError: false,
      setWorkStatusErrorMessage: '',
    });
  }

  /**
   * Change status from ignore to review or review to ignore
   */
  private restoreStatus() {
    if (this.state.submitDisabled === true) {
      this.setState({
        submitDisabled: false,
        workOrderStatus: WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]
      });
    } else {
      this.setState({
        submitDisabled: true,
        workOrderStatus: WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED]
      });
    }
  }

  /**
   * Handle event when user select an airport
   * @param pEvent Event handled
   */
  private handleAirportChange(pEvent: any) {
    const isCustomAirport = pEvent.currentTarget.value === 'Other airport';
    this.setState(
      {
        airport: pEvent.currentTarget.value,
        flightBefore: '',
        isCustomAirport,
        // Force user to select a flight if airport has changed
        isCustomFlight: false,
        registerEventItemSelected: null,
      },
      () => {
        this.defineApplyState();
      }
    );

    this.setFlightsBeforeList(pEvent.currentTarget.value);
  }

  /**
   * Handle event when user enter an airpot name
   * @param pEvent Event handled
   */
  private handleCustomAirportChange(pEvent: any) {
    this.setState(
      {
        airport: pEvent.currentTarget.value,
      },
      () => {
        this.defineApplyState();
      }
    );
  }

  /**
   * Handle event when user enter an flight name
   * @param pEvent Event handled
   */
  private handleCustomFlightChange(pEvent: any) {
    this.setState(
      {
        flightBefore: pEvent.currentTarget.value,
      },
      () => {
        this.defineApplyState();
      }
    );
  }
  /**
   * Handle event when user select a flight before
   * @param pEvent Event handled
   */
  private handleFlightBeforeChange(pEvent: any) {
    const flightBefore = pEvent.currentTarget.value;
    const isCustomFlight = flightBefore === 'Other flight';
    let registerEventItemSelected: SpmEventItem = null;
    for (const eventItem of this.state.registerEventItemsList) {
      if (eventItem.to === this.state.airport && eventItem.flightNb === flightBefore) {
        registerEventItemSelected = eventItem;
        break;
      }
    }
    // Define a dummy event item to save the work date
    if (isCustomFlight) {
      registerEventItemSelected = {} as SpmEventItem;
      const workOrderPlannedDate = moment(this.state.workOrderPlannedDate);
      registerEventItemSelected.toDate = workOrderPlannedDate.format();
    }
    this.setState(
      {
        flightBefore,
        isCustomFlight,
        registerEventItemSelected,
      },
      () => {
        this.defineApplyState();
      }
    );
  }

  /**
   * Constructs the list of airports from event items received from server
   * @param eventItems Raw event items received from server
   */
  public setAirportsList(eventItems: SpmEventItem[]) {
    let tmpAirportsList = eventItems.map((element: SpmEventItem, index: number) => {
      return element.to;
    });

    tmpAirportsList = tmpAirportsList.filter((element) => {
      return element !== null;
    });

    const cleanedAirportsList = Array.from(new Set(tmpAirportsList));
    cleanedAirportsList.splice(12);

    // Add custom airport to the end of list for the user to edit a custom airport
    cleanedAirportsList.push('Other airport');

    this.setState({
      airportsList: cleanedAirportsList
    });
  }

  /**
   * Constructs the list of flights before from event items received from server, according to airport selected
   * @param airport Airport selected by user
   */
  private setFlightsBeforeList(airport: string) {
    const tmpFlightsList: string[] = [];
    for (const element of this.state.registerEventItemsList) {
      if (element.to === airport) {
        tmpFlightsList.push(element.flightNb);
      }
    }
    
    const cleanedFlightsList = Array.from(new Set(tmpFlightsList));
    cleanedFlightsList.splice(12);

    // Add custom flight to the end of list for the user to edit a custom flight
    cleanedFlightsList.push('Other flight');

    this.setState({
      flightsBeforeList: cleanedFlightsList
    });
  }

  /**
   * Save the event as a temporary event display
   * @param newStatusInfoItem New Status object
   */
  private saveLocalEvent(newStatusInfoItem: any) {
    const localEvent = JSON.parse(JSON.stringify(this.props.event));
    localEvent.statusInfoItem.author = newStatusInfoItem.author;
    localEvent.statusInfoItem.comment = newStatusInfoItem.comment;
    localEvent.statusInfoItem.dateTime = newStatusInfoItem.dateTime;
    localEvent.statusInfoItem.status = newStatusInfoItem.status;
    localEvent.workOrderComment = newStatusInfoItem.comment;
    localEvent.workOrderCommentAuthor = newStatusInfoItem.author;
    localEvent.workOrderStatus = newStatusInfoItem.status;

    switch (this.props.action) {
      case WorkflowAction[WorkflowAction.SPM_PLAN_ACTION]:
        localEvent.statusInfoItem.workDatetime = newStatusInfoItem.workDatetime;
        localEvent.statusInfoItem.workReference = newStatusInfoItem.workReference;
        break;
      case WorkflowAction[WorkflowAction.SPM_REGISTER_ACTION]:
        localEvent.statusInfoItem.airport = newStatusInfoItem.airport;
        localEvent.statusInfoItem.fltBefore = newStatusInfoItem.fltBefore;
        localEvent.statusInfoItem.workDatetime = newStatusInfoItem.workDatetime;
        localEvent.statusInfoItem.workReference = newStatusInfoItem.workReference;
        break;        
      default:
        break;
    }
    
    this.props.addLocalEvent(localEvent);
  }

  /**
   * Performs actions when user submit workflow apply
   * @param event Event handled
   */
  public handleSubmit(event: any) {
    event.preventDefault();

    const now = new Date(Date.now()).toUTCString();
    const username = getUsername();
    const newStatusInfoItem: SpmStatusInfoItem = Object.assign({}, this.state.event.statusInfoItem);
    newStatusInfoItem.author = username;
    newStatusInfoItem.comment = this.state.comment;
    newStatusInfoItem.dateTime = new Date(now).toISOString();
    newStatusInfoItem.status = this.state.workOrderStatus;

    switch (this.props.action) {
      case WorkflowAction[WorkflowAction.SPM_PLAN_ACTION]:
        newStatusInfoItem.airport = '';
        newStatusInfoItem.fltBefore = '';
        newStatusInfoItem.workDatetime = new Date(this.state.workOrderPlannedDate).toISOString();
        newStatusInfoItem.workReference = this.state.workOrderReference;
        break;
      case WorkflowAction[WorkflowAction.SPM_REGISTER_ACTION]:
        const workOrderRegisterDate = new Date(this.state.registerEventItemSelected.toDate);
        workOrderRegisterDate.setUTCSeconds(workOrderRegisterDate.getUTCSeconds() + 1);
        newStatusInfoItem.airport = this.state.airport;
        newStatusInfoItem.fltBefore = this.state.flightBefore;
        newStatusInfoItem.workDatetime = workOrderRegisterDate.toISOString();
        newStatusInfoItem.workReference = this.state.workOrderReference;
        break;
      default:
        newStatusInfoItem.airport = '';
        newStatusInfoItem.fltBefore = '';
        newStatusInfoItem.workDatetime = '';
        newStatusInfoItem.workReference = '';
    }

    if (this.props.pageOrigin === 'SHM') {
      this.saveLocalEvent(newStatusInfoItem);
    }

    this.setState({ submitDisabled: true }, () => {
      this.closeModal();
      
      Promise.resolve(SpmEventController.setWorkOrderStatus(this.state.event.eventId, newStatusInfoItem, getIdToken())
        .then((put: Response) => {
          if (this.props.pageOrigin === WorkflowPageOrigin.SPM) {
            this.props.addWorkflowHistoryItem({
              status: this.state.workOrderStatus,
              tmp: true,
            });
          }
        })
        .catch((error: Response) => {
          this.handlePutError(error);
          switch (error.status) {
            case 400:
            case 401:
            case 403:
            case 404:
            case 409:
            case 412:
              // Decode response
              error.json().then((res) => {
                openErrorModal(
                  res.exception.smTraceId,
                  res.exception.message,
                  res.exception.support.techRequestUrl,
                  res.exception.support.contactEnglish,
                  res.exception.support.contactChinese);
              });
              break;
            case 500:
            case 501:
            default:
          }
        })
      );
    });
  }

  /**
   * Handle PUT error
   * @param response PUT HTTP response
   */
  private handlePutError(response: Response) {
    this.setState({
      setWorkStatusError: true,
      setWorkStatusErrorMessage: response.statusText,
      submitDisabled: false,
    });
  }

  /**
   * Defines if the scheme status have to be colored as Done status
   * @param status Current scheme status evaluated
   */
  public isStatusDone(status: string): boolean {
    const tmpWorkStatus = WorkOrderStatusEnum[WorkOrderStatusEnum[this.state.workOrderStatus]];
    const tmpStatus = SpmStatusDone[tmpWorkStatus];
    return tmpStatus.indexOf(status) !== -1;
  }

  /**
   * Defines if the scheme status have to be colored as Current status
   * @param status Current scheme status evaluated
   */
  public isStatusCurrent(status: string): boolean {
    return this.state.workOrderStatus === status;
  }

  /**
   * Defines if the scheme status is an achieved status
   * @param status Current scheme status evaluated
   */
  public isStatusAchieved(status: string): boolean {
    return (this.state.workOrderStatus === status) && (this.state.workOrderStatus !== this.state.workOrderOldStatus);
  }

  /**
   * Defines if the scheme status have to be colored as Reachable status
   * according to current WorkStatus and WorkAction
   * @param status Current scheme status evaluated
   */
  public isStatusReachable(status: string): boolean {
    if (status === WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED] &&
      this.props.action === WorkflowAction[WorkflowAction.SPM_IGNORE] &&
      this.state.workOrderStatus === this.state.workOrderOldStatus) {
      return true;
    }
    if (SpmActionsFrom[status][this.state.workOrderStatus] === this.props.action) {
      return true;
    }
    return false;
  }

  /**
   * Defines if the status which is reachable is not adjacent to current WorkStatus
   * @param status Current scheme status evaluated
   */
  public isNextStatusNotAdjacent(status: string): boolean {
    if (this.props.action === WorkflowAction[WorkflowAction.SPM_IGNORE]) {
      return true;
    }
    switch (status) {
      case WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]:
        return this.props.action === WorkflowAction[WorkflowAction.SPM_PLAN_ACTION];
      case WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_MONITORED]:
        return this.props.action === WorkflowAction[WorkflowAction.SPM_REJECT];
      default:
        return false;
    }
  }

  /**
   * Defines if the status which is reachable is not adjacent to current status
   * @param status Current scheme status evaluated
   */
  public isPrevStatusNotAdjacent(status: string): boolean {
    if (this.props.action === WorkflowAction[WorkflowAction.SPM_IGNORE]) {
      return true;
    }
    if (status === WorkOrderStatusEnum[WorkOrderStatusEnum.PLANNED] &&
      this.state.workOrderStatus === WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED] &&
      this.props.action === WorkflowAction[WorkflowAction.SPM_PLAN_ACTION]) {
      return true;
    }
    return false;
  }

  /**
   * Defines if the Apply button have to be enabled or disabled according to current action
   */
  public defineApplyState() {
    switch (this.props.action) {
      case WorkflowAction[WorkflowAction.SPM_WATCH]:
      case WorkflowAction[WorkflowAction.SPM_VALIDATE]:
      case WorkflowAction[WorkflowAction.SPM_REJECT]:
      case WorkflowAction[WorkflowAction.SPM_IGNORE]:
        if (this.state.comment.length > 0 || this.state.noCommentChecked) {
          this.setState({
            submitDisabled: false,
            workOrderStatus: SpmActionsToStatus[this.props.action],
          });
        } else {
          this.setState({
            submitDisabled: true,
            workOrderStatus: this.state.workOrderOldStatus,
          });
        }
        break;
      case WorkflowAction[WorkflowAction.SPM_PLAN_ACTION]:
        if (this.state.workOrderPlannedDate !== null) {
          this.setState({
            submitDisabled: false,
            workOrderStatus: SpmActionsToStatus[this.props.action],
          });
        } else {
          this.setState({
            submitDisabled: true,
            workOrderStatus: this.state.workOrderOldStatus,
          });
        }
        break;
      case WorkflowAction[WorkflowAction.SPM_REGISTER_ACTION]:
        if (this.state.flightBefore !== '') {
          this.setState({
            submitDisabled: false,
            workOrderStatus: SpmActionsToStatus[this.props.action],
          });
        } else {
          this.setState({
            submitDisabled: true,
            workOrderStatus: this.state.workOrderOldStatus,
          });
        }
        break;
      /* istanbul ignore next */
      default:
        if (this.state.comment.length > 0 || this.state.noCommentChecked) {
          this.setState({
            submitDisabled: false
          });
        } else {
          this.setState({
            submitDisabled: true
          });
        }
        break;
    }
  }

  /**
   * Date formatting to UI Display
   * @param date Date to format
   */
  public formatDateUi(date: Date = new Date()) {
    return formatDate(date, 'DD MMM YYYY');
  }

  public stripTags(str: string) {
    const goodStr = str.toString();
    return goodStr.replace(/<\/?[^>]+>/gi, '');
  }

  /**
   * Rendering method
   */
  public render() {
    const dateProps: any = {};
    if (this.state.workOrderPlannedDate) {
      dateProps.value = this.formatDateUi(this.state.workOrderPlannedDate);
    } else {
      dateProps.value = '';
    }

    return (
      <WorkflowModalView
        title={this.props.title}
        closeModal={this.closeModal}
        displayName={this.props.displayName}
        restoreStatus={this.restoreStatus}
        event={this.state.event}
        action={this.props.action}
        airport={this.state.airport}
        airportsList={this.state.airportsList}
        flightBefore={this.state.flightBefore}
        flightsBeforeList={this.state.flightsBeforeList}
        isCustomAirport={this.state.isCustomAirport}
        isCustomFlight={this.state.isCustomFlight}
        comment={this.state.comment}
        dateProps={dateProps}
        submitDisabled={this.state.submitDisabled}
        noCommentChecked={this.state.noCommentChecked}
        noFlightsAvailable={this.state.noFlightsAvailable}
        isStatusDone={this.isStatusDone}
        isStatusCurrent={this.isStatusCurrent}
        isStatusReachable={this.isStatusReachable}
        isNextStatusNotAdjacent={this.isNextStatusNotAdjacent}
        isPrevStatusNotAdjacent={this.isPrevStatusNotAdjacent}
        isStatusAchieved={this.isStatusAchieved}
        setWorkStatusError={this.state.setWorkStatusError}
        setWorkStatusErrorMessage={this.state.setWorkStatusErrorMessage}
        workOrderPlannedDate={this.state.workOrderPlannedDate}
        workOrderReference={this.state.workOrderReference}
        handleNoCommentCheck={this.handleNoCommentCheck}
        handleDayChange={this.handleDayChange}
        handleCommentChange={this.handleCommentChange}
        handleSubmit={this.handleSubmit}
        handleWorkReferenceChange={this.handleWorkReferenceChange}
        handleBannerClose={this.handleBannerClose}
        handleAirportChange={this.handleAirportChange}
        handleCustomAirportChange={this.handleCustomAirportChange}
        handleCustomFlightChange={this.handleCustomFlightChange}
        handleFlightBeforeChange={this.handleFlightBeforeChange}
        loadingFlights={this.state.loadingFlights}
        stripTags={this.stripTags}
      />
    );
  }
}
