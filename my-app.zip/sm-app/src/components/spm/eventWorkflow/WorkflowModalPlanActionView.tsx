/**
 * Class description: Workflow rendering component for Plan action
 * @author Capgemini
 * @version 1.0
 */
import { DSBanner, DSDatepicker } from '@sm/skywise-react-library';
import * as React from 'react';
import * as Strings from '../../../lang/strings.json';
import { SpmWorkStatusMaxComment } from '../../../model/EventsConstantes';
import { DSText } from '../../storybook/text/DSText';
import { Textarea } from '../../storybook/text/Textarea';

export const WorkflowModalPlanActionView = (props) => {
  return (
    <div>
      <DSText
        label={Strings.workflowModalWorkReferenceLabel}
        name={'WorkReference'}
        handleChange={props.handleWorkReferenceChange}
        value={props.workOrderReference}
        size={41}
      />
      <div className="ds-form-group">
        <label>Date</label>
        <div>
          <DSDatepicker
            handleDayChange={props.handleDayChange}
            dateProps={props.dateProps}
          />
          <div className="dotted-line" />
        </div>
      </div>
      <Textarea
        label={Strings.workflowModalCommentCount.replace('%s', String(SpmWorkStatusMaxComment - props.comment.length))}
        name={'workOrderComment'}
        handleChange={props.handleCommentChange}
        isDisabled={props.noCommentChecked}
        maxLength={SpmWorkStatusMaxComment}
        cols={40}
        value={props.workOrderComment}
      />
      {props.setWorkStatusError ?
        <DSBanner
          title={Strings.workflowModalApplyErrorMessage.replace('%s', props.setWorkStatusErrorMessage)}
          type={'error'}
          handleClose={props.handleBannerClose}
        />
        : null
      }
    </div>
  );
};
