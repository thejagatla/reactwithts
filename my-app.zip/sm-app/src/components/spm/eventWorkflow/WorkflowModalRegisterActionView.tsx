/**
 * Class description: Workflow rendering component for Register action
 * @author Capgemini
 * @version 1.0
 */
import { DSBanner, DSDatepicker, DSLoader } from '@sm/skywise-react-library';
import * as React from 'react';
import * as Strings from '../../../lang/strings.json';
import { SpmWorkStatusMaxComment } from '../../../model/EventsConstantes';
import { DSRadio } from '../../storybook/controls/DSRadio';
import { DSText } from '../../storybook/text/DSText';
import { Textarea } from '../../storybook/text/Textarea';

const INLINE_CONTROL_CLASS = 'ds-form-group ds-control-inline';
const FAKE_LABEL_CLASS = 'ds-fake-label';
const HELPTEXT_CLASS = 'ds-form-helptext';

function setAirportRadioList(props: any) {
  // Display the available airports or at least the custom airport textbox
  if (props.airportsList.length > 0) {
    return (
      <div id="airport-radio-group" className={INLINE_CONTROL_CLASS}>
        <label className={FAKE_LABEL_CLASS}>Airport</label>
        {props.airportsList.map((element: string, index: number) =>
            <DSRadio
              key={index}
              value={element}
              id={element}
              // Key of custom airport radio can't be used to check the radio
              // Use specific props isCustomAirport instead
              isChecked={(element === 'Other airport' && props.isCustomAirport) || props.airport === element}
              handleChange={props.handleAirportChange}
              label={element}
              forInline={true}
              name="airportRadio"
            />
        )}
        {props.isCustomAirport && 
          <DSText
            handleChange={props.handleCustomAirportChange}
            label="Custom airport"
            name="airportDefinedByUser"
          />
        }
      </div>
    );
  } 
  if (props.workOrderPlannedDate === null) {
    return (
      <div id="airport-radio-group-no-date" className={INLINE_CONTROL_CLASS}>
        <label className={FAKE_LABEL_CLASS}>Airport</label>
        <div className={HELPTEXT_CLASS}>Please select a date</div>
      </div>
    );
  } 
  if (props.loadingFlights) {
    return (
      <div id="airport-radio-group-loading" className={INLINE_CONTROL_CLASS}>
        <DSLoader size={'small'} id={'flightsLoading'} />
      </div>
    );
  }

  return (
    <div className="ds-form-group">
      <div className={HELPTEXT_CLASS}>No flights available</div>
    </div>
  );
}

function setFlightsRadioList(props: any) {
  // Display available flights or at least the custom flight textbox
  if (!props.loadingFlights && props.airportsList.length > 0) {
    if (props.flightsBeforeList.length > 0) {
      return (
        <div id="flight-radio-group" className={INLINE_CONTROL_CLASS}>
          <label className={FAKE_LABEL_CLASS}>Flight before</label>
          {props.flightsBeforeList.map((element: string, index: number) => 
            <DSRadio
              key={index}
              value={element}
              id={element}
              // Key of custom airport radio can't be used to check the radio
              // Use specific props isCustomAirport instead
              isChecked={(element === 'Other flight' && props.isCustomFlight) || props.flightBefore === element}
              handleChange={props.handleFlightBeforeChange}
              label={element}
              forInline={true}
              name="flightRadio"
            />
          )}
          {props.isCustomFlight && 
            <DSText
              handleChange={props.handleCustomFlightChange}
              label="Custom flight"
              name="flightDefinedByUser"
            />
          }
        </div>
      );
    }
    if (props.airport === '' && props.workOrderPlannedDate !== null) {
      return (
        <div id="flight-radio-group-no-airport" className={INLINE_CONTROL_CLASS}>
          <label className={FAKE_LABEL_CLASS}>Flight before</label>
          <div className={HELPTEXT_CLASS}>Please select an airport</div>
        </div>
      );
    }
  }
  return null;
}

export const WorkflowModalRegisterActionView = (props) => {
  const airportsRadioSection = setAirportRadioList(props);
  const flightsRadioSection = setFlightsRadioList(props);

  return (
    <div
      style={{
        maxHeight: '400px',
        overflowY: 'auto'
      }}
    >
      <DSText
        label={Strings.workflowModalWorkReferenceLabel}
        name={'WorkReference'}
        handleChange={props.handleWorkReferenceChange}
        value={props.workOrderReference}
        size={41}
      />
      <div className="ds-form-group">
        <label>
          Date
                    </label>
        <div>
          <DSDatepicker
            handleDayChange={props.handleDayChange}
            dateProps={props.dateProps}
          />
          <div className="dotted-line" />
        </div>
      </div>
      {airportsRadioSection}
      {flightsRadioSection}
      <Textarea
        label={Strings.workflowModalCommentCount.replace('%s', String(SpmWorkStatusMaxComment - props.comment.length))}
        name={'workOrderComment'}
        handleChange={props.handleCommentChange}
        isDisabled={props.noCommentChecked}
        maxLength={SpmWorkStatusMaxComment}
        cols={40}
        rows={2}
        value={props.workOrderComment}
      />
      {props.setWorkStatusError ?
        <DSBanner
          title={Strings.workflowModalApplyErrorMessage.replace('%s', props.setWorkStatusErrorMessage)}
          type={'error'}
          handleClose={props.handleBannerClose}
        />
        : null
      }
    </div>
  );
};
