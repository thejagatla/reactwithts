/**
 * Class description: Workflow rendering component
 * @author Capgemini
 * @version 1.0
 */
import { DSButton, DSModal, DSStep, DSSteppers } from '@sm/skywise-react-library';
import * as classNames from 'classnames';
import * as React from 'react';
import * as Strings from '../../../lang/strings.json';
import { WorkflowAction, WorkOrderStatus, WorkOrderStatusEnum } from '../../../model/EventsConstantes';
import { WorkflowModalHeaderView } from './WorkflowModalHeaderView';
import { WorkflowModalIgnoreActionView } from './WorkflowModalIgnoreActionView';
import { WorkflowModalPlanActionView } from './WorkflowModalPlanActionView';
import { WorkflowModalRegisterActionView } from './WorkflowModalRegisterActionView';
import { WorkflowModalRejectActionView } from './WorkflowModalRejectActionView';
import { WorkflowModalRestoreActionView } from './WorkflowModalRestoreActionView';
import { WorkflowModalValidateActionView } from './WorkflowModalValidateActionView';
import { WorkflowModalWatchActionView } from './WorkflowModalWatchActionView';

function getClassName(props: any, status: WorkOrderStatusEnum) {
  return classNames({
    'ds-step--achieved': props.isStatusAchieved(
      WorkOrderStatusEnum[status]
    ),
    'ds-step--reachable': props.isStatusReachable(
      WorkOrderStatusEnum[status]
    ),
    'next-step--not-adj': props.isNextStatusNotAdjacent(
      WorkOrderStatusEnum[status]
    ),
    'prev-step--not-adj': props.isPrevStatusNotAdjacent(
      WorkOrderStatusEnum[status]
    )
  });
}

function modalActionView(props: any) {
  switch (props.action) {
    case WorkflowAction[WorkflowAction.SPM_WATCH]:
      return (
        <WorkflowModalWatchActionView
          handleSubmit={props.handleSubmit}
          closeModal={props.closeModal}
          handleCommentChange={props.handleCommentChange}
          submitDisabled={props.submitDisabled}
          comment={props.comment}
          handleNoCommentCheck={props.handleNoCommentCheck}
          noCommentChecked={props.noCommentChecked}
          setWorkStatusError={props.setWorkStatusError}
          setWorkStatusErrorMessage={props.setWorkStatusErrorMessage}
          handleBannerClose={props.handleBannerClose}
        />
      );
    case WorkflowAction[WorkflowAction.SPM_PLAN_ACTION]:
      return (
        <WorkflowModalPlanActionView
          dateProps={props.dateProps}
          handleSubmit={props.handleSubmit}
          closeModal={props.closeModal}
          handleCommentChange={props.handleCommentChange}
          handleWorkReferenceChange={props.handleWorkReferenceChange}
          submitDisabled={props.submitDisabled}
          comment={props.comment}
          handleDayChange={props.handleDayChange}
          workOrderReference={props.workOrderReference}
          setWorkStatusError={props.setWorkStatusError}
          setWorkStatusErrorMessage={props.setWorkStatusErrorMessage}
          handleBannerClose={props.handleBannerClose}
        />
      );
    case WorkflowAction[WorkflowAction.SPM_VALIDATE]:
      return (
        <WorkflowModalValidateActionView
          handleSubmit={props.handleSubmit}
          closeModal={props.closeModal}
          handleCommentChange={props.handleCommentChange}
          submitDisabled={props.submitDisabled}
          comment={props.comment}
          handleNoCommentCheck={props.handleNoCommentCheck}
          noCommentChecked={props.noCommentChecked}
          setWorkStatusError={props.setWorkStatusError}
          setWorkStatusErrorMessage={props.setWorkStatusErrorMessage}
          handleBannerClose={props.handleBannerClose}
        />
      );
    case WorkflowAction[WorkflowAction.SPM_IGNORE]:
      return (
        <WorkflowModalIgnoreActionView
          handleSubmit={props.handleSubmit}
          closeModal={props.closeModal}
          handleCommentChange={props.handleCommentChange}
          submitDisabled={props.submitDisabled}
          comment={props.comment}
          handleNoCommentCheck={props.handleNoCommentCheck}
          noCommentChecked={props.noCommentChecked}
          setWorkStatusError={props.setWorkStatusError}
          setWorkStatusErrorMessage={props.setWorkStatusErrorMessage}
          handleBannerClose={props.handleBannerClose}
        />
      );
    case WorkflowAction[WorkflowAction.SPM_REJECT]:
      return (
        <WorkflowModalRejectActionView
          handleSubmit={props.handleSubmit}
          closeModal={props.closeModal}
          handleCommentChange={props.handleCommentChange}
          submitDisabled={props.submitDisabled}
          comment={props.comment}
          handleNoCommentCheck={props.handleNoCommentCheck}
          noCommentChecked={props.noCommentChecked}
          setWorkStatusError={props.setWorkStatusError}
          setWorkStatusErrorMessage={props.setWorkStatusErrorMessage}
          handleBannerClose={props.handleBannerClose}
        />
      );
    case WorkflowAction[WorkflowAction.SPM_REGISTER_ACTION]:
      return (
        <WorkflowModalRegisterActionView
          handleSubmit={props.handleSubmit}
          closeModal={props.closeModal}
          handleCommentChange={props.handleCommentChange}
          handleWorkReferenceChange={props.handleWorkReferenceChange}
          submitDisabled={props.submitDisabled}
          comment={props.comment}
          handleDayChange={props.handleDayChange}
          workOrderReference={props.workOrderReference}
          setWorkStatusError={props.setWorkStatusError}
          setWorkStatusErrorMessage={props.setWorkStatusErrorMessage}
          handleBannerClose={props.handleBannerClose}
          handleAirportChange={props.handleAirportChange}
          handleCustomAirportChange={props.handleCustomAirportChange}
          handleCustomFlightChange={props.handleCustomFlightChange}
          handleFlightBeforeChange={props.handleFlightBeforeChange}
          airportsList={props.airportsList}
          airport={props.airport}
          dateProps={props.dateProps}
          flightBefore={props.flightBefore}
          flightsBeforeList={props.flightsBeforeList}
          noFlightsAvailable={props.noFlightsAvailable}
          workOrderPlannedDate={props.workOrderPlannedDate}
          loadingFlights={props.loadingFlights}
          isCustomAirport={props.isCustomAirport}
          isCustomFlight={props.isCustomFlight}
        />
      );
    case WorkflowAction[WorkflowAction.SPM_RESTORE]: 
      return (
      <WorkflowModalRestoreActionView
          isCheked={!props.submitDisabled}
          restoreStatus={props.restoreStatus}
      />
      );
    default:
      return null;
  }
}

export const WorkflowModalView = (props) => {
  return (
    <DSModal
      id={'spm-workflow-modal'}
      className={'workflow-modal'}
      modalTitle={props.title}
      withHeaderIntro={true}
      onRequestClose={props.closeModal}
      withForm={true}
      withFooterBackground={true}
      onSubmit={props.handleSubmit}
      modalHeaderIntro={
        <WorkflowModalHeaderView
          ataChapter={props.event.ataChapter}
          riskName={props.event.riskName}
          displayName={props.displayName}
          event={props.event}
          stripTags={props.stripTags}
        />
      }
      modalContent={
        <div className="ds-row">
          <div className="ds-col-20" id="workflow-steppers-container">
            <DSSteppers
              animated={true}
            >
              <DSStep
                id={'workflow-step-tbr'}
                className={getClassName(props, WorkOrderStatusEnum.TO_BE_REVIEWED)}
                icon={'location'}
                label={WorkOrderStatus.TO_BE_REVIEWED}
                current={props.isStatusCurrent(WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED])}
                done={props.isStatusDone(WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED])}
              />
              <DSStep
                id={'workflow-step-opened'}
                className={getClassName(props, WorkOrderStatusEnum.OPENED)}
                icon={'eye'}
                label={WorkOrderStatus.OPENED}
                current={props.isStatusCurrent(WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED])}
                done={props.isStatusDone(WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED])}
              />
              <DSStep
                id={'workflow-step-planned'}
                className={getClassName(props, WorkOrderStatusEnum.PLANNED)}
                icon={'date_range'}
                label={WorkOrderStatus.PLANNED}
                current={props.isStatusCurrent(WorkOrderStatusEnum[WorkOrderStatusEnum.PLANNED])}
                done={props.isStatusDone(WorkOrderStatusEnum[WorkOrderStatusEnum.PLANNED])}
              />
              <DSStep
                id={'workflow-step-tbm'}
                className={getClassName(props, WorkOrderStatusEnum.TO_BE_MONITORED)}
                icon={'build'}
                label={WorkOrderStatus.TO_BE_MONITORED}
                current={props.isStatusCurrent(WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_MONITORED])}
                done={props.isStatusDone(WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_MONITORED])}
              />
              <DSStep
                id={'workflow-step-closed'}
                className={getClassName(props, WorkOrderStatusEnum.CLOSED)}
                icon={'check_checkbox'}
                label={WorkOrderStatus.CLOSED}
                current={props.isStatusCurrent(WorkOrderStatusEnum[WorkOrderStatusEnum.CLOSED])}
                done={props.isStatusDone(WorkOrderStatusEnum[WorkOrderStatusEnum.CLOSED])}
              />
            </DSSteppers>
            <DSSteppers
              animated={true}
            >
              <DSStep
                id={'workflow-step-ignored'}
                className={
                  classNames({
                    'ds-step--reachable': props.isStatusReachable(
                      WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED]
                    )
                  })
                }
                icon={'close'}
                label={WorkOrderStatus.IGNORED}
                alone={true}
                current={props.isStatusCurrent(WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED])}
              />
            </DSSteppers>
          </div>
          <div className="ds-col-28" id="workflow-form-container" >
            {modalActionView(props)}
          </div>
        </div>
      }
      modalFooter={
        <div>
          <DSButton
            content={Strings.workflowModalCancelButton}
            handleClick={props.closeModal}
          />
          <DSButton
            content={Strings.workflowModalApplyButton}
            isSubmit={true}
            type="primary"
            disabled={props.submitDisabled}
            handleClick={() => null}
          />
        </div>
      }
    />
  );
};
