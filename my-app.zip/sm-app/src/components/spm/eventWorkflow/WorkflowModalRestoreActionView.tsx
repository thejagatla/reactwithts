/**
 * Class description: Workflow modal rendering component for Restore action
 * @author Capgemini
 * @version 1.0
 */
import { DSCheckbox } from '@sm/skywise-react-library';
import * as React from 'react';
import * as Strings from '../../../lang/strings.json';

export interface WorkflowModalRestoreActionViewProps {
  restoreStatus: (pEvent: {}) => void;
  isCheked: boolean;
}

export const WorkflowModalRestoreActionView: React.SFC<WorkflowModalRestoreActionViewProps> = (props) => {
  return(
    <div>
      <DSCheckbox
        label={Strings.restoreWorkflow}
        isChecked={props.isCheked}
        handleChange={props.restoreStatus}
        id="restore-checkbox"
        isIndeterminate={false}
      />
    </div>
  );
};
