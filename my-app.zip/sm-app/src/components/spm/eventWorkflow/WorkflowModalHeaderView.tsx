/**
 * Class description: Header component of the workflow modal
 * @author Capgemini
 * @version 1.0
 */
import * as React from 'react';
import { EventTitle } from '../../common/events/EventTitle';

export const WorkflowModalHeaderView = (props) => {
  const eventShortinfoAircraftClass = 'event-shortinfo__aircraft';
  return (
    <div className="ds-row">
      <div className="ds-col-8">
      {props.displayName &&
        props.displayName === 'acNickName' &&
        props.event.acNickName ? (
          <span id={eventShortinfoAircraftClass}>
            {props.stripTags(props.event.acNickName)} 
          </span>
        ) : props.event.xmsn && props.displayName === 'msn' && props.event.xmsn ? (
          <span id={eventShortinfoAircraftClass}>{props.stripTags(props.event.xmsn)}</span>
        ) : (
          <span id={eventShortinfoAircraftClass}>
            {props.stripTags(props.event.tailNumber)}
          </span>
        )}
      </div>
      <div className="ds-col-32">
        <span id="event-shortinfo__ata">ATA {props.stripTags(props.ataChapter)} </span>
        <br/>
        <EventTitle text={props.riskName} />
      </div>
    </div>
  );
};
