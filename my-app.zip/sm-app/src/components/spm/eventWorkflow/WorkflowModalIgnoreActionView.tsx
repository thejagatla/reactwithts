/**
 * Class description: Workflow modal rendering component for Ignore action
 * @author Capgemini
 * @version 1.0
 */
import { DSBanner, DSCheckbox, DSTextarea } from '@sm/skywise-react-library';
import * as React from 'react';
import * as Strings from '../../../lang/strings.json';
import { SpmWorkStatusMaxComment } from '../../../model/EventsConstantes';

export const WorkflowModalIgnoreActionView = (props) => {
  return (
    <div>
      <DSTextarea
        label={Strings.workflowModalCommentCount.replace('%s', String(SpmWorkStatusMaxComment - props.comment.length))}
        name={'workOrderComment'}
        handleChange={props.handleCommentChange}
        isDisabled={props.noCommentChecked}
        maxLength={SpmWorkStatusMaxComment}
        cols={40}
        value={props.workOrderComment}
      />
      <DSCheckbox
        label={Strings.workflowModalNoCommentLabel}
        isChecked={props.noCommentChecked}
        handleChange={props.handleNoCommentCheck}
        id="no-comment"
        isIndeterminate={false}
      />
      {props.setWorkStatusError ?
        <DSBanner
          title={Strings.workflowModalApplyErrorMessage.replace('%s', props.setWorkStatusErrorMessage)}
          type={'error'}
          handleClose={props.handleBannerClose}
        />
        : null
      }
    </div>
  );
};
