/**
 * Class description: React predictive event details page header view controller
 * @author Capgemini
 * @version 1.0
 */
import { DSBanner, DSLoader } from '@sm/skywise-react-library';
import * as moment from 'moment';
import * as React from 'react';
import { ModalManager } from 'react-dynamic-modal';
import * as Strings from '../../../lang/strings.json';
import { WorkflowActionEnum, WorkflowPageOrigin } from '../../../model/EventsConstantes';
import { openErrorModal } from '../../../utils/ModalsUtils';
import { WorkflowModalViewController } from '../eventWorkflow/WorkflowModalViewController';
import { EventDetailsPageHeaderView } from './EventDetailsPageHeaderView';

/**
 * Component of the event details page
 */
export class EventDetailsPageHeaderViewController extends React.Component<any, any> {

  constructor(props: any) {
    super(props);

    this.openWorkflowModal = this.openWorkflowModal.bind(this);
  }

  /**
   * Open workflow modal
   */
  private openWorkflowModal(pAction: string) {
    ModalManager.open(
      <WorkflowModalViewController
        title={WorkflowActionEnum[pAction]}
        event={this.props.event}
        pageOrigin={WorkflowPageOrigin.SPM}
        action={pAction}
        loadEventIgnoreError={this.props.loadEventIgnoreError}
        addWorkflowHistoryItem={this.props.addWorkflowHistoryItem}
      />
    );
  }

  private defaultValue(value: any, type: string = '') {
    if (value !== '' && value !== null && value !== undefined) {
      const momentUTC = moment.utc(value);  
      switch (type) {
        case 'date':
          return  momentUTC.format('DD MMM YYYY');
        case 'time':
          return momentUTC.format('HH:mm');
        default:
          return value;
      }
    }
    return Strings.defaultNoValueLabel;
  }

  public render() {
    if (!this.props.eventLoaded && !this.props.eventLoadingError) {
      return (
        <DSLoader
          id={'eventHeaderLoader'}
          label={Strings.loaderEventLabel}
        />
      );
    }
    if (this.props.eventLoaded && this.props.eventLoadingError) {
      if (this.props.exception !== undefined) {
        openErrorModal(
          this.props.exception.smTraceId,
          this.props.exception.message,
          this.props.exception.support.techRequestUrl,
          this.props.exception.support.contactEnglish,
          this.props.exception.support.contactChinese);
        return null;
      }
      return (
        <div className="ds-col-48 text-uppercase">
          <DSBanner
            type={'info'}
            title={Strings.eventLoadingErrorMessage}
            id={'error-message'}
            withCloseButton={false}
            center={true}
          />
        </div>
      );
    }
    return (
      <EventDetailsPageHeaderView
        displayName={this.props.displayName}
        event={this.props.event}
        priorityClassName={this.props.event.riskPriority.toLowerCase()}
        openModal={this.openWorkflowModal}
        defaultValue={this.defaultValue}
      />
    );
  }
}
