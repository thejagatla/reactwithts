/**
 * Class description: React predictive event details page header component
 * @author Capgemini
 * @version 1.0
 */

import * as React from 'react';
import { WorkflowPageOrigin } from '../../../model/EventsConstantes';
import { EventLine } from '../../common/events/eventLine/EventLine';

declare global {
  interface Function {
    displayName?: string;
  }
}

/**
 * Class description: React predictive event details page header component
 * @author Capgemini
 * @version 1.0
 */
export const EventDetailsPageHeaderView = (props: any) => {
  props.event.priority = props.event.riskPriority;
  props.event.titleFromAircraft = props.event.riskName;
  props.event.eventType = 'PREDICTIVE';
  props.event.origin = 'SPM';
  props.event.acMatricule = props.event.tailNumber;
  props.event.flightNumber = props.event.lastFlightNb;
  props.event.smEventDate = props.event.lastFlightAlertDate;
  props.event.ata6 = props.event.ataChapter;
  props.event.workOrderStatus = props.event.statusInfoItem.status;
  props.event.acNickName = props.event.acNickName;

  return (
      <EventLine
        displayName={props.displayName}
        event={props.event}
        isEventDetails={true}
        style={{
          overflowX: false,
          overflowY: false,
        }}
        lightened={true}
        pageOrigin={WorkflowPageOrigin.SPM}
        priorityClassName={props.event.riskPriority.toLowerCase()}
        openModal={props.openModal}
        addLocalEvent={props.addLocalEvent}
      />
  );
};

EventDetailsPageHeaderView.displayName = 'EventDetailsPageHeaderView';
