/**
 * File description: FilterButton component
 * @author Capgemini
 * @version 1.0
 */
import { DSButton, DSIcon, DSTextIcon } from '@sm/skywise-react-library';
import * as classNames from 'classnames';
import * as React from 'react';
import { SkywiseICONS } from '..';

interface FilterButtonProps {
  handleButtonClick(value: any): void;
  iconsList?: SkywiseICONS[];
  isEmpty?: boolean;
  label?: string;
  type?: string;
  textList?: string[];
}

export const FilterButton: React.SFC<FilterButtonProps> = (props: FilterButtonProps) => {
  const btnClass = classNames({
    'ds-button': true,
    'ds-button--gray': true,
    'ds-button--negative': props.isEmpty !== false,
    'ds-button--small': true,
  });
  const labelClass = classNames({
    'ds-fake-label': true,
  });
  const spanClass = classNames({
    'ds-filter-button__elem': true,
  });

  function getTextButton() {
    let textButton;
    if (props.textList !== undefined && props.textList.length > 0
      && props.iconsList !== undefined && props.iconsList.length > 0) {

      textButton = props.textList.map((lValue: string, index: number) => {
        if (props.iconsList !== undefined && props.iconsList[index] !== undefined) {
          return (
            <DSTextIcon
              className="ds-filter-button__elem"
              key={(lValue + index).toString()}
              text={lValue}
              iconType={props.iconsList[index]}
            />
          );
        }
        return (
          <span key={(lValue + index).toString()} className={spanClass}>
            {lValue}
          </span>
        );
      });
    } else if (props.iconsList !== undefined && props.iconsList.length > 0) {

      textButton = props.iconsList.map((lValue: any, index: number) => {
        return (
          <span key={(lValue + index).toString()} className={spanClass} >
            <DSIcon type={lValue} />
          </span>
        );
      });
    } else if (props.textList !== undefined && props.textList.length > 0) {

      textButton = props.textList.map((lValue: string, index: number) => {
        return (
          <span key={(lValue + index).toString()} className={spanClass}>
            {lValue}
          </span>
        );
      });
    }
    return textButton;
  }

  return (
    <React.Fragment>
      {!props.isEmpty ?
        <div className={labelClass}>{props.label}</div> :
        <div className={labelClass}>&nbsp;</div>
      }
      <DSButton
        id={props.type}
        content={props.isEmpty ? props.label : getTextButton()}
        handleClick={props.handleButtonClick}
        className={btnClass}
      />
    </React.Fragment>
  );
};

FilterButton.displayName = 'FilterButton';
FilterButton.defaultProps = { isEmpty: true };
