/**
 * File description: A filter contain a filter choices panel.
 * @author Capgemini
 * @version 1.0
 */
import { DSButton, DSCheckbox } from '@sm/skywise-react-library';
import * as React from 'react';

import {
  HtmlCheckboxProps
} from '..';
import { DSRadio } from '../controls/DSRadio';

interface FilterChoicesProps {
  inputType?: 'checkbox' | 'radio';
  values: HtmlCheckboxProps[];
  handleCancelClick?(pEvent: React.MouseEvent<HTMLInputElement>): void;
  handleApplyClick?(pEvent: React.MouseEvent<HTMLInputElement>): void;
  handleClearFilterClick?(pEvent: React.MouseEvent<HTMLButtonElement>): void;
  handleCheckboxChange(pEvent: React.FormEvent<HTMLInputElement>): void;
}

export const FilterChoices: React.SFC<FilterChoicesProps> = (props: FilterChoicesProps) => {
  const triangleStyle = {
    left: '36px',
  };
  const dialogStyle = {
    marginTop: '8px',
    top: '100%',
    zIndex: 100,
  };

  return (
    <React.Fragment>
      <div className="ds-filter-choices sm-filterchoices" role="dialog" style={dialogStyle}>
        <div className="ds-filter-choices--inner">
          <span className="ds-filter--triangle" aria-hidden="true" style={triangleStyle} />
          <button
            className="ds-picklist--reset"
            onClick={props.handleClearFilterClick}
          >
            Clear filters
          </button>
          <form className="ds-filter-choices--form">
            {/* TODO need to create form-group UI component. */}
            <div className="ds-form-group">
              {props.values.map((lValue, index) => {
                if (props.inputType === 'checkbox') {
                  return (
                    <DSCheckbox
                      key={index}
                      id={lValue.id}
                      isChecked={lValue.active}
                      handleChange={props.handleCheckboxChange}
                      label={lValue.label}
                    />
                  );
                }
                return (
                  <DSRadio
                    key={index}
                    isChecked={lValue.active}
                    id={lValue.id}
                    label={lValue.label}
                    handleChange={props.handleCheckboxChange}
                    name="period"
                  />
                );
              })}
            </div>
            <div className="ds-form-group-submit">
              <DSButton content="Cancel" size="small" handleClick={props.handleCancelClick} />
              <DSButton content="Apply" size="small" type="primary" handleClick={props.handleApplyClick} />
            </div>
          </form>
        </div>
      </div>
    </React.Fragment>
  );
};

FilterChoices.displayName = 'FilterChoices';
FilterChoices.defaultProps = {};
