/**
 * File description: A filter allows a user to select a value from a series of options to launch an action.
 * @author Capgemini
 * @version 1.0
 */
import { DSHelp } from '@sm/skywise-react-library';
import * as classNames from 'classnames';
import * as React from 'react';
import * as ReactDOM from 'react-dom';

import {
  HtmlCheckboxProps,
  SkywiseICONS
} from '..'; // Store a file with all UI interfaces in StoryBook projet.
import { FilterButton } from './FilterButton';
import { FilterChoices } from './FilterChoices';

interface FilterProps {
  /* A FilterButton can be labeled. */
  label?: string;

  /** Values array that creates a list of checkboxes or radios. */
  values: (pType: string) => HtmlCheckboxProps[];

  /* Permits to identify the filter like an id */
  type?: string;

  /** Called when apply event happens */
  onSubmit?: (pType: string) => void;

  /** Additional classes. */
  classname?: string;

  /** A list of icons displayed in the filter button */
  iconList?: (pType: string) => SkywiseICONS[];

  /** A list of text displayed in the filter button */
  textList: (pType: string) => string[];

  /** Called when user clicks on Cancel button */
  handleCancelClick?: (pType: string) => void;

  /** Called when user clicks on button */
  handleButtonClick?: (pType: string) => void;

  /** Called when user toggles checkbox */
  handleCheckboxChange?: (pType: string, pId: string) => void;

  /** Indicates if filter button must be filled or not */
  isEmpty?: (pType: string) => boolean;

  /** Indicates the image to open in the modal */
  getHelpContent?: (pType: string) => JSX.Element;

  /** Indicates the image size to open in the modal */
  getHelpSize?: (pType: string) => string;

  /** Indicates the image size to open in the modal */
  getHelpTitle?: (pType: string) => string;

  /** Called when user clicks on Clear filters link */
  clearFilters?: (pType: string) => void;

  /** Type of inputs */
  inputType?: 'checkbox' | 'radio';
}

export class Filter extends React.Component<FilterProps, any> {

  /**
   * Constructor
   * @param props React props
   */
  public constructor(props: any) {
    super(props);

    this.state = {
      isButtonActive: false
    };

    this.handleApplyClick = this.handleApplyClick.bind(this);
    this.handleCancelClick = this.handleCancelClick.bind(this);
    this.handleCheckboxChange = this.handleCheckboxChange.bind(this);
    this.handleClearFilterClick = this.handleClearFilterClick.bind(this);
    this.handleFilterButtonClick = this.handleFilterButtonClick.bind(this);
    this.handleOutsideClick = this.handleOutsideClick.bind(this);
  }

  /**
   * Handle click outside the checkboxes panel
   * @param pEvent click event
   */
  private handleOutsideClick(pEvent: any) {
    pEvent.preventDefault();

    if (!ReactDOM.findDOMNode(this).contains(pEvent.target)) {
      // Remove listener
      document.removeEventListener('mousedown', this.handleOutsideClick, false);

      this.handleCancelClick(pEvent);
    }
  }

  /**
   * Call when the filter button is clicked.
   * @param {MouseEvent} pEvent React's original MouseEvent.
   */
  private handleFilterButtonClick(pEvent: React.MouseEvent<HTMLElement>): void {

    pEvent.preventDefault();

    if (!this.state.isButtonActive) {
      // Add listener when click outside the checkboxes panel
      document.addEventListener('mousedown', this.handleOutsideClick, false);

      const { handleButtonClick, type } = this.props;

      // Close button
      this.setState({ isButtonActive: true });

      // And, eventually, warn parent controller
      if (handleButtonClick && type) {
        handleButtonClick(type);
      }
    }
  }

  /**
   * Call when the Cancel button is clicked.
   * @param {MouseEvent} pEvent React's original MouseEvent.
   */
  private handleCancelClick(pEvent: React.MouseEvent<HTMLElement>): void {
    pEvent.preventDefault();

    // Update state
    this.setState({ isButtonActive: false });

    const { handleCancelClick, type } = this.props;

    // Warn parent controller
    if (handleCancelClick && type) {
      handleCancelClick(type);
    }
  }

  /**
   * Call when the Apply button is clicked.
   * @param {MouseEvent} pEvent React's original MouseEvent.
   */
  private handleApplyClick(pEvent: React.MouseEvent<HTMLElement>): void {
    pEvent.preventDefault();

    // Remove listener
    document.removeEventListener('mousedown', this.handleOutsideClick, false);

    const { onSubmit, type } = this.props;

    // Change state
    this.setState({ isButtonActive: false });

    // And call parent controller
    if (onSubmit && type) {
      onSubmit(type);
    }
  }

  /**
   * Call when the Clear button is clicked.
   * @param {MouseEvent} pEvent React's original MouseEvent.
   */
  private handleClearFilterClick(pEvent: React.MouseEvent<HTMLElement>): void {
    pEvent.preventDefault();
    const { clearFilters, type } = this.props;

    // Call parent controller
    if (clearFilters && type) {
      clearFilters(type);
    }
  }

  /**
   * Called when the user attempts to change the checked state.
   * @param {FormEvent} pEvent React's original MouseEvent.
   */
  private handleCheckboxChange(pEvent: React.FormEvent<HTMLInputElement>): void {
    pEvent.stopPropagation();
    const { handleCheckboxChange, type } = this.props;
    const lCheckboxId = pEvent.currentTarget.id;

    // Warn parent controller
    if (handleCheckboxChange && type) {
      handleCheckboxChange(type, lCheckboxId);
    }
  }

  /**
   * Return icons list to display on the filter button
   */
  private getIconsList(): SkywiseICONS[] {
    let lIconsList: SkywiseICONS[] = [];
    const { iconList, type } = this.props;

    // Call parent controller to get icons list
    if (iconList && type) {
      lIconsList = iconList(type);
    }

    return lIconsList;
  }

  /**
   *  Return text list to display on button
   */
  private getTextList(): string[] {
    let lTextList: string[] = [];
    const { textList, type } = this.props;

    // Call parent controller to get text list
    if (textList && type) {
      lTextList = textList(type);
    }

    return lTextList;
  }

  /**
   *  Return image to open when click on help button associated
   */
  private getHelpContent(): JSX.Element {
    const { getHelpContent, type } = this.props;

    let lHelpContent: JSX.Element = <React.Fragment />;

    // Call parent controller to get text list
    if (getHelpContent && type) {
      lHelpContent = getHelpContent(type);
    }

    return lHelpContent;
  }

  /**
   *  Return image to open when click on help button associated
   */
  private getHelpTitle(): string {
    const { getHelpTitle, type } = this.props;

    let title: string = '';

    // Call parent controller to get text list
    if (getHelpTitle && type) {
      title = getHelpTitle(type);
    }

    return title;
  }

  /**
   *  Return image size
   */
  private getHelpSize(): string {
    const { getHelpTitle, type } = this.props;

    let size: string = '';
    let helpTitle: string = '';

    // Call parent controller to get text list
    if (getHelpTitle && type) {
      helpTitle = getHelpTitle(type);
    }

    if (helpTitle === 'Workflow Status Help') {
      size = '850px';
    } else if (helpTitle === 'Occurrence Help') {
      size = '650px';
    }

    return size;
  }

  /**
   * Render Filter button part
   */
  private renderFilterButton(): React.ReactNode {
    let type = '';
    if (this.props.type !== undefined) {
      type = this.props.type.toLowerCase().replace(/_/g, '-');
    }
    return (
      <FilterButton
        label={this.props.label}
        type={type}
        isEmpty={this.props.isEmpty && this.props.type ? this.props.isEmpty(this.props.type) : false}
        iconsList={this.getIconsList()}
        textList={this.getTextList()}
        handleButtonClick={this.handleFilterButtonClick}
      />
    );
  }

  /**
   * Render Filter choices part
   */
  private renderFilterChoices(): React.ReactNode {
    return (
      <FilterChoices
        inputType={this.props.inputType !== undefined ? this.props.inputType : 'checkbox'}
        values={this.props.type !== undefined ? this.props.values(this.props.type) : []}
        handleCancelClick={this.handleCancelClick}
        handleApplyClick={this.handleApplyClick}
        handleClearFilterClick={this.handleClearFilterClick}
        handleCheckboxChange={this.handleCheckboxChange}
      />
    );
  }

  /**
   * React render method
   */
  public render() {
    // Classes
    const classes = classNames(
      'ds-filter',
      'search-facet',
      {
        'ds-filter--with-help': this.getHelpTitle() !== ''
      }
    );
    return (
      <div className={classes}>
        {this.getHelpTitle() !== '' &&
          <DSHelp
            title={this.getHelpTitle()}
            content={this.getHelpContent()}
            size={this.getHelpSize()}
            className="fr"
          />
        }
        {this.renderFilterButton()}
        {this.state.isButtonActive &&
          this.renderFilterChoices()
        }
      </div>
    );
  }
}
