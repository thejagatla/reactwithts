import { DSFormGroup } from '@sm/skywise-react-library';
import * as cx from 'classnames';
import * as React from 'react';

export interface SelectOption {
  label: string;
  value: string;
}

export interface SelectProps {
  /** A select can appear disabled. */
  disabled?: boolean;

  /** A unique identifier. */
  id: string;

  /** A label */
  label?: string;

  /** Options array. Each option has a 'value' and a 'label' property. */
  options: SelectOption[];

  /**
   * Called when user selects an option.
   *
   * @param {ChangeEvent<HTMLSelectElement>} event - React's original ChangeEvent.
   */
  handleChange?(event: React.ChangeEvent<HTMLSelectElement>): void;
}

export default class Select extends React.Component<SelectProps> {
  public static defaultProps = {};

  constructor(props: SelectProps) {
    super(props);
  }

  public render() {
    const { disabled, handleChange, id, label, options } = this.props;

    return (
      <DSFormGroup>
        <label htmlFor={id} className={cx('ds-label')}>
          {label}
        </label>
        <select
          id={id}
          aria-label="Label"
          onChange={handleChange}
          disabled={disabled}
        >
          {options.map((option: SelectOption, key: number) => (
            <option key={key} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </DSFormGroup>
    );
  }
}
