/**
 * File description: Contains all interface and others that can be usefull for Skywise User Interface.
 * @author Capgemini
 * @version 1.0
 */

// ======================================================
// Common element's props
// ======================================================

export interface HtmlCheckboxProps {
  active: boolean;
  id: string;
  label: string;
}

// ======================================================
// Styling
// ======================================================
export type SkywiseSIZES = 'medium' | 'small';

// ======================================================
// Headings list
// ======================================================
export type SkywiseHeadings = 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6';

// ======================================================
// Icon Names
// ======================================================
export type SkywiseICONS = 'airplane' | 'airplane-inactive' | 'bubble' | 'arrow-right' | 'block' | 'build' | 'cancel'
  | 'caret' | 'chart' | 'chart2' |
  'check' | 'check_checkbox' | 'check_circle' | 'chevron_down' | 'chevron_left' | 'chevron_right' | 'chevron_up'
  | 'close' |
  'clock' | 'date_range' | 'emoticon' | 'error' | 'eye' | 'help' | 'indeterminate' | 'info' | 'location' | 'more'
  | 'search' |
  'search_db' | 'settings' | 'star' | 'calendar' | 'cross' | 'locked' | 'target' | 'timer' | 'wrench' | 'pencil'
  | 'delete' |
  'dots-vertical' | 'edit' | 'help-circle' | 'magnify-plus' | 'minus' | 'open-in-new';

// ======================================================
// Component button types
// ======================================================
export type SkywiseButtonTYPES = 'primary' | 'ghost' | 'link' | 'close';

// ======================================================
// Component banner types
// ======================================================
export type SkywiseBannerTYPES = 'info' | 'success' | 'warning' | 'error';

// ======================================================
// Component colors
// ======================================================
export type SkywiseCOLORS = 'white' | 'grey';

// ======================================================
// Text align options
// ======================================================
export type SkywiseTextAlign = 'left' | 'center' | 'right' | 'justified';

// ======================================================
// Vertical align options
// ======================================================
export type SkywiseAlignItems = 'leading' | 'trailing' | 'center' | 'fill' | 'baseline';

export type SkywiseResizeOptions = 'both' | 'horizontal' | 'vertical' | 'none';

/**
 * Props where only the prop key is used in the className.
 * @param {*} val A props value
 * @param {string} classname A classname correspondance
 *
 */
export const keyToClassName = (val: any, classname: string): string => {
  return val && classname;
};

export const getComponentType = (Component, props) => {
  const { defaultProps } = Component;

  if (props.as !== undefined && props.as !== defaultProps.as) {
    return props.as;
  }

  if (props.href) {
    return 'a';
  }

  return defaultProps.as || 'div';
};

/**
 * Tests if children are nil in React and Preact.
 * @param {Object} children The children prop of a component.
 * @returns {Boolean}
 */
export const isNil = (children): boolean => {
  return children === null
    || children === undefined
    || (Array.isArray(children) && children.length === 0);
};

/**
 * Returns an object consisting of props beyond the scope of the Component.
 * Useful for getting and spreading unknown props from the user.
 * @param {function} Component A function or ReactClass.
 * @param {object} props A ReactElement props object
 * @returns {{}} A shallow copy of the prop object
 */
export const getUnhandledProps = (Component, props): any => {
  // Note that `handledProps` are generated automatically during build with `babel-plugin-transform-react-handled-props`
  const { handledProps = [] } = Component;

  return Object.keys(props).reduce(
    (acc, prop): any => {
      if (prop === 'childKey') {
        return acc;
      }
      if (handledProps.indexOf(prop) === -1) {
        acc[prop] = props[prop];
        return acc;
      }
    },
    {}
  );
};
