import * as cx from 'classnames';
import * as React from 'react';

export interface Props {
  /** Primary content. */
  children?: React.ReactNode;

  /** Additional classes. */
  className?: string;
}

/**
 * @name ButtonGroup
 * @description Buttons can be grouped.
 * @example
 * <ButtonGroup>
 *  <DSButton>Button 1</DSButton>
 *  <DSButton>Button 1</DSButton>
 * </ButtonGroup>
 */
export const ButtonGroup: React.SFC<Props> = (props: Props) => {
  return (
    <div className={cx('group-button', props.className)}>
      {React.Children.map(props.children, button => {
        if (!button) {
          return null;
        }
        return <React.Fragment>{button}</React.Fragment>;
      })}
    </div>
  );
};
