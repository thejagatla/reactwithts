import * as cx from 'classnames';
import * as React from 'react';

interface Props {
  /** Display or not the blanket. */
  displayed?: boolean;

  /** Whether mouse events can pierce the blanket.
   * If true, onBlanketClicked will not be fired.
   */
  canClickThrough?: boolean;

  /** Whether the blanket has a tinted background color. */
  tinted?: boolean;

  /** Handler function to be called when the blanket is clicked */
  onBlanketClicked?: (event: React.SyntheticEvent<HTMLElement>) => void;
}

class Blanket extends React.PureComponent<Props, any> {
  public static defaultProps: Partial<Props> = {
    canClickThrough: true,
    tinted: true
  };

  public render() {
    const { displayed, tinted, canClickThrough, onBlanketClicked } = this.props;

    const onClick = canClickThrough ? null : onBlanketClicked;

    const classes = cx(
      {
        'is-clickable': canClickThrough,
        'is-displayed': displayed,
        'is-tinted': tinted
      },
      'blanket'
    );
    return <div className={classes} {...onClick} />;
  }
}

export default Blanket;
