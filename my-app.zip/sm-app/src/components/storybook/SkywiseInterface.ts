/**
 * File description: Contains all interface and others that can be usefull for Skywise User Interface.
 * @author Capgemini
 * @version 1.0
 */

// ======================================================
// Common element's props
// ======================================================

export interface HtmlCheckboxProps {
  active: boolean;
  id: string;
  label: string;
}

// ======================================================
// Styling
// ======================================================
export type SkywiseSIZES = 'medium' | 'small';

// ======================================================
// Headings list
// ======================================================
export type SkywiseHeadings = 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6';

// ======================================================
// Icon Names
// ======================================================
export type SkywiseICONS =
  | 'airplane'
  | 'bubble'
  | 'arrow-right'
  | 'block'
  | 'build'
  | 'cancel'
  | 'caret'
  | 'chart'
  | 'chart2'
  | 'check'
  | 'check_checkbox'
  | 'check_circle'
  | 'chevron_down'
  | 'chevron_left'
  | 'chevron_right'
  | 'chevron_up'
  | 'close'
  | 'clock'
  | 'date_range'
  | 'emoticon'
  | 'error'
  | 'eye'
  | 'help'
  | 'indeterminate'
  | 'info'
  | 'location'
  | 'more'
  | 'search'
  | 'search_db'
  | 'settings'
  | 'star'
  | 'calendar'
  | 'cross'
  | 'locked'
  | 'target'
  | 'timer'
  | 'wrench'
  | 'pencil'
  | 'delete'
  | 'dots-vertical'
  | 'edit'
  | 'help-circle'
  | 'magnify-plus'
  | 'minus'
  | 'open-in-new';

// ======================================================
// Component button types
// ======================================================
export type SkywiseButtonTYPES = 'primary' | 'ghost' | 'link' | 'close';

// ======================================================
// Component banner types
// ======================================================
export type SkywiseBannerTYPES = 'info' | 'success' | 'warning' | 'error';

// ======================================================
// Component colors
// ======================================================
export type SkywiseCOLORS = 'white' | 'grey';

// ======================================================
// Text align options
// ======================================================
export type SkywiseTextAlign = 'left' | 'center' | 'right' | 'justified';

// ======================================================
// Vertical align options
// ======================================================
export type SkywiseAlignItems =
  | 'leading'
  | 'trailing'
  | 'center'
  | 'fill'
  | 'baseline';

export type SkywiseResizeOptions = 'both' | 'horizontal' | 'vertical' | 'none';

export type SkywiseAlignSelf = 'start' | 'center' | 'end';

export type SkywiseJustifyContent = SkywiseAlignSelf | 'around' | 'between';

export type SkywiseWidths =
  | 1
  | 2
  | 3
  | 4
  | 5
  | 6
  | 7
  | 8
  | 9
  | 10
  | 11
  | 12
  | number;
/**
 * Props where only the prop key is used in the className.
 * @param {*} val A props value
 * @param {string} classname A classname correspondance
 *
 */
export const keyToClassName = (val: any, classname: string): string => {
  return val && classname;
};

export const getComponentType = (Component, props) => {
  const { defaultProps } = Component;

  if (props.as !== undefined && props.as !== defaultProps.as) {
    return props.as;
  }

  if (props.href) {
    return 'a';
  }

  return defaultProps.as || 'div';
};

/**
 * Tests if children are nil in React and Preact.
 * @param {Object} children The children prop of a component.
 * @returns {Boolean}
 */
export const isNil = (children): boolean => {
  return (
    children === null ||
    children === undefined ||
    (Array.isArray(children) && children.length === 0)
  );
};
