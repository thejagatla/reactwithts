/**
 * File description: Collapsible sidebar
 *
 * @author Capgemini
 * @version 1.0
 */
import * as classNames from 'classnames';
import * as React from 'react';

export interface DSPanelProps {
  children: React.ReactNode;
  collapsed: boolean;
  id?: string;
  header?: React.ReactNode;
  handleToggle?(pEvent: {}): void;
}

export const DSPanel: React.SFC<DSPanelProps> = (props: DSPanelProps) => {
  const sidebarClasses = classNames({
    'ds-panel': true,
    'ds-show': !props.collapsed
  });

  return (
      <div id={props.id} className={sidebarClasses} >
          <div className="ds-notifications-panel--arrow" onClick={props.handleToggle}>
              <span className="ds-icon-chevron_left"/>
          </div>
          <div className="ds-panel--container">
              {props.header &&
                  <div className="ds-notifications-panel--header">
                    <h4>
                      {props.header}
                    </h4>
                  </div>
              }
              <div className="ds-notifications-panel--content">
                {props.children}
              </div>
          </div>
      </div>
  );
};
