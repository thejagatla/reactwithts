/**
 * File description: Textarea component
 * @author Capgemini
 * @version 1.0
 */
import * as classNames from 'classnames';
import * as React from 'react';

interface TextareaProps {
  label: string;
  name: string;
  isDisabled?: boolean;
  id?: string;
  ariaLabel?: string;
  placeholder?: string;
  rows?: number;
  cols?: number;
  className?: string;
  maxLength?: number;
  value?: string;
  isMandatory?: boolean;
  handleChange(value: any): void;
}

export const Textarea: React.SFC<TextareaProps> = (props: TextareaProps) => {
  const txtAreaClass = classNames({
    'ds-form-group': true,
    [`${props.className}`]: typeof props.className !== 'undefined'
  });

  return (
    <div className={txtAreaClass}>
      <label className="ds-label" htmlFor={props.id}>{props.label}{props.isMandatory ? '*' : ''}</label>
      <textarea
        id={props.id}
        name={props.name}
        rows={props.rows}
        cols={props.cols}
        placeholder={props.placeholder}
        disabled={props.isDisabled}
        onChange={props.handleChange}
        maxLength={props.maxLength}
        wrap={'hard'}
        value={props.value}
      />
    </div>
  );
};

Textarea.displayName = 'Textarea';
Textarea.defaultProps = {
  cols: 20,
  isDisabled: false,
  rows: 4,
};
