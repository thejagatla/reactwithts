/**
 * File description: Text component
 * @author Capgemini
 * @version 1.0
 */
import * as classNames from 'classnames';
import * as React from 'react';

interface TextProps {
  label: string;
  name: string;
  isDisabled?: boolean;
  id?: string;
  size?: number;
  ariaLabel?: string;
  placeholder?: string;
  className?: string;
  maxLength?: number;
  value?: string;
  handleChange?(value: any): void;
}

export const DSText: React.SFC<TextProps> = (props: TextProps) => {
  const textClass = classNames({
    'ds-form-group': true
  });

  return (
    <div className={textClass}>
      <label className="ds-label" htmlFor={props.id}>{props.label}</label>
      <input
        type={'text'}
        id={props.id}
        name={props.name}
        size={props.size}
        placeholder={props.placeholder}
        disabled={props.isDisabled}
        onChange={props.handleChange}
        maxLength={props.maxLength}
        value={props.value}
      />
    </div>
  );
};

DSText.displayName = 'DSText';
DSText.defaultProps = {
  isDisabled: false,
  size: 30
};
