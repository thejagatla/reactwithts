import * as classNames from 'classnames';
import * as React from 'react';
import { getUnhandledProps } from '..';
import { SkywiseDirections } from './Pass';

import { keyToClassName } from '@sm/skywise-react-library/dist/SkywiseInterface';

export interface PassCellProps {
  [key: string]: any;

  /** Primary content. */
  children?: React.ReactNode;

  /** Additional classes. */
  className?: string;

  direction?: SkywiseDirections;
}

/**
 * File description:
 *
 * @see Card
 */
export const PassCell: React.SFC<PassCellProps> = (props: PassCellProps) => {
  const {
    children,
    className,
    direction
  } = props;

  const classes = classNames(
    'pass-event__cell',
    keyToClassName(direction, 'ds-flex-' + direction),
    className
  );

  const rest = getUnhandledProps(PassCell, props);

  return (
    <div {...rest} className={classes}>
      {children}
    </div>
  );
};
