import * as classNames from 'classnames';
import * as React from 'react';
import { getUnhandledProps } from '..';

import { getComponentType } from '@sm/skywise-react-library/dist/SkywiseInterface';
export interface PassColumnProps {
  [key: string]: any;

  /** An element type to render as (string). */
  as?: string;

  /** Primary content. */
  children?: React.ReactNode;

  /** Additional classes. */
  className?: string;
}

/**
 * File description:
 *
 * @see Card
 */
export const PassColumn: React.SFC<PassColumnProps> = (props: PassColumnProps) => {
  const {
    children,
    className,
  } = props;

  const classes = classNames(
    'pass-event__column',
    className
  );

  const rest = getUnhandledProps(PassColumn, props);
  const ComponentType = getComponentType(PassColumn, props);

  return (
    <ComponentType {...rest} className={classes}>
      {children}
    </ComponentType>
  );
};

PassColumn.defaultProps = {
  as: 'div'
};
