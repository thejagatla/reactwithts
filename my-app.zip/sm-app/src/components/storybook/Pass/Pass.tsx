import * as classNames from 'classnames';
import * as React from 'react';
import { PassCell } from './PassCell';
import { PassColumn } from './PassColumn';
import { PassSection } from './PassSection';

import { getUnhandledProps } from '..';

export type SkywiseDirections = 'column' | 'column-reverse' | 'row' | 'ro-reverse';

export interface PassProps {
  [key: string]: any;

  /** Correspond of the heanding level. */
  // as?: string;

  /** Primary content. */
  children?: React.ReactNode;

  /** Additional classes. */
  className?: string;
}

/**
 * File description: A Card Event is used to display a complex flight event.
 *
 * @see PassSection
 * @see PassCell
 * @see PassColumn
 */
export class Pass extends React.Component<PassProps> {
  public static Section: typeof PassSection;
  public static Cell: typeof PassCell;
  public static Column: typeof PassColumn;

  public render() {
    const {
      children,
      className
    } = this.props;

    const classes = classNames(
      'pass-event',
      className
    );

    const rest = getUnhandledProps(Pass, this.props);

    return (
      <div {...rest} className={classes}>
        {children}
      </div>
    );
  }
}

Pass.Cell = PassCell;
Pass.Column = PassColumn;
Pass.Section = PassSection;
