import * as classNames from 'classnames';
import * as React from 'react';

export interface PassSectionProps {
  /** Correspond of the heanding level. */
  // as?: string;

  /** Primary content. */
  children?: React.ReactNode;

  /** Additional classes. */
  className?: string;
}

/**
 * File description:
 *
 * @see Card
 */
export const PassSection: React.SFC<PassSectionProps> = (props: PassSectionProps) => {
  const {
    children,
    className,
  } = props;

  const classes = classNames(
    'pass-event__section',
    className
  );

  return (
    <div className={classes}>
      {children}
    </div>
  );
};
