/**
 * File description: Message component
 *
 * @author Capgemini
 * @version 1.0
 */
import { DSIcon } from '@sm/skywise-react-library';
import * as classNames from 'classnames';
import * as React from 'react';
import { SkywiseICONS } from '.';
import { startAnimation } from '../../utils/RenderUtils';

export interface MessageProps {
  /** Primary content. */
  text: any;

  /** Additional classes. */
  icon?: SkywiseICONS;
}

export class Message extends React.Component<MessageProps, any> {
  /**
   * Constructor
   * @param props React props
   */
  constructor(props: any) {
    super(props);

    this.state = {
      mounted: false
    };
  }

  public componentDidMount() {
    startAnimation(() => {
      this.setState({ mounted: true });
    });
  }

  public render() {
    const classes = classNames({
      message: true,
      mounted: this.state.mounted
    });

    return(
      <div className={classes}>
        {this.props.icon &&
          <DSIcon
            type={this.props.icon}
          />
        }
        <p>
          {this.props.text}
        </p>
      </div>
    );
  }
}
