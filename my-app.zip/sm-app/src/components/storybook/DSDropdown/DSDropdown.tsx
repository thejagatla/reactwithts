import { DSIcon, DSMenuExpand } from '@sm/skywise-react-library';
import { SkywiseICONS } from '@sm/skywise-react-library/dist/SkywiseInterface';
import * as classNames from 'classnames';
import * as _ from 'lodash';
import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { DSMenuExpandItem, DSMenuExpandItemProps } from '../DSMenuExpand/DSMenuExpandItem';
import { DSMenuExpandList } from '../DSMenuExpand/DSMenuExpandList';

interface DropdownProps {
  /** Dropdown can open to the left or to the right. */
  direction?: 'left' | 'right';

  /** Dropdown can be disabled. It's disabled by default, if there is no options. */
  disabled?: boolean;

  /** Additional classes. */
  className?: string;

  /** Icon displayed after text. */
  icon?: SkywiseICONS;

  /** A label can be displayed before the text. */
  label?: string;

  negative?: boolean;

  /** Controls whether or not the dropdown menu is displayed. */
  open?: boolean;

  /** Array of DropdownItem props */
  options?: DSMenuExpandItemProps[];

  /** The text displayed in the dropdown, usually for the active item. */
  text?: string;

  /** Custom element to trigger the menu. Takes place of 'text'. */
  trigger?: React.ReactNode;

  /** Current value (the selected item of options). */
  value?: string;

  /**
   * Called when an close event happens.
   *
   * @param {SyntheticEvent} event - React's original SyntheticEvent.
   * @param {object} data - All props.
   */
  onClose?: (event: React.SyntheticEvent<HTMLElement>, data: DropdownProps) => void;

  /**
   * Called when an open event happens.
   *
   * @param {SyntheticEvent} event - React's original SyntheticEvent.
   * @param {object} data - All props.
   */
  onOpen?: (event: React.SyntheticEvent<HTMLElement>, data: DropdownProps) => void;

  /**
   * Called when the user click on an item.
   *
   * @param {string} value - Item value selected.
   */
  onItemClick?: (value: string) => void;
}

interface DropdownState {
  open: boolean;
  selectedIndex?: number; // id index of tab
  upward?: boolean;
  value?: string; // key of DropdownItemProps selected.
}

/**
 * Class description: A Dropdown rendering component
 * @author Capgemini
 * @version 1.0
 */
export class DSDropdown extends React.Component<DropdownProps, DropdownState> {
  private dropdownRef;

  public static defaultProps: Partial<DropdownProps> = {
    disabled: false,
    icon: 'chevron_down'
  };

  /**
   * Constructor
   * @param props props
   */
  constructor(props: any) {
    super(props);

    this.state = {
      open: false,
      upward: false
    };

    this.handleClick = this.handleClick.bind(this);
    this.handleClose = this.handleClose.bind(this);
    this.handleItemClick = this.handleItemClick.bind(this);
    this.handleOpen = this.handleOpen.bind(this);
    this.handleOutsideClick = this.handleOutsideClick.bind(this);
  }

  private getValueOrText(value: string | number, text: string): React.ReactText {
    return _.isNil(value) ? text : value;
  }

  private getItemByValue(value: string) {
    const { options } = this.props;

    return _.find(options, { value });
  }

  private setValue(value: string) {
    this.setState({
      value
    });
  }

  private setSelectedIndex(value: string) {
    let newSelectedIndex;
    const { options } = this.props;

    newSelectedIndex = _.findIndex(options, ['value', value]);

    this.setState({ selectedIndex: newSelectedIndex });
  }

  private computeMenuPosition(): void {
    if (!this.dropdownRef) {
      return;
    }

    const dropdown: any = this.dropdownRef;
    const dropdownMenu: any = dropdown.querySelector('.sm-dropdown__menu');
    const dropdownRect: ClientRect = dropdown.getBoundingClientRect();

    const { upward } = this.state;
    const height = dropdownRect.height + dropdownRect.top;
    const bodyHeight = dropdown.ownerDocument.body.offsetHeight;
    const menuHeight = dropdownMenu.offsetHeight;

    let newUpward: boolean = false;
    if (menuHeight > (bodyHeight - height)) {
      newUpward = true;
    }

    if (upward !== newUpward) {
      this.setState({
        upward: newUpward
      });
    }
  }

  public componentWillMount() {
    const { value } = this.props;
    const { open } = this.state;

    this.setValue(value);
    this.setSelectedIndex(value);

    if (open) {
      this.handleOpen();
    }
  }

  public componentWillReceiveProps(nextProps: any) {
    if (nextProps.value !== this.props.value) {
      this.setValue(nextProps.value);
      this.setSelectedIndex(nextProps.value);
    }
  }

  public componentDidUpdate(prevProps: any, prevState: any) {
    if (!prevState.open && this.state.open) {
      this.attachHandlersOnOpen();
      this.computeMenuPosition();
    } else if (prevState.open && !this.state.open) {
      this.detachHandlersOnOpen();
    }
  }

  public componentWillUnmount(): void {
    this.detachHandlersOnOpen();
  }

  private handleClick(e: any): void {
    const { disabled } = this.props;

    if (disabled) {
      return;
    }

    return this.handleToggle(e);
  }

  private handleItemClick(e: React.MouseEvent<HTMLElement>, item: any): void {
    e.preventDefault();
    const { value } = item;
    const { onItemClick } = this.props;

    this.setValue(value);
    this.setSelectedIndex(value);

    // Eventually, warn parent controller.
    if (onItemClick && value) {
      onItemClick(value);
    }
    this.handleToggle(e);
  }

  private handleToggle(e: any): void {
    this.state.open ? this.handleClose(e) : this.handleOpen(e);
  }

  /**
   * Handle click outside dropdown component.
   * @param e click event
   */
  private handleOutsideClick(e: any): void {
    if (!ReactDOM.findDOMNode(this).contains(e.target)) {
      this.handleClose(e);
    }
  }

  private handleOpen(e?: any): void {
    const { disabled, onOpen } = this.props;

    if (disabled) {
      return;
    }

    // Eventually, warn parent controller.
    if (onOpen && e) {
      onOpen(e, this.props);
    }

    this.setState({ open: true });
  }

  private handleClose(e: any): void {
    const { onClose } = this.props;

    // Eventually, warn parent controller.
    if (onClose) {
      onClose(e, this.props);
    }
    this.setState({ open: false });
  }

  private attachHandlersOnOpen(): void {
    document.addEventListener('mousedown', this.handleOutsideClick);
  }

  private detachHandlersOnOpen(): void {
    document.removeEventListener('mousedown', this.handleOutsideClick, false);
  }

  private renderLabel(): React.ReactNode {
    const { label } = this.props;
    if (!_.isNil(label)) {
      // TODO: create DSLabel.
      return (<span id="dsDropdown" className="sm-dropdown__label">{label}</span>);
    }
    return null;

  }

  private renderText(): React.ReactNode {
    const { text } = this.props;
    const { value } = this.state;
    const classes = classNames(
      'sm-dropdown__input'
    );

    let lText = '';
    if (text) {
      lText = text;
    } else if (!_.isNil(value) && value !== '') {
      lText = _.get(this.getItemByValue(value), 'text');
    }

    return (
      <div
        className={classes}
        aria-live="polite"
        id="dsDropdown"
      // onClick={this.handleClick}
      >
        {this.renderLabel()}{lText}{this.renderIcon()}
      </div>
    );
  }

  private renderIcon(): React.ReactNode | void {
    const { disabled, icon } = this.props;

    if (disabled) {
      return;
    }

    return (
      <DSIcon type={icon} className="sm-dropdown__icon" />
    );
  }

  private renderMenu(): any {
    const { direction, disabled } = this.props;

    if (disabled) {
      return;
    }

    const { open } = this.state;
    const menuClasses = classNames(
      'sm-dropdown__menu',
      {
        'sm-dropdown__menu--left': direction === 'left',
        'sm-dropdown__menu--show': open
      }

    );

    return (
      <DSMenuExpand className={menuClasses} aria-labelledby="dsDropdown">
        <DSMenuExpandList>
          {this.renderOptions()}
        </DSMenuExpandList>
      </DSMenuExpand>

    );
  }

  private renderOptions() {
    const { options } = this.props;
    const { selectedIndex } = this.state;

    return _.map(options, (opt: DSMenuExpandItemProps, index: number) =>
      (
        <DSMenuExpandItem
          as={opt.as}
          text={opt.text}
          active={selectedIndex === index}
          value={this.getValueOrText(opt.value, opt.text)}
          onClick={this.handleItemClick}
          key={index}
        />
      )
    );
  }

  /**
   * Rendering method
   */
  public render() {
    const { className, disabled, negative, options, trigger } = this.props;
    const { open, upward } = this.state;
    const classes = classNames(
      {
        'has-elements': _.isLength(options),
        'sm-dropdown': true,
        'sm-dropdown--active': open,
        'sm-dropdown--disabled': disabled,
        'sm-dropdown--negative': negative,
        'sm-dropdown--upward': upward
      },
      className
    );

    return (
      <div 
        className={classes} 
        ref={(dropdownRef) => { this.dropdownRef = dropdownRef; }}
        onClick={this.handleClick}
      >
        {trigger || this.renderText()}
        {this.renderMenu()}
      </div>
    );
  }
}
