/**
 * File description: Menu Expand can have a divider.
 *
 * @author Capgemini
 * @version 1.0
 */
import { getComponentType } from '@sm/skywise-react-library/dist/SkywiseInterface';
import * as classNames from 'classnames';
import * as React from 'react';

export interface DSMenuExpandDividerProps {
  /** <hr> HTML tag is use for divider. */
  as?: 'hr';

  /** Additional classes. */
  className?: string;
}

export const DSMenuExpandDivider: React.SFC<DSMenuExpandDividerProps> = (props: DSMenuExpandDividerProps) => {
  const {
    className
  } = props;

  const classes = classNames(
    className
  );

  const ComponentType = getComponentType(DSMenuExpandDivider, props);

  return (
    <ComponentType className={classes} />
  );
};

DSMenuExpandDivider.defaultProps = {
  as: 'hr'
};
