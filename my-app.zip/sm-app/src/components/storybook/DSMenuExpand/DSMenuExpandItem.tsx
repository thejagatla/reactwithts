/**
 * File description: An item of Menu Expand component.
 *
 * @author Capgemini
 * @version 1.0
 */
import { getComponentType } from '@sm/skywise-react-library/dist/SkywiseInterface';
import * as classNames from 'classnames';
import * as React from 'react';

export interface DSMenuExpandItemProps {
  /** Item can be <a> or <button> HTML tag. */
  as?: 'a' | 'button';

  /** Item can be active. */
  active?: boolean;

  /** Additional classes. */
  className?: string;

  /** Display text. */
  text?: string;

  /** Stored value. */
  value?: number | string;

  /**
   * Called when user clicks on item.
   *
   * @param {} value - React's original SyntheticEvent.
   */
  onClick?(event: React.MouseEvent<HTMLElement>, data: DSMenuExpandItemProps): void;
}

export const DSMenuExpandItem: React.SFC<DSMenuExpandItemProps> = (props: DSMenuExpandItemProps) => {
  const {
    className,
    text
  } = props;

  const classes = classNames(
    'ds-menu-expand--item',
    className
  );

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    const { onClick } = props;

    if (onClick) {
      onClick(event, props);
    }
  };

  const getPropsByType = (componentType: string) => {
    const propstype: any = {};
    if (componentType === 'button') {
      propstype.type = 'button';
      if (props.active) {
        propstype.className = classNames({
          'ds-active': props.active
        });
      }
    } else if (componentType === 'a') {
      propstype.href = '';
    }

    return propstype;
  };

  const ItemType = getComponentType(DSMenuExpandItem, props);
  const rest = getPropsByType(ItemType);

  return (
    <li className={classes}>
      <ItemType {...rest} onClick={handleClick} >{text}</ItemType>
    </li>
  );
};

DSMenuExpandItem.defaultProps = {
  as: 'a'
};
