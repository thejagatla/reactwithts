/**
 * File description: Menu expand is a container with a list of items.
 *
 * @author Capgemini
 * @version 1.0
 */
import * as classNames from 'classnames';
import * as React from 'react';
import { isNil } from '..';

export interface DSMenuExpandProps {
  /** Correspond of the heanding level. */
  as?: string;

  id?: string;

  /** Primary content. */
  children?: React.ReactNode;

  /** Additional classes. */
  className?: string;
}

export const DSMenuExpand: React.SFC<DSMenuExpandProps> = (props: DSMenuExpandProps) => {
  const {
    children,
    className,
    id
  } = props;

  const classes = classNames(
    'ds-menu-expand',
    className
  );

  return (
    <div id={id} className={classes} role="dialog">
      <div className="ds-menu-expand--inner">
        {!isNil(children) && children}
      </div>
    </div>
  );
};
