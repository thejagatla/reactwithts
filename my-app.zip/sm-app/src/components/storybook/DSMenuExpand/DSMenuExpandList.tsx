/**
 * File description: Wrapper of Menu Expand items.
 *
 * @author Capgemini
 * @version 1.0
 */
import * as classNames from 'classnames';
import * as React from 'react';
import {
  isNil
} from '..';

export interface DSMenuExpandListProps {
  /** Primary content. */
  children?: React.ReactNode;

  /** Additional classes. */
  className?: string;
}

export const DSMenuExpandList: React.SFC<DSMenuExpandListProps> = (props: DSMenuExpandListProps) => {
  const {
    children,
    className,
  } = props;

  const classes = classNames(
    'ds-menu-expand--list',
    className
  );

  return (
    <ul className={classes}>
      {!isNil(children) && children}
    </ul>
  );
};
