import * as React from 'react';

/**
 * @name RibbonIcon
 * @description Display a ribbon icon.
 * @type [UI Presenter]
 */
const RibbonIcon = ({ children }) => {
  return <span className="ribbon-link__icon">{children}</span>;
};

export default RibbonIcon;
