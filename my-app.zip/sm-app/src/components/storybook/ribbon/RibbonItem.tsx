import { DSIcon } from '@sm/skywise-react-library';
import { SkywiseICONS } from '@sm/skywise-react-library/dist/SkywiseInterface';
import * as _ from 'lodash';
import * as React from 'react';
import { Link } from 'react-router-dom';
import RibbonIcon from './RibbonIcon';

import * as cx from 'classnames';

export interface RibbonItemProps {
  /** Location to link out to on click. This is passed down to the custom link
   * component if one is provided.
   */
  href?: string;

  /** Target frame for item `href` link to be aimed at. */
  target?: string;

  active?: boolean;

  /** React element to appear to the left of the text. This should be an @RibbonIcon.
   * For accessibility reasons, set the label for the icon to an empty string if providing a text prop for this item.
   */
  icon?: React.ReactNode;

  /** Main text to be displayed as the item.
   * Accepts a react component but in most cases this should just be a string.
   */
  text?: React.ReactNode;

  /** Icon to be shown alongside the main `text`. */
  subIcon?: SkywiseICONS;
}

/**
 * @name RibbonItems
 * @description
 * @type [UI Presenter]
 */
export const RibbonItem: React.SFC<RibbonItemProps> = (
  props: RibbonItemProps
) => {
  const { active, icon, text, subIcon, href, target } = props;
  const classes = cx({ 'is-active': active }, 'ribbon-link');

  if (!_.isNil(target)) {
    return (
      <Link className={classes} to={target}>
        {icon && <RibbonIcon>{icon}</RibbonIcon>}
        <span className="ribbon-link__text">
          {text}
          {subIcon && (
            <DSIcon className="ribbon-link__external" type={subIcon} />
          )}
        </span>
      </Link>
    );
  }

  return (
    <a className={classes} href={href}>
      {icon && <RibbonIcon>{icon}</RibbonIcon>}
      <span className="ribbon-link__text">
        {text}
        {subIcon && <DSIcon className="ribbon-link__external" type={subIcon} />}
      </span>
    </a>
  );
};
