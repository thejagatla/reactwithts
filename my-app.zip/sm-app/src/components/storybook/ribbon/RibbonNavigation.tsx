import * as React from 'react';
import { isNil } from '../SkywiseInterface';

export interface RibbonNavigationProps {
  /** React elements display in Navigation component. This should be an @RibbonItem.
   */
  children?: React.ReactNode;
}

/**
 * @name RibbonNavigation
 * @description Component displays the list of items on the ribbon
 * @type [UI Presenter]
 */
export const RibbonNavigation: React.SFC<RibbonNavigationProps> = (
  props: RibbonNavigationProps
) => {
  const { children } = props;

  return (
    <div className="ribbon__content-nav">
      <ul className="ribbon-nav">
        {!isNil(children) &&
          React.Children.map(children, (RibbonItem: React.ReactChild) => {
            return <li className="ribbon-nav_item">{RibbonItem}</li>;
          })}
      </ul>
    </div>
  );
};
