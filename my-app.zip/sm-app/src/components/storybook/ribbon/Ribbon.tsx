import * as cx from 'classnames';
import * as React from 'react';
import { MdClose } from 'react-icons/md';
import Blanket from '../blanket/Blanket';

export interface RibbonProps {
  /** Side band header */
  logo?: React.ReactNode;

  logoAlternative?: string;

  /** Primary content. */
  children?: React.ReactNode;

  /** Controls whether or not the dropdown menu is displayed. */
  open?: boolean;

  above?: boolean;

  /**
   * Called when an open event happens.
   *
   * @param {SyntheticEvent} event - React's original SyntheticEvent.
   */
  onOpen?: (event: React.SyntheticEvent<HTMLElement>) => void;

  /**
   * Called when an close event happens.
   *
   * @param {SyntheticEvent} event - React's original SyntheticEvent.
   * @param {object} data - All props.
   */
  onClose?: (event: React.SyntheticEvent<HTMLElement>) => void;
}

interface RibbonState {
  open: boolean;
}

/**
 * @name Ribbon
 * @description Component displays the ribbon list items with the header.
 * @type [UI Presenter]
 */
export class Ribbon extends React.Component<RibbonProps, RibbonState> {
  public static defaultProps: Partial<RibbonProps> = {
    above: false
  };

  /**
   * Constructor
   * @param props props
   */
  constructor(props: any) {
    super(props);

    this.state = {
      open: false
    };

    this.handleClose = this.handleClose.bind(this);
    this.handleOpen = this.handleOpen.bind(this);
  }

  private setOpen(open: boolean) {
    this.setState({
      open
    });
  }

  public static getDerivedStateFromProps(
    nextProps: RibbonProps,
    prevState: RibbonState
  ) {
    if (nextProps.open !== prevState.open) {
      return { open: nextProps.open };
    }
    return null;
  }

  public shouldComponentUpdate(
    nextProps: any,
    nextState: any,
    nextContext: any
  ) {
    const { open } = this.state;
    return nextProps.open !== open || nextState.open !== open;
  }

  private handleOpen(e?: any): void {
    const { onOpen } = this.props;

    // Eventually, warn parent controller.
    if (onOpen && e) {
      onOpen(e);
    }

    this.setOpen(true);
  }

  private handleClose(e: any): void {
    const { onClose } = this.props;

    // Eventually, warn parent controller.
    if (onClose) {
      onClose(e);
    }
    this.setOpen(false);
  }

  private renderHeader(): React.ReactNode {
    const { logo, logoAlternative } = this.props;
    return (
      <header className="ribbon-header">
        <div className="ribbon-header__logo" title={logoAlternative}>
          {logo}
        </div>
        <button
          type="button"
          className="ribbon-header__button"
          aria-label="Close Ribbon"
          onClick={this.handleClose}
        >
          <MdClose className="ribbon-header__icon" size="1.6rem" />
        </button>
      </header>
    );
  }
  private renderBlanket(): React.ReactNode {
    const { open } = this.state;
    return <Blanket displayed={open} />;
  }

  public render() {
    const { above, children } = this.props;
    const { open } = this.state;
    const classes = cx({ 'is-opened': open, 'is-above': above }, 'ribbon');
    return (
      <React.Fragment>
        <div className={classes}>
          <div className="ribbon__container">
            {this.renderHeader()}
            <div className="ribbon__content">{children}</div>
          </div>
        </div>
        {this.renderBlanket()}
      </React.Fragment>
    );
  }
}
