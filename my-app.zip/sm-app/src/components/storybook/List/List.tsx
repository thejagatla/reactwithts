import * as classNames from 'classnames';
import * as _ from 'lodash';
import * as React from 'react';

import { getComponentType } from '@sm/skywise-react-library/dist/SkywiseInterface';
import { ListHeader } from './ListHeader';
import { ListItem, ListItemProps } from './ListItem';
import { ListList } from './ListList';

import { getUnhandledProps, isNil } from '..';

export interface ListProps {
  [key: string]: any;

  /** An element type to render as (string). */
  as?: string;

  /** Primary content. */
  children?: React.ReactNode;

  /** Additional classes. */
  className?: string;

  items?: ListItemProps[] | React.ReactNode[];
}

/**
 * File description:
 *
 * @see ListHeader
 * @see ListItem
 * @see ListList
 */
export class List extends React.Component<ListProps> {
  public static Header: typeof ListHeader;
  public static Item: typeof ListItem;
  public static List: typeof ListList;

  public static defaultProps: Partial<ListProps> = {
    as: 'div'
  };

  private renderItems() {
    const { items } = this.props;
    return _.map(items, (item: ListItemProps) => {
      if (_.isString(item)) {
        return <ListItem>{item}</ListItem>;
      }
      if (_.isPlainObject(item)) {
        return <ListItem {...item} />;
      }
      return null;
    });
  }

  public render() {
    const { children, className } = this.props;

    const classes = classNames('list', className);

    const rest = getUnhandledProps(List, this.props);
    const ComponentType = getComponentType(List, this.props);

    if (!isNil(children)) {
      return (
        <ComponentType {...rest} role="list" className={classes}>
          {children}
        </ComponentType>
      );
    }

    return (
      <ComponentType {...rest} role="list" className={classes}>
        {this.renderItems()}
      </ComponentType>
    );
  }
}

List.Header = ListHeader;
List.Item = ListItem;
List.List = ListList;
