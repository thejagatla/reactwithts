import * as classNames from 'classnames';
import * as React from 'react';

import { getComponentType } from '@sm/skywise-react-library/dist/SkywiseInterface';

export interface ListListProps {
  /** An element type to render as (string). */
  as?: string;

  /** Primary content. */
  children?: React.ReactNode;

  /** Additional classes. */
  className?: string;
}

/**
 * @name ListList
 * @description.
 * @type
 */
export const ListList: React.SFC<ListListProps> = (props: ListListProps) => {
  const { children, className } = props;

  const classes = classNames('list', className);

  const ComponentType = getComponentType(ListList, props);

  return <ComponentType className={classes}>{children}</ComponentType>;
};

ListList.defaultProps = {
  as: 'div'
};
