import * as classNames from 'classnames';
import * as React from 'react';

import {
  getComponentType,
  keyToClassName,
  SkywiseAlignSelf
} from '@sm/skywise-react-library/dist/SkywiseInterface';

export interface ListItemProps {
  /** An element type to render as (string). */
  as?: string;

  /** Primary content. */
  children?: React.ReactNode;

  /** Additional classes. */
  className?: string;

  verticalAlign?: SkywiseAlignSelf;
}

/**
 * File description:
 *
 * @see List
 */
export const ListItem: React.SFC<ListItemProps> = (props: ListItemProps) => {
  const { children, className, verticalAlign } = props;

  const classes = classNames(
    'list__item',
    keyToClassName(verticalAlign, 'list__item--' + verticalAlign),
    className
  );

  const ComponentType = getComponentType(ListItem, props);

  return (
    <ComponentType role="listitem" className={classes}>
      {children}
    </ComponentType>
  );
};

ListItem.defaultProps = {
  as: 'div'
};
