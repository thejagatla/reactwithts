import * as classNames from 'classnames';
import * as React from 'react';

import { getComponentType } from '@sm/skywise-react-library/dist/SkywiseInterface';

export interface ListHeaderProps {
  /** An element type to render as (string). */
  as?: string;

  /** Primary content. */
  children?: React.ReactNode;

  /** Additional classes. */
  className?: string;
}

/**
 * File description:
 *
 * @see List
 */
export const ListHeader: React.SFC<ListHeaderProps> = (props: ListHeaderProps) => {
  const {
    children,
    className,
  } = props;

  const classes = classNames(
    'list__header',
    className
  );

  const ComponentType = getComponentType(ListHeader, props);

  return (
    <ComponentType className={classes}>
      {children}
    </ComponentType>
  );
};

ListHeader.defaultProps = {
  as: 'div'
};
