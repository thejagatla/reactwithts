/**
 * File description: DS Card listing
 *
 * @author Capgemini
 * @version 1.0
 */
import { DSCard } from '@sm/skywise-react-library';
import * as clasNames from 'classnames';
import * as React from 'react';

export interface DSCardListingProps {
  /** Primary content. */
  children?: any;

  /** Additional classes. */
  className?: string;
}

export class DSCardListing extends React.Component<DSCardListingProps> {
  public static Card: typeof DSCard;

  public render() {
    const {
      children,
      className
    } = this.props;

    const classes = clasNames(
      className,
      'ds-card-listing'
    );

    return(
      <ul className={classes}>
        {React.Children.map(children, (card) => {
          return (
            <li className="ds-card-listing__item">
              {card}
            </li>
          );
        })}
      </ul>
    );
  }
}

DSCardListing.Card = DSCard;
