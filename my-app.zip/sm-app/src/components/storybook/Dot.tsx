import * as classNames from 'classnames';
import * as React from 'react';

import { getComponentType, keyToClassName } from '@sm/skywise-react-library/dist/SkywiseInterface';

export type DotColor =
  | 'red'
  | 'orange'
  | 'yellow'
  | 'grey'
  | 'light-grey';

interface DotProps {
  /** An element type to render as (string). */
  as?: string;

  /** Additional classes. */
  className?: string;

  /** A Dot can be formatted to be different colors. */
  color?: DotColor;
}

/**
 * @name Dot
 * @description Dot can be display a value (number) in circle shape.
 * @example
 * <Dot color="red" size="small"/>
 */
export const Dot: React.SFC<DotProps> = (props: DotProps) => {
  const {
    className,
    color,
  } = props;

  const classes = classNames(
    'dot',
    keyToClassName(color, 'is-' + color),
    className
  );

  const ComponentType = getComponentType(Dot, props);

  return (
    <ComponentType className={classes}>
      <React.Fragment/>
    </ComponentType>
  );
};

Dot.defaultProps = {
  as: 'span'
};
