import * as classNames from 'classnames';
import * as React from 'react';
import { getUnhandledProps } from '..';

export interface StepperTrackerStepProps {
  [key: string]: any;

  /** Primary content. */
  children?: React.ReactNode;

  /** Additional classes. */
  className?: string;
}

/**
 * File description:
 *
 * @see Card
 */
export const StepperTrackerStep: React.SFC<StepperTrackerStepProps> = (props: StepperTrackerStepProps) => {
  const {
    children,
    className,
  } = props;

  const classes = classNames(
    'stepper-tracker--step',
    className
  );

  const rest = getUnhandledProps(StepperTrackerStep, props);

  return (
    <div {...rest} className={classes}>
      {children}
    </div>
  );
};
