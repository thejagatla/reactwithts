import { DSIcon } from '@sm/skywise-react-library';
import { SkywiseICONS } from '@sm/skywise-react-library/dist/SkywiseInterface';
import * as classNames from 'classnames';
import * as _ from 'lodash';
import * as React from 'react';

interface StepperTrackerProps {
  unit?: string;
  line?: {
    start: number;
    size: number;
  };
  // start?: number;
  total?: number;
  items?: StepperTrackerStep[];
  className?: string;
}

export interface StepperTrackerStep {
  icon?: SkywiseICONS;
  timelineRatio?: number;
}

/**
 * @name StepperTracker
 * @description .
 * @example
 * <StepperTracker/>
 */
export class StepperTracker extends React.Component<StepperTrackerProps, any> {

  private renderStep(step: StepperTrackerStep, key: number): any {

    const { unit } = this.props;

    const classes = classNames(
      'progress-tracker--item',
      'p-' + step.timelineRatio
    );
    const itemStyle = {
      left: `calc(${unit} * ${step.timelineRatio} + ${unit}/2)`,
    };

    return (
      <li className={classes} style={itemStyle} key={key}>
        <DSIcon type={step.icon}/>
      </li>
    );
  }

  private renderLine(): React.ReactNode | void {
    const { line, unit } = this.props;

    if (_.isNil(line) || _.isNil(line.size) || line.size === 0) {
      return;
    }

    const { start, size } = line;
    const lineStyle = {
      marginLeft: `calc(${unit} * ${start}`,
      width: `calc(${unit} * ${size}`
    };

    const classes = classNames(
      'progress-tracker--line',
      'start-' + start,
      'size-' + size
    );

    return (
      <li className={classes} style={lineStyle}>
        <React.Fragment/>
      </li>
    );

  }

  /**
   * Rendering method
   */
  public render() {
    const { unit, total, items, className } = this.props;

    const classes = classNames(
      'progress-tracker',
      className
    );
    let trackerStyle = null;

    trackerStyle = {
      width: `calc(${unit} * ${total}`
    };

    return (
      <ol className={classes} style={trackerStyle}>
        {this.renderLine()}
        {!_.isNil(items) && _.map(items, (item, key) => this.renderStep(item, key))}
      </ol>
    );
  }
}
