import { DSFormGroup } from '@sm/skywise-react-library';
import * as cx from 'classnames';
import * as React from 'react';

export interface SelectOption {
  label: string;
  value: string;
}

export interface InputFileProps {
  /** Additional classes. */
  className?: string;

  /** A unique identifier. */
  id: string;

  /** A label */
  label?: string;

  buttonLabel?: string;

  /**
   * Called when file is selected.
   *
   * @param {ChangeEvent<HTMLSelectElement>} event - React's original ChangeEvent.
   */
  handleChange?(event: React.ChangeEvent<HTMLInputElement>): void;
}

export interface InputFileState {
  fileName: string;
}

export default class InputFile extends React.Component<
  InputFileProps,
  InputFileState
> {
  constructor(props: InputFileProps) {
    super(props);
    this.state = {
      fileName: ''
    };

    this.onChange = this.onChange.bind(this);
  }
  private onChange(e?: React.ChangeEvent<HTMLInputElement>): void {
    const { handleChange } = this.props;
    const files: FileList = e.target.files;

    if (files.length) {
      this.setState({ fileName: files.item(files.length - 1).name });
    }
    if (handleChange && e) {
      // Eventually, warn parent controller.
      handleChange(e);
    }
  }

  public render() {
    const { buttonLabel, className, id, label } = this.props;

    return (
      <DSFormGroup className={cx(className)}>
        <label htmlFor={id} className={cx('ds-label')}>
          {label}
        </label>
        <div className="input-file">
          <input type="file" onChange={this.onChange} id={id} />
          <label className="input-file__label" htmlFor={id}>
            <span>{this.state.fileName}</span>
            <strong>{buttonLabel ? buttonLabel : `Select a file`}</strong>
          </label>
        </div>
      </DSFormGroup>
    );
  }
}
