/**
 * File description: DSRadio rendering component
 * @author Capgemini
 * @version 1.0
 */
import * as classNames from 'classnames';
import * as React from 'react';

export interface RadioProps {
  /** The text display in the label element. */
  label: string;

  /** Group radio buttons with a same name. */
  name: string;

  /** A unique identifier. */
  id: string;

  /** Value of the HTML input. */
  value?: string;

  /** A radio button can appear disabled. */
  isDisabled?: boolean;

  /** Whether or not checkbox is checked. */
  isChecked?: boolean;

  /** Additional classes. */
  className?: string;
  forInline?: boolean;
  /**
   * Called when user clicks on a radio button.
   *
   * @param {ChangeEvent<HTMLInputElement>} event - React's original ChangeEvent.
   */
  handleChange?(event: React.ChangeEvent<HTMLInputElement>): void;
}

export const DSRadio: React.SFC<RadioProps> = (props: RadioProps) => {

  const classes = classNames(
    { 'ds-form-group': props.forInline },
    'ds-radio',
    props.className,
  );

  return (
    <div className={classes}>
      <input
        type="radio"
        id={props.id}
        value={props.value}
        name={props.name}
        onChange={props.handleChange}
        aria-checked={props.isChecked}
        checked={props.isChecked}
        disabled={props.isDisabled}
      />
      <label htmlFor={props.id}>{props.label}</label>
    </div>
  );
};

DSRadio.defaultProps = {
  isChecked: false,
  isDisabled: false
};

DSRadio.displayName = 'DSRadio';
