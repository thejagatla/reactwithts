/**
 * File description: A checkbox allows a user to select a value from a small set of options
 * @author Capgemini
 * @version 1.0
 */
import * as classNames from 'classnames';
import * as React from 'react';

interface CheckboxProps {
  label: string;
  isChecked: boolean;
  handleCheckboxChange(pEvent: React.FormEvent<HTMLInputElement>): void;
  isDisabled?: boolean;
  isIndeterminate?: boolean;
  type?: string; // future function that will permits to define className.
  id: string;
}

export const Checkbox: React.SFC<CheckboxProps> = (props: CheckboxProps) => {
  const classes = classNames({
    'ds-checkbox': true,
  });

  return (
    <div className={classes}>
      <input
        type="checkbox"
        id={props.id}
        aria-checked={props.isChecked}
        checked={props.isChecked}
        disabled={props.isDisabled}
        onChange={props.handleCheckboxChange}
      />
      <label htmlFor={props.id}>{props.label}</label>
    </div>
  );
};

Checkbox.displayName = 'Checkbox';
Checkbox.defaultProps = { isDisabled: false, isIndeterminate: true };
