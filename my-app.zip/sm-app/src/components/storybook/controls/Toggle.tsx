/**
 * File description: Toggle component
 * @author Capgemini
 * @version 1.0
 */
import * as classNames from 'classnames';
import * as React from 'react';

interface ToggleProps {
  text: string | any;
  size?: 'normal' | 'small';
  type?: 'regular' | 'dark';
  isChecked?: boolean;
  id?: string;
  ariaLabel?: string;
  className?: string;
  handleChange(value: any): void;
}

export const Toggle: React.SFC<ToggleProps> = (props: ToggleProps) => {
  const toggleClass = classNames({
    'ds-form-group ds-toggles': typeof props.type !== 'undefined' || typeof props.size !== 'undefined',
    'ds-toggles--dark': props.type === 'dark',
    'ds-toggles--small': props.size === 'small',
    [`${props.className}`]: typeof props.className !== 'undefined'
  });

  return (
    <div className={toggleClass}>
      <input
        type="checkbox"
        id={props.id}
        name="togglesfield"
        onChange={props.handleChange}
        defaultChecked={props.isChecked}
        aria-label={props.ariaLabel}
      />
      <div className="ds-label-wrapper">
        <label>{props.text}</label>
      </div>
    </div>
  );
};

Toggle.defaultProps = { isChecked: false };
