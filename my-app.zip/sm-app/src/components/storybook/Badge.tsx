import * as classNames from 'classnames';
import * as _ from 'lodash';
import * as React from 'react';

import { getComponentType, keyToClassName } from '@sm/skywise-react-library/dist/SkywiseInterface';
import { SkywiseSIZES } from '.';

export type BadgeColor =
  | 'red'
  | 'orange'
  | 'yellow'
  | 'grey'
  | 'light-grey';

interface BadgeProps {
  /** An element type to render as (string). */
  as?: string;

  basic?: boolean;

  /** . */
  children?: number;

  /** Additional classes. */
  className?: string;

  /** A Badge can be formatted to be different colors. */
  color?: BadgeColor;

  /** Badge can be have different size. */
  size?: SkywiseSIZES;
}

/**
 * @name Badge
 * @description Badge can be display a value (number) in circle shape.
 * @example
 * <Badge color="red" basic={true} size="small">1</Badge>
 */
export const Badge: React.SFC<BadgeProps> = (props: BadgeProps) => {
  const {
    basic,
    children,
    className,
    color,
    size
  } = props;

  const classes = classNames(
    'badge',
    {
      'badge--basic': basic,
      'badge--with-number': _.isNumber(children) && Math.floor(children / 10) > 0
    },
    keyToClassName(color, 'is-' + color),
    keyToClassName(size, 'badge--' + size),

    className
  );

  const ComponentType = getComponentType(Badge, props);

  return (
    <ComponentType className={classes}>
      {children}
    </ComponentType>
  );
};

Badge.defaultProps = {
  as: 'span',
  basic: true
};
