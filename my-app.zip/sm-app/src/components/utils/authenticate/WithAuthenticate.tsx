import * as React from 'react';
import { CognitoState } from 'react-cognito';
import { connect } from 'react-redux';
// import { Redirect } from 'react-router-dom';
import { ONELOGIN_LOGGED_IN } from '../../../store/actions/LoginActions';

import { push } from 'react-router-redux';

/**
 * @name WithAuthenticate
 * @description HOC that handles whether or not the user is allowed to see the component/function passed.
 * @example
 * export default AuthorizationHOC(['admin'],() => ('<div>Unauthorized</div>'))(Component);
 */
export default function(WrappedComponent: any, redirectNoAcces?: string) {
  // return WrappedComponent => {
  class WithAuthenticate extends React.Component<any, any> {
    public componentDidMount() {
      this.checkAndRedirect();
    }

    public componentDidUpdate() {
      this.checkAndRedirect();
    }

    private checkAndRedirect() {
      const { cognito, oneLogin } = this.props;

      if (
        cognito.state === CognitoState.LOGGED_IN ||
        oneLogin.state === ONELOGIN_LOGGED_IN
      ) {
        if (redirectNoAcces) {
          push(redirectNoAcces);
        }
        push('login');
      }
    }

    public render() {
      if (this.props.isAuthenticated) {
        return <WrappedComponent {...this.props} />;
      }
      return null;
    }
  }

  return connect((state: any) => {
    return {
      cognito: state.cognito && state.cognito.state,
      oneLogin: state.oneLogin && state.oneLogin.state
    };
  })(WithAuthenticate);
  // };
}
