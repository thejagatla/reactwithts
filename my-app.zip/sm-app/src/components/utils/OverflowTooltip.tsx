/**
 * Class description:
 * @author Capgemini
 * @version 1.0
 */
import * as React from 'react';
import * as ReactDOM from 'react-dom';

interface OverflowTooltipProps {
  /** Minimum number of pixels between the size of the displayed element and the overflow. */
  minDiff?: number;
  /** Permits to defines the type of overflow inspected. */
  overflowType?: 'height' | 'width' | 'both';
  /** The title displayed. */
  title?: string;
}
export class OverflowTooltip extends React.Component<OverflowTooltipProps, any> {
  /**
   * Constructor
   * @param props React props
   */
  constructor(props: any) {
    super(props);

    this.state = {
      overflow: false
    };
  }

  public componentDidMount() {
    this.checkOverflow();
  }

  public componentWillReceiveProps() {
    this.setState({ overflow: false });
  }

  public componentDidUpdate() {
    this.checkOverflow();
  }

  private isTextOverflow(element: any) {
    const { minDiff, overflowType } = this.props;
    const diff = minDiff !== undefined ? minDiff : 0;
    const clientHeight = element.clientHeight + diff;
    const clientWidth = element.clientWidth + diff;
    switch (overflowType) {
      case 'height':
        return clientHeight < element.scrollHeight;
      case 'width':
        return clientWidth < element.scrollWidth;
      default:
        return (clientHeight < element.scrollHeight) || (clientWidth < element.scrollWidth);
    }
  }

  public checkOverflow() {
    const element = ReactDOM.findDOMNode(this);

    const lOverflow = this.isTextOverflow(element);
    if (lOverflow !== this.state.overflow) {
      this.setState({ overflow: lOverflow });
    }
  }

  public render() {
    const childProps = { title: '' };
    if (this.state.overflow) {
      childProps.title = this.props.title;
    }

    return React.cloneElement(
      React.Children.only(this.props.children),
      childProps
    );
  }
}
