import * as React from 'react';
import { connect } from 'react-redux';
import { checkPermissions } from './AuthorizationUtils';

/**
 * @name withAuthorization
 * @description HOC that handles whether or not the user is allowed to see the component/function passed.
 * @example
 * export default AuthorizationHOC(['admin'],() => ('<div>Unauthorized</div>'))(Component);
 */
export default function withAuthorization(allowedPermissions: string[], renderNoAccess?: any) {
  return (WrappedComponent) => {
    class WithAuthorization extends React.Component<any, any> {

      constructor(props: any) {
        super(props);
      }

      public render() {
        const { userPermissions } = this.props;
        const permitted = checkPermissions(userPermissions, allowedPermissions);

        if (permitted) {
          return <WrappedComponent {...this.props} />;
        }
        return renderNoAccess();
      }
    }

    return connect((state: any) => {
      return { userPermissions: state.userProfile && state.userProfile.allowedActions };
    })(WithAuthorization);
  };
}
