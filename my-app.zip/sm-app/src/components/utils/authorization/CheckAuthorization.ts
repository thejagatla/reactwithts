import { connect } from 'react-redux';
import { checkPermissions } from './AuthorizationUtils';

/**
 * @name CheckAuthorization
 * @description RenderProps that handles whether or not the user is allowed to see the component/function passed.
 * @example
 * <CheckAuthorization allowedPermissions={["admin"]} renderNoAccess={() => <div>Unauthorized</div>}>
 *   {() => <Component />}
 * </CheckAuthorization>;
 */
const CheckAuthorization = ({
  userPermissions,
  allowedPermissions,
  renderNoAccess,
  children
}) => {
  const permitted = checkPermissions(userPermissions, allowedPermissions);

  if (permitted) {
    return children;
  }
  return renderNoAccess();
};

// Compose CheckAuthorization component with redux.
export default connect((state: any) => ({
  userPermissions: state.userProfile && state.userProfile.allowedActions
}))(CheckAuthorization);
