export const checkPermissions = (userPermissions, allowedPermissions) => {
  if (allowedPermissions.length === 0) {
    return true;
  }

  if (userPermissions.length === 0) {
    return false;
  }
  return userPermissions.some(permission =>
    allowedPermissions.includes(permission)
  );
};
