import { connect } from 'react-redux';
import { checkFeatureFlipping } from './FeatureFlippingUtils';

/**
 * @name CheckFeatureFlipping
 * @description RenderProps that handles whether or not display the component/function passed.
 * @example
 * <CheckFeatureFlipping feature={'featureName'}>
 *   {isActive => (
 *     {isActive && <Component/>}
 *   )}
 * </CheckFeatureFlipping>
 * <CheckFeatureFlipping feature={['featureName1', 'featureName2']}>
 *   {({featureName1, featureName2}) => (
 *     {featureName1 && <Component1/>}
 *     {featureName2 && <Component2/>}
 *   )}
 * </CheckFeatureFlipping>
 */
const CheckFeatureFlipping = ({ enabledFeatures, feature, children }) => {
  const features = checkFeatureFlipping(enabledFeatures, feature);
  return children(features);
};

// Compose CheckFeature component with redux.
export default connect((state: any) => ({
  enabledFeatures:
    state.enabledFeaturesReducer && state.enabledFeaturesReducer.enabledFeatures
}))(CheckFeatureFlipping);
