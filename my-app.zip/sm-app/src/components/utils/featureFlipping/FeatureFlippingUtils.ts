export const checkFeatureFlipping = (enabledFeatures, checkFeature) => {
  if (enabledFeatures.length === 0) {
    return false;
  }

  if (typeof checkFeature === 'string') {
    return enabledFeatures.includes(checkFeature);
  }
  const features = [];
  checkFeature.forEach(feature => {
    features[feature] = enabledFeatures.includes(feature);
  });
  return features;
};
