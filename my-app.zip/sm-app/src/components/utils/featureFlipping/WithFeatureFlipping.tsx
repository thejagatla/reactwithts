import * as React from 'react';
import { connect } from 'react-redux';
import { checkFeatureFlipping } from './FeatureFlippingUtils';

/**
 * @name WithFlippingFeature
 * @description HOC that handles whether or not display the component/function passed.
 * @example
 * export default WithFlippingFeature(['featureName'])(ComponentName);
 */
export default function withFeatureFlipping(feature: string) {
  return WrappedComponent => {
    class WithFeatureFlipping extends React.Component<any, any> {
      public render() {
        const { enabledFeatures } = this.props;
        const renderFlippingFeature = checkFeatureFlipping(
          enabledFeatures,
          feature
        );

        if (renderFlippingFeature) {
          return <WrappedComponent {...this.props} />;
        }
        return null;
      }
    }

    // Connect HOC to redux store
    return connect((state: any) => {
      return {
        enabledFeatures:
          state.enabledFeaturesReducer &&
          state.enabledFeaturesReducer.enabledFeatures
      };
    })(WithFeatureFlipping);
  };
}
