/**
 * Class description: Error modal rendering component
 * @author Capgemini
 * @version 1.0
 */
import { DSLink, DSModal } from '@sm/skywise-react-library';
import * as React from 'react';
import * as reactStringReplace from 'react-string-replace';
import * as Strings from '../../../lang/strings.json';

import { isEmpty } from 'lodash';

export interface ErrorModalProps {
  languageInfo?: string[];
  traceId?: string;
  techRequestUrl?: string;
  message?: string;
  UnauthorizedAccess?: boolean;
}

export const ErrorModalView: React.SFC<ErrorModalProps> = (props: ErrorModalProps) => {

  const renderModalContent = (): JSX.Element => {
    const {
      languageInfo,
      traceId,
      techRequestUrl,
      message,
      UnauthorizedAccess
    } = props;

    if (UnauthorizedAccess) {
      return (
        <React.Fragment>
          <p>{message}</p>
        </React.Fragment>
      );
    }

    let replacedMessage;
    replacedMessage = Strings.errorModal.errorModalMessage.replace('%traceId', traceId);
   
    if (message === undefined) {
      replacedMessage = replacedMessage.replace('%message', '');
    } else {
      replacedMessage = replacedMessage.replace('%message', message);
    }
    replacedMessage = reactStringReplace(replacedMessage, '\n', (match, i) => (
      <br key={match + i} />
    ));
    replacedMessage = reactStringReplace(replacedMessage, '%techRequest', (match, i) => (
      <DSLink key={match + i} href={techRequestUrl} target="_blank">
        {Strings.errorModal.errorModalRequestName}
      </DSLink>
    ));

    return (
      <React.Fragment>
        <p>{replacedMessage}</p>
        {!isEmpty(languageInfo) &&
          <React.Fragment>
            {reactStringReplace(Strings.errorModal.errorModalContactMessage, '\n', (match, i) => (
              <br key={match + i} />
            ))}
            <ul>
              {languageInfo.map((lang, index) => {
                return (<li key={lang + index}>{lang}</li>);
              })}
            </ul>
          </React.Fragment>
        }
      </React.Fragment>
    );
  };

  return (
    <DSModal
      modalTitle={Strings.errorModal.errorModalTitle}
      withForm={false}
      modalContent={renderModalContent()}
      modalFooter="" // TODO: needs to be deleted when modalFooter prop will no longer be required.
    />
  );
};
