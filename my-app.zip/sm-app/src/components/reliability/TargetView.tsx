import * as React from 'react';

interface TargetViewProps {
  alertTargetName: string;
  alertTargetValue: string;
  alertTargetUnit?: string;
}

/**
 * Class description: Target Cell rendering component (SRS)
 * @author Capgemini
 * @version 1.0
 */
export const TargetView = (props: TargetViewProps) => {
  const targetUnit = (props.alertTargetUnit !== undefined) && props.alertTargetUnit;
  return (
    <div className="event-shortinfo__target">
      <label>{props.alertTargetName}:</label> {props.alertTargetValue}{targetUnit}
    </div>
  );
};

TargetView.displayName = 'TargetView';
