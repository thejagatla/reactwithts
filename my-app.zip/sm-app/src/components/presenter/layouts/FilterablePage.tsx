import * as React from 'react';

interface FilterablePageProps {
  filters?: React.ReactNode;
  title?: React.ReactNode;
  search?: React.ReactNode;
  sort?: React.ReactNode;
  children?: React.ReactNode;

}

/**
 * Class description: A page view that permit to display a filterable list.
 *
 * Component Type: UI Presenter
 * TODO: main doit etre sorti au niveau de App (template général de page)
 *
 */
export const FilterablePage: React.SFC<FilterablePageProps> = (props: FilterablePageProps) => {
  return (
    <div className="filterable-page">
      <div className="filterable-page__filters">
        {props.filters}
      </div>
      <div className="filterable-page__content">
        <div className="filterable-page__head-content">
          <div className="filterable-page__title">
            {props.title}
          </div>
          <div className="filterable-page__search">
            {props.search}
          </div>
          <div className="filterable-page__sort">
            {props.sort}
          </div>
        </div>
        <div className="filterable-page__list" role="main">
          {props.children}
        </div>
      </div>
    </div>
  );
};
