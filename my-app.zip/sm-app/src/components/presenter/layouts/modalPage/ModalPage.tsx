import * as cx from 'classnames';
import * as React from 'react';
import { MdClose } from 'react-icons/md';

interface Props {
  /** */
  children?: React.ReactNode;

  title?: string;

  /**
   * Called when an close event happens.
   *
   * @param {SyntheticEvent} event - React's original SyntheticEvent.
   */
  onClose?: (event: React.SyntheticEvent<HTMLElement>) => void;
}

/**
 * @name ModalPage
 * @description .
 * @type [UI Presenter]
 */
export class ModalPage extends React.Component<Props, any> {
  /**
   * Constructor
   * @param props props
   */
  constructor(props: any) {
    super(props);
    this.handleClose = this.handleClose.bind(this);
  }
  private handleClose(e: any): void {
    const { onClose } = this.props;

    // Eventually, warn parent controller.
    if (onClose) {
      onClose(e);
    }
  }

  public render() {
    const classes = cx('is-opened', 'modal-page');
    return (
      <div className={classes}>
        <div className="modal-page__header">
          <h3 className="modal-page__title">{this.props.title}</h3>
          <button
            type="button"
            className="modal-page__close-button"
            aria-label="Close"
            onClick={this.handleClose}
          >
            <MdClose className="close-icon" size="1.6rem" />
          </button>
        </div>
        <div className="modal-page__container">{this.props.children}</div>
      </div>
    );
  }
}

export default ModalPage;
