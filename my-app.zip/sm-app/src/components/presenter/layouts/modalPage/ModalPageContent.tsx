import * as React from 'react';

import PageHeader from '../../patterns/PageHeader';

interface Props {
  /** . */
  actions?: React.ReactNode;

  /** The contents of the page. Takes our layouts components. */
  children?: React.ReactNode;
  /** */
  title?: string;

  /** Display list of messages. Use react component Message (existe pas encore) */
  messages?: React.ReactNode;
}

/**
 * @name ModalPageContent
 * @description .
 * @type [UI Presenter]
 */
const ModalPageContent = (props: Props) => {
  return (
    <div className="modal-page__content">
      <PageHeader
        className="modal-page__section-header"
        actions={props.actions}
      >
        {props.title}
      </PageHeader>
      <div className="admin-content__section-content">{props.children}</div>
    </div>
  );
};

export default ModalPageContent;
