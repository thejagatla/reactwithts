import * as React from 'react';
// import { List } from '../../../storybook/List/List';

interface Props {
  /** The contents of the page. Takes our layouts components. */
  children?: React.ReactNode;

  // items?: ModalPageSideBandItems;
}

/**
 * @name ModalPageSideBand
 * @description .
 * @type [UI Presenter]
 */
const ModalPageSideBand = (props: Props) => {
  return (
    <div className="modal-page__sideband">
      {props.children}
      {/* {React.Children.count(props.children) !== 0 && (
        <List as="ul">
          {React.Children.map(props.children, child => {
            if (!child) {
              return null;
            }
            return <List.Item as="li">{child}</List.Item>;
          })}
        </List>
      )} */}
    </div>
  );
};

export default ModalPageSideBand;
