import * as React from 'react';

interface Props {
  /** Contents of the action bar to be rendered next to the page title. */
  actions?: React.ReactNode;
  /** Content of the page title. */
  children?: React.ReactNode;

  className?: string;
  /** Prevent the title from wrapping across lines */
}

/**
 * @name PageHeader
 * @description The page header pattern.
 * @type [UI Presenter]
 */
const PageHeader = (props: Props) => {
  return (
    <div className={'page-header ' + props.className}>
      <div className="page-header__title-wrapper">
        <div className="page-header__title-container">
          <div className="page-header__title">{props.children}</div>
        </div>
        <div className="page-header__action">{props.actions}</div>
      </div>
    </div>
  );
};

export default PageHeader;
