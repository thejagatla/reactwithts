import { isNil } from 'lodash';
import * as React from 'react';

interface Props {
  /** The site have a header. */
  header?: React.ReactNode;
  /** The contents of the page. Takes our layouts components. */
  children?: React.ReactNode;
  /** */
  navigation?: React.ReactNode;
}

/**
 * @name Page
 * @description The main structure of page layout.
 * @type [UI Presenter]
 */
export const Page: React.SFC<Props> = (props: Props) => {
  return (
    <div className="l-page">
      {!isNil(props.navigation) && (
        <div className="l-page--navigation">{props.navigation}</div>
      )}
      <div className="l-page--main">
        {!isNil(props.header) && (
          <header className="l-header l-page--header" role="banner" id="header">
            {props.header}
          </header>
        )}
        <div className="l-page--content">{props.children}</div>
      </div>
    </div>
  );
};
