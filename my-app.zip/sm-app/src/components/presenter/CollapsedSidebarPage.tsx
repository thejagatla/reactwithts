import * as classNames from 'classnames';
import * as React from 'react';
import { DSPanel } from '../storybook/DSPanel';

interface CollapsedSidebarPageProps {
  content?: React.ReactNode;
  sidebarContent?: React.ReactNode;
  sidebarHeader?: string;
}

/**
 * Class description: A page view that permit to display some content with a collapsed sidebar.
 *
 * Component Type: UI Presenter
 * TODO: main doit etre sorti au niveau de App (template général de page)
 *
 */
export class CollapsedSidebarPage extends React.Component<CollapsedSidebarPageProps, any> {
  /**
   * Constructor
   * @param props props
   */
  constructor(props: any) {
    super(props);

    this.state = {
      collapsed: true
    };

    this.handleToggle = this.handleToggle.bind(this);
  }

  private handleToggle() {
    this.setState({
      collapsed: !this.state.collapsed
    });
  }

  public render() { 
    const pageClasses = classNames({
      'sidebar-visible': !this.state.collapsed,
      'sm-collapsed-sidebar-page__content': true
    });

    return (
      <React.Fragment>
        <div className={pageClasses}>
          {this.props.content}
        </div>
        {this.props.sidebarContent || this.props.sidebarHeader &&
          <DSPanel
            collapsed={this.state.collapsed}
            handleToggle={this.handleToggle}
            header={this.props.sidebarHeader}
          >
            {this.props.sidebarContent}
          </DSPanel>
        }
      </React.Fragment>
    );
  }
}
