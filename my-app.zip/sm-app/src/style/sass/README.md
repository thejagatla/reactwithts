# <div style="color:red;padding: 4px 8px;margin: 20px;border: 2px solid red;text-align:center;"> !!! IN PROGRESS !!! </div>
# Skywise HTML and CSS/SASS Styleguide

*A style guide inspire by the front-end community and update for our project's needs.  
All following rules can be in addition to the SonarQube rules but doesn't cancel them.*

## Preface


## Table of contents

1. [General](#general)
2. [HTML](#html)
    - [HTML5 elements](#html5)
    - [Number of classes](#number-classes)
    - [Target _blank](#target-blank)
    - [Divide](#divide)
    - [Divide](#divide)
3. [CSS](#css)
    - [Comments](#comments)
    - [Global Policy of CSS selectors](#global-policy)
    - [Namespacing](#namespacing)
    - [Border](#border)
    - [Flux](#flux)
    - [Positionning](#positionning)
    - [ID Selectors](#id-selectors)
    - [Selectors weight](#selectors-weight)
    - ["Structural" selectors](#structural-selectors)
    - [Structure vs Appearance](#structure-vs-appearance)
    - [Overload](#overload)
    - [Shorthand properties](#structural-selectors)
	  - [Units](#structural-selectors)
	  - [Performant animations](#performant-animations)
    - [OOCSS and BEM](#oocss-and-bem)
4. [Sass](#sass)
    - [Syntaxe](#syntaxe)
	  - [Duplication](#duplication)
    - [Variables](#variables)
    - [Extend directive](#extend-directive)
    - [Nested selectors](#nested-selectors)

## General

* File encoding must be in UTF-8 (without BOM)
* Use soft tabs (2 spaces) for indentation
* Use dashes over camelCasing in class names
* Do not use ID selectors
* When using multiple selectors in a rule declaration, give each selector its own line.
* As much as possible, prefer the syntax via shortened properties: margin, padding, font, border, background, border-radius
* Do not specify unit for null values and for line heights: margin: 0; line-height: 1.5

## HTML

### HTML5 elements

Prefer use HTML5 `<header>`, `<article>`, `<main>`, `<footer>`, `<aside>`, `<section>` and `<nav>` elements if it possible instead of `<div>` element.

### Number of classes

Try not to exceed four class names per HTML element. Beyond that, you must be creates a custom class.

**Bad**
```html
<div class="clearfix ds-left mlm mrm ds-col-12 ds-text-hide"></div>
```
**Good**
```html
<div class="my-component"></div>
```
### Target _blank

Avoid as much as possible the use of links opening a new window / tab without explicitly reporting it because they disturb navigation and can create security vulnerabilities.  
**Always use `rel="noopener noreferrer"` on links `target="_blank"`.**

See [https://medium.com/@jitbit/target-blank-the-most-underestimated-vulnerability-ever-96e328301f4c](https://medium.com/@jitbit/target-blank-the-most-underestimated-vulnerability-ever-96e328301f4c)

## CSS

### Comments

* Prefer line comments (// in Sass-land) to block comments.
* Prefer comments on their own line. Avoid end-of-line comments.
* Write detailed comments for code that isn't self-documenting:
  * Uses of z-index
  * Compatibility or browser-specific hacks

### Global Policy of CSS selectors

Be sure to target elements regardless of their context, such as a module or component, so that they keep their styles even when they are moved from their contexts.

* Prefer to use HTML classes to select elements, for example `.h2-like`
* D'ont use ID selector because they introduce an unnecessarily high level of [specificity](https://developer.mozilla.org/en-US/docs/Web/CSS/Specificity) to your rule declarations.
* Avoid using cascaded selectors: `div.header ul.nav li a.link`

### Namespacing

Prefer define your own classes for your project rather than redefining design classes.  
Use `sm` prefix for Skywise Monitoring.

**Bad :**

```html
<ul class="ds-tabs ds-tabs--stepping">...</ul>
```

**Good :**

```html
<ul class="ds-tabs sm-tabs--stepping">...</ul>
```

### Border

Use `0` instead of `none` to specify that a style has no border.

**Bad :**
```css
.foo {
  border: none;
}
```

**Good :**
```css
.foo {
  border: 0;
}
```
**[⬆ Retour en haut](#table-des-matieres)**

### Flux

Avoid to get elements out of the stream (`float`, `position`) unnecessarily.

**Bad :**
```css
.my-class {
  position: absolute;
  right: 0;
}
```

**Good :**
```css
.my-class {
  margin-left: auto;
}
```
### Positionning

Position elements by choosing among these methods, in order:
1. <span style="background-color:#119447;padding: 4px 8px;">display: block | inline;</span>

2. <span style="background-color:#119447;padding: 4px 8px">display: flex | inline-flex;</span>
3. <span style="background-color:#d37127;padding: 4px 8px">display: inline-block | table-cell;</span>
4. <span style="background-color:#d6732f;padding: 4px 8px; font-size: 1.1em: letter-spacing: 1.3em">float: left | right;</span>
5. <span style="background-color:#c53b29;padding: 4px 8px">position: relative | absolute | sticky | fixed;</span>

### ID Selectors

While it is possible to select elements by ID in CSS, it should generally be considered an anti-pattern. ID selectors introduce an unnecessarily high level of [specificity](https://developer.mozilla.org/en-US/docs/Web/CSS/Specificity) to your rule declarations, and they are not reusable.

For more on this subject, read [CSS Wizardry's article](http://csswizardry.com/2014/07/hacks-for-dealing-with-specificity/) on dealing with specificity.

### Selectors weight

Avoid overloading a selector because it adds weight unnecessarily.

**Bad :**
```css
ul.nav li a.navlink {
  …
}
```

**Good :**
```css
.navlink {
  …
}
```

**Bad :**
```css
input[type="submit"] {
…
}
```

**Good :**
```css
[type="submit"] {
…
}
```

Documentation: [http://cssspecificity.com/](http://cssspecificity.com/)

### "Structural" selectors

Avoid selectors associated with the HTML structure, an element must be able to be targeted regardless of its container or its location in the DOM.

**Bad :**
```css
div > h1 + p {
  …
}
```

**Good :**
```css
.intro {
  …
}
```

**Bad :**
```css
#navigation h2, #sidebar h2 {
  …
}
```

**Good :**
```css
.h2-like {
  …
}
```

### Structure vs Appearance

Try to separate the structure of the appearance in the selectors to facilitate factorization (for example do not mix `padding` and `background`).
Create reusable base styles, and then graphic variant classes.

**Bad**

```css
.button {
  display: inline-block;
  padding: 1em;
  background: pink;
  color: white;
}
```

**Good**
```css
.button {
  display: inline-block;
}
.button-big {
  padding: 1em;
}
.button-primary {
  background: pink;
  color: white;
}
```

### Overload

Avoid overwriting one rule by another.

**Bad**

```css
li {
  visibility: hidden;
}
li:first-child {
  visibility: visible;
}
```

**Good**

```css
li:not(:first-child) {
  visibility: hidden;
}
```

Documentation : https://github.com/bendc/frontend-guidelines#overriding

### Shorthand properties

Prefer use shortened properties.

**Bad**
```css
div {
  top: 50%;
  margin-top: -10px;
  flex-grow: 1;
  flex-basis: 0;
  padding-top: 5px;
  padding-right: 10px;
  padding-bottom: 20px;
  padding-left: 10px;
  border-color: #cccccc;
  border-style: solid;
  border-width: 1px;
}
```

**Good**
```css
div {
  top: calc(50% - 10px);
  flex: 1 0 auto;
  padding: 5px 10px 20px;
  border: 1px solid #ccc;
}
```
### Units

Don't use unit when value is null. Do not give unit at `line-height` property.

**Bad**
```css
div {
  margin: 0px;
  font-size: 0.9em;
  line-height: 22px;
  transition: 500ms;
}
```

**Good**
```css
div {
  margin: 0;
  font-size: .9rem;
  line-height: 1.5;
  transition: .5s;
}
```
### Performant animations

Always specify which property(ies) should be animated in transition or animation.  
Avoid animating properties other than `transform` or `opacity` or `filter`.

**Bad**

```css
div {
  margin-left: 100px;
  transition: .5s;
}
```

**Good**

```css
div {
  transform: translateX(100px);
  transition: transform .5s;
}
```

### OOCSS and BEM

We encourage some combination of **OOCSS** and **BEM** for these reasons:

* It helps create clear, strict relationships between CSS and HTML
* It helps us create reusable, composable components
* It allows for less nesting and lower specificity
* It helps in building scalable stylesheets

**OOCSS**, or “Object Oriented CSS”, is an approach for writing CSS that encourages you to think about your stylesheets as a collection of “objects”: reusable, repeatable snippets that can be used independently throughout a website.

* Nicole Sullivan's [OOCSS wiki](https://github.com/stubbornella/oocss/wiki)
* Smashing Magazine's Introduction to [Introduction to OOCSS](http://www.smashingmagazine.com/2011/12/12/an-introduction-to-object-oriented-css-oocss/)

**BEM**, or “Block-Element-Modifier”, is a naming convention for classes in HTML and CSS. It was originally developed by Yandex with large codebases and scalability in mind, and can serve as a solid set of guidelines for implementing OOCSS.

* CSS Trick's [BEM 101](https://css-tricks.com/bem-101/)
* Harry Roberts' [introduction to BEM](http://csswizardry.com/2013/01/mindbemding-getting-your-head-round-bem-syntax/)

We recommend to use a variant of BEM with:
* block-name
* block-name.modifier-name
* block-name--element-name
* block-name--element-name.modifier-name

## Sass

### Syntaxe

* Use the `.scss` syntax, never the original `.sass` syntax
* Order your regular CSS and `@include` declarations logically (see below)

### Ordering of property declarations

1. Property declarations

    List all standard property declarations, anything that isn't an `@include` or a nested selector.

    ```scss
    .btn-green {
      background: green;
      font-weight: bold;
      // ...
    }
    ```

2. `@include` declarations

    Grouping `@include` at the end makes it easier to read the entire selector.

    ```scss
    .btn-green {
      background: green;
      font-weight: bold;
      @include transition(background 0.5s ease);
      // ...
    }
    ```

3. Nested selectors

    Nested selectors, _if necessary_, go last, and nothing goes after them. Add whitespace between your rule declarations and nested selectors, as well as between adjacent nested selectors. Apply the same guidelines as above to your nested selectors.

    ```scss
    .btn {
      background: green;
      font-weight: bold;
      @include transition(background 0.5s ease);

      .icon {
        margin-right: 10px;
      }
    }
    ```

### Duplication

Use preprocessors (Sass) to avoid code repetition.

Mainly concerned :

* text colors
* background colors
* font sizes
* Media Queries breakpoints

**Bad :**

```css
li {
  color: red;
}
div {
  color: #F00;
}
p {
  color: #FF0000;
}
p {
  color: #FF0001;
}
```

**Good :**

```css
// sass variable.
$color: #F00;

// we use the variable.
li {
  color: $color;
}
div {
  color: $color;
}
p {
  color: $color;
}
```

### Variables

Prefer dash-cased variable names (e.g. `$my-variable`) over camelCased or snake_cased variable names.  
Prefer, the name of the component first appears in the name of a variable (for example `$checkbox-size` rather than `$size-checkbox`), with the exception of global text or background colors (`$color-primary`, `$background-base`, etc.).

It is acceptable to prefix variable names that are intended to be used only within the same file with an underscore (e.g. `$_my-variable`).

### Extend directive

`@extend` should be avoided because it has unintuitive and potentially dangerous behavior, especially when used with nested selectors. Even extending top-level placeholder selectors can cause problems if the order of selectors ends up changing later (e.g. if they are in other files and the order the files are loaded shifts). Gzipping should handle most of the savings you would have gained by using `@extend`, and you can DRY up your stylesheets nicely with mixins.

### Nested selectors

**Do not nest selectors more than three levels deep!**

```scss
.page-container {
  .content {
    .profile {
      // STOP!
    }
  }
}
```

When selectors become this long, you're likely writing CSS that is:

* Strongly coupled to the HTML (fragile) *—OR—*
* Overly specific (powerful) *—OR—*
* Not reusable

Again: **never nest ID selectors!**

If you must use an ID selector in the first place (and you should really try not to), they should never be nested. If you find yourself doing this, you need to revisit your markup, or figure out why such strong specificity is needed. If you are writing well formed HTML and CSS, you should **never** need to do this.

**[⬆ back to top](#table-of-contents)**
