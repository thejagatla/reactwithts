All sass components defined in this folders [will/needs to] be moved in the Skywise React Library.
This is an action defines by the GUILD FRONT !
and it is here to help you to understand these rules, your are not alone :D
