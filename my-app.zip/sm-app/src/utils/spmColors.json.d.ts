interface spmColors {
 
    graphColor1: string;
    graphColor2: string;
    graphColor3: string;
    graphColor4: string;
    graphColor5: string;
    graphColor6: string;
    graphColor7: string;
    graphColor8: string;
    thresholdColor1: string;
    thresholdColor2: string;
    thresholdColor3: string;
    thresholdColor4: string;
    thresholdColor5: string;
    thresholdColor6: string;
    thresholdColor7: string;
    thresholdColor8: string;
    titleColor: string;
    gridLineColor: string;
    minorGridLineColor: string;
    iconsAxColor1: string;
    iconsAxColor2: string;
    tooltipBorderColor: string;
    tooltipBackgroundColor: string;
    separatorColor: string;
    transparent: string;
  }
  declare const value: spmColors;
  export = value;
  