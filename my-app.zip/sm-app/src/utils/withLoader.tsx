import { DSLoader } from '@sm/skywise-react-library';
import * as React from 'react';
import HeaderViewController from '../components/common/header/HeaderViewController';
import { Page } from '../components/presenter/templates/Page';
import * as Strings from '../lang/strings.json';

interface AdditionalProps {
  loading: boolean;
}

export const withLoader = <P extends object>(
  Component: React.ComponentType<P>
): React.SFC<P & AdditionalProps> => ({ loading, ...props }: AdditionalProps) =>
  loading ? (
    <Page header={<HeaderViewController {...props} />}>
      <div className="page-loader">
        <DSLoader label={Strings.loadingUserProfile} />
      </div>
    </Page>
  ) : (
    <Component {...props} />
  );
