/**
 * File description: Class providing fleet sweep utils methods.
 * @author Capgemini
 * @version 1.0
 */
import { SkywiseICONS } from '../components/storybook';
import { Occurrence, OccurrenceEnum, WorkOrderStatus, WorkOrderStatusEnum } from '../model/EventsConstantes';
import {
  FleetsweepEventRank,
  FleetsweepEventRankEnum,
  FleetsweepFilterTypeEnum,
  FleetsweepPriority,
  FleetsweepPriorityEnum  
} from '../model/fleetsweep/FleetsweepConstantes';

/**
 * Return full enum value
 * @param pType Fleetsweep filter type
 * @param pEnumValue enum
 */
export const getFullFleetsweepValueFromEnum = (pType: any, pEnumValue: string): string => {

  let lResult: string = '';

  switch (pType) {
    case FleetsweepFilterTypeEnum.EVENT_RANK:
      lResult = getEventRankValueFromEnum(pEnumValue);
      break;
    case FleetsweepFilterTypeEnum.PRIORITY:
      lResult = getFullPriorityValueFromEnum(pEnumValue);
      break;
    case FleetsweepFilterTypeEnum.WORK_STATUS:
      lResult = getWorkStatusValueFromEnum(pEnumValue);
      break;
    case FleetsweepFilterTypeEnum.OCCURRENCE:
      lResult = getOccurrenceValueFromEnum(pEnumValue);
      break;
    case FleetsweepFilterTypeEnum.AIRCRAFT_TYPE:
      lResult = pEnumValue;
      break;
    default:
  }

  return lResult;
};

/**
 * Return work status icon associated to enum
 * @param pEnumValue enum
 */
export const getIconFromWorkStatusEnum = (pEnumValue: string): SkywiseICONS => {

  let lResult: SkywiseICONS;

  switch (pEnumValue) {
    case WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED]:
      lResult = 'eye';
      break;
    case WorkOrderStatusEnum[WorkOrderStatusEnum.PLANNED]:
      lResult = 'date_range';
      break;
    case WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_MONITORED]:
      lResult = 'build';
      break;
    case WorkOrderStatusEnum[WorkOrderStatusEnum.CLOSED]:
      lResult = 'check_checkbox';
      break;
    case WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED]:
      lResult = 'cancel';
      break;
    case WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]:
    default:
      lResult = 'location';
  }

  return lResult;
};

/**
 * Return short class name work status associated to enum
 * @param pEnumValue enum
 */
export const getShortClassFromWorkStatusEnum = (pEnumValue: string): string => {
  let lResult: string;

  switch (pEnumValue) {
    case WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED]:
      lResult = 'opened';
      break;
    case WorkOrderStatusEnum[WorkOrderStatusEnum.PLANNED]:
      lResult = 'planned';
      break;
    case WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_MONITORED]:
      lResult = 'tbm';
      break;
    case WorkOrderStatusEnum[WorkOrderStatusEnum.CLOSED]:
      lResult = 'closed';
      break;
    case WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED]:
      lResult = 'ignored';
      break;
    case WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]:
    default:
      lResult = 'tbr';
  }

  return lResult;
};

/**
 * Return short enum value
 * @param pType Fleetsweep filter type
 * @param pEnumValue enum
 */
export const getShortFleetsweepValueFromEnum = (pType: FleetsweepFilterTypeEnum, pEnumValue: string): string => {

  let lResult: string = '';

  switch (pType) {
    case FleetsweepFilterTypeEnum.EVENT_RANK:
      lResult = pEnumValue;
      break;
    case FleetsweepFilterTypeEnum.PRIORITY:
      lResult = getShortPriorityValueFromEnum(pEnumValue);
      break;
    case FleetsweepFilterTypeEnum.WORK_STATUS:
    default:
  }

  return lResult;
};

/**
 * Return short priority enum value
 * @param pEnumValue enum
 */
const getShortPriorityValueFromEnum = (pEnumValue: string): string => {
  return getFullPriorityValueFromEnum(pEnumValue).substring(0, 1);
};

/**
 * Return full priority enum value
 * @param pEnumValue enum
 */
const getFullPriorityValueFromEnum = (pEnumValue: string): string => {

  let lResult: string = '';

  switch (pEnumValue) {
    case FleetsweepPriority[FleetsweepPriority.HIGH]:
      lResult = FleetsweepPriorityEnum.HIGH;
      break;
    case FleetsweepPriority[FleetsweepPriority.MEDIUM]:
      lResult = FleetsweepPriorityEnum.MEDIUM;
      break;
    case FleetsweepPriority[FleetsweepPriority.LOW]:
      lResult = FleetsweepPriorityEnum.LOW;
      break;
    case FleetsweepPriority[FleetsweepPriority.NONE]:
      lResult = FleetsweepPriorityEnum.NONE;
      break;
    case FleetsweepPriority[FleetsweepPriority.SPURIOUS]:
      lResult = FleetsweepPriorityEnum.SPURIOUS;
      break;
    default:
  }

  return lResult;
};

/**
 * Return event rank value from its enum
 * @param pEnumValue event rank enum
 */
const getEventRankValueFromEnum = (pEnumValue: string): string => {

  let lResult: string = '';

  switch (pEnumValue) {
    case FleetsweepEventRank[FleetsweepEventRank.W]:
      lResult = FleetsweepEventRankEnum.W;
      break;
    case FleetsweepEventRank[FleetsweepEventRank.P]:
      lResult = FleetsweepEventRankEnum.P;
      break;
    case FleetsweepEventRank[FleetsweepEventRank.C1]:
      lResult = FleetsweepEventRankEnum.C1;
      break;
    case FleetsweepEventRank[FleetsweepEventRank.C2]:
      lResult = FleetsweepEventRankEnum.C2;
      break;
    case FleetsweepEventRank[FleetsweepEventRank.OR]:
      lResult = FleetsweepEventRankEnum.OR;
      break;
    case FleetsweepEventRank[FleetsweepEventRank.SE]:
      lResult = FleetsweepEventRankEnum.SE;
      break;
    case FleetsweepEventRank[FleetsweepEventRank.MTBUR]:
      lResult = FleetsweepEventRankEnum.MTBUR;
      break;
    case FleetsweepEventRank[FleetsweepEventRank.Lb]:
      lResult = FleetsweepEventRankEnum.Lb;
      break;
    default:
  }

  return lResult;
};

/**
 * Return work status enum value
 * @param pEnumValue enum
 */
const getWorkStatusValueFromEnum = (pEnumValue: string): string => {

  let lResult: string = '';

  switch (pEnumValue) {
    case WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_REVIEWED]:
      lResult = WorkOrderStatus.TO_BE_REVIEWED;
      break;
    case WorkOrderStatusEnum[WorkOrderStatusEnum.OPENED]:
      lResult = WorkOrderStatus.OPENED;
      break;
    case WorkOrderStatusEnum[WorkOrderStatusEnum.PLANNED]:
      lResult = WorkOrderStatus.PLANNED;
      break;
    case WorkOrderStatusEnum[WorkOrderStatusEnum.TO_BE_MONITORED]:
      lResult = WorkOrderStatus.TO_BE_MONITORED;
      break;
    case WorkOrderStatusEnum[WorkOrderStatusEnum.CLOSED]:
      lResult = WorkOrderStatus.CLOSED;
      break;
    case WorkOrderStatusEnum[WorkOrderStatusEnum.IGNORED]:
      lResult = WorkOrderStatus.IGNORED;
      break;
    default:
  }

  return lResult;
};

/**
 * Return occurrence enum value
 * @param pEnumValue enum
 */
const getOccurrenceValueFromEnum = (pEnumValue: string): string => {

  let lResult: string = '';

  switch (pEnumValue) {
    case OccurrenceEnum[OccurrenceEnum.LAST]:
      lResult = Occurrence.LAST;
      break;
    case OccurrenceEnum[OccurrenceEnum.NOT_IN_LAST]:
      lResult = Occurrence.NOT_IN_LAST;
      break;

    default:
  }

  return lResult;
};
