/**
 * @name LinkUtils
 * @description .
 * @type .
 */
export const buildURL = (
  docType: any,
  taskRef: any,
  tsmLink?: any,
  mainEvent?: any
) => {
  let acTypeRefactored = '';
  let programCode = '';
  let suffixBase = '';
  let prefix = '';
  let msn = '';
  let acType = '';

  if (tsmLink && tsmLink.suffixBase) {
    suffixBase = tsmLink.suffixBase;
  }
  if (tsmLink && tsmLink.prefix) {
    prefix = tsmLink.prefix;
  }

  if (mainEvent.msn) {
    msn = mainEvent.msn;
  }

  if (mainEvent.aircraftType) {
    acType = mainEvent.aircraftType;
  }

  if (acType) {
    if (['A300', 'A310'].indexOf(acType) >= 0) {
      programCode = 'W';
    } else if (['A318', 'A319', 'A320', 'A321'].indexOf(acType) >= 0) {
      programCode = 'N';
    } else if (['A330', 'A340'].indexOf(acType) >= 0) {
      programCode = 'F';
    } else if (acType === 'A380') {
      programCode = 'L';
    } else if (acType === 'A350') {
      programCode = 'P';
    }
    acTypeRefactored = programCode + msn;
  }

  const airnavxUrl = buildAirnavxUrl(
    taskRef.ref,
    suffixBase,
    prefix,
    docType,
    msn,
    programCode,
    acTypeRefactored,
    acType
  );

  return airnavxUrl;
};

export const buildAirnavxUrl = (
  ref: any,
  suffix: string,
  prefix: string,
  docType: string,
  msn: string,
  programCode: string,
  acTypeRefactored: string,
  acType: string
) => {
  const searchTextURL = 'search/text?q=';
  const tailNumberURL = ';tailNumber:';
  const acTypeURL = '*&wc=acType:';
  const tokenURL = '&token=';
  const programURL = '&program=';
  const msnURL = '&msn=';
  const docTypeURL = ';doctype:' + docType;

  let airnavxUrl = '';

  if (suffix === 'AIRNAVX_1') {
    airnavxUrl =
      prefix +
      searchTextURL +
      ref +
      acTypeURL +
      acType +
      docTypeURL +
      tailNumberURL +
      acTypeRefactored;
  } else if (suffix === 'AIRNAVX_13') {
    airnavxUrl =
      prefix +
      'interopService/datasearch?query=' +
      ref +
      '&doctype=' +
      docType +
      '&acType=' +
      acType +
      programURL +
      programCode +
      msnURL +
      msn +
      tokenURL +
      'AIB_999_999';
  } else {
    airnavxUrl =
      'https://v3.airbus.com/other/' +
      searchTextURL +
      ref +
      docTypeURL +
      msn +
      tailNumberURL +
      acTypeRefactored;
  }

  return airnavxUrl;
};
