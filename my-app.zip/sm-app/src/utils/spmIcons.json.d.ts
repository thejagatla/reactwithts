interface SpmIcons{
    iconEye: string;
    iconCheck: string;
    iconWrench: string;
    iconIgnore: string;
    missingIcon: string;
    alertIcon: string;
    defaultIcon: string;
}
declare const value: SpmIcons;
export = value;