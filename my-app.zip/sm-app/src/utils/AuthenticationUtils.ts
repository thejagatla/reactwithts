/**
 * File description: Class providing authentication utils methods.
 * @author Capgemini
 * @version 1.0
 */
import * as AWSCognito from 'amazon-cognito-auth-js/dist/amazon-cognito-auth';
import { store } from '../store/configureStore';

/**
 * Return idToken
 */
export const getIdToken = (): string => {
  let lIdToken: string = 'not-authenticated';
  const lStoredValues: any = store.getState();
  let lClientId: string = null;
  let lIdTokenKey: string = null;

  // Authentication with oneLogin
  if (lStoredValues.onelogin.auth !== null) {
    const lAuth: AWSCognito.CognitoAuth = new AWSCognito.CognitoAuth(lStoredValues.onelogin.auth);
    lClientId = `CognitoIdentityServiceProvider.${lAuth.getClientId()}`;
    lIdTokenKey = `${lClientId}.${lAuth.getUsername()}.idToken`;
    // Authentication with cognito
  } else if (lStoredValues.cognito.user && lStoredValues.cognito.user.signInUserSession) {
    lClientId = `CognitoIdentityServiceProvider.${lStoredValues.cognito.user.pool.clientId}`;
    lIdTokenKey = `${lClientId}.${lStoredValues.cognito.user.username}.idToken`;
  }

  if (lIdTokenKey !== null) {
    lIdToken = localStorage.getItem(lIdTokenKey);
  }

  return lIdToken;
};

/**
 * Return username
 */
export const getUsername = (): string => {
  const lStoredValues: any = store.getState();
  let lUsername: string = '';

  // Authentication with oneLogin
  if (lStoredValues.onelogin.username !== null) {
    lUsername = lStoredValues.onelogin.username;
  } else if (lStoredValues.cognito.user) {
    lUsername = lStoredValues.cognito.user.username;
  }

  return lUsername;
};
