import * as React from 'react';
import { ModalManager } from 'react-dynamic-modal';
import { ErrorModalView } from '../components/utils/errorModal/ErrorModalView';

export const closeModal = (pTimer: number = 0) => {
  setTimeout(
    ModalManager.close(),
    pTimer
  );
};

/**
 * Open the error modal
 * @param pTraceId trace id
 * @param pTechRequestUrl support URL
 * @param pContactEnglish english contact reference
 * @param pContactChinese chinese contact reference
 */
export const openErrorModal = (
  pTraceId: string,
  message?: string,
  pTechRequestUrl?: string,
  pContactEnglish?: string,
  pContactChinese?: string) => {
  ModalManager.open(
    <ErrorModalView
      languageInfo={[pContactEnglish, pContactChinese]}
      techRequestUrl={pTechRequestUrl}
      traceId={pTraceId}
      message={message}
    />
  );
};
