/**
 * File description: Contains all render utils functions.
 * @author Capgemini
 * @version 1.0
 */

import { isNil } from 'lodash';
import * as moment from 'moment';
import * as React from 'react';

export const renderInHTML = (value: string, classes?: string): React.ReactNode => {
  return (
    <span
      dangerouslySetInnerHTML={{ __html: value }}
      className={classes}
    />
  );
};

export const stripTags = (str: string): string | undefined => {
  if (isNil(str)) {
    return undefined;
  }
  const goodStr = str.toString();
  return goodStr.replace(/<\/?[^>]+>/gi, '');
};

export const startAnimation = (callback) => {
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      callback();
    });
  });
};

export const formatDate = (dateToFormat: Date, format: string): string => {
  const momentUTC = moment.utc(dateToFormat);  
  return momentUTC.format(format);
};
