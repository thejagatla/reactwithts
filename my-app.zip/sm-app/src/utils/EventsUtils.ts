/**
 * File description: Class providing utils methods for events cockpit.
 * @author Capgemini
 * @version 1.0
 */
import { SkywiseICONS } from '../components/storybook/SkywiseInterface';
import * as Strings from '../lang/strings.json';
import { fetchEvents, setTimeoutId } from '../store/actions/EventsActions';
import { store } from '../store/configureStore';

/**
 * Return the displayed value associated to the displayed field
 * @param pDisplayed the displayed value to convert into string
 */
export const getDisplayedValue = (pDisplayed: boolean): string => {
  let lResult: string = null;

  if (pDisplayed !== null && pDisplayed !== undefined) {
    if (!pDisplayed) {
      lResult = Strings.notDisplayed;
    } else {
      lResult = Strings.displayed;
    }
  }

  return lResult;
};

/**
 * Start fetch events
 * @param pShouldRestoreDefaultState true if default state is used, false otherwise
 * @param pShouldRefreshInfiniteLoader true if refresh loader, false otherwise
 * @param pLoadingMore true if should load more row, false otherwise
 */
export const startTimeout = (
  pShouldRestoreDefaultState: boolean = false,
  pShouldRefreshInfiniteLoader: boolean = false,
  pLoadingMore: boolean = false
) => {
  const storedValues: any = store.getState();
  const { pollingDelay, timeoutId } = storedValues.eventReducer;

  clearTimeout(timeoutId);

  store.dispatch(
    fetchEvents(
      pShouldRestoreDefaultState,
      pShouldRefreshInfiniteLoader,
      pLoadingMore
    )
  );

  const lTimeoutId = setTimeout(startTimeout, pollingDelay);

  store.dispatch(setTimeoutId(lTimeoutId));
};

/**
 * Get the good event type icon
 * @param eventOrigin The event type
 */
export const getIconByEventType = (eventOrigin: string): SkywiseICONS => {
  switch (eventOrigin) {
    case 'SHM':
      return 'timer';

    case 'SPM':
      return 'search_db';

    case 'SRS':
    default:
      return 'chart2';
  }
};
