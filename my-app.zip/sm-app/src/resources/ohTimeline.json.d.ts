interface JsonOhTimeline {
  events: any
}

declare const value: JsonOhTimeline;
export = value;