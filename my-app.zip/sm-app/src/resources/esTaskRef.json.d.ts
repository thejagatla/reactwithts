interface JsonEsTaskRef {
  esTaskRef: any
}

declare const value: JsonEsTaskRef;
export = value;