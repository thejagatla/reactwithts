// filter definition
interface JsonPeriodFilter {
    title: string;
    type: string;
    values: Array<JsonPeriodFilterValue>;
}

interface JsonPeriodFilterValue {
    value: string;
    active: boolean;
}

declare const value: JsonPeriodFilter;
export = value;