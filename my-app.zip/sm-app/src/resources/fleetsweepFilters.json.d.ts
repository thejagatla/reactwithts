// main object
interface JsonFleetsweepFilters {
    tabs: Array<JsonFleetsweepTab>;
}

// tab definition
interface JsonFleetsweepTab {
    origin: JsonFleetsweepFilter;
    title: string;
    filters: Array<JsonFleetsweepFilter>;
}

// filter definition
interface JsonFleetsweepFilter {
    title: string;
    type: string;
    values: Array<JsonFleetsweepFilterValue>;
}

interface JsonFleetsweepFilterValue {
    value: string;
    active: boolean;
}

declare const value: JsonFleetsweepFilters;
export = value;