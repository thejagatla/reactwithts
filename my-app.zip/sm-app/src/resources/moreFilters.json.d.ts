// More filters definition
interface JsonMoreFilterTab {
  title: string;
  filters: Array<JsonMoreFilterFilter>;
}

// filter definition
interface JsonMoreFilterFilter {
  title: string;
  type: string;
  values: JsonMoreFilterValue[];
}

interface JsonMoreFilterValue {
  value: string;
  active: boolean;
}

declare const value: JsonMoreFilterTab;
export = value;
