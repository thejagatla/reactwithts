/**
 * Class description: Class responsible for SPM Model Trends API calls
 * @author Capgemini
 * @version 1.0
 */

const API_URL = '/api/pm';
const MODEL_TRENDS_FILTERS_API = '/model-trends/fleets-infos/';

import 'whatwg-fetch';

export class ModelTrendsController {

  /**
   * Get all the required filter data according to a user permissions
   * @param idToken The token of the user for which all the required filter data shall be loaded
   */
  public static loadFiltersByUser(idToken: string) {

    return new Promise((resolve, reject) => {
      this.get(MODEL_TRENDS_FILTERS_API, idToken)
        .then((fleetsInfos: Response) => {
          resolve(fleetsInfos.json());
        })
        .catch((error) => {
          reject(error);
        });
    });
  }

  /**
   * Make a GET request to the specified URL
   * @param url The URL of GET request
   */
  private static get(url: string, idToken: string): Promise<Response> {
    const request = new Request(API_URL + url, {
      headers: new Headers({
        'Content-Type': 'application/json',
        'X-SKYWISE-AUTH': idToken
      }),
      method: 'GET'
    });
    return new Promise((resolve, reject) => {
      ModelTrendsController.request(request, 200)
        .then((response: Response) => {
          resolve(response);
        })
        .catch((error) => {
          reject(error);
        });
    });
  }

  private static request(request: Request, expectedResponseCode: number) {
    return new Promise((resolve, reject) => {
      fetch(request)
        .then((response) => {
          if (response.status === expectedResponseCode) {
            resolve(response);
          } else {
            reject(response);
          }
        })
        .catch((error) => {
          reject(error);
        });
    });
  }
}
