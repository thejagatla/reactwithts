/**
 * Class description: Class responsible for SPM API calls
 * @author Capgemini
 * @version 1.0
 */

const API_URL = '/api/pm';
const ADMIN_API = '/admin/airlines';
const API_IMPORT_PRIORITY = '/api/priorityFileUpload';

const tokenAttribute = 'X-SKYWISE-AUTH';

export class AdministrationController {
  /**
   * Build header for GET request
   * @param pIdToken id token
   * @returns GET request header
   */
  private static buildHeader(pIdToken: string): Headers {
    return new Headers({
      'Content-Type': 'application/json',
      [tokenAttribute]: pIdToken
    });
  }

  /**
   * Export priorities file
   * @param pUrl Rest API url
   * @param pAirline airline
   * @param pAircraftFamily aircraft family
   * @param pIdToken id token
   */
  public static exportPrioritiesFile(
    pUrl: string,
    pAirline: string,
    pAircraftFamily: string,
    pIdToken: string
  ): Promise<{}> {
    return new Promise((resolve, reject) => {
      const requestObject: any = {
        headers: this.buildHeader(pIdToken),
        method: 'GET'
      };
      fetch(`${pUrl}?airline=${pAirline}&aircraftfamily=${pAircraftFamily}`, requestObject)
        .then(
          response => resolve(response),
          error => reject(error)
        );
    });
  }

  /**
   * Build header for POST request
   * @param pIdToken id token
   * @returns POST request header
   */
  private static buildPostHeader(pIdToken: string): Headers {
    return new Headers({
      'Content-Type': 'text/plain',
      [tokenAttribute]: pIdToken
    });
  }

  /**
   * Get user profile and features flipping
   * @param pUserProfileUrl user profile URL
   * @param pFlippingUrl features flipping URL
   * @param pIdToken user id token
   */
  public static getUserProfileAndFeatureFlipping(
    pUserProfileUrl: string,
    pFlippingUrl: string,
    pIdToken: string
  ): Promise<{}> {
    return new Promise((resolve, reject) => {
      Promise.all([
        this.getUserProfile(pUserProfileUrl, pIdToken),
        this.getEnabledFeatures(pFlippingUrl, pIdToken)
      ])
        .then((responses: any) => {
          resolve(responses);
        })
        .catch(error => {
          reject(error);
        });
    });
  }

  /**
   * Get the profile of the user
   * @param pUserProfileUrl API rest URL
   * @param pIdToken id token
   */
  public static getUserProfile(
    pUserProfileUrl: string,
    pIdToken: string
  ): Promise<{}> {
    return new Promise((resolve, reject) => {
      const requestObject: any = {
        headers: this.buildHeader(pIdToken),
        method: 'GET'
      };
      fetch(pUserProfileUrl, requestObject)
        .then(response => {
          if (response.ok) {
            resolve(response.json());
          } else {
            reject(response.json());
          }
        })
        .catch(error => {
          reject(error);
        });
    });
  }

  /**
   * Get enabled features list
   * @param pUrl API rest URL
   * @param pIdToken id token
   */
  public static getEnabledFeatures(
    pFlippingUrl: string,
    pIdToken: string
  ): Promise<{}> {
    return new Promise((resolve, reject) => {
      const requestObject: any = {
        headers: this.buildHeader(pIdToken),
        method: 'GET'
      };
      fetch(pFlippingUrl, requestObject)
        .then(response => {
          if (response.ok) {
            resolve(response.json());
          } else {
            reject(response.json());
          }
        })
        .catch(error => {
          reject(error);
        });
    });
  }

  /**
   * Get the list of icaos for current user
   * E.g [ "AIJ", "EZY" ]
   */
  public static getAirlines(idToken: string) {
    return new Promise((resolve, reject) => {
      this.get(ADMIN_API, idToken)
        .then((icaos: Response) => {
          resolve(icaos.json());
        })
        .catch(error => {
          reject(error);
        });
    });
  }

  /**
   * Get the list of models for current user
   * @param icao The icao for the airline which will give the list of models
   */
  // E.g [
  //   {
  //     "id" : "IDG_FREQUENCY_EXCURSION_M2:A320_#0_FREQUENCY^HIGH_FREQ_RISK_IDG1",
  //     "atas" : [ "24", "25" ],
  //     "title" : "Pack 1 heat exchanger efficiency low"
  //   },
  // ]
  public static getModels(icao: string, idToken: string) {
    return new Promise((resolve, reject) => {
      this.get(ADMIN_API + '/' + icao + '/models', idToken)
        .then((models: Response) => {
          resolve(models.json());
        })
        .catch(error => {
          reject(error);
        });
    });
  }

  /**
   * Get a specific model for current airline
   * @param icao of the airline to configure
   * @param modelId of the model to configure
   */
  // E.g
  // {
  //   "id": "ATA24_IDG_COOLING_FAILURE_M3:A320_#0_GENERIC^PRECURSOR_IDG1",
  //   "atas": ["24"],
  //   "title": "Failure precursor on IDG1",
  //   "description": null,
  //   "automaticWorkflow": {
  //     "enabled": true,
  //     "flightsBeforeReviewToIgnored": {
  //       "value": 30,
  //       "min": 1,
  //       "max": 999
  //     },
  //     "flightsBeforeOpenedToIgnored": {
  //       "value": 30,
  //       "min": 1,
  //       "max": 999
  //     },
  //     "flightsBeforeMonitorToClosed": {
  //       "value": 30,
  //       "min": 1,
  //       "max": 999
  //     }
  //   }
  // }
  public static getModel(icao: string, modelId: string, idToken: string) {
    return new Promise((resolve, reject) => {
      const modelIdEncoded = encodeURIComponent(modelId);
      this.get(ADMIN_API + '/' + icao + '/models/' + modelIdEncoded, idToken)
        .then((model: Response) => {
          resolve(model.json());
        })
        .catch(error => {
          reject(error);
        });
    });
  }

  public static putModel(
    icao: string,
    modelId: string,
    workflowConfiguration: any,
    idToken: string
  ) {
    return new Promise((resolve, reject) => {
      const modelIdEncoded = encodeURIComponent(modelId);
      this.put(
        ADMIN_API + '/' + icao + '/models/' + modelIdEncoded,
        workflowConfiguration,
        idToken
      )
        .then((model: any) => {
          resolve(model);
        })
        .catch(error => {
          reject(error);
        });
    });
  }

  /**
   * Make a GET request to the specified URL
   * @param url The URL of GET request
   */
  private static get(url: string, idToken: string): Promise<Response> {
    const request = new Request(API_URL + url, {
      headers: this.buildHeader(idToken),
      method: 'GET'
    });
    return new Promise((resolve, reject) => {
      this.request(request, 200)
        .then((response: Response) => {
          resolve(response);
        })
        .catch(error => {
          reject(error);
        });
    });
  }

  /**
   * Make a PUT request to the specified URL
   * @param url The URL of PUT request
   */
  private static put(
    url: string,
    body: {},
    idToken: string
  ): Promise<Response> {
    const request = new Request(API_URL + url, {
      body: JSON.stringify(body),
      headers: new Headers({
        [tokenAttribute]: idToken
      }),
      method: 'PUT'
    });
    return new Promise((resolve, reject) => {
      this.request(request, 204)
        .then((response: Response) => {
          resolve(response);
        })
        .catch(error => {
          reject(error);
        });
    });
  }

  private static request(request: Request, expectedResponseCode: number) {
    return new Promise((resolve, reject) => {
      fetch(request)
        .then(response => {
          if (response.status === expectedResponseCode) {
            resolve(response);
          } else {
            reject(response);
          }
        })
        .catch(error => {
          reject(error);
        });
    });
  }

  /**
   * Upload import priorities file
   * @param pUrl Rest API url
   * @param pImportFile priority importing file
   * @param pIdToken id token
   */
  public static uploadImportPrioritiesFile(
    pAirline: string,
    pAcFamily: string,
    pImportFile: File,
    pIdToken: string
  ): Promise<{}> {
    return new Promise((resolve, reject) => {
      const requestObject: any = {
        body: pImportFile,
        headers: this.buildPostHeader(pIdToken),
        method: 'POST'
      };
      fetch(`${API_IMPORT_PRIORITY}?airline=${pAirline}&aircraftFamily=${pAcFamily}`, requestObject)
        .then(response => {
          if (response.ok) {
            resolve(response.json());
          } else {
            reject(response);
          }
        })
        .catch(error => {
          reject(error);
        });
    });
  }

}
