/**
 * Class description: Class responsible for API calls
 * @author Capgemini
 * @version 1.0
 */

const API_URL = '/api/events';

export class WorkStatusController {
  public static setWorkOrderStatus(
    hashKey: string,
    oldStatus: string,
    newStatus: string,
    idToken: string,
    newWorkOrderCommentAuthor: string,
    newWorkOrderReference?: string,
    newWorkOrderComment?: string,
    newWorkOrderPlannedDate?: string,
    newWorkOrderIgnoredReason?: string
  ) {
    return new Promise((resolve, reject) => {
      const goodUrl = encodeURIComponent(hashKey);
      const body = {
        workOrderComment: newWorkOrderComment,
        workOrderCommentAuthor: newWorkOrderCommentAuthor,
        workOrderIgnoredReason: newWorkOrderIgnoredReason,
        workOrderOldStatus: oldStatus,
        workOrderPlannedDate: newWorkOrderPlannedDate,
        workOrderReference: newWorkOrderReference,
        workOrderStatus: newStatus
      };
      fetch(`${API_URL}/${goodUrl}`, {
        body: JSON.stringify(body),
        headers: {
          'X-SKYWISE-AUTH': idToken
        },
        method: 'PATCH'
      })
        .then(
          (response) => {
            return resolve(response.json().then(res => ({
              body: res,
              status: response.status
            })));
          },
          (error) => {
            return reject(error);
          }
        )
        .catch((err) => {
          return reject(err);
        });
    });
  }
}
