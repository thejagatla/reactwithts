/**
 * Class description: Class responsible for SPM API calls
 * @author Capgemini
 * @version 1.0
 */

const API_URL = '/api/pm';
const EVENTS_API = '/event-items/';

import * as moment from 'moment';
import 'whatwg-fetch';
import { Comment } from '../model/Comment';
import { SpmStatusInfoItem } from '../model/spm/SpmStatusInfoItem';

export class SpmEventController {

  /**
   * Get the data for a given event
   * @param eventId The id of the event we want to get the data
   */
  public static getEventById(eventId: string, idToken: string) {
    return new Promise((resolve, reject) => {
      this.get('/events/' + eventId, idToken)
        .then((event: Response) => {
          resolve(event.json());
        })
        .catch((error) => {
          reject(error);
        });
    });
  }

  /**
   * Get the data for a given event item of a given event
   * @param aircraftId The id of the aircraft related to the event
   * @param eventId The id of the event we want the event item
   * @param eventItemId The id of the event item we want the data
   */
  public static getEventItemByEventId(eventId: string, toDate: string, idToken: string) {
    return new Promise((resolve, reject) => {
      const encodedEventId = encodeURIComponent(eventId);
      this.get(EVENTS_API + encodedEventId + '/' + encodeURIComponent(toDate), idToken)
        .then((eventItem: Response) => {
          resolve(eventItem.json());
        })
        .catch((error) => {
          reject(error);
        });
    });
  }

  /**
   * Get the data for a given event item and date
   * @param aircraftId The id of the aircraft related to the event
   * @param eventId The id of the event we want the event item
   * @param eventItemId The id of the event item we want the data
   */
  public static getEventItemByEventIdAndDateBefore(eventId: string, toDate: string, idToken: string) {
    return new Promise((resolve, reject) => {
      const encodedEventId = encodeURIComponent(eventId);
      this.get(
        EVENTS_API + encodedEventId + '/flights/around-date/' + moment.utc(toDate).format('YYYY-MM-DD'),
        idToken)
        .then((eventItem: Response) => {
          resolve(eventItem.json());
        })
        .catch((error) => {
          reject(error);
        });
    });
  }

  /**
   * Get the chart datas for a given event
   * @param aircraftId The id of the aircraft related to the event
   * @param eventId The id of the event we want to get the chart
   */
  public static getChartByEventId(eventId: string, idToken: string) {
    return new Promise((resolve, reject) => {
      this.get(EVENTS_API + eventId + '/graph', idToken)
        .then((chart: Response) => {
          // Robustness processing (see ZaOG)
          // NaN is not part of JSON spec, replace NaN values by null
          return new Promise((resolveNaN) => {
            chart.text().then((s) => {
              const result = s.replace(/":\s*NaN/g, '":null');
              resolveNaN(result);
            });
          });
        }).then((chart: any) => {
          const chartJSON = JSON.parse(chart);
          chartJSON.eventItems
          .forEach(eventItem => {
            for (const key in eventItem.graphData) {
              if (eventItem.graphData.hasOwnProperty(key)) {
                // Robustness processing (see ZaOG)
                // String values are not processed by Highcharts, force parsing to float
                eventItem.graphData[key] = parseFloat(eventItem.graphData[key]);
              }
            }
          });
          resolve(chartJSON);
        })
        .catch((error) => {
          reject(error);
        });
    });
  }

  /**
   * Put a new status info item on an event
   * @param eventId Event ID to update
   * @param statusInfoItem The new status info object
   * @param idToken Cognito token
   */
  public static setWorkOrderStatus(eventId: string, statusInfoItem: SpmStatusInfoItem, idToken: string) {
    return new Promise((resolve, reject) => {
      const encodedEventId = encodeURIComponent(eventId);
      this.put('/events/' + encodedEventId, statusInfoItem, idToken)
        .then((response: Response) => {
          resolve(response);
        })
        .catch((error) => {
          reject(error);
        });
    });
  }

  public static postCommentByEventId(eventId: string, comment: Comment, idToken: string) {
    return new Promise((resolve, reject) => {
      const encodedEventId = encodeURIComponent(eventId);
      this.post(`/events/${encodedEventId}/comments`, comment, idToken)
        .then((response: Response) => {
          resolve(response);
        })
        .catch((error) => {
          reject(error);
        });
    });
  }

  /**
   * Build an request object
   * @param  {string} url
   * @param  {{}} body
   * @param  {} idToken
   * @param  {String} requestType: http request type (GET, PUT, POST)
   */
  private static buildRequest = (url, body, idToken, requestType) => {
    return new Request(API_URL + url, {
      body: body ? JSON.stringify(body) : null,
      headers: new Headers({
        'Content-Type': 'application/json',
        'X-SKYWISE-AUTH': idToken,
      }),
      method: requestType
    });
  }
  
  /**
   * Make a GET request to the specified URL
   * @param url The URL of GET request
   */
  private static get(url: string, idToken: string): Promise<Response> {
    const request = SpmEventController.buildRequest(url, null, idToken, 'GET');
    return new Promise((resolve, reject) => {
      SpmEventController.request(request, 200)
        .then((response: Response) => {
          resolve(response);
        })
        .catch((error) => {
          reject(error);
        });
    });
  }

  /**
   * Make a PUT request to the specified URL
   * @param url The URL of PUT request
   */
  private static put(url: string, body: {}, idToken: string): Promise<Response> {
    const request = SpmEventController.buildRequest(url, body, idToken, 'PUT');
    return new Promise((resolve, reject) => {
      SpmEventController.request(request, 204)
        .then((response: Response) => {
          resolve(response);
        })
        .catch((error) => {
          reject(error);
        });
    });
  }

  /**
   * Make a POST request to the specified URL
   * @param url The URL of POST request
   */
  private static post(url: string, body: {}, idToken: string): Promise<Response> {
    const request = SpmEventController.buildRequest(url, body, idToken, 'POST');
    return new Promise((resolve, reject) => {
      SpmEventController.request(request, 204)
        .then((response: Response) => {
          resolve(response);
        })
        .catch((error) => {
          console.log(error);
          reject(error);
        });
    });
  }

  private static request(request: Request, expectedResponseCode: number) {
    return new Promise((resolve, reject) => {
      fetch(request)
        .then((response) => {
          if (response.status === expectedResponseCode) {
            resolve(response);
          } else {
            reject(response);
          }
        })
        .catch((error) => {
          reject(error);
        });
    });
  }
}
