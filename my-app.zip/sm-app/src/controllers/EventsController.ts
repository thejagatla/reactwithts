/**
 * Class description: Class responsible for API calls
 * @author Capgemini
 * @version 1.0
 */

const API_URL = '/api/events';
import { HoursByLabel } from '../model/FiltersConstantes';
import { FleetsweepFilterTypeESEnum } from '../model/fleetsweep/FleetsweepConstantes';
import { FleetsweepFilter } from '../model/fleetsweep/FleetsweepInterfaces';

export class EventsController {

  /**
   * Call API to get all events
   * @param from begin offset
   * @param size events number
   * @param searchText search filter
   * @param pSort events sort
   */
  public static fetchEvents(
    idToken: string,
    from: any,
    size: any,
    searchText: string,
    filters: FleetsweepFilter[],
    period: any,
    pSort: string
  ) {
    return new Promise((resolve, reject) => {
      const requestObject: any = {
        headers: {
          'X-SKYWISE-AUTH': idToken
        },
        method: 'GET',
      };
      const query = this.buildQueryObject(searchText, filters, period);
      fetch(`${API_URL}?from=${from}&size=${size}&query=${query}&sort=${pSort}`, requestObject)
        .then(
          response => resolve(response.json()),
          error => reject(error)
        );
    });
  }

  public static buildQueryObject(searchText: string, filters: FleetsweepFilter[], period: any) {
    const queryObj: any = {};
    if (searchText !== '') {
      queryObj.searchText = searchText;
    }
    if (filters.length > 0) {
      queryObj.filters = {};
      for (const filter of filters) {
        queryObj.filters[FleetsweepFilterTypeESEnum[filter.type]] = [];
        for (const value of filter.values) {
          if (value.active) {
            queryObj.filters[FleetsweepFilterTypeESEnum[filter.type]].push(value.value);
          }
        }
      }
    }
    if (period !== -1) {
      queryObj.period = HoursByLabel[period];
    }

    return encodeURIComponent(JSON.stringify(queryObj));
  }
}
