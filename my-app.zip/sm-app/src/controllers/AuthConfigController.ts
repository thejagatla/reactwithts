/**
 * Class description: Class responsible for API calls to get login config
 * @author Capgemini
 * @version 1.0
 */

export class AuthConfigController {

  /**
   * Call API to get authentication config
   * @param pURL URL config file
   */
  public static getAuthConfig(pURL: string) {
    return new Promise((resolve, reject) => {
      fetch(`${pURL}`)
        .then(
          (response) => {
            if (response.ok) {
              resolve(response.json());
            }
          },
          error => reject(error)
        );
    });
  }
}
