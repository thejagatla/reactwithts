const API_CORRELATION = '/api/tsm-correlation';
const API_EVENTS_BY_ID_URL = '/api/events-by-ids';
const API_MIS_DATA = '/api/misData';
const API_EVENT_DETAILS = '/api/events/';

const tokenAttribute = 'X-SKYWISE-AUTH';

/**
 * Class description: Class responsible for API calls
 * @author Capgemini
 * @version 1.0
 */
export class ShmEventController {
  /**
   * Fetch the correlated events given the correlation id
   * @param correlationID The id of the event we want to get the data
   */
  public static getCorrelatedEventsHashKeys(
    idToken: string,
    hashKey: string,
    correlationId: string
  ) {
    return new Promise((resolve, reject) => {
      const body = { eventHashKey: hashKey };
      const requestObject: any = {
        body: JSON.stringify(body),
        headers: {
          [tokenAttribute]: idToken
        },
        method: 'POST'
      };
      fetch(
        `${API_CORRELATION}/${correlationId}?eventHashKey=${encodeURIComponent(
          hashKey
        )}`,
        requestObject
      ).then(
        response => {
          resolve(response.json());
        },
        error => {
          reject(error);
        }
      );
    });
  }

  /**
   * Fetch the correlated events given the correlation id
   * @param correlationID The id of the event we want to get the data
   */
  public static getCorrelatedEventsIds(
    idToken: string,
    correlatedEvents: string[]
  ) {
    return new Promise((resolve, reject) => {
      const body = correlatedEvents;
      fetch(API_EVENTS_BY_ID_URL, {
        body: JSON.stringify(body),
        headers: {
          [tokenAttribute]: idToken
        },
        method: 'POST'
      }).then(
        response => {
          resolve(response.json());
        },
        error => reject(error)
      );
    });
  }

  /**
   * Get MIS data details for event.
   * @param pIdToken id token
   * @param pWorkReference work order reference
   * @param pAcMatricule aircraft matricule
   */
  public static getMisDataDetails(
    pIdToken: string,
    pWorkReference: string,
    pAcMatricule: string
  ): Promise<{}> {
    return new Promise((resolve, reject) => {
      fetch(
        `${API_MIS_DATA}?workReference=${pWorkReference}&acMatricule=${pAcMatricule}`,
        {
          headers: {
            [tokenAttribute]: pIdToken
          },
          method: 'GET'
        }
      )
        .then(response => {
          if (response.ok) {
            resolve(response.json());
          } else {
            reject(response.json());
          }
        })
        .catch(error => reject(error));
    });
  }

  /**
   * Get event details by its hash key
   * @param pIdToken id token
   * @param pHashkey event hash key
   */
  public static getEventDetailsByHashkey(
    pIdToken: string,
    pHashkey: string
  ): Promise<{}> {
    return new Promise((resolve, reject) => {
      fetch(`${API_EVENT_DETAILS}${encodeURIComponent(pHashkey)}`, {
        headers: {
          [tokenAttribute]: pIdToken
        },
        method: 'GET'
      })
        .then(response => {
          if (response.ok) {
            resolve(response.json());
          } else {
            reject(response.json());
          }
        })
        .catch(error => reject(error));
    });
  }
}
