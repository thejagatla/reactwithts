interface Urls {
    cockpitUrl: string;
    srsUrl: string;
}

declare const value: Urls;
export = value;
