/**
 * Class description: Redux action creators linked to eventDetails
 * @author Capgemini
 * @version 1.0
 */
import { ShmEventController } from '../../controllers/ShmEventController';
import { getIdToken } from '../../utils/AuthenticationUtils';

export const LOADEVENTERROR = 'LOADEVENTERROR';
export const LOADMISDATA = 'LOADMISDATA';
export const LOADCORRELATEDEVENTSSUCCESS = 'LOADCORRELATEDEVENTSSUCCESS';
export const SETNOCORRELATION = 'SETNOCORRELATION';
export const CORRELATIONREQUESTERROR = 'CORRELATIONREQUESTERROR';
export const CLEAREVENT = 'CLEAREVENT';
export const SETTASKREFLIST = 'SETTASKREFLIST';
export const SETFAULTCASELINKS = 'SETFAULTCASELINKS';
export const SETCORRELATIONERROR = 'SETCORRELATIONERROR';

interface MisDataResponse {
  data: MisDataDetails;
  message: string;
  status: string;
}

interface MisDataDetails {
  action: string;
  ataChapter: string;
  ataSection: string;
  closedDate: string;
  description: string;
  id: string;
  status: string;
}

/**
 * Fetch the event data for a given event id
 * Dispatch a LOADEVENTSUCCESS action when done
 * @param eventId The id of the event we want to get the data
 */
export function loadEvent(
  hashKey: string,
  smEventDate: string,
  correlId: string
) {
  if (correlId && correlId !== 'null') {
    return loadEventWithCorrelId(hashKey, smEventDate, correlId);
  }
  return loadEventWithoutCorrelId(hashKey, smEventDate);
}

export function loadEventWithCorrelId(
  hashKey: string,
  smEventDate: string,
  correlId: string
) {
  return (dispatch: any) => {
    let correlById: boolean = false;
    let oneFaultCase: boolean = false;

    return ShmEventController.getCorrelatedEventsHashKeys(
      getIdToken(),
      hashKey,
      correlId
    )
      .then((correlation: any) => {
        if (correlation.exception) {
          dispatch(setCorrelationError('NO_TSM_FOUND'));
        } else {
          if (
            correlation.data.hasOwnProperty('correlatedFaultCases') &&
            correlation.data.correlatedFaultCases.length === 1
          ) {
            oneFaultCase = true;
          }

          if (correlation.data.taskRefs) {
            dispatch(setTaskRefList(correlation.data.taskRefs));
          }
          if (
            correlation.data.correlatedEventList &&
            correlation.data.correlatedEventList != null
          ) {
            correlById = true;
            dispatch(
              manageCorrelatedEvents(
                correlId,
                correlation.data.correlatedEventList,
                hashKey,
                smEventDate,
                correlById,
                oneFaultCase
              )
            );
          } else if (
            correlation.data.correlatedEvents &&
            correlation.data.correlatedEvents.length > 0
          ) {
            dispatch(
              manageCorrelatedEvents(
                correlId,
                correlation.data.correlatedEvents,
                hashKey,
                smEventDate,
                correlById,
                oneFaultCase
              )
            );
          } else {
            correlById = true;
            dispatch(
              manageCorrelatedEvents(
                null,
                null,
                hashKey,
                smEventDate,
                correlById,
                oneFaultCase
              )
            );
            dispatch(setCorrelationError('NO_TSM_DATA'));
          }
        }
      })
      .catch((error: any) => {
        dispatch(correlationRequestError());
      });
  };
}

export function loadEventWithoutCorrelId(hashKey: string, smEventDate: string) {
  return (dispatch: any) => {
    dispatch(getCorrelatedEventsById(null, null, hashKey, smEventDate));
    dispatch(setCorrelationError('NO_TSM_FOUND'));
  };
}

/**
 * Manage the storage of correlatedEvents received from api
 * @param correlatedEvents Array of correlated events hashkeys
 */
export function manageCorrelatedEvents(
  correlId: any,
  correlatedEvents: any,
  hashKey: string,
  smEventDate: string,
  correlById: boolean,
  oneFaultCase?: boolean
) {
  return (dispatch: any) => {
    if (correlatedEvents && correlatedEvents[0] === 'NO_TSM_FOUND') {
      dispatch(setCorrelationError('NO_TSM_FOUND'));
    } else if (correlById) {
      dispatch(
        getCorrelatedEventsById(
          correlId,
          correlatedEvents,
          hashKey,
          smEventDate,
          oneFaultCase
        )
      );
    } else {
      loadEventWithoutCorrelId(hashKey, smEventDate);
    }
  };
}

/**
 * Fetch the correlated events given the correlated events id
 * @param correlId id of the correlation
 * @param correlatedEvents Array of correlated events hashkeys
 * @param hashKey hashKey of main event
 * @param smEventDate date of main event
 */
export function getCorrelatedEventsById(
  correlId: any,
  correlatedEvents: any,
  hashKey: string,
  smEventDate: string,
  oneFaultCase?: boolean
) {
  const correlatedResults = buildCorrelatedEventsInfos(
    correlatedEvents,
    hashKey,
    smEventDate
  );

  const correlatedEventsId = correlatedResults.eventsId;
  const correlatedHashKeyLinks = correlatedResults.hashKeyLinks;
  const associatedEvents = correlatedResults.associated;
  const correlEvents = [];

  return (dispatch: any) => {
    return ShmEventController.getCorrelatedEventsIds(
      getIdToken(),
      correlatedEventsId
    )
      .then((correlation: any) => {
        if (correlation != null && !correlation.exception) {
          const hashKeyCorrelatedEvents = [];

          correlation.events.forEach((event: any) => {
            hashKeyCorrelatedEvents.push(event.hashKey);
            event.flightOccurrence = correlation.flightOccurrence;
          });

          const idHashKeyCorrelById = hashKeyCorrelatedEvents.indexOf(hashKey);
          if (idHashKeyCorrelById !== -1) {
            const eventRemoved: any = correlation.events[idHashKeyCorrelById];
            correlation.events.splice(idHashKeyCorrelById, 1);
            correlation.events.unshift(eventRemoved);
          }

          if (correlation.events.length > 0) {
            const correlatedLinks = [];
            correlation.events.forEach((event: any) => {
              if (
                correlatedHashKeyLinks.indexOf(event.hashKey) >= 0 &&
                !oneFaultCase
              ) {
                correlatedLinks.push({
                  link: buildEventDetailLink(
                    event.hashKey,
                    event.smEventDate,
                    correlId
                  ),
                  title: event.titleFromAircraft
                });
              } else {
                correlEvents.push(event);
              }
            });

            const correlatedEventsDifferencied: any = differenciateAssociatedEvents(
              correlEvents,
              associatedEvents
            );

            dispatch(loadCorrelatedEventsSuccess(correlatedEventsDifferencied));
            dispatch(setFaultCaseLinks(correlatedLinks));
          }
        } else if (correlation.exception) {
          dispatch(setCorrelationError('NO_TSM_FOUND'));
          loadEventWithoutCorrelId(hashKey, smEventDate);
        }
      })
      .catch((error: any) => {
        dispatch(correlationRequestError());
      });
  };
}

/**
 * Get MIS data
 * @param pHashKey event hash key
 */
export function getMisDataDetails(pHashKey: string) {
  return (dispatch: any) => {
    const lIdToken: string = getIdToken();
    return ShmEventController.getEventDetailsByHashkey(lIdToken, pHashKey)
      .then((eventByHashKeyResponse: any) => {
        if (eventByHashKeyResponse.status === 'success') {
          // Call MIS data API
          ShmEventController.getMisDataDetails(
            lIdToken,
            eventByHashKeyResponse.data.workOrderReference,
            eventByHashKeyResponse.data.acMatricule
          )
            .then((response: MisDataResponse) => {
              if (response.status === 'success') {
                dispatch(loadMisData(response.data));
              } else {
                dispatch(loadMisData(null));
              }
            })
            .catch(error => {
              dispatch(loadMisData(null));
            });
        } else {
          dispatch(loadMisData(null));
        }
      })
      .catch(error => {
        dispatch(loadMisData(null));
      });
  };
}

/**
 * Dispatch MIS data in Redux store
 * @param pMisDataDetails MIS data
 */
function loadMisData(pMisDataDetails: MisDataDetails) {
  return {
    misData: pMisDataDetails,
    type: LOADMISDATA
  };
}

/**
 * Fetch the correlated events information (build correlatedEvents ids,
 * build correlatedLinks list if main event is a associated warning,
 * build associatedEvents list to diferenciate warning of associated warning if main event isn't an associated warning
 * @param correlId id of the correlation
 * @param correlatedEvents Array of correlated events hashkeys
 * @param hashKey hashKey of main event
 * @param smEventDate date of main event
 */
export function buildCorrelatedEventsInfos(
  correlatedEvents: any,
  hashKey: string,
  smEventDate: string
) {
  const correlatedEventsId = [];
  const correlatedHashKeyLinks = [];
  const associatedEvents = [];

  if (correlatedEvents && correlatedEvents.length !== 0) {
    correlatedEvents.forEach((cEvent: any) => {
      correlatedEventsId.push(cEvent.hashKey + '_' + cEvent.smEventDate);
      if (cEvent.hasOwnProperty('linked')) {
        if (cEvent.linked === false && cEvent.tsmType === 'fltDesc2') {
          associatedEvents.push(cEvent.hashKey);
        } else if (
          cEvent.hashKey !== hashKey &&
          cEvent.tsmType !== 'fltDesc' &&
          cEvent.linked === true
        ) {
          correlatedHashKeyLinks.push(cEvent.hashKey);
        }
      }
    });
  } else {
    correlatedEventsId.push(hashKey + '_' + smEventDate);
  }

  return {
    associated: associatedEvents,
    eventsId: correlatedEventsId,
    hashKeyLinks: correlatedHashKeyLinks
  };
}

export function buildEventDetailLink(
  hashKey: string,
  smEventDate: any,
  correlId: any
) {
  const eventLink = encodeURI(
    '/shm-event/' +
      encodeURIComponent(hashKey) +
      '?smEventDate=' +
      encodeURIComponent(smEventDate) +
      '&correlId=' +
      encodeURIComponent(correlId)
  );

  return eventLink;
}

/**
 * add boolean isAssociated as true if the correlatedEvent is an associated warning
 * @param associatedWarningsHashKeys hashkeys of the events whom are associatedWarning
 * @param correlatedEvents Array of correlated events hashkeys
 *
 */
export function differenciateAssociatedEvents(
  correlatedEvents: any,
  associatedWarningsHashKeys: any
) {
  correlatedEvents.forEach((event: any) => {
    event.isAssociated = false;

    if (associatedWarningsHashKeys.indexOf(event.hashKey) >= 0) {
      event.isAssociated = true;
    }
  });

  return correlatedEvents;
}

/**
 * Return a SETTASKREFLIST action
 */
export function setTaskRefList(esTaskRefList: any) {
  // Clean the taskRef to remove duplicates
  const tasksRefsList = Object.keys(esTaskRefList);
  const finalList = [];
  tasksRefsList.forEach((fc: any) => {
    esTaskRefList[fc].forEach((taskRef: any) => {
      finalList.push(taskRef);
    });
  });

  return { type: 'SETTASKREFLIST', finalList };
}

/**
 * Return a SETFAULTCASELINKS action
 */
export function setFaultCaseLinks(correlatedLinks: any) {
  return { type: 'SETFAULTCASELINKS', correlatedLinks };
}

/**
 * Return a SETCORRELATIONERROR action
 */
export function setCorrelationError(error: string) {
  return { type: 'SETCORRELATIONERROR', error };
}

/**
 * Return a CLEAREVENT action
 */
export function clearEvent() {
  return { type: 'CLEAREVENT' };
}

/**
 * Return a CORRELATIONREQUESTERROR action
 */
export function correlationRequestError() {
  return { type: 'CORRELATIONREQUESTERROR' };
}

/**
 * Return a LOADCORRELATEDEVENTSSUCCESS action
 * @param event The event loaded
 */
export function loadCorrelatedEventsSuccess(correlatedEvents: any) {
  return { type: 'LOADCORRELATEDEVENTSSUCCESS', correlatedEvents };
}

/**
 * Return a LOADEVENTERROR404 action
 */
export function loadEventError() {
  return { type: 'LOADEVENTERROR' };
}
