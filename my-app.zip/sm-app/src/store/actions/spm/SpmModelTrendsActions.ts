import { ModelTrendsController } from '../../../controllers/ModelTrendsController';
import { FleetInfos } from '../../../model/spm/modelTrends/FleetInfos';
import { getIdToken } from '../../../utils/AuthenticationUtils';

/**
 * Fetch models configuration
 */
export function loadFilters() {
  return (dispatch) => {
    return ModelTrendsController.loadFiltersByUser(getIdToken())
      .then((fleetsInfos: FleetInfos[]) => {
        dispatch(loadFiltersSuccess(fleetsInfos));
      })
      .catch((error: Response) => {
        error.json().then((res) => {
          if (res.exception !== undefined) {
            dispatch(loadFiltersError(res));
          } else {
            dispatch(loadFiltersError(error.status));
          } 
        });
      });
  };
}

/**
 * Return a LOADFILTERSSUCCESS action
 * @param event The fleets informations for filters loaded
 */
export function loadFiltersSuccess(fleetsInfos: FleetInfos[]) {
  return { type: 'LOADFILTERSSUCCESS', fleetsInfos };
}

/**
 * Return a LOADFILTERSERROR action
 */
export function loadFiltersError(exception: any) {
  return { type: 'LOADFILTERSERROR', exception };
}

/**
 * Set filters panel visibility
 * @param pIsVisible true if filters are visible, false otherwise
 */
export function setToggleFiltersVisibility(pIsVisible: boolean) {
  return { type: 'TOGGLEFILTERSVISIBILITY', filtersVisible: pIsVisible };
}
