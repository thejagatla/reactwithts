import { AdministrationController } from '../../../controllers/AdministrationController';
import { getIdToken } from '../../../utils/AuthenticationUtils';

/**
 * Fetch airlines from the server
 * Dispatch a LOADAIRLINESSUCCESS action when done
 * @param eventId The id of the event we want to get the data
 */
export function loadAirlines() {
  return (dispatch) => {
    return AdministrationController.getAirlines(getIdToken())
      .then((icaos: any) => {
        dispatch(loadAirlinesSuccess(icaos));
      })
      .catch((error: Response) => {
        if (error instanceof Response) {
          error.json().then((res) => {
            if (res.exception !== undefined) {
              dispatch(loadAirlinesError(res.exception));
            } else {
              dispatch(loadAirlinesError(error.status));
            } 
          });
        } else {
          dispatch(loadAirlinesError({
            message: 'Call to API airlines failed'
          }));
        }
      });
  };
}

/**
 * Fetch models for a fiven airline icao
 * Dispatch LOADMODELSSUCCESS if OK
 * @param selectedIcao
 */
export function loadModels(selectedIcao: string) {
  return (dispatch) => {
    dispatch(modelsIsLoading());
    return AdministrationController.getModels(selectedIcao, getIdToken())
      .then((modelsForSelectedAirline: any[]) => {
        // Get group by atas
        let modelsSelectedByIcao = [];
        modelsForSelectedAirline.forEach((model) => {
          modelsSelectedByIcao = modelsSelectedByIcao.concat(model.atas);
        });
        // Remove duplicates
        const atasAsSet = new Set(modelsSelectedByIcao);
        const ataForSelectedAirline = Array.from(atasAsSet.values()).sort();
        dispatch(loadModelsSuccess(modelsForSelectedAirline, ataForSelectedAirline));
      }).catch((error: any) => {
        dispatch(loadModelsError(error));
      });
  };
}
/**
 * Return a loadAirlinesSuccess action
 * @param event The event loaded
 */
export function loadAirlinesSuccess(icaos: any) {
  return { type: 'LOADAIRLINESSUCCESS', icaos };
}

/**
 * Return a loadAirlinesError404 action
 */
export function loadAirlinesError(exception: any) {
  return { type: 'LOADAIRLINESERROR', exception };
}

/**
 * Return a loadModelsSuccess action
 */
export function loadModelsSuccess(models: any[], atas: any[]) {
  return { type: 'LOADMODELSSUCCESS', models, atas };
}

/**
 * Return loadModelsError action
 */
export function loadModelsError(exception: any) {
  return { type: 'LOADMODELSERROR', exception };
}

/**
 * Return modelsLoading action
 */
export function modelsIsLoading() {
  return { type: 'MODELSLOADING' };
}
