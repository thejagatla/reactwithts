import { SpmEventController } from '../../../controllers/SpmEventController';
import { SpmEvent } from '../../../model/spm/SpmEvent';
import { SpmEventItem } from '../../../model/spm/SpmEventItem';
import { getIdToken } from '../../../utils/AuthenticationUtils';

/**
 * Fetch the event data for a given event id
 * Dispatch a LOADEVENTSUCCESS action when done
 * @param eventId The id of the event we want to get the data
 */
export function loadEvent(eventId: string) {
  return dispatch => {
    return SpmEventController.getEventById(eventId, getIdToken())
      .then((event: SpmEvent) => {
        event.origin = 'SPM';
        dispatch(loadEventSuccess(event));
      })
      .catch((error: Response) => {
        error.json().then(res => {
          if (res.exception !== undefined) {
            dispatch(loadEventError(res));
          } else {
            dispatch(loadEventError(error.status));
          }
        });
      });
  };
}

/**
 * Return a CLEAREVENT action
 */
export function clearEvent() {
  return { type: 'CLEAREVENT' };
}

/**
 * Fetch the event data for a given event id
 * Dispatch a LOADEVENTSUCCESS action when done
 * @param eventId The id of the event we want to get the data
 */
export function loadEventIgnoreError(eventId: string) {
  return dispatch => {
    return SpmEventController.getEventById(eventId, getIdToken()).then(
      (event: SpmEvent) => {
        event.origin = 'SPM';
        dispatch(loadEventSuccess(event));
      }
    );
  };
}

/**
 * Return a LOADEVENTSUCCESS action
 * @param event The event loaded
 */
export function loadEventSuccess(event: SpmEvent) {
  return { type: 'LOADEVENTSUCCESS', event };
}

/**
 * Return a LOADEVENTERROR404 action
 */
export function loadEventError(exception: any) {
  return { type: 'LOADEVENTERROR', exception };
}

/**
 * Fetch the chart data for a given event
 * Dispatch a LOADCHARTSUCCESS action when done
 * @param eventId The id of the event we want to get the chart
 */
export function loadChart(eventId: string) {
  return dispatch => {
    return SpmEventController.getChartByEventId(eventId, getIdToken())
      .then((eventChart: SpmEventItem[]) => {
        dispatch(loadChartSuccess(eventChart));
      })
      .catch((error: Response) => {
        error.json().then(res => {
          if (res.exception !== undefined) {
            dispatch(loadChartError(res));
          } else {
            dispatch(loadChartError(error.status));
          }
        });
      });
  };
}

/**
 * Fetch an event item by its id for a given event
 * @param eventId Id of the event we want the event item
 * @param eventItemId Id of the event item we want
 */
export function loadEventItemById(eventId: string, toDate: string) {
  return dispatch => {
    return SpmEventController.getEventItemByEventId(
      eventId,
      toDate,
      getIdToken()
    )
      .then((eventItem: SpmEventItem) => {
        dispatch(loadEventItemSuccess(eventItem));
      })
      .catch((error: any) => {
        dispatch(loadEventItemError());
      });
  };
}

/**
 * Return a LOADCHARTSUCCESS action
 * @param chart The chart loaded
 */
export function loadChartSuccess(chart: SpmEventItem[]) {
  return { type: 'LOADCHARTSUCCESS', chart };
}

/**
 * Return a LOADCHARTERROR action
 */
export function loadChartError(exception: any) {
  return { type: 'LOADCHARTERROR', exception };
}

/**
 * Return a LOADEVENTITEMSUCCESS action
 * @param eventItem The event item loaded
 */
export function loadEventItemSuccess(eventItem: SpmEventItem) {
  return { type: 'LOADEVENTITEMSUCCESS', eventItem };
}

/**
 * Return a LOADEVENTITEMERROR action
 * @param eventItem The event item loaded
 */
export function loadEventItemError() {
  return { type: 'LOADEVENTITEMERROR' };
}

/**
 * Return a ADDWORKFLOWHISTORYITEM action
 */
export function addWorkflowHistoryItem(item: any) {
  return { type: 'ADDWORKFLOWHISTORYITEM', item };
}
