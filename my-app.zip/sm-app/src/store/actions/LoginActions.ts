/**
 * Class description: Redux action creators linked to eventDetails
 * @author Capgemini
 * @version 1.0
 */
import * as AWSCognito from 'amazon-cognito-auth-js/dist/amazon-cognito-auth';
import { setupCognito } from 'react-cognito';
import { AdministrationController } from '../../controllers/AdministrationController';
import { AuthConfigController } from '../../controllers/AuthConfigController';
import { getIdToken, getUsername } from '../../utils/AuthenticationUtils';
import { store } from '../configureStore';

const COGNITO_API_URL = '/api/config/cognito.json';
const ONELOGIN_API_URL = '/api/config/onelogin.json';
const FEATURE_FLIPPING_URL = 'api/hp/tools/feature-flipping';
const USER_PROFILE_URL = 'api/users/';

export const ONELOGIN_LOGGED_IN = 'LOGGED_IN';
export const ONELOGIN_LOGGIN_IN = 'LOGGIN_IN';
export const ONELOGIN_LOGGIN_OUT = 'LOGGIN_OUT';
export const ONELOGIN_LOGGED_OUT = 'COGNITO_LOGOUT';
export const SAVEENABLEDFEATURES = 'SAVEENABLEDFEATURES';
export const SAVEUSERPROFILE = 'SAVEUSERPROFILE';
export const REQUESTDONE = 'REQUESTDONE';

/**
 * Setup Cognito config
 */
export function setupCognitoConfig() {
  return (dispatch, getState) => {
    return AuthConfigController.getAuthConfig(COGNITO_API_URL)
      .then((response: any) => {
        setupCognito(store, response);
      })
      .catch(error => {
        console.error('Exception getting cognito config', error);
      });
  };
}

/**
 * Get user profile and flipping features settings
 */
export function getUserProfileAndFeatureFlipping() {
  return dispatch => {
    const lUserName: string = getUsername();

    return AdministrationController.getUserProfileAndFeatureFlipping(
      USER_PROFILE_URL + lUserName,
      FEATURE_FLIPPING_URL,
      getIdToken()
    )
      .then((responses: any) => {
        dispatch(userProdileRequestDone());
        // Save user profile settings
        dispatch(
          saveUserProfile(
            responses[0].mainCompany,
            responses[0].actions,
            responses[0].airlines,
            responses[0].airlineProfile
          )
        );

        // Save feature flipping settings
        dispatch(saveEnabledFeatures(responses[1]));
      })
      .catch(error => {
        dispatch(userProdileRequestDone());
        console.error(
          'Unable to retrieve user profile or flipping features',
          error
        );
      });
  };
}

/**
 * Retrieve enabled features
 */
export function getEnabledFeatures() {
  return dispatch => {
    return AdministrationController.getEnabledFeatures(
      FEATURE_FLIPPING_URL,
      getIdToken()
    )
      .then((response: any) => {
        dispatch(saveEnabledFeatures(response));
      })
      .catch(error => {
        console.error('Exception getting enabled features', error);
      });
  };
}

/**
 * Setup OneLogin config
 */
export function setupOneLoginConfig() {
  return dispatch => {
    return AuthConfigController.getAuthConfig(ONELOGIN_API_URL)
      .then((response: any) => {
        const lCurrentUrl: string = window.location.href;

        // Setup config
        const auth: AWSCognito.CognitoAuth = new AWSCognito.CognitoAuth(
          response
        );

        auth.userhandler = {
          onFailure: (err: any) => {
            // An error occured, launch logout process
            dispatch(oneLoginLogout());
          },
          onSuccess: (result: any) => {
            dispatch(oneLoginSuccess(result));

            // Get user profile and features flipping
            dispatch(getUserProfileAndFeatureFlipping());
          }
        };

        auth.useCodeGrantFlow();

        if (lCurrentUrl.indexOf('?code') !== -1) {
          auth.parseCognitoWebResponse(lCurrentUrl);
        } else {
          auth.getSession();

          // Store auth data
          dispatch(toLogginIn(response));
        }
      })
      .catch(error => {
        console.error('Exception getting oneLogin config', error);
      });
  };
}

/**
 * End of oneLogin setup
 * @param pAuth authentication data
 */
function toLogginIn(pAuthData: any) {
  return {
    authData: pAuthData,
    type: ONELOGIN_LOGGIN_IN
  };
}

/**
 * OneLogin authentication success
 * @param pSession user session
 */
function oneLoginSuccess(pSession: AWSCognito.CognitoAuthSession) {
  const lIdtoken = pSession.getIdToken().getJwtToken();
  const lPayload = lIdtoken.split('.')[1];
  const lTokenobj = JSON.parse(atob(lPayload));

  return {
    type: ONELOGIN_LOGGED_IN,
    username: lTokenobj.preferred_username
  };
}

/**
 * OneLogin logout
 */
export function oneLoginLogout() {
  return (dispatch, getState) => {
    // Sign-out
    const auth: AWSCognito.CognitoAuth = new AWSCognito.CognitoAuth(
      getState().onelogin.auth
    );
    auth.signOut();
    dispatch(oneLoginLogginOut());
  };
}

function oneLoginLogginOut() {
  return { type: ONELOGIN_LOGGIN_OUT };
}

export function confirmLogout() {
  return { type: ONELOGIN_LOGGED_OUT };
}

/**
 * Save enabled features list in redux store
 * @param pEnabledFeatures list of enabled features
 */
function saveEnabledFeatures(pEnabledFeatures: string[]) {
  return {
    enabledFeatures: pEnabledFeatures,
    type: SAVEENABLEDFEATURES
  };
}

/**
 * Inform that the request for user profile is done
 */
function userProdileRequestDone() {
  return {
    type: REQUESTDONE
  };
}

/**
 * Save user profile in redux store
 * @param pMainCompany user main airline
 * @param pActions user actions list
 * @param pAirlines user airlines list
 * @param pAirlineProfile user airline preferences
 */
function saveUserProfile(
  pMainCompany: string,
  pActions: string[],
  pAirlines: string[],
  pAirlineProfile: {
    displayName: string;
    tsmLink: {
      prefix: string;
      suffixBase: string;
    };
  }
) {
  return {
    actions: pActions,
    airlineProfile: pAirlineProfile,
    airlines: pAirlines,
    mainCompany: pMainCompany,
    type: SAVEUSERPROFILE
  };
}
