/**
 * Class description: Redux action creators linked to filters
 * @author Capgemini
 * @version 1.0
 */
// import store from '../configureStore';
import { FleetsweepFilter } from '../../model/fleetsweep/FleetsweepInterfaces';

export const SETACTIVETAB = 'SETACTIVETAB';
export const SETMOREFILTERS = 'SETMOREFILTERS';
export const SETFILTERS = 'SETFILTERS';
export const SETFLEETSWEEPSTATE = 'SETFLEETSWEEPSTATE';
export const SETPERIOD = 'SETPERIOD';
export const TOGGLEFILTERSVISIBILITY = 'TOGGLEFILTERSVISIBILITY';

/**
 * Set filters in redux state
 * @param filters filters enabled
 */
export function setFilters(filters: FleetsweepFilter[]) {
  return {
    filters,
    type: SETFILTERS,
  };
}

/**
 * Set filters in redux state
 * @param filters filters enabled
 */
export function setPeriod(period: number) {
  return {
    period,
    type: SETPERIOD,
  };
}

/**
 * Set "more filter" filters in redux state
 * @param pMoreFilters "more filter" filters
 */
export function setMoreFilters(pMoreFilters: FleetsweepFilter[]) {
  return {
    moreFilters: pMoreFilters,
    type: SETMOREFILTERS
  };
}

/**
 * Set active fleesweep tab
 * @param pActiveTab active tab
 */
export function setActiveTab(pActiveTab: number) {
  return {
    selectedTabId: pActiveTab,
    type: SETACTIVETAB
  };
}

/**
 * Set tabs content
 * @param pNewState new fleetsweep state
 */
export function setFleetsweepState(pNewState: any) {
  return {
    customizeTab: pNewState.customizeTab,
    selectedTabId: pNewState.selectedTabId,
    tabs: pNewState.tabs,
    type: SETFLEETSWEEPSTATE
  };
}

/**
 * Set filters panel visibility
 * @param pIsVisible true if filters are visible, false otherwise
 */
export function setToggleFiltersVisibility(pIsVisible: boolean) {
  return {
    filtersVisible: pIsVisible,
    type: TOGGLEFILTERSVISIBILITY
  };
}
