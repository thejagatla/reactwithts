/**
 * Class description: Redux action creators linked to events sort
 * @author Capgemini
 * @version 1.0
 */
export const CHANGESORT = 'CHANGESORT';

/**
 * Trigger sort change
 * @param pNewSortValue new sort value
 */
export function changeSort(pNewSortValue: string) {
  return {
    newSortValue: pNewSortValue,
    type: CHANGESORT
  };
}
