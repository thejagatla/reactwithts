/**
 * Class description: Redux action creators linked to events
 * @author Capgemini
 * @version 1.0
 */
import * as AWSCognito from 'amazon-cognito-auth-js/dist/amazon-cognito-auth';
import { List } from 'react-virtualized';
import { EventsController } from '../../controllers/EventsController';
import * as Strings from '../../lang/strings.json';
import { StatusText } from '../../model/EventsConstantes';
import { FleetsweepFilter } from '../../model/fleetsweep/FleetsweepInterfaces';
import { getIdToken } from '../../utils/AuthenticationUtils';
import { store } from '../configureStore';
import { oneLoginLogout } from './LoginActions';

export const SAVELOCALEVENTS = 'SAVELOCALEVENTS';
export const SETAUTOSIZERHEIGHT = 'SETAUTOSIZERHEIGHT';
export const REQUESTEVENTS = 'REQUESTEVENTS';
export const RECEIVEEVENTS = 'RECEIVEEVENTS';
export const LOADINGEVENTS = 'LOADINGEVENTS';
export const SAVESEARCHTEXT = 'SAVESEARCHTEXT';
export const SAVENEWINTERVALS = 'SAVENEWINTERVALS';
export const RESTOREDEFAULTSTATE = 'RESTOREDEFAULTSTATE';
export const RESTOREINFINITELOADER = 'RESTOREINFINITELOADER';
export const FINISHEDFETCHING = 'FINISHEDFETCHING';
export const SETITIMEOUTID = 'SETITIMEOUTID';
export const SETLISTREF = 'SETLISTREF';

const STATUS_LOADING = 1;
const STATUS_LOADED = 2;

/**
 * Request events from server-side action
 */
export function requestEvents() {
  return {
    type: REQUESTEVENTS
  };
}

/**
 * Request events from server-side action
 */
export function setAutosizerHeight(height: number) {
  return {
    height,
    type: SETAUTOSIZERHEIGHT
  };
}

/**
 * End of fetching reporting
 * @param error If the request sent an error
 */
export function finishedFetching(error: boolean = false) {
  return {
    error,
    type: FINISHEDFETCHING
  };
}

/**
 * Set new timeout Id in redux
 * @param timeoutId timeout Id
 */
export function setTimeoutId(timeoutId: any) {
  return {
    timeoutId,
    type: SETITIMEOUTID
  };
}

/**
 * Retrieving events from server-side action
 * @param loadedRowsMap map of loaded rows
 */
export function loadingEvents(loadedRowsMap: { [id: number]: number }) {
  return {
    loadedRowsMap,
    type: LOADINGEVENTS
  };
}

/**
 * Add local event
 * @param localEvent Local Event (updating event)
 */
export function addLocalEvent(localEvent: any) {
  const storedValues: any = store.getState();
  const { localEvents, localEventsHashKeys } = storedValues.eventReducer;
  localEvent.localEventCreationDate = new Date().getTime();
  localEvents.push(localEvent);
  localEventsHashKeys.push(localEvent.hashKey);

  return {
    localEvents,
    localEventsHashKeys,
    type: SAVELOCALEVENTS
  };
}

/**
 * Remove a local event
 * @param localEventId ID of the local event to delete
 */
export function removeLocalEvent(localEventId: any) {
  const storedValues: any = store.getState();
  const { localEvents, localEventsHashKeys } = storedValues.eventReducer;
  const indexHash = localEventsHashKeys.indexOf(localEventId);
  if (indexHash > -1) {
    localEventsHashKeys.splice(indexHash, 1);
  }
  localEvents.map((event, index) => {
    if (event.hashKey === localEventId) {
      localEvents.splice(indexHash, 1);
    }
  });

  return {
    localEvents,
    localEventsHashKeys,
    type: SAVELOCALEVENTS
  };
}

/**
 * Save search text field action
 * @param searchText filled text in search box
 */
export function saveSearchText(searchText: string) {
  return {
    searchText,
    type: SAVESEARCHTEXT
  };
}

/**
 * Save new interval rows action
 * @param from begin offset
 * @param size events number
 */
export function setListRef(listRef: List) {
  return {
    listRef,
    type: SETLISTREF
  };
}

/**
 * Save new interval rows action
 * @param from begin offset
 * @param size events number
 */
export function saveNewIntervals(from: number, size: number) {
  return {
    from,
    size,
    type: SAVENEWINTERVALS
  };
}

/**
 * Update displayed events action
 * @param from begin offset
 * @param size events number
 * @param loadedRowsMap map of loaded events
 * @param action action
 */
export function updateLoadingEvents(
  from: number, size: number, action: number) {
  return (dispatch, getState) => {
    const storedValuesUpdated: any = getState();
    const loadedRowsMap = storedValuesUpdated.eventReducer.loadedRowsMap;
    const events = storedValuesUpdated.eventReducer.events;
    for (let i = from; i < (from + size); i = i + 1) {
      if ((action === STATUS_LOADED && events[i])) {
        if (loadedRowsMap[i] !== action) {
          loadedRowsMap[i] = action;
        }   
      } else if (action === STATUS_LOADING && !events[i]) {
        loadedRowsMap[i] = action;
      }
    }
    dispatch(loadingEvents(loadedRowsMap));
  };
}

/**
 * Set into state the redirection URL
 * @param url destination url
 */
export function updateGrid() {
  return (dispatch, getState) => {
    const storedValues: any = getState();
    storedValues.eventReducer.listRef.forceUpdateGrid();
  };
}

/**
 * Prepare request
 */
export function fetchEvents(
  shouldRestoreDefaultState: boolean = false,
  shouldRefreshInfiniteLoader: boolean = false,
  loadingMore: boolean = false,
) {
  return (dispatch, getState) => {
    dispatch(requestEvents());

    const storedValues: any = getState();
    let from = storedValues.eventReducer.from;
    const { searchText, apiRequestId } = storedValues.eventReducer;
    const { moreFilters, filters, period } = storedValues.filtersReducer;
    const { currentSort } = storedValues.sortReducer;
    const idToken = getIdToken();

    // Add more filters to filters list
    const lFinalFilters = filters.concat(moreFilters);

    let size = storedValues.eventReducer.size;
    if (size === 0) {
      size = storedValues.eventReducer.minimumBatchSize;
    }

    if (shouldRestoreDefaultState) {
      dispatch(restoreDefaultState());
      size = storedValues.eventReducer.minimumBatchSize;
      from = 0;
    } else if (!shouldRefreshInfiniteLoader) {
      dispatch(updateLoadingEvents(from, size, STATUS_LOADING));
    } else {
      from = 0;
    }
    dispatch(
      launchRequestEvents(
        idToken,
        from,
        size,
        searchText,
        lFinalFilters,
        period,
        apiRequestId,
        shouldRestoreDefaultState,
        shouldRefreshInfiniteLoader,
        loadingMore,
        currentSort
      )
    );
  };
}

/**
 * Fetch events from API through EventsController
 * @param pIdToken API authentication token
 * @param pFrom begin offset
 * @param pSize results size
 * @param pSearchText text searched
 * @param pFilters filters
 * @param pPeriod search launch frequency
 * @param pApiRequestId request id
 * @param pShouldRestoreDefaultState true if restore state, false otherwise
 * @param pLoadingMore true if load more, false otherwise
 * @param pSort events sort value
 */
function launchRequestEvents(
  pIdToken: string,
  pFrom: any,
  pSize: any,
  pSearchText: string,
  pFilters: FleetsweepFilter[],
  pPeriod: any,
  pApiRequestId: number,
  pShouldRestoreDefaultState: boolean,
  pshouldRefreshInfiniteLoader: boolean,
  pLoadingMore: boolean,
  pSort: string
) {
  return (dispatch, getState) => {
    EventsController.fetchEvents(
      pIdToken,
      pFrom,
      pSize,
      pSearchText,
      pFilters,
      pPeriod,
      pSort
    )
      .then((response: any) => {
        if (response.status === StatusText.SUCCESS && response.data) {
          dispatch(refreshToken());

          dispatch(manageResponse(
            response,
            pFrom,
            pSize,
            pApiRequestId,
            pShouldRestoreDefaultState,
            pshouldRefreshInfiniteLoader,
            response.context.pollingDelay,
            pLoadingMore
          ));
        } else {
          // Unauthorized error
          if ((response.message === Strings.expiredToken) || (response.message === Strings.unauthorized)) {
            dispatch(refreshToken());
          } else {
            console.error('Error retrieving events ' + response.message);

            dispatch(restoreDefaultState());
            dispatch(finishedFetching());
          }
        }
      }).catch((error) => {
        console.error('Exception retrieving events ', error);
        dispatch(restoreDefaultState());
        dispatch(finishedFetching(true));
      });
  };
}

/**
 * Refresh token
 */
function refreshToken() {
  return (dispatch, getState) => {
    const storedValues: any = getState();

    // Try to refresh tokens with oneLogin
    if (storedValues.onelogin.auth !== null) {
      const auth: AWSCognito.CognitoAuth = new AWSCognito.CognitoAuth(storedValues.onelogin.auth);

      auth.userhandler = {
        onFailure: (err: any) => {
          // An error occured, launch logout process
          dispatch(oneLoginLogout());
        },
        onSuccess: (result: any) => {
          // refresh successful => do nothing
        }
      };

      auth.getSession();
    // Try to refresh tokens with cognito
    } else {
      // Find a way using react-cognito to refresh the user token
    }
  };
}

function setLoaderAnimationState(eventsList: any, apiRequestId: number, numberOfElementsToAnimate: number) {
  if (apiRequestId > 1) {
    for (let j = 0; j <= numberOfElementsToAnimate; j = j + 1) {
      if (eventsList[j]) {
        eventsList[j].loaded = true;
      }
    }
  }

  return eventsList;
}

/**
 * Receive events from API
 * @param from begin offset
 */
export function manageResponse(
  response: any,
  from: number,
  size: number,
  thisRequestId: number,
  shouldRestoreDefaultState: boolean,
  shouldRefreshInfiniteLoader: boolean,
  pollingDelay: number,
  loadingMore: boolean
) {
  return (dispatch, getState) => {
    const storedValues: any = getState();
    const { apiRequestId, autosizerHeight, rowHeight } = storedValues.eventReducer;
    if (apiRequestId === thisRequestId || loadingMore) {
      let eventsList: any[] = storedValues.eventReducer.events;
      const to = from + response.data.result.length;
      const numberOfElementsToAnimate = Math.ceil(autosizerHeight / rowHeight);

      for (let i = from; i < to; i = i + 1) {
        eventsList[i] = response.data.result[i - from];
        eventsList[i].loaded = !(i <= numberOfElementsToAnimate && apiRequestId === 1);
      }
      eventsList = setLoaderAnimationState(eventsList, apiRequestId, numberOfElementsToAnimate);
      if (eventsList.length > response.data.total) {
        eventsList = eventsList.slice(0, response.data.total);
      }
      if (shouldRefreshInfiniteLoader) {
        dispatch(restoreInfiniteLoader());
        dispatch(updateLoadingEvents(from, size, STATUS_LOADED));
      }
      dispatch(receiveEvents(eventsList, from, size, pollingDelay, response.data.total));
      dispatch(updateLoadingEvents(from, size, STATUS_LOADED));
      dispatch(updateGrid());
      dispatch(finishedFetching());
    }
  };
}

/**
 * Receive events from server-side action
 * @param response events retrieved from server
 * @param from begin offset
 * @param size events number
 * @param pollingDelay polling delay to re-request api
 * @param totalEvents Total number of events
 */
export function receiveEvents(eventsList: any, from: number, size: number, pollingDelay: number, totalEvents: number) {
  return {
    eventsList,
    from,
    pollingDelay,
    size,
    totalEvents,
    type: RECEIVEEVENTS
  };
}

/**
 * Define new interval action
 * @param from begin offset
 * @param size events number
 */
export function setNewIntervals(from: number, size: number) {
  return (dispatch, getState) => {
    const storedValues: any = getState();
    const goodSize = size < storedValues.eventReducer.minimumBatchSize ?
      storedValues.eventReducer.minimumBatchSize : size;
    dispatch(saveNewIntervals(from, goodSize));
    dispatch(fetchEvents(false, false, true));
  };
}

/**
 * Restore default state action
 */
export function restoreInfiniteLoader() {
  return {
    type: RESTOREINFINITELOADER
  };
}

/**
 * Restore default state action
 */
export function restoreDefaultState() {
  return {
    type: RESTOREDEFAULTSTATE
  };
}

/**
 * Set a new filter
 */
export function setSearchText(text: string) {
  return (dispatch) => {
    dispatch(saveSearchText(text));
  };
}
