export const VISIBILITYCOMPONENTPANEL = 'VISIBILITYCOMPONENTPANEL';

/**
 *
 * @param lVisible
 */
export function changeVisibilityComponentPanel(lVisible: boolean) {
  console.log('changeVisibilityComponentPanel >>>>>>>>>>>>>');
  return {
    newVisibilityPanel: lVisible,
    type: VISIBILITYCOMPONENTPANEL
  };
}
