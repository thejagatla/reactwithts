/**
 * Class description: React/Redux linker class
 * @author Capgemini
 */

import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { SpmModelTrendsViewController } from '../../../components/spm/modelTrends/SpmModelTrendsViewController';
import * as ModelTrendsActions from '../../actions/spm/SpmModelTrendsActions';

const mapStateToProps = (state, props) => {
  return {
    ...state.spmModelTrendsReducer,
    state: {
      filtersVisible: state.spmModelTrendsReducer.filtersVisible,
    }
  };
};

/**
 * Map actions to component props
 * @param dispatch Redux dispatcher
 */
const mapDispatchToProps = (dispatch: any) => {
  return {
    loadFilters: () => {
      dispatch(ModelTrendsActions.loadFilters());
    },
    setToggleFiltersVisibility: (visibility) => {
      dispatch(ModelTrendsActions.setToggleFiltersVisibility(visibility));
    }
  };
};

const SpmModelTrendsContainer: any = connect(
  mapStateToProps,
  mapDispatchToProps
)(SpmModelTrendsViewController);

export default withRouter(SpmModelTrendsContainer);
