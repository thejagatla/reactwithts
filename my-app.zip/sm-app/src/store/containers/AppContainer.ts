/**
 * Class description: React/Redux linker class
 * @author Capgemini
 * @version 1.0
 */
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { App } from '../../components/App';
import * as OneLoginActions from '../actions/LoginActions';

const mapStateToProps = state => {
  return {
    cognito: state.cognito,
    oneLogin: state.onelogin,
    userProfile: state.userProfile
  };
};

const mapDispatchToProps = dispatch => {
  return {
    oneLoginLogout: () => {
      dispatch(OneLoginActions.oneLoginLogout());
    }
  };
};

const AppContainer: any = connect(
  mapStateToProps,
  mapDispatchToProps
)(App);

export default withRouter(AppContainer);
