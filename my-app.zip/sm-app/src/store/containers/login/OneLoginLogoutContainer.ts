/**
 * Class description: React/Redux linker class
 * @author Capgemini
 * @version 1.0
 */
import { connect } from 'react-redux';
import { OneLoginLogoutView } from '../../../components/common/login/OneLoginLogoutView';
import * as OneLoginActions from '../../actions/LoginActions';

const mapStateToProps = (state) => {
  return {
    oneLogin: state.onelogin
  };
};

const mapDispatchToProps = (dispatch, getState) => {
  return {
    confirmLogout: () => {
      dispatch(OneLoginActions.confirmLogout());
    },
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(OneLoginLogoutView);
