/**
 * Class description: React/Redux linker class
 * @author Capgemini
 * @version 1.0
 */
import { connect } from 'react-redux';
import { OneLoginViewController } from '../../../components/common/login/OneLoginViewController';
import * as OneLoginActions from '../../actions/LoginActions';

const mapStateToProps = (state) => {
  return {
    cognito: state.cognito,
    oneLogin: state.onelogin
  };
};

const mapDispatchToProps = (dispatch, getState) => {
  return {
    setupOneLoginConfig: () => {
      dispatch(OneLoginActions.setupOneLoginConfig());
    },
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(OneLoginViewController);
