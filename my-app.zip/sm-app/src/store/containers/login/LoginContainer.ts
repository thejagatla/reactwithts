/**
 * Class description: React/Redux linker class
 * @author Capgemini
 * @version 1.0
 */
import { connect } from 'react-redux';
import { BaseDashboard } from '../../../components/common/login/BaseDashboard';
import * as LoginActions from '../../actions/LoginActions';

const mapStateToProps = (state, props) => {
  return {
    location: props.location,
    oneLogin: state.onelogin,
    state: state.cognito.state,
    user: state.cognito.user
  };
};

const mapDispatchToProps = dispatch => {
  return {
    getUserProfileAndFeatureFlipping: () => {
      dispatch(LoginActions.getUserProfileAndFeatureFlipping());
    },
    setupCognitoConfig: () => {
      dispatch(LoginActions.setupCognitoConfig());
    }
  };
};

const LoginContainer: any = connect(
  mapStateToProps,
  mapDispatchToProps
)(BaseDashboard);

export default LoginContainer;
