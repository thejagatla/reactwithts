/**
 * Class description: React/Redux linker class
 * @author Capgemini
 * @version 1.0
 */
import { connect } from 'react-redux';
import * as RibbonActions from '../../actions/RibbonActions';

import HeaderViewController from '../../../components/common/header/HeaderViewController';

const mapStateToProps = (state, ownProps) => {
  return {
    props: ownProps,
    visibilityPanel: state.ribbonReducer.visibilityPanel
  };
};

const mapDispatchToProps = dispatch => {
  return {
    updateVisibility: (pVisibility: boolean) => {
      dispatch(RibbonActions.changeVisibilityComponentPanel(pVisibility));
    }
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(HeaderViewController);
