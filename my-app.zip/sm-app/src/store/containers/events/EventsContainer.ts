/**
 * Class description: React/Redux linker class
 * @author Capgemini
 * @version 1.0
 */
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { EventsViewController } from '../../../components/common/events/EventsViewController';
import * as EventActions from '../../actions/EventsActions';

const mapStateToProps = state => {
  return {
    state: {
      apiRequestId: state.eventReducer.apiRequestId,
      autosizerHeight: state.eventReducer.autosizerHeight,
      displayName: state.userProfile.displayName,
      events: state.eventReducer.events,
      firstRequestProcessed: state.eventReducer.firstRequestProcessed,
      isFetching: state.eventReducer.isFetching,
      lastRequestError: state.eventReducer.lastRequestError,
      loadedRowsMap: state.eventReducer.loadedRowsMap,
      localEvents: state.eventReducer.localEvents,
      localEventsHashKeys: state.eventReducer.localEventsHashKeys,
      numberLoaded: state.eventReducer.numberLoaded,
      rowHeight: state.eventReducer.rowHeight,
      totalEvents: state.eventReducer.totalEvents,
      tsmLink: state.userProfile.tsmLink
    }
  };
};

const mapDispatchToProps = dispatch => {
  return {
    addLocalEvent: localEvent => {
      dispatch(EventActions.addLocalEvent(localEvent));
    },
    removeLocalEvent: localEventId => {
      dispatch(EventActions.removeLocalEvent(localEventId));
    },
    setAutosizerHeight: height => {
      dispatch(EventActions.setAutosizerHeight(height));
    },
    setListRef: listRef => {
      dispatch(EventActions.setListRef(listRef));
    },
    setNewIntervals: (from, size) => {
      dispatch(EventActions.setNewIntervals(from, size));
    },
    setSearchText: text => {
      dispatch(EventActions.setSearchText(text));
    }
  };
};

const EventsContainer: any = connect(
  mapStateToProps,
  mapDispatchToProps
)(EventsViewController);

export default withRouter(EventsContainer);
