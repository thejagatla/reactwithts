/**
 * Class description: React/Redux linker class
 * @author Capgemini
 * @version 1.0
 */
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { EventCockpit } from '../../../components/common/cockpit/EventCockpit';

const mapStateToProps = state => {
  return {
    totalEvents: state.eventReducer.totalEvents
  };
};

const EventCockpitContainer: any = connect(
  mapStateToProps,
  null
)(EventCockpit);

export default withRouter(EventCockpitContainer);
