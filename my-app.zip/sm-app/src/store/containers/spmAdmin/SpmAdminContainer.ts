/**
 * Class description: React/Redux linker class
 * @author Capgemini
 */

import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { SpmAdminControllerView } from '../../../components/spm/admin/SpmAdminControllerView';
import * as SpmAdministrationActions from '../../actions/spm/SpmAdministrationActions';

const mapStateToProps = (state, props) => {
  return {
    ...state.spmAdminReducer,
  };
};

const mapDispatchToProps = (dispatch: any) => {
  return {
    getAirlines: () => {
      dispatch(SpmAdministrationActions.loadAirlines());
    },
    getModels: (icao: string) => {
      dispatch(SpmAdministrationActions.loadModels(icao));
    }
  };
};

const SpmAdminContainer: any = connect(
  mapStateToProps,
  mapDispatchToProps
)(SpmAdminControllerView);

export default withRouter(SpmAdminContainer);
