/**
 * Class description: React/Redux linker class
 * @author Capgemini
 * @version 1.0
 */
import { connect } from 'react-redux';
import { EventDetailsPageViewController } from '../../../components/shm/eventDetails/EventDetailsPageViewController';
import * as EventDetailsActions from '../../actions/EventDetailsActions';

const mapStateToProps = (state, ownProps) => {
  return {
    state: {
      correlatedEvents: state.eventDetailsReducer.correlatedEvents,
      correlatedEventsLoaded: state.eventDetailsReducer.correlatedEventsLoaded,
      correlatedLinksList: state.eventDetailsReducer.correlatedLinksList,
      displayName: state.userProfile.displayName,
      esTaskRefList: state.eventDetailsReducer.esTaskRefList,
      hashKey: decodeURIComponent(ownProps.route.match.params.id),
      loadingCorrelation: state.eventDetailsReducer.loadingCorrelation,
      loadingCorrelationError:
        state.eventDetailsReducer.loadingCorrelationError,
      loadingMmel: state.eventDetailsReducer.loadingMmel,
      misData: state.eventDetailsReducer.misData,
      misDataLoaded: state.eventDetailsReducer.misDataLoaded,
      route: ownProps.route,
      tsmCorrelationMessage: state.eventDetailsReducer.tsmCorrelationMessage,
      tsmLink: state.userProfile.tsmLink
    }
  };
};

const mapDispatchToProps = dispatch => {
  return {
    clearEvent: () => {
      dispatch(EventDetailsActions.clearEvent());
    },
    getMisDataDetails: pHashkey => {
      dispatch(EventDetailsActions.getMisDataDetails(pHashkey));
    },
    loadEvent: (hashKey, smEventDate, correlId) => {
      dispatch(EventDetailsActions.loadEvent(hashKey, smEventDate, correlId));
    }
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(EventDetailsPageViewController);
