import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { EventDetailsPageViewController } 
    from '../../../components/spm/eventDetailsPage/EventDetailsPageViewController';
import * as EventActions from '../../actions/spm/SpmEventActions';

/**
 * Map the Redux state to component props
 * @param state Redux state
 * @param ownProps Component props
 */
const mapStateToProps = (state: any, ownProps: any) => {
  return {
    state: {
      ...state.spmEventReducer,
      displayName: state.userProfile.displayName,
      eventId: String(ownProps.match.params.id),
    }
  };
};

/**
 * Map actions to component props
 * @param dispatch Redux dispatcher
 */
const mapDispatchToProps = (dispatch: any) => {
  return {
    addWorkflowHistoryItem: (item: any) => {
      dispatch(EventActions.addWorkflowHistoryItem(item));
    },
    clearEvent: () => {
      dispatch(EventActions.clearEvent());
    },
    loadChart: (eventId: string) => {
      dispatch(EventActions.loadChart(eventId));
    },
    loadEvent: (eventId: string) => {
      dispatch(EventActions.loadEvent(eventId));
    },
    loadEventIgnoreError: (eventId: string) => {
      dispatch(EventActions.loadEventIgnoreError(eventId));
    },
    loadEventItem: (eventId: string, toDate: string) => {
      dispatch(EventActions.loadEventItemById(eventId, toDate));
    }
  };
};

/**
 * Connect component to Redux
 */
const SpmEventContainer: any = connect(
  mapStateToProps,
  mapDispatchToProps
)(EventDetailsPageViewController);

export default withRouter(SpmEventContainer);
