/**
 * Class description: React/Redux linker class
 * @author Capgemini
 * @version 1.0
 */
import { connect } from 'react-redux';
import { SortViewController } from '../../../components/common/sort/SortViewController';
import * as SortActions from '../../actions/SortActions';

const mapStateToProps = (state) => {
  return {
    currentSort: state.sortReducer.currentSort,
  };
};
  
const mapDispatchToProps = (dispatch) => {
  return {
    changeSort: (pNewSortValue: string) => {
      dispatch(SortActions.changeSort(pNewSortValue));
    },
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(SortViewController);
