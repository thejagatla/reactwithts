/**
 * Class description: React/Redux linker class
 * @author Capgemini
 * @version 1.0
 */
import { connect } from 'react-redux';
import { FiltersPanelViewController } from '../../../components/common/filters/FiltersPanelViewController';
import { FleetsweepFilter } from '../../../model/fleetsweep/FleetsweepInterfaces';
import * as FilterActions from '../../actions/FiltersActions';

const mapStateToProps = (state, ownProps) => {
  return {
    state: {
      customizeTab: state.filtersReducer.customizeTab,
      filters: state.filtersReducer.filters,
      filtersVisible: state.filtersReducer.filtersVisible,
      moreFilters: state.filtersReducer.moreFilters,
      period: state.filtersReducer.period,
      selectedTabId: state.filtersReducer.selectedTabId,
      tabs: state.filtersReducer.tabs
    }
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    setActiveTab: (activeTab) => {
      dispatch(FilterActions.setActiveTab(activeTab));
    },
    setFilters: (filters) => {
      dispatch(FilterActions.setFilters(filters));
    },
    setFleetsweepState: (newState) => {
      dispatch(FilterActions.setFleetsweepState(newState));
    },
    setMoreFilters: (pMoreFilters: FleetsweepFilter[]) => {
      dispatch(FilterActions.setMoreFilters(pMoreFilters));
    },
    setPeriod: (period) => {
      dispatch(FilterActions.setPeriod(period));
    },
    setToggleFiltersVisibility: (visibility) => {
      dispatch(FilterActions.setToggleFiltersVisibility(visibility));
    }
  };
};

const FiltersContainer: any = connect(
  mapStateToProps,
  mapDispatchToProps
)(FiltersPanelViewController);

export default FiltersContainer;
