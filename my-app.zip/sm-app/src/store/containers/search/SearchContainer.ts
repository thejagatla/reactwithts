/**
 * Class description: React/Redux linker class
 * @author Capgemini
 * @version 1.0
 */
import { connect } from 'react-redux';
import { SearchViewController } from '../../../components/common/search/SearchViewController';
import * as EventActions from '../../actions/EventsActions';

const mapStateToProps = state => {
  return {
    searchText: state.eventReducer.searchText,
    totalEvents: state.eventReducer.totalEvents
  };
};

const mapDispatchToProps = dispatch => {
  return {
    setSearchText: text => {
      dispatch(EventActions.setSearchText(text));
    }
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(SearchViewController);
