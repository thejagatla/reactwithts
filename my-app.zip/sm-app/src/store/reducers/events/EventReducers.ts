/**
 * Class description: Events reducer
 * @author Capgemini
 * @version 1.0
 */

import * as types from '../../actions/EventsActions';

const pLocalEvents = localStorage.getItem('localEvents');
let pLocalEventsArray = [];
const pLocalEventsHashKeys = [];
if (pLocalEvents) {
  pLocalEventsArray = JSON.parse(pLocalEvents);
  pLocalEventsArray.forEach((localEvent: any) => {
    pLocalEventsHashKeys.push(localEvent.hashKey);
  });
}

const initialState = {
  apiRequestId: 0,
  autosizerHeight: 0,
  events: [],
  firstRequestProcessed: false,
  from: 0,
  isFetching: false,
  lastRequestError: false,
  listRef: '',
  loadedRowsMap: {},
  localEvents: pLocalEventsArray,
  localEventsHashKeys: pLocalEventsHashKeys,
  minimumBatchSize: 60,
  numberLoaded: 0,
  pageSize: 60,
  pollingDelay: 4000,
  rowHeight: 118,
  searchText: '',
  size: 60,
  timeoutId: -1,
  totalEvents: 0
};

/**
 * Events reducer
 * @param state app state
 * @param action action trigger
 */
const EventReducers = (state = initialState, action) => {
  switch (action.type) {
    case types.REQUESTEVENTS:
      return {
        ...state,
        apiRequestId: state.apiRequestId + 1,
        isFetching: true
      };

    case types.SAVENEWINTERVALS:
      return {
        ...state,
        from: action.from,
        size: action.size
      };

    case types.SAVELOCALEVENTS:   
      localStorage.setItem('localEvents', JSON.stringify(action.localEvents));
      
      return {
        ...state,
        localEvents: action.localEvents,
        localEventsHashKeys: action.localEventsHashKeys
      };

    case types.SETAUTOSIZERHEIGHT:
      return {
        ...state,
        autosizerHeight: action.height
      };

    case types.SETITIMEOUTID:
      return {
        ...state,
        timeoutId: action.timeoutId
      };

    case types.SETLISTREF:
      return {
        ...state,
        listRef: action.listRef
      };

    case types.RECEIVEEVENTS:
      return {
        ...state,
        events: action.eventsList,
        firstRequestProcessed: true,
        from: action.from,
        isFetching: false,
        lastRequestError: false,
        numberLoaded: action.eventsList.length,
        pollingDelay: action.pollingDelay,
        size: action.size,
        totalEvents: action.totalEvents,
      };

    case types.LOADINGEVENTS:
      return {
        ...state,
        loadedRowsMap: action.loadedRowsMap
      };

    case types.SAVESEARCHTEXT:
      return {
        ...state,
        searchText: action.searchText
      };

    case types.RESTOREDEFAULTSTATE:
      return {
        ...state,
        apiRequestId: 0,
        events: [],
        firstRequestProcessed: false,
        from: 0,
        loadedRowsMap: {},
        numberLoaded: 0,
        size: 0,
        totalEvents: 0
      };

    case types.RESTOREINFINITELOADER:
      return {
        ...state,
        from: 0,
        loadedRowsMap: {},
        numberLoaded: 0,
        size: 60
      };

    case types.FINISHEDFETCHING:
      return {
        ...state,
        isFetching: false, 
        lastRequestError: action.error
      };

    default:
      return state;
  }
};

export default EventReducers;
