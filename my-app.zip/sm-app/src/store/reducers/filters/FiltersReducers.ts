/**
 * Class description: Filters reducer
 * @author Capgemini
 * @version 1.0
 */
import * as fleetsweepfilters from '../../../resources/fleetsweepFilters.json';
import * as morefilters from '../../../resources/moreFilters.json';
import * as types from '../../actions/FiltersActions';

const initialState = {
  customizeTab: false,
  filters: fleetsweepfilters.tabs[0].filters,
  filtersVisible: true,
  moreFilters: morefilters.filters,
  period: -1,
  selectedTabId: 0,
  tabs: fleetsweepfilters.tabs
};

/**
 * Events reducer
 * @param state app state
 * @param action action trigger
 */
const FilterReducers = (state = initialState, action) => {
  switch (action.type) {
    case types.SETACTIVETAB:
      return {
        ...state,
        selectedTabId: action.selectedTabId,
      };
    case types.SETFILTERS:
      return {
        ...state,
        filters: action.filters,
      };
    case types.SETFLEETSWEEPSTATE:
      return {
        ...state,
        customizeTab: action.customizeTab,
        selectedTabId: action.selectedTabId,
        tabs: action.tabs,
      };
    case types.SETPERIOD:
      return {
        ...state,
        period: action.period,
      };
    case types.TOGGLEFILTERSVISIBILITY:
      return {
        ...state,
        filtersVisible: action.filtersVisible
      };
    case types.SETMOREFILTERS:
      return {
        ...state,
        moreFilters: action.moreFilters
      };
    default:
      return state;
  }
};

export default FilterReducers;
