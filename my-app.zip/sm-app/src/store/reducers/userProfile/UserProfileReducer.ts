import * as types from '../../actions/LoginActions';

const initialState = {
  airlineProfile: {
    displayName: '',
    tsmLink: {
      prefixe: '',
      suffixe: ''
    }
  },
  airlines: [],
  allowedActions: [],
  mainCompany: '',
  requestDone: false
};

/**
 * User profile reducer
 * @param state app state
 * @param action action trigger
 */
const UserProfileReducer = (state = initialState, action) => {
  if (action.type === types.SAVEUSERPROFILE) {
    return {
      ...state,
      airlines: action.airlines,
      allowedActions: action.actions,
      displayName: action.airlineProfile.displayName,
      mainCompany: action.mainCompany,
      tsmLink: action.airlineProfile.tsmLink
    };
  }

  if (action.type === types.REQUESTDONE) {
    return {
      ...state,
      requestDone: true
    };
  }

  return state;
};

export default UserProfileReducer;
