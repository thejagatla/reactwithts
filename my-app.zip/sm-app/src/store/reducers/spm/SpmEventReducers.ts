import { SpmEvent } from '../../../model/spm/SpmEvent';
import { SpmStatusInfoItem } from '../../../model/spm/SpmStatusInfoItem';
import * as types from '../../actions/spm/SpmActionsTypes';

/* tslint:disable */

const initialState = {
  chart: [],
  chartLoaded: false,
  chartLoadingError: false,
  chartLoadingErrorCode: null,
  commentsHistory: [],
  event: {},
  eventDetailsDisplay: {},
  statusHistory: [],
  eventId: null,
  eventItems: [],
  eventLoaded: false,
  eventLoadingError: false,
  eventLoadingErrorCode: null,
  lastEventItemLoadingError: false,
  loadEventException: {},
  loadChartException: {},
  maintenanceAdvices: null,
  description: null
};

/**
 * Concat status history array and event current status
 * @param event Current event
 * @param statusHistory Current event status history
 */
function setStatusHistory(event: SpmEvent, statusHistory: SpmStatusInfoItem[]) {
  const completeStatusHistory = statusHistory;
  completeStatusHistory.unshift(event.statusInfoItem);

  return completeStatusHistory;
}

/**
 * Modify app Redux state according to the called action
 * @param state Component state
 * @param action Action called
 */
const SpmEventReducers = (state = initialState, action: any) => {
  switch (action.type) {
    case types.LOADEVENTSUCCESS:
      return {
        ...state,
        commentsHistory: action.event.commentsHistory,
        event: action.event.event,
        eventDetailsDisplay: action.event.eventDetailsDisplay,
        statusHistory: setStatusHistory(
          action.event.event,
          action.event.statusHistory
        ),
        eventLoaded: true,
        eventLoadingError: false,
        eventLoadingErrorCode: null,
        maintenanceAdvices: action.event.maintenanceAdvices,
        description: action.event.description
      };
    case types.LOADEVENTERROR:
      return {
        ...state,
        event: {},
        eventLoaded: true,
        eventLoadingError: true,
        eventLoadingErrorCode: action.code,
        loadEventException: action.exception.exception
      };
    case types.CLEAREVENT:
      return {
        ...state,
        chart: [],
        chartLoaded: false,
        chartLoadingError: false,
        chartLoadingErrorCode: null,
        commentsHistory: [],
        event: {},
        eventDetailsDisplay: {},
        statusHistory: [],
        eventId: null,
        eventItems: [],
        eventLoaded: false,
        eventLoadingError: false,
        eventLoadingErrorCode: null,
        lastEventItemLoadingError: false,
        loadEventException: {},
        loadChartException: {},
        maintenanceAdvices: null,
        description: null
      };
    case types.LOADCHARTSUCCESS:
      return {
        ...state,
        chart: action.chart,
        chartLoaded: true,
        chartLoadingError: false,
        chartLoadingErrorCode: null
      };
    case types.LOADCHARTERROR:
      return {
        ...state,
        chart: [],
        chartLoaded: true,
        chartLoadingError: true,
        chartLoadingErrorCode: action.code,
        loadChartException: action.exception.exception
      };
    case types.LOADEVENTITEMSUCCESS:
      return {
        ...state,
        eventItems: [...state.eventItems, action.eventItem],
        lastEventItemLoadingError: false
      };
    case types.LOADEVENTITEMERROR:
      return {
        ...state,
        lastEventItemLoadingError: true
      };
    case types.ADDWORKFLOWHISTORYITEM:
      return {
        ...state,
        statusHistory: [action.item, ...state.statusHistory]
      };
    default:
      return state;
  }
};

export default SpmEventReducers;
