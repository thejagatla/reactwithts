import * as types from '../../actions/spm/SpmActionsTypes';

const initialState = {
  exception : null,
  filtersVisible: true,
  fleetsInfos: [],
  fleetsInfosLoaded: false,
};

/**
 * Modify app Redux state according to the called action
 * @param state Component state
 * @param action Action called
 */
const SpmModelTrendsReducer = (state = initialState, action: any) => {
  switch (action.type) {
    case types.LOADFILTERSSUCCESS:
      return {
        ...state,
        fleetsInfos: action.fleetsInfos,
        fleetsInfosLoaded: true
      };
    case types.LOADFILTERSERROR:
      return {
        ...state,
        exception: action.exception,
        fleetsInfosLoaded: true
      };
    case types.TOGGLEFILTERSVISIBILITY:
      return {
        ...state,
        filtersVisible: action.filtersVisible
      };
    default: 
      return state;
  }
};

export default SpmModelTrendsReducer;
