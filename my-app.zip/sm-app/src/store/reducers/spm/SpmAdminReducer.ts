import * as types from '../../actions/spm/SpmActionsTypes';

const initialState = {
  ataForSelectedAirline: [],
  exception: null,
  icaos: [],
  icaosLoaded: false,
  loadingModelsException: null,
  modelsForSelectedAirline: [],
  modelsLoading: false,
};

/**
 * Modify app Redux state according to the called action
 * @param state Component state
 * @param action Action called
 */
const SpmAdminReducer = (state = initialState, action: any) => {
  switch (action.type) {
    case types.LOADAIRLINESERROR:
      return {
        ...state,
        exception: action.exception,
        icaosLoaded: true
      };
    case types.LOADAIRLINESSUCCESS:
      return {
        ...state,
        icaos: action.icaos,
        icaosLoaded: true
      };
    case types.LOADMODELSSUCCESS:
      return {
        ...state,
        ataForSelectedAirline: action.atas,
        modelsForSelectedAirline: action.models,
        modelsLoading: false,
      };
    case types.LOADMODELSERROR:
      return {
        ...state,
        loadingModelsException: action.exception,
        modelsLoading: false
      };
    case types.MODELSLOADING:
      return {
        ...state,
        modelsLoading: true
      };
    default: 
      return state;
  }
};

export default SpmAdminReducer;
