/**
 * Class description: Sort reducer
 * @author Capgemini
 * @version 1.0
 */
import { SortValuesEnum } from '../../../model/sort/SortConstantes';
import * as types from '../../actions/SortActions';

const initialState = {
  currentSort: SortValuesEnum[SortValuesEnum.DATE_TIME]
};

/**
 * Sort reducer
 * @param state app state
 * @param action action trigger
 */
const SortReducer = (state = initialState, action) => {
  if (action.type === types.CHANGESORT) {
    return {
      ...state,
      currentSort: action.newSortValue,
    };
  }

  return state;
};

export default SortReducer;
