import * as types from '../../actions/RibbonActions';

const initialState = {
  visibilityPanel: false
};

/**
 * Ribbon reducer
 * @param state Ribbon state
 * @param action action trigger
 */
const RibbonReducer = (state = initialState, action) => {
  if (action.type === types.VISIBILITYCOMPONENTPANEL) {
    return {
      ...state,
      visibilityPanel: action.newVisibilityPanel
    };
  }

  return state;
};

export default RibbonReducer;
