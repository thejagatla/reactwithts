/**
 * Class description: Event Details reducer
 * @author Capgemini
 * @version 1.0
 */

import * as types from '../actions/LoginActions';

const initialState = {
  auth: null,
  state: types.ONELOGIN_LOGGED_OUT,
  username: null
};

/**
 * OneLogin reducer
 * @param state app state
 * @param action action trigger
 */
const OneLoginReducer = (state = initialState, action) => {
  switch (action.type) {
    case types.ONELOGIN_LOGGED_OUT:
    case types.ONELOGIN_LOGGIN_OUT:
      return {
        ...state,
        auth: null,
        state: action.type,
        username: null
      };
    case types.ONELOGIN_LOGGED_IN:
      return {
        ...state,
        state: action.type,
        username: action.username
      };
    case types.ONELOGIN_LOGGIN_IN:
      if (state.state !== types.ONELOGIN_LOGGED_IN || !state.auth) {
        return {
          ...state,
          auth: action.authData,
          state: action.type
        };
      }
      return state;
    default:
      return state;
  }
};

export default OneLoginReducer;
