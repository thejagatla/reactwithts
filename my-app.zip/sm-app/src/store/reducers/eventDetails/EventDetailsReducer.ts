/**
 * Class description: Event Details reducer
 * @author Capgemini
 * @version 1.0
 */
import * as types from '../../actions/EventDetailsActions';

const initialState = {
  correlatedEvents: [],
  correlatedEventsLoaded: false,
  esTaskRefList: [],
  event: {},
  eventLoadingError: false,
  loadingCorrelation: true,
  loadingMmel: true,
  misData: {},
  misDataLoaded: false,
  tsmCorrelationMessage: ''
};

/**
 * Events reducer
 * @param state app state
 * @param action action trigger
 */
const EventDetailsReducers = (state = initialState, action) => {
  switch (action.type) {
    case types.SETTASKREFLIST:
      return {
        ...state,
        esTaskRefList: action.finalList
      };

    case types.SETFAULTCASELINKS:
      return {
        ...state,
        correlatedLinksList: action.correlatedLinks
      };

    case types.CLEAREVENT:
      return {
        ...state,
        correlatedEvents: [],
        correlatedEventsLoaded: false,
        esTaskRefList: [],
        event: {},
        eventLoadingError: false,
        loadingCorrelation: true,
        loadingMmel: true,
        misData: {},
        misDataLoaded: false,
        tsmCorrelationMessage: ''
      };

    case types.LOADCORRELATEDEVENTSSUCCESS:
      return {
        ...state,
        correlatedEvents: action.correlatedEvents,
        correlatedEventsLoaded: true,
        loadingCorrelation: false
      };

    case types.SETCORRELATIONERROR:
      return {
        ...state,
        loadingCorrelation: false,
        tsmCorrelationMessage: action.error
      };

    case types.CORRELATIONREQUESTERROR:
      return {
        ...state,
        loadingCorrelation: false
      };

    case types.LOADEVENTERROR:
      return {
        ...state,
        event: {},
        eventLoadingError: true
      };

    case types.LOADMISDATA:
      return {
        ...state,
        misData: action.misData,
        misDataLoaded: true
      };

    default:
      return state;
  }
};

export default EventDetailsReducers;
