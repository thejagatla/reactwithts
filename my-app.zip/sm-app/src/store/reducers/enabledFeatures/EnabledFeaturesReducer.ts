import * as types from '../../actions/LoginActions';

const initialState = {
  enabledFeatures: []
};

/**
 * Enabled features reducer
 * @param state app state
 * @param action action trigger
 */
const EnabledFeaturesReducer = (state = initialState, action) => {
  if (action.type === types.SAVEENABLEDFEATURES) {
    return {
      ...state,
      enabledFeatures: action.enabledFeatures
    };
  }

  return state;
};

export default EnabledFeaturesReducer;
