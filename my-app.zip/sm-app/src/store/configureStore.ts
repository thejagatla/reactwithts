/**
 * Class description: Redux store initialization
 * @author Capgemini
 * @version 1.0
 */
import { cognito } from 'react-cognito';
import { applyMiddleware, combineReducers, createStore } from 'redux';
import { persistReducer, persistStore } from 'redux-persist';
import autoMergeLevel1 from 'redux-persist/lib/stateReconciler/autoMergeLevel1';
import autoMergeLevel2 from 'redux-persist/lib/stateReconciler/autoMergeLevel2';
import storage from 'redux-persist/lib/storage';
import reduxThunk from 'redux-thunk';
import EnabledFeaturesReducer from './reducers/enabledFeatures/EnabledFeaturesReducer';
import EventDetailsReducer from './reducers/eventDetails/EventDetailsReducer';
import EventReducers from './reducers/events/EventReducers';
import FiltersReducers from './reducers/filters/FiltersReducers';
import OneLoginReducer from './reducers/OneLoginReducer';
import RibbonReducer from './reducers/ribbon/RibbonReducer';
import SortReducer from './reducers/sort/SortReducer';
import SpmAdminReducer from './reducers/spm/SpmAdminReducer';
import SpmEventReducers from './reducers/spm/SpmEventReducers';
import SpmModelTrendsReducer from './reducers/spm/SpmModelTrendsReducer';
import UserProfileReducer from './reducers/userProfile/UserProfileReducer';

const lStorage = storage;

const persistUserProfileConfig = {
  key: 'userProfile',
  stateReconcilier: autoMergeLevel1,
  storage: lStorage
};

const persistEnabledFeaturesReducerConfig = {
  key: 'enabledFeaturesReducer',
  stateReconcilier: autoMergeLevel1,
  storage: lStorage
};

const persistOneLoginConfig = {
  key: 'onelogin',
  stateReconcilier: autoMergeLevel1,
  storage: lStorage
};

const persistCognitoConfig = {
  key: 'cognito',
  stateReconcilier: autoMergeLevel1,
  storage: lStorage,
  whitelist: ['state', 'user']
};

const persistFiltersConfig = {
  key: 'filtersReducer',
  stateReconcilier: autoMergeLevel2,
  storage: lStorage
};

const persistSortConfig = {
  key: 'sortReducer',
  storage: lStorage
};

/**
 * Combine reducers
 */
const rootReducer = combineReducers({
  cognito: persistReducer(persistCognitoConfig, cognito),
  enabledFeaturesReducer: persistReducer(
    persistEnabledFeaturesReducerConfig,
    EnabledFeaturesReducer
  ),
  eventDetailsReducer: EventDetailsReducer,
  eventReducer: EventReducers,
  filtersReducer: persistReducer(persistFiltersConfig, FiltersReducers),
  onelogin: persistReducer(persistOneLoginConfig, OneLoginReducer),
  ribbonReducer: RibbonReducer,
  sortReducer: persistReducer(persistSortConfig, SortReducer),
  spmAdminReducer: SpmAdminReducer,
  spmEventReducer: SpmEventReducers,
  spmModelTrendsReducer: SpmModelTrendsReducer,
  userProfile: persistReducer(persistUserProfileConfig, UserProfileReducer)
});

/**
 * Configure store
 */
function configureStore() {
  return createStore(rootReducer, applyMiddleware(reduxThunk));
}

export const store = configureStore();
export const persistor = persistStore(store);
