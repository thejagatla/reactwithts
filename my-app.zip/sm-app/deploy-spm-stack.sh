#!/bin/bash
read -p 'Environment to deploy: ' -n 10 STAGE

echo '----------------------------------------------------'
echo 'Start of deployment on: ' $STAGE
echo '----------------------------------------------------'

echo '----------------------------------------------------'
echo '------------------- BUILDING APP -------------------'
echo '----------------------------------------------------'
#build
rm -rf node_modules/ client/dist/
yarn
node_modules/.bin/grunt build

echo '-----------------------------------------------------'
echo '------------------- DEPLOYING APP -------------------'
echo '-----------------------------------------------------'
# then deploy
export SPM_API_EVENTS_ID=tqov4d8bhg
export SPM_API_EVENT_ITEMS_ID=efzk65hiqb
export SPM_APIS_ORIGIN_PATH=$STAGE
rm -rf client
mkdir client
mv build client/dist
node scripts/update_cognito_config.js $STAGE
npm i --no-save serverless-finch
sls client deploy --stage $STAGE
sls deploy --force --stage $STAGE

echo '------------------------------------------------------'
echo '---------------- REINIT LOCAL DEV ENV ----------------'
echo '------------------------------------------------------'
rm -rf node_modules/
yarn
