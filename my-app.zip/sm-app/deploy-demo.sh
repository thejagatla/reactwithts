#!/bin/bash

export STAGE=o1122
#build
rm -rf node_modules/ client/dist/
yarn
node_modules/.bin/grunt build
# then deploy
export SPM_API_EVENTS_ID=twu3o19z5l
export SPM_API_EVENT_ITEMS_ID=vxjoybgcp4
export SPM_APIS_ORIGIN_PATH=demo
rm -rf client
mkdir client
mv build client/dist
node scripts/update_cognito_config.js $STAGE
yarn add serverless-finch
sls client deploy --stage $STAGE
sls deploy --force --stage $STAGE
