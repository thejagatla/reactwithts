import * as React from 'react';
import { Route, Switch } from 'react-router';
import { BrowserRouter as Router } from 'react-router-dom';
import Base from './Base';
import Risks from './Risks';

export const App = (props: any) => {
  return (
    <Router>
      <Switch>
        <Route path="/" component={Base} exact />
        <Route path="/risks" component={Risks} />
      </Switch>
    </Router>
  );
};

export default App;
