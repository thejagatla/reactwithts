import * as React from 'react';

export const Base = (props: any) => {
  return <h1>Base</h1>;
};

export default Base;
