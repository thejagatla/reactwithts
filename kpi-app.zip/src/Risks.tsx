import * as React from 'react';

export const Risks = (props: any) => {
  return <h1>Risks</h1>;
};

export default Risks;
